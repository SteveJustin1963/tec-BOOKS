/*****************************************************************************/
/* XC FLASHER                                                                */
/* rs232.h : handler for rs232 serial interface access                       */
/*****************************************************************************/
/* program, erase, protect, unprotect and test flashes                       */
/* for the c167, xc167 microcontroller family                                */
/*                                                                           */
/* (c) 2003 by Infineon                                                      */
/* Christian Perschl                                                         */
/*****************************************************************************/

#include "stdafx.h"

#if !defined(RS232_H_INCLUDED)
#define RS232_H_INCLUDED


struct t_rs232settings
{
	char comport[6];
	unsigned long baudrate;
	int parity;
	int databits;
	int stopbits;
	int timeout;
};


int rs232_init(t_rs232settings *settings);
void rs232_send(unsigned char *buffer,unsigned int length);
int rs232_receive(unsigned char *buffer, unsigned int length);
int rs232_receiveblocked(unsigned char *buffer, unsigned int length);
void rs232_sendchar(unsigned char ch);
int rs232_receivechar(void);
int rs232_open();
void rs232_close();
int rs232_statusmessage(void);
void rs232_purge(void);

VOID CALLBACK rs232_writecomplete(DWORD dwErrorCode, DWORD dwNumberOfBytesTransfered, LPOVERLAPPED lpOverlapped);
VOID CALLBACK rs232_readcomplete(DWORD dwErrorCode, DWORD dwNumberOfBytesTransfered, LPOVERLAPPED lpOverlapped);


#endif