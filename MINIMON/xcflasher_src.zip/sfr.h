/*****************************************************************************/
/* XC FLASHER                                                                */
/* sfr.h : sfr definitions and functions                                     */
/*****************************************************************************/
/* program, erase, protect, unprotect and test flashes                       */
/* for the c167, xc167 microcontroller family                                */
/*                                                                           */
/* (c) 2003 by Infineon                                                      */
/* Christian Perschl                                                         */
/*****************************************************************************/


#if !defined(SFR_H_INCLUDED)
#define SFR_H_INCLUDED

#define MAXSFR 128
#define MAXSFRNAMELENGTH 32

void sfr_init(void);
unsigned long sfr_getaddress(char *sfrname);
int sfr_exists(char *sfrname);


struct t_sfr
{
	char name[MAXSFRNAMELENGTH];
	unsigned long address;
};

#endif
