/*****************************************************************************/
/* XC FLASHER                                                                */
/* ihex.cpp : intel hex file functions                                       */
/*****************************************************************************/
/* program, erase, protect, unprotect and test flashes                       */
/* for the c167, xc167 microcontroller family                                */
/*                                                                           */
/* (c) 2003 by Infineon                                                      */
/* Christian Perschl                                                         */
/*****************************************************************************/

#include "stdafx.h"
#include "ihex.h"
#include "mem.h"
#include "misc.h"
#include "log.h"
#include <stdio.h>
#include "common.h"


/*****************************************************************************/
/* ihex_read                                                                 */
/*---------------------------------------------------------------------------*/
/* reads an intel hex file into buffer                                       */
/*****************************************************************************/
int ihex_read(char *filename)
{
	FILE *fp;
	char line[255];
	t_hexrec ihrec;
	unsigned long upper16address=0;
	int result = 0;
	int reccounter = 0;

	if ((fp  = fopen(xcflasher_extendfullpath(filename),"r")) == NULL)
		result = -1;
	else
	{
		while ((fgets(line,255,fp)!=NULL) && (!result))
		{

			eliminatespaces(line);
			result = ihex_readrecord(line,&ihrec);
			if (!result)
			{
				switch (ihrec.type)
				{
					case IHEX_DATAREC:
						mem_write(upper16address+ihrec.offset,ihrec.length,ihrec.data);
						mem_addselection(upper16address+ihrec.offset,ihrec.length);
					break;
					case IHEX_ENDREC:
						// end of file reached
					break;
					case IHEX_SEGREC:
						upper16address = (((unsigned long) ihrec.data[0])*0x100+(unsigned long) ihrec.data[1]) << 4;
					break;
					case IHEX_SEGREC32:
						upper16address = (((unsigned long) ihrec.data[0])*0x100+(unsigned long) ihrec.data[1]) << 16;
					break;
					default:
						// wrong record type: ignore
					break;
				}
				reccounter++;
			}
		}

		fclose(fp);	
	}

	mem_optimizeselections();

	return result;
}


/*****************************************************************************/
/* ihex_readrecord                                                           */
/*---------------------------------------------------------------------------*/
/* reads an intel hex record into t_hexrec structure                         */
/*****************************************************************************/
int ihex_readrecord(char *string, t_hexrec *rec)
{
	unsigned int i = 0;
	unsigned char currentchar[128];
	unsigned char currentchar_counter = 0;

	// look for leading ":"
	while ((i<strlen(string)) && (string[i++]!=':'));


	if (i<strlen(string))
	{
		while (i<strlen(string))
		{
			sscanf(&string[i],"%02X",&currentchar[currentchar_counter++]);
			i=i+2;
		}
	}

	// check if at least 6 characters are available
	if (currentchar_counter<5)
		return 1;

	rec->length = currentchar[0];
	rec->offset = ((unsigned int) currentchar[1])*0x100+(unsigned int) currentchar[2];
	rec->type = currentchar[3];
	rec->checkSum = currentchar[rec->length+4];

	// check if record length fits with availiable data
	if (currentchar_counter-5!=rec->length)
		return 2;

	memcpy(rec->data,&currentchar[4],rec->length);

	return ihex_verifyrecordchecksum(rec);
}


/*****************************************************************************/
/* ihex_verifyrecordchecksum                                                 */
/*---------------------------------------------------------------------------*/
/* checks if the record checksum of an intel hex record is ok                */
/*****************************************************************************/
int ihex_verifyrecordchecksum(t_hexrec *rec)
{
	unsigned int i = 0;
	unsigned int cs;


	cs =rec->length;
	cs+=(rec->offset & 0x00FF);
	cs+=(rec->offset >> 8) & 0x00FF;
	cs+=rec->type;
	for (i=0;i<rec->length;i++)
		cs+= rec->data[i];
	cs = cs & 0x00FF;
	cs = 0x100 - cs;
	cs = cs & 0x00FF;

	if (rec->checkSum == cs)
		return 0;
	else
		return 1;

}



