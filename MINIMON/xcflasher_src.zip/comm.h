/*****************************************************************************/
/* XC FLASHER                                                                */
/* comm.h : the communication interface to the target                        */
/*****************************************************************************/
/* program, erase, protect, unprotect and test flashes                       */
/* for the c167, xc167 microcontroller family                                */
/*                                                                           */
/* (c) 2003 by Infineon                                                      */
/* Christian Perschl                                                         */
/*****************************************************************************/

#include "stdafx.h"

#if !defined(COMM_H_INCLUDED)
#define COMM_H_INCLUDED


#define COMM_WRITEWORD  0x82
#define COMM_WRITEBLOCK 0x84
#define COMM_READBLOCK  0x85
#define COMM_CALL       0x9F
#define COMM_GO         0x41
#define COMM_EINIT      0x31
#define COMM_SRST       0x32
#define COMM_CHECKSUM   0x33
#define COMM_TEST       0x93

#define COMM_LOADERACK  0x01
#define COMM_MINIMONACK 0x03
#define COMM_ACK1       0xAA
#define COMM_ACK2       0xEA

#define COMM_NOTCONNECTED       0x00
#define COMM_CONNECTED	        0x01
#define COMM_USERPROGRAMRUNNING 0x02

void comm_init(void);
int comm_connect(char *loaderfilename,char *minimonfilename);
int comm_writeword(unsigned long address, unsigned int data);
int comm_write(unsigned long address, unsigned int length, unsigned char *data);
int comm_read(unsigned long address, unsigned int length, unsigned char *data);
int comm_call(unsigned long address, unsigned short *parameters, unsigned short *responseparameters);
int comm_test(void);
int comm_getchecksum(unsigned int *checksum);
int comm_einit(void);
int comm_srst(void);
int comm_go(unsigned long address);
int comm_bringup(void);
int comm_initregs(void);

#endif