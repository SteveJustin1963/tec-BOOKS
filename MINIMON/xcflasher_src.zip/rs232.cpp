/*****************************************************************************/
/* XC FLASHER                                                                */
/* rs232.cpp : handler for rs232 serial interface access                     */
/*****************************************************************************/
/* program, erase, protect, unprotect and test flashes                       */
/* for the c167, xc167 microcontroller family                                */
/*                                                                           */
/* (c) 2003 by Infineon                                                      */
/* Christian Perschl                                                         */
/*****************************************************************************/

#include "stdafx.h"
#include "rs232.h"
#include "log.h"
#include <stdio.h>
#include "common.h"

HANDLE rs232_handle;
DCB rs232_dcb;
COMMTIMEOUTS rs232_cto;
OVERLAPPED rs232_ol;
unsigned long rs232_totalreadbytes;
unsigned long rs232_totalwritebytes;
int rs232_combuf[256];
t_rs232settings rs232_settings;

unsigned long rs232_error;
struct _COMSTAT rs232_comstat;


/*****************************************************************************/
/* rs232_init                                                                */
/*---------------------------------------------------------------------------*/
/* initializes and clears rs232 module                                       */
/*****************************************************************************/
int rs232_init(t_rs232settings *settings)
{

	rs232_settings.baudrate = settings->baudrate;
	strcpy(rs232_settings.comport,settings->comport);
	rs232_settings.databits = settings->databits;
	rs232_settings.parity = settings->parity;
	rs232_settings.stopbits = settings->stopbits;
	rs232_settings.timeout = settings->timeout;

	
	rs232_handle = CreateFile( rs232_settings.comport, GENERIC_READ | GENERIC_WRITE,
                  0,                    // exclusive access
                  NULL,                 // no security attrs
                  OPEN_EXISTING,
                  FILE_ATTRIBUTE_NORMAL,
				  NULL );
	
	if (rs232_handle == INVALID_HANDLE_VALUE)
	{
		return 1;
	}
	else
	{

    
		GetCommTimeouts(rs232_handle, &rs232_cto);
		GetCommState(rs232_handle, &rs232_dcb);

		memset(&rs232_ol,0,sizeof(rs232_ol));

		switch (rs232_settings.baudrate)
		{
			case  9600: rs232_dcb.BaudRate = CBR_9600;
			break;
			case 19200: rs232_dcb.BaudRate = CBR_19200;
			break;
			case 38400: rs232_dcb.BaudRate = CBR_38400;
			break;
			case 57600: rs232_dcb.BaudRate = CBR_57600;
			break;
			default:
				rs232_dcb.BaudRate = CBR_19200;
		}

		switch (rs232_settings.parity)
		{
			case 0: rs232_dcb.Parity = NOPARITY;
			break;
			case 1: rs232_dcb.Parity = EVENPARITY;
			break;
			case 2: rs232_dcb.Parity= ODDPARITY;
			break;
			default:
				rs232_dcb.Parity = NOPARITY;
		}

		switch (rs232_settings.stopbits)
		{
			case 1: rs232_dcb.StopBits = ONESTOPBIT;
			break;
			case 2: rs232_dcb.StopBits = TWOSTOPBITS;
			break;
			default:
				rs232_dcb.StopBits = ONESTOPBIT;
		}

		char temp[255];
		sprintf(temp,"Baudrate=%ld Parity=%d",rs232_dcb.BaudRate,rs232_dcb.Parity);
		log_write(MODULE_PREFS,temp);

		rs232_dcb.fDtrControl = DTR_CONTROL_DISABLE;
		rs232_dcb.fRtsControl = RTS_CONTROL_DISABLE;
		
		rs232_dcb.fOutxCtsFlow = FALSE;      // CTS output flow control 
		rs232_dcb.fOutxDsrFlow = FALSE;      // DSR output flow control 
		rs232_dcb.fDtrControl= FALSE;       // DTR flow control type 
		rs232_dcb.fDsrSensitivity= FALSE;   // DSR sensitivity 
		rs232_dcb.fTXContinueOnXoff= FALSE; // XOFF continues Tx 
		rs232_dcb.fOutX = FALSE;
		rs232_dcb.fInX = FALSE;
		rs232_dcb.fBinary = TRUE;
		rs232_dcb.ByteSize = 8;
	
		rs232_cto.ReadTotalTimeoutConstant = rs232_settings.timeout; //rs232_settings.timeout;
		rs232_cto.ReadTotalTimeoutMultiplier = MAXDWORD ; 
		rs232_cto.ReadIntervalTimeout = MAXDWORD ;
		rs232_cto.WriteTotalTimeoutConstant = 10000;
		rs232_cto.WriteTotalTimeoutMultiplier = 1;

		SetCommTimeouts(rs232_handle, &rs232_cto);
		SetCommState(rs232_handle, &rs232_dcb);
			
		ClearCommError(rs232_handle,&rs232_error,&rs232_comstat);

		if (rs232_comstat.cbInQue>0)
		{
			ReadFile(rs232_handle,rs232_combuf,rs232_comstat.cbInQue,&rs232_totalreadbytes, &rs232_ol);
			rs232_statusmessage();
		}

		CancelIo(rs232_handle);
		CloseHandle(rs232_handle);

		return 0;
	}


}

/*****************************************************************************/
/* rs232_open                                                                */
/*---------------------------------------------------------------------------*/
/* opens the rs232 interface                                                 */
/*****************************************************************************/
int rs232_open()
{
	int result;
	
	memset(&rs232_ol,0,sizeof(rs232_ol));
	
	rs232_handle = CreateFile( rs232_settings.comport, GENERIC_READ | GENERIC_WRITE,
                  0,                    // exclusive access
                  NULL,                 // no security attrs
                  OPEN_EXISTING,
                  FILE_ATTRIBUTE_NORMAL, // overlapped I/O
				  NULL );


	if (rs232_handle == INVALID_HANDLE_VALUE)
	{
		return 1;
	}
	else
	{
		result = SetCommTimeouts(rs232_handle, &rs232_cto);
		if (result==0)
			return 2;
		
		result = SetCommState(rs232_handle, &rs232_dcb);
		if (result==0)
			return 3;

		result = ClearCommError(rs232_handle,&rs232_error,&rs232_comstat);
		if (result==0)
			return 4;

		result = SetupComm(rs232_handle,1024,1024);
		if (result==0)
			return 5;

		result = PurgeComm(rs232_handle,PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR);
		if (result==0)
			return 6;	

	}
	return 0;

}


/*****************************************************************************/
/* rs232_close                                                               */
/*---------------------------------------------------------------------------*/
/* closes the rs232 interface                                                */
/*****************************************************************************/
void rs232_close(void)
{

	ClearCommError(rs232_handle,&rs232_error,&rs232_comstat);
	CancelIo(rs232_handle);
	CloseHandle(rs232_handle);

}

/*****************************************************************************/
/* rs232_purge                                                               */
/*---------------------------------------------------------------------------*/
/* purges all pending communication on the rs232 interface                   */
/*****************************************************************************/
void rs232_purge(void)
{
	PurgeComm(rs232_handle,PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR);
	CancelIo(rs232_handle);
	ClearCommError(rs232_handle,&rs232_error,&rs232_comstat);
}


/*****************************************************************************/
/* rs232_send                                                                */
/*---------------------------------------------------------------------------*/
/* sends a data block to rs232                                               */
/*****************************************************************************/
void rs232_send(unsigned char *buffer,unsigned int length)
{
	WriteFile(rs232_handle,buffer,length,&rs232_totalwritebytes, &rs232_ol);
}

/*****************************************************************************/
/* rs232_receive                                                             */
/*---------------------------------------------------------------------------*/
/* receives a datablock, times out                                           */
/*****************************************************************************/
int rs232_receive(unsigned char *buffer, unsigned int length)
{

	unsigned int bytecounter=0;

	do
	{
		ReadFile(rs232_handle,buffer,length,&rs232_totalreadbytes, &rs232_ol);
		buffer+= rs232_totalreadbytes;
		bytecounter+= rs232_totalreadbytes;
	}	while ((bytecounter<length) && (rs232_totalreadbytes>0));


	if (bytecounter<length)
		return -1;
	else
		return 0;
}


/*****************************************************************************/
/* rs232_receiveblocked                                                      */
/*---------------------------------------------------------------------------*/
/* receives a datablock blocking, times out                                  */
/*****************************************************************************/
int rs232_receiveblocked(unsigned char *buffer, unsigned int length)
{

	
	do
	{
		ClearCommError(rs232_handle,&rs232_error,&rs232_comstat);
	}	while (rs232_comstat.cbInQue<length);
	

	ReadFile(rs232_handle,buffer,length,&rs232_totalreadbytes, &rs232_ol);

	if (rs232_totalreadbytes<length)
		return -1;
	else
		return 0;
}


/*****************************************************************************/
/* rs232_sendchar                                                            */
/*---------------------------------------------------------------------------*/
/* sends singular character                                                  */
/*****************************************************************************/
void rs232_sendchar(unsigned char ch)
{
	WriteFile(rs232_handle,&ch,1,&rs232_totalwritebytes, &rs232_ol);
}

/*****************************************************************************/
/* rs232_receivechar                                                         */
/*---------------------------------------------------------------------------*/
/* receives a singular character busy, times out                             */
/*****************************************************************************/
int rs232_receivechar(void)
{
	unsigned char buffer;


	ReadFile(rs232_handle,&buffer,1,&rs232_totalreadbytes, &rs232_ol);

	// char temp[255];
	// sprintf(temp,"RS232_RECEIVECHAR: %02X",buffer);
	// log_write(MODULE_RS232,temp);

	if (rs232_totalreadbytes ==1)
	{
		return (buffer & 0xFF);
	}
	else 
	{
		return -1;
	}

}


VOID CALLBACK rs232_writecomplete(DWORD dwErrorCode, DWORD dwNumberOfBytesTransfered, LPOVERLAPPED lpOverlapped)
{
	
}

VOID CALLBACK rs232_readcomplete(DWORD dwErrorCode, DWORD dwNumberOfBytesTransfered, LPOVERLAPPED lpOverlapped)
{

}

/*****************************************************************************/
/* rs232_statusmessage                                                       */
/*---------------------------------------------------------------------------*/
/* displays a status message                                                 */
/*****************************************************************************/
int rs232_statusmessage(void)
{
	char line[255];

	ClearCommError(rs232_handle,&rs232_error,&rs232_comstat);
	sprintf(line,"RS232 Status: %ld Error= Comstat=%ld,%ld,%ld,%ld,%ld,%ld,%ld,%ld,%ld", 
		rs232_error,
		rs232_comstat.cbInQue,
		rs232_comstat.cbOutQue,
		rs232_comstat.fCtsHold,
		rs232_comstat.fDsrHold,
		rs232_comstat.fEof,
		rs232_comstat.fRlsdHold,
		rs232_comstat.fTxim,
		rs232_comstat.fXoffHold,
		rs232_comstat.fXoffSent
	);
	
	return -1;

}
