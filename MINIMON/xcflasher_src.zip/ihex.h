/*****************************************************************************/
/* XC FLASHER                                                                */
/* ihex.h : intel hex file functions                                         */
/*****************************************************************************/
/* program, erase, protect, unprotect and test flashes                       */
/* for the c167, xc167 microcontroller family                                */
/*                                                                           */
/* (c) 2003 by Infineon                                                      */
/* Christian Perschl                                                         */
/*****************************************************************************/

#if !defined(IHEX_H_INCLUDED)
#define IHEX_H_INCLUDED

#define MAXRECLENGTH 0xFF

struct t_hexrec
{
	unsigned char length;
	unsigned char type;
	unsigned short offset;
	unsigned char data[MAXRECLENGTH];
	unsigned char checkSum;
};

#define IHEX_DATAREC 0x0
#define IHEX_ENDREC 0x1
#define IHEX_SEGREC 0x2
#define IHEX_SEGREC32 0x4


int ihex_read(char *filename);
int ihex_readrecord(char *string, t_hexrec *rec);
int ihex_verifyrecordchecksum(t_hexrec *rec);

#endif