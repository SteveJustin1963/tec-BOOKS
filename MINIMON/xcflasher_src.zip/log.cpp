/*****************************************************************************/
/* XC FLASHER                                                                */
/* log.cpp : command and error logging                                       */
/*****************************************************************************/
/* program, erase, protect, unprotect and test flashes                       */
/* for the c167, xc167 microcontroller family                                */
/*                                                                           */
/* (c) 2003 by Infineon                                                      */
/* Christian Perschl                                                         */
/*****************************************************************************/

#include "stdafx.h"
#include <stdio.h>
#include "common.h"
#include "log.h"

char log_file[255];
char log_buffer[LOG_BUFFERSIZE][255];
int  log_buffersize;


/*****************************************************************************/
/* log_init                                                                  */
/*---------------------------------------------------------------------------*/
/* initializes log queue                                                     */
/*****************************************************************************/
void log_init()
{
	FILE *fp;

	strcpy(log_file,"xcflasher.log");
	fp = fopen(xcflasher_extendfullpath(log_file),"w");
	fclose(fp);
	log_buffersize = 0;
}


/*****************************************************************************/
/* log_getmodulename                                                         */
/*---------------------------------------------------------------------------*/
/* returns module name                                                       */
/*****************************************************************************/
char* log_getmodulename(int module)
{
	switch (module)
	{
		case MODULE_CMD:       return "CMD  ";
		case MODULE_COMM:      return "COMM ";
		case MODULE_FLASH:     return "FLASH";
		case MODULE_IHEX:      return "IHEX ";
		case MODULE_LOG:       return "LOG  ";
		case MODULE_MEM:       return "MEM  ";
		case MODULE_MISC:      return "MISC ";
		case MODULE_PARSE:     return "PARSE";
		case MODULE_PREFS:     return "PREFS";
		case MODULE_RS232:     return "RS232";
		case MODULE_SFR:       return "SFR  ";
		case MODULE_XCF:       return "XCF  ";

		default:               return "-----";
	}
}


/*****************************************************************************/
/* log_write                                                                 */
/*---------------------------------------------------------------------------*/
/* writes text to log                                                        */
/*****************************************************************************/
void log_write(int module,char *string)
{
	FILE *fp;
	char temp[255];
	sprintf(temp,"\n%s:  %s",log_getmodulename(module), string);

	fp = fopen(xcflasher_extendfullpath(log_file),"a+");
	fprintf(fp,"%s",temp);
	fclose(fp);

	if (log_buffersize<LOG_BUFFERSIZE)
	{
		strcpy(log_buffer[log_buffersize++],temp);
		xcflasher_redraw();
	}

}



/*****************************************************************************/
/* log_getlogbuffer                                                          */
/*---------------------------------------------------------------------------*/
/* returns buffer of given index from log buffer                             */
/*****************************************************************************/
char *log_getlogtext(int index)
{
	if (index<log_buffersize)
		return log_buffer[index];
	else
		return 0;
}

/*****************************************************************************/
/* log_getlogbuffer                                                          */
/*---------------------------------------------------------------------------*/
/* returns number of entries in log buffer                                   */
/*****************************************************************************/
int log_getlogbuffercount(void)
{
		return log_buffersize;
}



