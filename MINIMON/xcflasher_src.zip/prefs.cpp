/*****************************************************************************/
/* XC FLASHER                                                                */
/* prefs.cpp : reading and setting preferences                               */
/*****************************************************************************/
/* program, erase, protect, unprotect and test flashes                       */
/* for the c167, xc167 microcontroller family                                */
/*                                                                           */
/* (c) 2003 by Infineon                                                      */
/* Christian Perschl                                                         */
/*****************************************************************************/

#include "stdafx.h"
#include "prefs.h"
#include "sfr.h"
#include "log.h"
#include <stdio.h>
#include "common.h"

extern char xcflasher_path[];

// [Minimon]
char prefs_loaderfilename[255];  // filename loader
char prefs_minimonfilename[255]; // filename minimon

// [Communication]
char prefs_comport[6];           // "COM1", "COM2"....
int  prefs_baudrate;             // 9600, 19200, 38400 ...
int  prefs_parity;               // 0.. none, 1.. odd , 3.. even
int  prefs_databits;             // 8 databits
int  prefs_stopbits;             // 1 stopbits
int  prefs_timeout;              // timeoutvalue in ms

// [Controller]
char prefs_controller[64];       // e.g. "XC167"
int  prefs_clk;                  // up to 40000000

// [Memory]
t_memory prefs_mem[64];
int prefs_memcount;

// [Register]
t_reg prefs_reg[16];
int  prefs_regcount;

// [Commands]
int  prefs_calleinit;


/*****************************************************************************/
/* prefs_load                                                                */
/*---------------------------------------------------------------------------*/
/* reads the preferences from a give file                                    */
/*****************************************************************************/
int prefs_load(char *filename)
{
	FILE *fp;
	char line[255];
	char* entry;
	char* value;
	int i;
	int j;
	int current_section=0;
	char *pdriverfeatures[MAXFEATURES];

	if ((fp  = fopen(xcflasher_extendfullpath(filename),"r")) == NULL)
		return -1;
	else
	{
		prefs_calleinit = 0;
		// read preferences from file
		while (fgets(line,255,fp)!=NULL)
		{
			eliminatespaces(line);

			if (strcmp(line,"[Minimon]")==0)
				current_section = 1;
			if (strcmp(line,"[Communication]")==0)
				current_section = 2;
			if (strcmp(line,"[Controller]")==0)
				current_section = 3;
			if (strcmp(line,"[Memory]")==0)
			 	current_section = 4;
			if (strcmp(line,"[Register]")==0)
				current_section = 5;
			if (strcmp(line,"[Commands]")==0)
				current_section = 6;


			// search for '=' and substitute with 0
			// generate pointers entry and value
			i=0;
			while ((line[i]!='=') && (line[i]!=0))
				i++;
			if (line[i]=='=')
			{
				line[i]=0;
				entry = &line[0];
				value = &line[i+1];
			}
			else
			{
				entry = &line[0];
				value = &line[0];
			}

			
			switch (current_section)
			{
				case 1: //[Minimon]

					if (strcmp(entry,"LOADER")==0)
						strcpy(prefs_loaderfilename,value);

					if (strcmp(entry,"MINIMON")==0)
						strcpy(prefs_minimonfilename,value);

				break;
				case 2: //[Communication]
					if (strcmp(entry,"PORT")==0)
						strcpy(prefs_comport,value);
					if (strcmp(entry,"BAUDRATE")==0)
						prefs_baudrate=atol(value);
					if (strcmp(entry,"PARITY")==0)
						prefs_parity=atoi(value);
					if (strcmp(entry,"DATA")==0)
						prefs_databits=atoi(value);
					if (strcmp(entry,"STOPBITS")==0)
						prefs_stopbits=atoi(value);
					if (strcmp(entry,"TIMEOUT")==0)
						prefs_timeout=atol(value);

				break;
				case 3: //[Controller]

					if (strcmp(entry,"MCTYPE")==0)
						strcpy(prefs_controller,value);
					if (strcmp(entry,"CLK")==0)
						prefs_clk=atol(value);

				break;
				case 4: //[Memory]

					if (strcmp(entry,"NAME")==0)
					{
						// new memory section
						prefs_memcount++;
						strcpy(prefs_mem[prefs_memcount-1].name,value);
					}

					if (prefs_memcount>0)
					{					
						if (strcmp(entry,"TYPE")==0)
						{
							strcpy(prefs_mem[prefs_memcount-1].type,value);
						}
						if (strcmp(entry,"BLANK")==0)
						{
							sscanf(value,"0x%02X",&(prefs_mem[prefs_memcount-1].blank));
						}
						if (strcmp(entry,"BURSTSIZE")==0)
						{
							sscanf(value,"0x%04X",&(prefs_mem[prefs_memcount-1].burstsize));
						}
						if (strcmp(entry,"DRIVER.PATH")==0)
						{
							strcpy(prefs_mem[prefs_memcount-1].driver_path,value);
						}
						if (strcmp(entry,"DRIVER.BUFFERADDRESS")==0)
						{
							sscanf(value,"%06X",&(prefs_mem[prefs_memcount-1].driver_bufferaddress));
						}

						
						if (strstr(entry,"SECTION")!=NULL)
						{
							if (strstr(entry,"STARTADDRESS")!=NULL)
							{
								sscanf(entry,"SECTION(%d).STARTADDRESS(%d)",&i,&j);
								// i contains section number, j contains subsection (should be 0)
								sscanf(value,"0x%06X",&(prefs_mem[prefs_memcount-1].sector[i].startaddress));

							}
							if (strstr(entry,"LENGTH")!=NULL)
							{
								sscanf(entry,"SECTION(%d).LENGTH(%d)",&i,&j);
								sscanf(value,"0x%06X",&(prefs_mem[prefs_memcount-1].sector[i].length));
							}

							// update sector count
							if (i+1>prefs_mem[prefs_memcount-1].sector_count)
							{
								prefs_mem[prefs_memcount-1].sector_count = i+1;
							}
							
						}

						if (strstr(entry,"STATUS")!=NULL)
						{
							if (strstr(entry,"NAME")!=NULL)
							{
								sscanf(entry,"STATUS(%d).NAME",&i,&j);
								// i contains section number, j contains subsection (should be 0)
								sscanf(value,"%s",&(prefs_mem[prefs_memcount-1].statusreg[i].name));
							}

							// update status count
							if (i+1>prefs_mem[prefs_memcount-1].statusreg_count)
							{
								prefs_mem[prefs_memcount-1].statusreg_count = i+1;
							}
							
						}

						if (strcmp(entry,"DRIVER.FEATURES")==0)
						{
							prefs_mem[prefs_memcount-1].driverfeatures_count=0;

							// set up pointers
							pdriverfeatures[prefs_mem[prefs_memcount-1].driverfeatures_count++]=&value[0];
							i=0;
							while (value[i]!=0)
							{
								if (value[i]==',')
								{
									pdriverfeatures[prefs_mem[prefs_memcount-1].driverfeatures_count++]=&value[i+1];
									value[i]=0;
								}
								i++;
							}

							for (i=0;i<prefs_mem[prefs_memcount-1].driverfeatures_count;i++)
								strcpy(prefs_mem[prefs_memcount-1].driverfeatures[i],pdriverfeatures[i]);

						}
						if (strcmp(entry,"PROTECTIONSECTORS")==0)
						{
							sscanf(value,"%d",&(prefs_mem[prefs_memcount-1].protection_sectors));
						}
						


					}
		
				break;
				case 5: //[Register]

					if (sfr_exists(entry))
					{
						strcpy(prefs_reg[prefs_regcount].name,entry);
						prefs_reg[prefs_regcount].address = sfr_getaddress(prefs_reg[prefs_regcount].name);
						sscanf(value,"0x%04X",&(prefs_reg[prefs_regcount].value));
						prefs_regcount++;
					}
					else
					{
						if ((strcmp(entry,"GENERIC1")==0) || (strcmp(entry,"GENERIC2")==0))
						{
							strcpy(prefs_reg[prefs_regcount].name,entry);
							sscanf(value,"0x%04X,%06X",&(prefs_reg[prefs_regcount].value),&(prefs_reg[prefs_regcount].address));
							prefs_regcount++;
						}
					}

				break;
				case 6: //[Commands]
					if (strcmp(entry,"EINIT")==0)
						prefs_calleinit=-1;

				break;
			}
			

		}


		fclose(fp);
		return 0;
	}
}

/*****************************************************************************/
/* prefs_save                                                                */
/*---------------------------------------------------------------------------*/
/* writes the preferences to a given file                                    */
/*****************************************************************************/
int prefs_save(char *filename)
{
	FILE *fp;
	int i;

	if ((fp  = fopen(xcflasher_extendfullpath(filename),"w")) == NULL)
		return -1;
	else
	{
		// write preferences to file
        fprintf(fp,"\n[Minimon]");
		fprintf(fp,"\n");
		fprintf(fp,"\nLOADER=%s",prefs_loaderfilename);
		fprintf(fp,"\nMINIMON=%s",prefs_minimonfilename);
		fprintf(fp,"\n");
        fprintf(fp,"\n[Communication]");
		fprintf(fp,"\n");
		fprintf(fp,"\nPORT=%s",prefs_comport);
		fprintf(fp,"\nBAUDRATE= %ld",prefs_baudrate);
		fprintf(fp,"\nPARITY= %d",prefs_parity);
		fprintf(fp,"\nDATA= %d",prefs_databits);
		fprintf(fp,"\nSTOPBITS= %d",prefs_stopbits);
		fprintf(fp,"\nTIMEOUT= %d",prefs_timeout);

		fprintf(fp,"\n");
        fprintf(fp,"\n[Controller]");
		fprintf(fp,"\n");
		fprintf(fp,"\nMCTYPE=%s",prefs_controller);
		fprintf(fp,"\nCLK= %ld",prefs_clk);

		fprintf(fp,"\n");
        fprintf(fp,"\n[Register]");
		fprintf(fp,"\n");
		for (i=0;i<prefs_regcount;i++)
		{
			fprintf(fp,"\n%s=%04X",prefs_reg[i].name,prefs_reg[i].value);
		}

		fprintf(fp,"\n");
        fprintf(fp,"\n[Commands]");
		fprintf(fp,"\n");
		if (prefs_calleinit) 
		{
			fprintf(fp,"\nEINIT");
		}
		fprintf(fp,"\n");

		fclose(fp);
		return 0;
	}
}

/*****************************************************************************/
/* prefs_init                                                                */
/*---------------------------------------------------------------------------*/
/* sets the preferences to the default values                                */
/*****************************************************************************/
void prefs_init(void)
{

	// [Minimon]
	strcpy(prefs_loaderfilename,"MCProg\\LOAD.HEX");
	strcpy(prefs_minimonfilename,"MCProg\\MINIMON.HEX");

	// [Communication]
	strcpy(prefs_comport,"COM1");
	prefs_baudrate = 9600;
	prefs_parity = 0;
	prefs_databits = 8;
	prefs_stopbits = 1;
	prefs_timeout = 2000;

	// [Controller]
	strcpy(prefs_controller,"XC167");
	prefs_clk = 20000000;

	// [Memory]
	prefs_memcount = 0;

	// [Register]
	prefs_regcount = 0;

	// [Commands]
	prefs_calleinit = -1;

}

/*****************************************************************************/
/* prefs_getrs232settings                                                    */
/*---------------------------------------------------------------------------*/
/* returns rs232 com settings of current preferences                         */
/*****************************************************************************/
void prefs_getrs232settings(t_rs232settings *settings)
{
	strcpy(settings->comport,prefs_comport);
	settings->baudrate = prefs_baudrate;
	settings->parity = prefs_parity;
	settings->databits = prefs_databits;
	settings->stopbits = prefs_stopbits;
	settings->timeout = prefs_timeout;
}

/*****************************************************************************/
/* prefs_getflashinfos                                                       */
/*---------------------------------------------------------------------------*/
/* searches for flash memory in prefs and returns all informations           */
/*****************************************************************************/
t_memory *prefs_getflashinfos(void)
{
	int i=0;

	// 
	while ((strcmp(prefs_mem[i].type,"FLASH")!=0) && 
		   (strcmp(prefs_mem[i].type,"IFLASH")!=0) && (i<prefs_memcount))
		i++;
	if (i<prefs_memcount)
	{
		// flash 
		return &prefs_mem[i];
	}
	else
		return 0;
}

/*****************************************************************************/
/* prefs_getinitregs                                                         */
/*---------------------------------------------------------------------------*/
/* returns initialization register information                               */
/*****************************************************************************/
t_reg *prefs_getinitregs(int *regcount)
{
	*regcount = prefs_regcount;
	return prefs_reg;
}

/*****************************************************************************/
/* prefs_getloaderfilename                                                   */
/*---------------------------------------------------------------------------*/
/* returns full path and filename of the loader                              */
/*****************************************************************************/
char *prefs_getloaderfilename(void)
{
	return prefs_loaderfilename;
}

/*****************************************************************************/
/* prefs_getminimonfilename                                                  */
/*---------------------------------------------------------------------------*/
/* returns full path and filename of minimon                                 */
/*****************************************************************************/
char *prefs_getminimonfilename(void)
{
	return prefs_minimonfilename;
}


/*****************************************************************************/
/* prefs_calleinit                                                           */
/*---------------------------------------------------------------------------*/
/* returns wether einit has to be called or not                              */
/*****************************************************************************/
int prefs_einit(void)
{
	return prefs_calleinit;
}






/*****************************************************************************/
/* prefs_print                                                               */
/*---------------------------------------------------------------------------*/
/* displays the preferences                                                  */
/*****************************************************************************/
void prefs_print(void)
{
	int i;
	int j;
	char temp[255];


	sprintf(temp,"prefs_loaderfilename = %s",prefs_loaderfilename);
	log_write(MODULE_PREFS,temp);
	sprintf(temp,"prefs_minimonfilename = %s",prefs_minimonfilename);
	log_write(MODULE_PREFS,temp);
	sprintf(temp,"prefs_comport = %s",prefs_comport);
	log_write(MODULE_PREFS,temp);
	sprintf(temp,"prefs_baudrate = %ld",prefs_baudrate);
	log_write(MODULE_PREFS,temp);
	sprintf(temp,"prefs_parity = %d",prefs_parity);
	log_write(MODULE_PREFS,temp);
	sprintf(temp,"prefs_databits = %d",prefs_databits);
	log_write(MODULE_PREFS,temp);
	sprintf(temp,"prefs_stopbits = %d",prefs_stopbits);
	log_write(MODULE_PREFS,temp);
	sprintf(temp,"prefs_timeout = %d",prefs_timeout);
	log_write(MODULE_PREFS,temp);
	sprintf(temp,"prefs_controller = %s",prefs_controller);
	log_write(MODULE_PREFS,temp);
	sprintf(temp,"prefs_clk = %ld",prefs_clk);
	log_write(MODULE_PREFS,temp);

	for (i=0;i<prefs_regcount;i++)
	{
		sprintf(temp,"SFR(%d) %s at 0x%06X = 0x%04X",i,prefs_reg[i].name,prefs_reg[i].address,prefs_reg[i].value);
		log_write(MODULE_PREFS,temp);
	}

	for (i=0;i<prefs_memcount;i++)
	{
		sprintf(temp,"MEM(%d).name=%s",i,prefs_mem[i].name);
		log_write(MODULE_PREFS,temp);
		sprintf(temp,"MEM(%d).type=%s",i,prefs_mem[i].type);
		log_write(MODULE_PREFS,temp);
		sprintf(temp,"MEM(%d).blank=0x%02X",i,prefs_mem[i].blank);
		log_write(MODULE_PREFS,temp);
		sprintf(temp,"MEM(%d).burstsize=0x%04X",i,prefs_mem[i].burstsize);
		log_write(MODULE_PREFS,temp);
		sprintf(temp,"MEM(%d).driver_path=%s",i,prefs_mem[i].driver_path);
		log_write(MODULE_PREFS,temp);
		sprintf(temp,"MEM(%d).driver_bufferaddress=0x%06X",i,prefs_mem[i].driver_bufferaddress);
		log_write(MODULE_PREFS,temp);

		for (j=0;j<prefs_mem[i].driverfeatures_count;j++)
		{
			sprintf(temp,"MEM(%d).Driverfeature(%d)=%s",i,j,prefs_mem[i].driverfeatures[j]);
			log_write(MODULE_PREFS,temp);
		}

		for (j=0;j<prefs_mem[i].sector_count;j++)
		{
			sprintf(temp,"MEM(%d).Sector(%d).Startaddress=0x%06X",i,j,prefs_mem[i].sector[j].startaddress);
			log_write(MODULE_PREFS,temp);
			sprintf(temp,"MEM(%d).Sector(%d).Length=0x%06X",i,j,prefs_mem[i].sector[j].length);
			log_write(MODULE_PREFS,temp);
		}
	}

}





