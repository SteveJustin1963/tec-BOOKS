/*****************************************************************************/
/* XC FLASHER                                                                */
/* sfr.cpp : sfr definitions and functions                                   */
/*****************************************************************************/
/* program, erase, protect, unprotect and test flashes                       */
/* for the c167, xc167 microcontroller family                                */
/*                                                                           */
/* (c) 2003 by Infineon                                                      */
/* Christian Perschl                                                         */
/*****************************************************************************/

#include "stdafx.h"
#include "sfr.h"
#include "log.h"
#include "common.h"

t_sfr sfr_list[MAXSFR];
int sfr_count;

/*****************************************************************************/
/* sfr_init                                                                  */
/*---------------------------------------------------------------------------*/
/* initializes sfr module                                                    */
/*****************************************************************************/
void sfr_init(void)
{
	sfr_count = 0;

	// C167 Architecture
	strcpy(sfr_list[sfr_count].name,"SYSCON");
	sfr_list[sfr_count].address = 0x00FF12;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"BUSCON0");
	sfr_list[sfr_count].address = 0x00FF0C;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"BUSCON1");
	sfr_list[sfr_count].address = 0x00FF14;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"BUSCON2");
	sfr_list[sfr_count].address = 0x00FF16;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"BUSCON3");
	sfr_list[sfr_count].address = 0x00FF18;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"BUSCON4");
	sfr_list[sfr_count].address = 0x00FF1A;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"ADDRSEL1");
	sfr_list[sfr_count].address = 0x00FE18;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"ADDRSEL2");
	sfr_list[sfr_count].address = 0x00FE1A;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"ADDRSEL3");
	sfr_list[sfr_count].address = 0x00FE1C;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"ADDRSEL4");
	sfr_list[sfr_count].address = 0x00FE1E;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"DPP0");
	sfr_list[sfr_count].address = 0x00FE00;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"DPP1");
	sfr_list[sfr_count].address = 0x00FE02;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"DPP2");
	sfr_list[sfr_count].address = 0x00FE04;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"DPP3");
	sfr_list[sfr_count].address = 0x00FE06;
	sfr_count++;

	// XC Architecture
	strcpy(sfr_list[sfr_count].name,"FCONCS0");
	sfr_list[sfr_count].address = 0x00EE12;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"FCONCS0");
	sfr_list[sfr_count].address = 0x00EE12;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"FCONCS1");
	sfr_list[sfr_count].address = 0x00EE1A;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"FCONCS2");
	sfr_list[sfr_count].address = 0x00EE22;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"FCONCS3");
	sfr_list[sfr_count].address = 0x00EE2A;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"TCONCS0");
	sfr_list[sfr_count].address = 0x00EE10;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"TCONCS1");
	sfr_list[sfr_count].address = 0x00EE18;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"TCONCS2");
	sfr_list[sfr_count].address = 0x00EE20;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"TCONCS3");
	sfr_list[sfr_count].address = 0x00EE28;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"EBCMOD0");
	sfr_list[sfr_count].address = 0x00EE00;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"EBCMOD1");
	sfr_list[sfr_count].address = 0x00EE02;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"SYSCON0");
	sfr_list[sfr_count].address = 0x00F1BE;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"SYSCON1");
	sfr_list[sfr_count].address = 0x00F1DC;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"SYSCON3");
	sfr_list[sfr_count].address = 0x00F1D4;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"RSTCON");
	sfr_list[sfr_count].address = 0x00F1E0;
	sfr_count++;
	strcpy(sfr_list[sfr_count].name,"FOCON");
	sfr_list[sfr_count].address = 0x00FFAA;
	sfr_count++;




}

/*****************************************************************************/
/* sfr_getaddress                                                            */
/*---------------------------------------------------------------------------*/
/* initializes and clears command queue                                      */
/*****************************************************************************/
unsigned long sfr_getaddress(char *sfrname)
{
	int i=0;

	while ((i<sfr_count) && (strcmp(sfr_list[i].name,sfrname)!=0))
		i++;

	if (i<sfr_count)
	{
		// sfr found
		return sfr_list[i].address;
	}
	else
		return 0;
}

/*****************************************************************************/
/* sfr_exists                                                                */
/*---------------------------------------------------------------------------*/
/* initializes and clears command queue                                      */
/*****************************************************************************/
int sfr_exists(char *sfrname)
{
	int i=0;

	while ((i<sfr_count) && (strcmp(sfr_list[i].name,sfrname)!=0))
		i++;

	if (i<sfr_count)
	{
		// sfr found
		return -1;
	}
	else
		return 0;
}
