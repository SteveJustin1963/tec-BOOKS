/*****************************************************************************/
/* XC FLASHER                                                                */
/* misc.cpp : miscellaneous and universal functions                          */
/*****************************************************************************/
/* program, erase, protect, unprotect and test flashes                       */
/* for the c167, xc167 microcontroller family                                */
/*                                                                           */
/* (c) 2003 by Infineon                                                      */
/* Christian Perschl                                                         */
/*****************************************************************************/

#include "misc.h"
#include "stdafx.h"
#include "log.h"
#include <stdio.h>
#include "common.h"

/*****************************************************************************/
/* fileexists                                                                */
/*---------------------------------------------------------------------------*/
/* this universal function prooves if a file with the given filename exists  */
/*****************************************************************************/
int fileexists(char *filename)
{
	FILE *fp;

	if ((fp  = fopen(xcflasher_extendfullpath(filename),"r")) == NULL)
		return 0;
	else
	{
		fclose(fp);
		return -1;
	}
}

/*****************************************************************************/
/* eliminatespaces                                                           */
/*---------------------------------------------------------------------------*/
/* this universal function eliminates any spaces, tabs and newlines in string*/
/*****************************************************************************/
void eliminatespaces(char *string)
{
	unsigned int i,j;
  
	i=0;
	while (string[i]!=0)
	{
		if ((string[i]==0x0D) || (string[i]==0x0A) || (string[i]==0x09) || (string[i]==' '))
		{
			for (j=i;j<strlen(string);j++)
			{
				string[j]=string[j+1];
			}
		}
		else
		 i++;
	}
  
}

