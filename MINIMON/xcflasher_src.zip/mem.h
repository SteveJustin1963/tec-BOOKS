/*****************************************************************************/
/* XC FLASHER                                                                */
/* mem.h : buffering for files (imaging of hardware memory)                */
/*****************************************************************************/
/* program, erase, protect, unprotect and test flashes                       */
/* for the c167, xc167 microcontroller family                                */
/*                                                                           */
/* (c) 2003 by Infineon                                                      */
/* Christian Perschl                                                         */
/*****************************************************************************/


#if !defined(MEM_H_INCLUDED)
#define MEM_H_INCLUDED

#define MAXBUFFERSIZE 16777216
#define MAXSELECTIONS 32768

struct t_selection
{
	unsigned long startaddress;
	unsigned long length;
};


void mem_init(void);
void mem_write(unsigned long startaddress, unsigned long length, unsigned char *srcbuf);
void mem_read(unsigned long startaddress, unsigned long length, unsigned char *dstbuf);
unsigned char* mem_getbufferaddress(void);
void mem_fill(unsigned char fillchar);
void mem_print(unsigned long startaddress, unsigned long length);
unsigned long mem_readused(unsigned char *dstbuf);
unsigned long mem_getlowestaddress(void);
unsigned long mem_getusedlength(void);

void mem_addselection(unsigned long startaddress, unsigned long length);
void mem_clearselections(void);
t_selection *mem_getselection(t_selection *startsel);
void mem_optimizeselections(void);
void mem_printselections(void);


#endif
