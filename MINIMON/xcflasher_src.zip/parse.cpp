/*****************************************************************************/
/* XC FLASHER                                                                */
/* parse.cpp : command queue and command execution                           */
/*****************************************************************************/
/* program, erase, protect, unprotect and test flashes                       */
/* for the c167, xc167 microcontroller family                                */
/*                                                                           */
/* (c) 2003 by Infineon                                                      */
/* Christian Perschl                                                         */
/*****************************************************************************/

#include "stdafx.h"
#include <stdio.h>
#include "common.h"
#include "misc.h"
#include "cmd.h"
#include "prefs.h"
#include "sfr.h"
#include "mem.h"
#include "ihex.h"
#include "comm.h"
#include "parse.h"
#include "log.h"


int parse_menue(void);
void parse_usage(void);
void parse_printinfo(void);
extern char prefs_loaderfilename[];
extern char prefs_minimonfilename[];

char temp[255];


/*****************************************************************************/
/* parse_commandline                                                         */
/*---------------------------------------------------------------------------*/
/* parses the given string into command queue                                */
/*****************************************************************************/
int parse_commandline(char *string)
{
	int i = 0;
	int parse_error = 0;
	int result = 0;
	int argc = 1;
	char *argv[32];
	char *prefsfile = DEFAULT_PREFSFILE;

	parse_printinfo();

	argv[argc++]=string;
	while (string[i]!=0)
	{
		if (string[i]==' ')
		{
			argv[argc]=&string[i+1];
			string[i]=0;
			argc++;
		}
		i++;
	}
	
	i = 1;
	while ((i<argc) && (!parse_error))
	{
		parse_error = 1;

		// A) commands with no additional parameter
		// command "e" - erase whole flash
		// command "m" - test whole flash (margin check)
		// command "c"
		// command "s" - get (status) register(s)
		if ((strcmp(argv[i],"e")==0) || (strcmp(argv[i],"m")==0) || (strcmp(argv[i],"c")==0) || (strcmp(argv[i],"s")==0))
		{
			parse_error = 0;
			cmd_add(argv[i],ALLSECTORS,0,0);
		}

		// B) commands with one additional parameter: sector number 
		// command "es" - erase flash sector
		// command "ms" - test flash sector (margin check)
		// command "s" - read status register
		if ((strcmp(argv[i],"es")==0) || (strcmp(argv[i],"ms")==0))
		{

			// read sector number
			i++;
			if ((i<argc) && ((atoi(argv[i])>0) || (strcmp(argv[i],"0")==0)))
			{
				cmd_add(argv[i-1],atoi(argv[i]),0,0);
				parse_error = 0;
			}
			else
			{
				if (i<argc)
				{
					sprintf(temp,"ERROR: sector '%s' is not valid",argv[i]);
					log_write(MODULE_PARSE,temp);
				}
				else
				{
					sprintf(temp,"ERROR: parameter <sector> missing");
					log_write(MODULE_PARSE,temp);
				}
				continue;
			}
		}

		// C) commands with one additional parameter: read file name
		// command "p" - program flash
		// command "v" - verify flash
		if ((strcmp(argv[i],"p")==0) || (strcmp(argv[i],"v")==0))
		{
			
			// look for file name
			i++;
			if ((i<argc) && (fileexists(argv[i])))
			{
				cmd_add(argv[i-1],ALLSECTORS,argv[i],0);
				parse_error = 0;
			}
			else
			{
				if (i<argc)
				{
					sprintf(temp,"ERROR: file '%s' does not exist",argv[i]);
					log_write(MODULE_PARSE,temp);
				}
				else
				{
					sprintf(temp,"ERROR: parameter <filename> missing");
					log_write(MODULE_PARSE,temp);
				}
				continue;
			}
		}

		// D) commands with one additional parameter: password
		// command "r+" - enable flash read protection 
		// command "r-" - disable flash read protection
		// command "w-" - disable flash read protection
		if ((strcmp(argv[i],"r+")==0) || (strcmp(argv[i],"r-")==0) || (strcmp(argv[i],"w-")==0))
		{
			
			// read password
			i++;
			if (i<argc)
			{
				strcpy(temp,argv[i]);
				parser_extendpassword(temp);
				cmd_add(argv[i-2],0,0,temp);
				parse_error = 0;
			}
			else
			{
				sprintf(temp,"ERROR: parameter <password> missing");
				log_write(MODULE_PARSE,temp);
				continue;
			}

		}

		// E) commands with two additional parameters: sector number and password
		// command "ws+" - enable flash write protection for one sector
		if (strcmp(argv[i],"ws+")==0)
		{
			
			// read sector number
			i++;
			if ((i<argc) && ((atoi(argv[i])>0) || (strcmp(argv[i],"0")==0)))
			{
				// read password
				i++;
				if (i<argc)
				{
					strcpy(temp,argv[i]);
					parser_extendpassword(temp);
					cmd_add(argv[i-2],atoi(argv[i-1]),0,temp);
					parse_error = 0;
				}
				else
				{
					sprintf(temp,"ERROR: parameter <password> missing");
					log_write(MODULE_PARSE,temp);
					continue;
				}
			}
			else
			{
				sprintf(temp,"ERROR: sector '%s' is not valid",argv[i]);
				log_write(MODULE_PARSE,temp);
				continue;
			}

		}

		// F) options with one additional parameter: filename
		if (strcmp(argv[i],"-i")==0)
		{
			
			// look for file name
			i++;
			if ((i<argc) && (fileexists(argv[i])))
			{
				prefsfile = argv[i];
				parse_error = 0;
			}
			else
			{
				if (i<argc)
				{
					sprintf(temp,"ERROR: file '%s' does not exist",argv[i]);
					log_write(MODULE_PARSE,temp);
				}
				else
				{
					sprintf(temp,"ERROR: parameter <filename> missing");
					log_write(MODULE_PARSE,temp);
				}
				continue;
			}
		}


		if (parse_error == 1) 
		{
			sprintf(temp,"ERROR: unknown command '%s'",argv[i]);
			log_write(MODULE_PARSE,temp);
		}

		i++;
	}

	if (parse_error)
	{
		parse_usage();
		result = 1;
	}
	else
	{	
		if (result = prefs_load(prefsfile))
		{
			sprintf(temp,"WARNING: preferences file '%s' not found - generating default file",prefsfile);
			log_write(MODULE_PARSE,temp);

			prefs_save(prefsfile);
		}
		result = cmd_executeall();

	}

	return result;
}


/*****************************************************************************/
/* parse_printinfo                                                           */
/*---------------------------------------------------------------------------*/
/* if password length < 8, fill up with spaces, if longer, shorten           */
/*****************************************************************************/
void parser_extendpassword(char *password)
{
	// fill up with spaces
	int i;
	for (i=strlen(password);i<8;i++)
		password[i]=' ';

	password[8] = 0;
}



/*****************************************************************************/
/* parse_printinfo                                                           */
/*---------------------------------------------------------------------------*/
/* displays informations about the XC FLASHER                                */
/*****************************************************************************/
void parse_printinfo(void)
{

	log_write(MODULE_PARSE,"XC FLASHER v1.0");
	log_write(MODULE_PARSE,"(c) 2003 by Infineon");
	log_write(MODULE_PARSE,"Christian Perschl");
	log_write(MODULE_PARSE,"");
}

/*****************************************************************************/
/* parse_usage                                                               */
/*---------------------------------------------------------------------------*/
/* this function displays the usage message, if any commandline parameter    */
/* error occurs                                                              */
/*****************************************************************************/
void parse_usage(void)
{
	log_write(MODULE_PARSE,"");
	log_write(MODULE_PARSE,"usage: xcflasher <command> [<file>|<sector>] [<command>...] [options]");
	log_write(MODULE_PARSE,"");
	log_write(MODULE_PARSE,"commands: ");
	log_write(MODULE_PARSE,"          c                              ... connect to hardware");
	log_write(MODULE_PARSE,"          e                              ... erase whole flash");
	log_write(MODULE_PARSE,"          es <sector number>             ... erase flash sector");
	log_write(MODULE_PARSE,"          p  <hex file>                  ... program file into flash");
	log_write(MODULE_PARSE,"          v  <hex file>                  ... verify flash contents with file");
	log_write(MODULE_PARSE,"          ws+ <sector number> <password> ... enable sector write protection");
	log_write(MODULE_PARSE,"          w- <password>	                 ... disable write protection");
	log_write(MODULE_PARSE,"          r+ <password>	                 ... enable read protection");
	log_write(MODULE_PARSE,"          r- <password>                  ... disable read protection");
	log_write(MODULE_PARSE,"          m					             ... margin check");
	log_write(MODULE_PARSE,"          ms <sector number>             ... margin check for given flash sector");
	log_write(MODULE_PARSE,"          s  <register number>           ... read status register");
	log_write(MODULE_PARSE,"");
	log_write(MODULE_PARSE,"options: ");
	log_write(MODULE_PARSE,"          -i <ini file>                  ... use preferences file ");
	log_write(MODULE_PARSE,"                                             (default is xcflasher.ini)");
	log_write(MODULE_PARSE,"");
}



