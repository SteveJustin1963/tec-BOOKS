/*****************************************************************************/
/* XC FLASHER                                                                */
/* log.h : command and error logging                                         */
/*****************************************************************************/
/* program, erase, protect, unprotect and test flashes                       */
/* for the c167, xc167 microcontroller family                                */
/*                                                                           */
/* (c) 2003 by Infineon                                                      */
/* Christian Perschl                                                         */
/*****************************************************************************/


#if !defined(LOG_H_INCLUDED)
#define LOG_H_INCLUDED

#define LOG_BUFFERSIZE 1000

void log_init(void);
void log_write(int module,char *string);
char *log_getmodulename(int module);
char *log_getlogtext(int index);
int log_getlogbuffercount(void);


#endif