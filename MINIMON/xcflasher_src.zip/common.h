/*****************************************************************************/
/* XC FLASHER                                                                */
/* common.h : common definitions and constants                               */
/*****************************************************************************/
/* program, erase, protect, unprotect and test flashes                       */
/* for the c167, xc167 microcontroller family                                */
/*                                                                           */
/* (c) 2003 by Infineon                                                      */
/* Christian Perschl                                                         */
/*****************************************************************************/

#if !defined(COMMON_H_INCLUDED)
#define COMMON_H_INCLUDED


#define DEFAULT_PREFSFILE "xcflasher.ini"
#define MODULE_CMD       0x1000
#define MODULE_COMM      0x2000
#define MODULE_FLASH     0x3000
#define MODULE_IHEX      0x4000
#define MODULE_LOG       0x5000
#define MODULE_MEM       0x6000
#define MODULE_MISC      0x7000
#define MODULE_PARSE     0x8000
#define MODULE_PREFS     0x9000
#define MODULE_RS232     0xA000
#define MODULE_SFR       0xB000
#define MODULE_XCF       0xC000

void xcflasher_redraw(void);
void xcflasher_selectfile(char *filename);
char *xcflasher_extendfullpath(char *filename);

#endif
