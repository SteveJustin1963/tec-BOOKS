/*****************************************************************************/
/* XC FLASHER                                                                */
/* flash.cpp : the flash routines                                            */
/*****************************************************************************/
/* program, erase, protect, unprotect and test flashes                       */
/* for the c167, xc167 microcontroller family                                */
/*                                                                           */
/* (c) 2003 by Infineon                                                      */
/* Christian Perschl                                                         */
/*****************************************************************************/

#include "stdafx.h"
#include "prefs.h"
#include "comm.h"
#include "mem.h"
#include "flash.h"
#include "log.h"
#include "common.h"


t_memory *flash_s;
int flash_driverloaded;
unsigned long flash_driverstartaddress=0;

/*****************************************************************************/
/* flash_init                                                                */
/*---------------------------------------------------------------------------*/
/* reads the flash infos from preference module                              */
/*****************************************************************************/
void flash_init(void)
{
	flash_s= prefs_getflashinfos();
	flash_driverloaded = 0;
}

/*****************************************************************************/
/* flash_eraseall                                                            */
/*---------------------------------------------------------------------------*/
/* erases the whole flash                                                    */
/*****************************************************************************/
int flash_eraseall(void)
{
	int result=0;
	unsigned short registers[8];
	unsigned short registers2[8];

	// look if flash is configured
	if (flash_s)
	{
		if (flash_isfeature("ERASE"))
		{
			// 1.look if driver is loaded, and load it
			if (!flash_driverloaded)
				result = flash_loaddriver();
			if (result)
				return 1;

			// 2.call erase function
			registers[0] = FLASH_ERASEALL;
			registers[1] = 0;
			registers[2] = 0;
			registers[3] = 0;
			registers[4] = 0;
			registers[5] = 0;
			registers[6] = 0;
			registers[7] = 0;
			result = comm_call(flash_driverstartaddress,registers,registers2);
			if (result)
				return 2;

			// 3. evaluate return parameters
			if (registers2[7])
				return 3;

			return 0;
		}
		else
			return 4;

	}
	else 
		return 5;
}


/*****************************************************************************/
/* flash_erasesector                                                         */
/*---------------------------------------------------------------------------*/
/* erases one flash sector                                                   */
/*****************************************************************************/
int flash_erasesector(int sectornr)
{
	int result=0;
	unsigned short registers[8];
	unsigned short registers2[8];

	// look if flash is configured
	if (flash_s)
	{
		if (flash_isfeature("ERASE"))
		{
			// 1.look if driver is loaded, and load it
			if (!flash_driverloaded)
				result = flash_loaddriver();
			if (result)
				return 1;

			// 2.call erase function
			registers[0] = FLASH_ERASESECTOR;
			registers[1] = 0;
			registers[2] = 0;
			registers[3] = 0;
			registers[4] = 0;
			registers[5] = 0;
			registers[6] = (unsigned short) sectornr;
			registers[7] = 0;
			result = comm_call(flash_driverstartaddress,registers,registers2);
			if (result)
				return 2;

			// 3. evaluate return parameters
			if (registers2[7])
				return 3;

			return 0;
		}
		else
			return 4;

	}
	else 
		return 5;
}

/*****************************************************************************/
/* flash_program                                                             */
/*---------------------------------------------------------------------------*/
/* programs a given file into the flash                                      */
/*****************************************************************************/
int flash_program(char *filename)
{
	int result=0;
	unsigned short registers[8];
	unsigned short registers2[8];
	unsigned long startaddress;
	unsigned long length;
	unsigned long l;
	unsigned char buffer[1024];
	t_selection *pselection=0;
	unsigned long current_block=1;
	char temp[255];

	// look if flash is configured
	if (flash_s)
	{
		if (flash_isfeature("PROGRAM"))
		{
			
			// 1.look if driver is loaded, and load it
			if (!flash_driverloaded)
			{
				result = flash_loaddriver();
					if (result)
				return 1;
			}

			// 2. load user file
			mem_init();
			mem_fill(flash_s->blank);
			result = ihex_read(filename);
			mem_printselections();

			if (result)
				return 2;

			while (pselection=mem_getselection(pselection))
			{
				
				length = pselection->length;
				startaddress = pselection->startaddress;

				// the length and the start address has to be adapted for the burstsize borders
				length+= startaddress-(startaddress & (0xFFFFFFFF-flash_s->burstsize+1));
				startaddress&= (0xFFFFFFFF-flash_s->burstsize+1);

				// 3. program user file into memory
				for (l=startaddress;l<startaddress+length;l+=flash_s->burstsize)
				{

					// program only if this block was not already programmed just before
					if ((l & (0xFFFFFFFF-flash_s->burstsize+1)) != current_block)
					{
						current_block = l & (0xFFFFFFFF-flash_s->burstsize+1);

						// 3.1 read current package from mem module
						mem_read(l,flash_s->burstsize,buffer);

						// 3.2. load buffer into target driver buffer
						result = comm_write(flash_s->driver_bufferaddress,flash_s->burstsize,buffer);
						if (result)
							return 3;

						// 3.3 call program function
						registers[0] = FLASH_PROGRAM;
						registers[1] = flash_s->burstsize;
						registers[2] = (unsigned short) (flash_s->driver_bufferaddress & 0xFFFF);
						registers[3] = (unsigned short) ((flash_s->driver_bufferaddress >> 16) & 0xFFFF);
						registers[4] = 0;
						registers[5] = (unsigned short) (l & 0xFFFF);
						registers[6] = (unsigned short) ((l >> 16) & 0xFFFF);
						registers[7] = 0;

						result = comm_call(flash_driverstartaddress,registers,registers2);
						if (result)
							return 4;

						sprintf(temp,"program 0x%02X bytes at address 0x%08X (selection startaddress: 0x%08X)",flash_s->burstsize,l,pselection->startaddress);
						log_write(MODULE_FLASH,temp);
					}
				}

				// 5. evaluate return parameters
				if (registers2[7])
					return 5;

			}

			return 0;
		}
		else
			return 6;

	}
	else 
		return 7;
}



/*****************************************************************************/
/* flash_verify                                                              */
/*---------------------------------------------------------------------------*/
/* verifys a given file with flash contents                                  */
/*****************************************************************************/
int flash_verify(char *filename)
{
	int result=0;
	unsigned long startaddress;
	unsigned long length;
	unsigned long l;
	unsigned char buffer1[1024];
	unsigned char buffer2[1024];
	int blocksize = flash_s->burstsize;
	t_selection *pselection=0;

	// look if flash is configured
	if (flash_s)
	{

		// 1. load user file
		mem_init();
		result = ihex_read(filename);
		if (result)
			return 1;

		while (pselection=mem_getselection(pselection))
		{

			length = pselection->length;
			startaddress =  pselection->startaddress;

			// 2. read user file from memory
			for (l=startaddress;l<startaddress+length;l+=blocksize)
			{

				if ((l+blocksize)>=(startaddress+length))
				{
					// 2.1a read the last package from mem module
					mem_read(l,startaddress+length-l,buffer1);

					// 2.2a read the last package from target memory
					result = comm_read(l,startaddress+length-l,buffer2);
					if (result)
						return 2;

					// 2.3a compare target memory with mem
					if (memcmp(buffer1,buffer2,startaddress+length-l)!=0)
						return 3;
				}
				else
				{
					// 2.1b. read other package from mem module
					mem_read(l,blocksize,buffer1);

					// 2.2b read the last package from target memory
					result = comm_read(l,blocksize,buffer2);
					if (result)
						return 4;

					// 2.3b compare target memory with mem
					if (memcmp(buffer1,buffer2,blocksize)!=0)
						return 5;
				}

			}

		}

		return 0;
	}
	else 
		return 6;
}



/*****************************************************************************/
/* flash_writeprotection_enable                                              */
/*---------------------------------------------------------------------------*/
/* protects one flash sector                                                 */
/*****************************************************************************/
int flash_writeprotection_enable(int sectornr, char *password)
{
	int result=0;
	unsigned short registers[8];
	unsigned short registers2[8];
	int password_length = 8;

	// look if flash is configured
	if (flash_s)
	{
		if (flash_isfeature("LOCK"))
		{
			// 1.look if driver is loaded, and load it
			if (!flash_driverloaded)
				result = flash_loaddriver();
			if (result)
				return 1;

			// 2. download password
			result = comm_write(flash_s->driver_bufferaddress,password_length,(unsigned char *) password);
			if (result)
				return 2;

			// 3.call protect function
			registers[0] = FLASH_LOCK;
			registers[1] = password_length; 
			registers[2] = (unsigned short) (flash_s->driver_bufferaddress & 0xFFFF);
			registers[3] = (unsigned short) ((flash_s->driver_bufferaddress >> 16) & 0xFFFF);
			registers[4] = 0;
			registers[5] = 0;
			registers[6] = (unsigned short) sectornr;
			registers[7] = 0;
			result = comm_call(flash_driverstartaddress,registers,registers2);
			if (result)
				return 3;

			// 4. evaluate return parameters
			if (registers2[7])
				return 4;

			return 0;
		}
		else
			return 5;

	}
	else 
		return 6;
}


/*****************************************************************************/
/* flash_writeprotection_disable                                             */
/*---------------------------------------------------------------------------*/
/* unprotects one flash sector                                               */
/*****************************************************************************/
int flash_writeprotection_disable(char *password)
{
	int result=0;
	unsigned short registers[8];
	unsigned short registers2[8];
	int password_length = 8;

	// look if flash is configured
	if (flash_s)
	{
		if (flash_isfeature("UNLOCK"))
		{
			// 1.look if driver is loaded, and load it
			if (!flash_driverloaded)
				result = flash_loaddriver();
			if (result)
				return 1;

			// 2. download password
			result = comm_write(flash_s->driver_bufferaddress,password_length,(unsigned char *) password);
			if (result)
				return 2;

			// 3.call protect function
			registers[0] = FLASH_UNLOCK;
			registers[1] = password_length; 
			registers[2] = (unsigned short) (flash_s->driver_bufferaddress & 0xFFFF);
			registers[3] = (unsigned short) ((flash_s->driver_bufferaddress >> 16) & 0xFFFF);
			registers[4] = 0;
			registers[5] = 0;
			registers[6] = 0;
			registers[7] = 0;
			result = comm_call(flash_driverstartaddress,registers,registers2);
			if (result)
				return 3;

			// 4. evaluate return parameters
			if (registers2[7])
				return 4;

			return 0;
		}
		else
			return 5;

	}
	else 
		return 6;
}


/*****************************************************************************/
/* flash_readprotection_enable                                               */
/*---------------------------------------------------------------------------*/
/* protects the whole flash against reading                                  */
/*****************************************************************************/
int flash_readprotection_enable(char *password)
{
	int result=0;
	unsigned short registers[8];
	unsigned short registers2[8];
	int password_length = 8;

	// look if flash is configured
	if (flash_s)
	{
		if (flash_isfeature("PROTECT"))
		{
			// 1.look if driver is loaded, and load it
			if (!flash_driverloaded)
				result = flash_loaddriver();
			if (result)
				return 1;

			// 2. download password
			result = comm_write(flash_s->driver_bufferaddress,password_length,(unsigned char *) password);
			if (result)
				return 2;

			// 3.call protect function
			registers[0] = FLASH_PROTECT;
			registers[1] = password_length; 
			registers[2] = (unsigned short) (flash_s->driver_bufferaddress & 0xFFFF);
			registers[3] = (unsigned short) ((flash_s->driver_bufferaddress >> 16) & 0xFFFF);
			registers[4] = 0;
			registers[5] = 0;
			registers[6] = 0;
			registers[7] = 0;
			result = comm_call(flash_driverstartaddress,registers,registers2);
			if (result)
				return 3;

			// 4. evaluate return parameters
			if (registers2[7])
				return 4;

			return 0;
		}
		else
			return 5;

	}
	else 
		return 6;
}


/*****************************************************************************/
/* flash_readprotection_disable                                              */
/*---------------------------------------------------------------------------*/
/* disables the read protection of the whole flash                           */
/*****************************************************************************/
int flash_readprotection_disable(char *password)
{
	int result=0;
	unsigned short registers[8];
	unsigned short registers2[8];
	int password_length = 8;

	// look if flash is configured
	if (flash_s)
	{
		if (flash_isfeature("UNPROTECT"))
		{
			// 1.look if driver is loaded, and load it
			if (!flash_driverloaded)
				result = flash_loaddriver();
			if (result)
				return 1;

			// 2. download password
			result = comm_write(flash_s->driver_bufferaddress,password_length,(unsigned char *) password);
			if (result)
				return 2;

			// 3.call protect function
			registers[0] = FLASH_UNPROTECT;
			registers[1] = password_length; 
			registers[2] = (unsigned short) (flash_s->driver_bufferaddress & 0xFFFF);
			registers[3] = (unsigned short) ((flash_s->driver_bufferaddress >> 16) & 0xFFFF);
			registers[4] = 0;
			registers[5] = 0;
			registers[6] = 0;
			registers[7] = 0;
			result = comm_call(flash_driverstartaddress,registers,registers2);
			if (result)
				return 3;

			// 4. evaluate return parameters
			if (registers2[7])
				return 4;

			return 0;
		}
		else
			return 5;

	}
	else 
		return 6;
}


/*****************************************************************************/
/* flash_getstatus                                                           */
/*---------------------------------------------------------------------------*/
/* returns the flash status register										 */
/*****************************************************************************/
int flash_getstatus(unsigned short *regbuffer,unsigned short *regnumbers)
{
	int result=0;
	unsigned short registers[8];
	unsigned short registers2[8];

	// look if flash is configured
	if (flash_s)
	{
		if (flash_isfeature("STATUS"))
		{
			// 1.look if driver is loaded, and load it
			if (!flash_driverloaded)
				result = flash_loaddriver();
			if (result)
				return 1;

			// 2.call erase function
			registers[0] = FLASH_STATUS;
			registers[1] = 0;
			registers[2] = (unsigned short) (flash_s->driver_bufferaddress & 0xFFFF);
			registers[3] = (unsigned short) ((flash_s->driver_bufferaddress >> 16) & 0xFFFF);
			registers[4] = 0;
			registers[5] = 0;
			registers[6] = 0;
			registers[7] = 0;
			result = comm_call(flash_driverstartaddress,registers,registers2);
			if (result)
				return 2;

			// 3. evaluate return parameters
			if (registers2[7])
				return 4;

			*regnumbers = registers2[0];

			// 4. readback register values
			result = comm_read(flash_s->driver_bufferaddress,*regnumbers*2,(unsigned char *) regbuffer);
			if (result)
				return 5;

			return 0;
		}
		else
			return 6;

	}
	else 
		return 7;
}


/*****************************************************************************/
/* flash_loaddriver                                                          */
/*---------------------------------------------------------------------------*/
/* loads the driver into the target memory                                   */
/*****************************************************************************/
int flash_loaddriver(void)
{
	int result=0;
	unsigned char driverbuffer[4096];
	unsigned long length;

	mem_init();
	result = ihex_read(flash_s->driver_path);
	if (result)
		return 1;

	length=mem_readused(driverbuffer);
	flash_driverstartaddress = mem_getlowestaddress();

	result = comm_write(flash_driverstartaddress,length,driverbuffer);
	if (result)
		return 2;
	
	flash_driverloaded = 1;

	return 0;
}


/*****************************************************************************/
/* flash_isfeature                                                           */
/*---------------------------------------------------------------------------*/
/* looks if the given feature is supported by the configured flash type      */
/*****************************************************************************/
int flash_isfeature(char *feature)
{
	int i=0;

	while ((strcmp(flash_s->driverfeatures[i],feature)!=0) && (i<flash_s->driverfeatures_count))
		i++;

	if (i<flash_s->driverfeatures_count)
		return -1;
	else
		return 0;

}

/*****************************************************************************/
/* flash_invalidatedriver                                                    */
/*---------------------------------------------------------------------------*/
/* marks the driver as unloaded, used by the connect function                */
/*****************************************************************************/
void flash_invalidatedriver(void)
{
	flash_driverloaded = 0;
}



