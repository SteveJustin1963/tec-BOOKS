/*****************************************************************************/
/* XC FLASHER                                                                */
/* prefs.h : reading and setting preferences                               */
/*****************************************************************************/
/* program, erase, protect, unprotect and test flashes                       */
/* for the c167, xc167 microcontroller family                                */
/*                                                                           */
/* (c) 2003 by Infineon                                                      */
/* Christian Perschl                                                         */
/*****************************************************************************/

#include "misc.h"
#include "sfr.h"
#include "rs232.h"

#if !defined(PREFS_H_INCLUDED)
#define PREFS_H_INCLUDED

#define MAXNAME 32
#define MAXPATH 512
#define MAXSECTORS 32
#define MAXFEATURES 32
#define MAXSTATUSREGS 32


struct t_reg
{
	char name[MAXNAME];
	unsigned long address;
	unsigned int value;
};

struct t_sectors
{
	unsigned long startaddress;
	unsigned long length;
};

struct t_statusreg
{
	char name[MAXNAME];
};

struct t_memory
{
	char name[MAXNAME];
	char type[MAXNAME];
	unsigned char blank;
	int burstsize;
	t_sectors sector[MAXSECTORS];
	int sector_count;
	char driver_path[MAXPATH];
	unsigned long driver_bufferaddress;
	char driverfeatures[MAXFEATURES][MAXNAME];
	int driverfeatures_count;
	int protection_sectors;
	t_statusreg statusreg[MAXSTATUSREGS];
	int statusreg_count;
};



int prefs_load(char *filename);
int prefs_save(char *filename);
void prefs_init(void);
void prefs_print(void);

void prefs_getrs232settings(t_rs232settings *settings);
t_memory *prefs_getflashinfos(void);
t_reg *prefs_getinitregs(int *regcount);
int prefs_einit(void);
char *prefs_getloaderfilename(void);
char *prefs_getminimonfilename(void);

#endif



