/*****************************************************************************/
/* XC FLASHER                                                                */
/* comm.cpp : the communication interface to the target                      */
/*****************************************************************************/
/* program, erase, protect, unprotect and test flashes                       */
/* for the c167, xc167 microcontroller family                                */
/*                                                                           */
/* (c) 2003 by Infineon                                                      */
/* Christian Perschl                                                         */
/*****************************************************************************/

#include "stdafx.h"
#include "comm.h"
#include "rs232.h"
#include "mem.h"
#include "ihex.h"
#include "flash.h"
#include "prefs.h"
#include "log.h"
#include "common.h"

int comm_state;

/*****************************************************************************/
/* comm_init                                                                 */
/*---------------------------------------------------------------------------*/
/* initializes and clears comm module                                        */
/*****************************************************************************/
void comm_init(void)
{
	comm_state = COMM_NOTCONNECTED;
}


/*****************************************************************************/
/* comm_connect                                                              */
/*---------------------------------------------------------------------------*/
/* connects to the target                                                    */
/*****************************************************************************/
int comm_connect(char *loaderfilename,char *minimonfilename)
{
	int result;
	unsigned char buffer[1024];
	t_selection *pselection;

	flash_invalidatedriver();

	rs232_purge();

	// 1. Send Byte 0 to RS232
	rs232_sendchar(0);

	// 2. Receive Controller ID Byte
	result = rs232_receivechar();
	if (result==-1) 
		return 1;

	// 3. Send 32 Bytes of loader
	mem_init();
	result=ihex_read(loaderfilename);
	if (result) 
		return 2;
	// size=mem_readused(buffer);
	pselection = mem_getselection(0);
	mem_read(pselection->startaddress,pselection->length,buffer);
	rs232_send(buffer,32);

	// 4. Receive Acknowledge Byte from Loader 
	result = rs232_receivechar();
	if (result==-1) 
		return 3;
	if (result!= COMM_LOADERACK) 
		return 4;

	// 5. Send Minimon
	mem_init();
	result=ihex_read(minimonfilename);
	if (result) 
		return 5;
	// size=mem_readused(buffer);
	pselection = mem_getselection(0);
	mem_read(pselection->startaddress,pselection->length,buffer);
	rs232_send(buffer,pselection->length);

	// 6. Receive Acknowledge Byte from Minimon
	result = rs232_receivechar();
	if (result==-1) 
		return 6;
	if (result!= COMM_MINIMONACK) 
		return 7;

	comm_state = COMM_CONNECTED;

	// 7. initialize registers
	result = comm_initregs();
	if (result) 
		return 8;

	return 0;
}

/*****************************************************************************/
/* comm_initregs                                                             */
/*---------------------------------------------------------------------------*/
/* initializes registers and calls einit if neccessary                       */
/*****************************************************************************/
int comm_initregs(void)
{
	int result;
	int i;
	t_reg *initregs;
	int regcount;

	initregs=prefs_getinitregs(&regcount);


	for (i=0;i<regcount;i++)
	{
		result = comm_writeword(initregs->address,initregs->value);
		if (result)
			return 1;
	}

	// call einit if neccessary
	if (prefs_einit())
	{
		result = comm_einit();
		if (result)
			return 2;
	}

	return 0;
}



/*****************************************************************************/
/* comm_writeword                                                            */
/*---------------------------------------------------------------------------*/
/* writes one word to target                                                 */
/*****************************************************************************/
int comm_writeword(unsigned long address, unsigned int data)
{
	int result = 0;

	// 1. send command byte
	rs232_sendchar(COMM_WRITEWORD);

	// 2. receive first command acknowledge
	result = rs232_receivechar();
	if (result==-1) return 1;
	if (result!=COMM_ACK1) return 2;

	// 3. send command parameters
	rs232_sendchar((unsigned char) (address & 0xFF));
	rs232_sendchar((unsigned char) ((address >> 8) & 0xFF));
	rs232_sendchar((unsigned char) ((address >> 16) & 0xFF));
	rs232_sendchar((unsigned char) (data & 0xFF));
	rs232_sendchar((unsigned char) ((data >> 8) & 0xFF));

	// 4. nothing to receive for this command

	// 5. receive second command acknowledge
	result = rs232_receivechar();
	if (result==-1) return 4;
	if (result!=COMM_ACK2) return 5;

	return 0;
}

/*****************************************************************************/
/* comm_write                                                                */
/*---------------------------------------------------------------------------*/
/* writes a block to target memory                                           */
/*****************************************************************************/
int comm_write(unsigned long address, unsigned int length, unsigned char *data)
{
	int result = 0;

	// 1. send command byte
	rs232_sendchar(COMM_WRITEBLOCK);

	// 2. receive first command acknowledge
	result = rs232_receivechar();
	if (result==-1) return 1;
	if (result!=COMM_ACK1) return 2;

	// 3. send command parameters
	rs232_sendchar((unsigned char) (address & 0xFF));
	rs232_sendchar((unsigned char) ((address >> 8) & 0xFF));
	rs232_sendchar((unsigned char) ((address >> 16) & 0xFF));
	rs232_sendchar((unsigned char) (length & 0xFF));
	rs232_sendchar((unsigned char) ((length >> 8) & 0xFF));
	rs232_send(data,length);

	// 4. nothing to receive for this command

	// 5. receive second command acknowledge
	result = rs232_receivechar();
	if (result==-1) return 4;
	if (result!=COMM_ACK2) return 5;

	return 0;
}

/*****************************************************************************/
/* comm_read                                                                 */
/*---------------------------------------------------------------------------*/
/* reads a block from target memory                                          */
/*****************************************************************************/
int comm_read(unsigned long address, unsigned int length, unsigned char *data)
{
	int result = 0;

	// 1. send command byte
	rs232_sendchar(COMM_READBLOCK);

	// 2. receive first command acknowledge
	result = rs232_receivechar();
	if (result==-1) return 1;
	if (result!=COMM_ACK1) return 2;
	
	// 3. send command parameters
	rs232_sendchar((unsigned char) (address & 0xFF));
	rs232_sendchar((unsigned char) ((address >> 8) & 0xFF));
	rs232_sendchar((unsigned char) ((address >> 16) & 0xFF));
	rs232_sendchar((unsigned char) (length & 0xFF));
	rs232_sendchar((unsigned char) ((length >> 8) & 0xFF));

	// 4. receive response 
	result = rs232_receiveblocked(data,length);
	// result = rs232_receive(data,length);
	if (result==-1) return 3;

	// 5. receive second command acknowledge
	result = rs232_receivechar();
	if (result==-1) return 4;
	if (result!=COMM_ACK2) return 5;


	return 0;
}

/*****************************************************************************/
/* comm_call                                                                 */
/*---------------------------------------------------------------------------*/
/* calls a subroutine on target memory with parameters                       */
/*****************************************************************************/
int comm_call(unsigned long address, unsigned short *parameters, unsigned short *responseparameters)
{
	int result = 0;

	// 1. send command byte
	rs232_sendchar(COMM_CALL);

	// 2. receive first command acknowledge
	result = rs232_receivechar();
	if (result==-1) return 1;
	if (result!=COMM_ACK1) return 2;

	// 3. send command parameters
	rs232_sendchar((unsigned char) (address & 0xFF));
	rs232_sendchar((unsigned char) ((address >> 8) & 0xFF));
	rs232_sendchar((unsigned char) ((address >> 16) & 0xFF));
	rs232_send((unsigned char *) parameters,16);
	
	// 4. receive response 
	// result = rs232_receive((unsigned char *) responseparameters,16);
	result = rs232_receiveblocked((unsigned char *) responseparameters,16);

	if (result==-1) return 3;

	// 5. receive second command acknowledge
	result = rs232_receivechar();
	if (result==-1) return 4;
	if (result!=COMM_ACK2) return 5;

	return 0;
}

/*****************************************************************************/
/* comm_test                                                                 */
/*---------------------------------------------------------------------------*/
/* tests the connection to the target, used for reconnect, too               */
/*****************************************************************************/
int comm_test(void)
{
	int result = 0;

	// 1. send command byte
	rs232_sendchar(COMM_TEST);

	// 2. receive first command acknowledge
	result = rs232_receivechar();
	if (result==-1) return 1;
	if (result!=COMM_ACK1) return 2;

	// 3. no command parameters

	// 4. nothing to receive for this command

	// 5. receive second command acknowledge
	result = rs232_receivechar();
	if (result==-1) return 4;
	if (result!=COMM_ACK2) return 5;

	return 0;
}

/*****************************************************************************/
/* comm_getchecksum                                                          */
/*---------------------------------------------------------------------------*/
/* reads the last transfer checksum from target                              */
/*****************************************************************************/
int comm_getchecksum(unsigned int *checksum)
{
	int result = 0;

	// 1. send command byte
	rs232_sendchar(COMM_CHECKSUM);

	// 2. receive first command acknowledge
	result = rs232_receivechar();
	if (result==-1) return 1;
	if (result!=COMM_ACK1) return 2;

	// 3. no command parameters

	// 4. receive response 
	result = rs232_receive((unsigned char *) checksum,2);
	if (result==-1) return 3;

	// 5. receive second command acknowledge
	result = rs232_receivechar();
	if (result==-1) return 4;
	if (result!=COMM_ACK2) return 5;

	return 0;
}


/*****************************************************************************/
/* comm_einit                                                                */
/*---------------------------------------------------------------------------*/
/* calls the einit command on the target                                     */
/*****************************************************************************/
int comm_einit(void)
{
	int result = 0;

	// 1. send command byte
	rs232_sendchar(COMM_EINIT);

	// 2. receive first command acknowledge
	result = rs232_receivechar();
	if (result==-1) return 1;
	if (result!=COMM_ACK1) return 2;

	// 3. no command parameters

	// 4. nothing to receive for this command

	// 5. receive second command acknowledge
	result = rs232_receivechar();
	if (result==-1) return 4;
	if (result!=COMM_ACK2) return 5;

	return 0;
}

/*****************************************************************************/
/* comm_srst                                                                 */
/*---------------------------------------------------------------------------*/
/* calls a software reset on the target                                      */
/*****************************************************************************/
int comm_srst(void)
{
	int result = 0;

	// 1. send command byte
	rs232_sendchar(COMM_SRST);

	// 2. receive first command acknowledge
	result = rs232_receivechar();
	if (result==-1) return 1;
	if (result!=COMM_ACK1) return 2;

	// 3. no command parameters

	// 4. nothing to receive for this command

	// 5. receive second command acknowledge
	result = rs232_receivechar();
	if (result==-1) return 4;
	if (result!=COMM_ACK2) return 5;

	comm_state = COMM_USERPROGRAMRUNNING;

	return 0;
}


/*****************************************************************************/
/* comm_go                                                                   */
/*---------------------------------------------------------------------------*/
/* jumps to given address on the target                                      */
/*****************************************************************************/
int comm_go(unsigned long address)
{
	int result = 0;

	// 1. send command byte
	rs232_sendchar(COMM_GO);

	// 2. receive first command acknowledge
	result = rs232_receivechar();
	if (result==-1) return 1;
	if (result!=COMM_ACK1) return 2;

	// 3. send command parameters
	rs232_sendchar((unsigned char) (address & 0xFF));
	rs232_sendchar((unsigned char) ((address >> 8) & 0xFF));
	rs232_sendchar((unsigned char) ((address >> 16) & 0xFF));

	// 4. nothing to receive for this command

	// 5. receive second command acknowledge
	result = rs232_receivechar();
	if (result==-1) return 4;
	if (result!=COMM_ACK2) return 5;

	comm_state = COMM_USERPROGRAMRUNNING;
	
	return 0;
}


/*****************************************************************************/
/* comm_timeouterror                                                         */
/*---------------------------------------------------------------------------*/
/* here all commands have been placed when connection is lost                */
/*****************************************************************************/
void comm_timeouterror(void)
{
	comm_state = COMM_NOTCONNECTED;
	flash_invalidatedriver();
}

