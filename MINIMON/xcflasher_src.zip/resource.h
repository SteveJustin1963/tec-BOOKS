//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by xcflasher.rc
//
#define IDC_MYICON                      2
#define IDD_XCFLASHER_DIALOG            102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_XCFLASHER                   107
#define IDI_SMALL                       108
#define IDC_XCFLASHER                   109
#define IDR_MAINFRAME                   128
#define IDD_INPUTBOX                    130
#define IDC_TEXT                        1001
#define IDC_PROMPT                      1002
#define ID_TARGET_CONNECT               32771
#define ID_TARGET_ERASE                 32772
#define ID_TARGET_PROGRAM               32773
#define ID_TARGET_VERIFY                32774
#define ID_TARGET_WRITEPROTECTION_ENABLE 32775
#define ID_TARGET_READPROTECTION_ENABLE 32776
#define ID_TARGET_MARGINTEST            32777
#define ID_FILE_LOAD                    32778
#define ID_TARGET_WRITEPROTECTION_DISABLE 32780
#define ID_TARGET_READPROTECTION_DISABLE 32781
#define ID_TARGET_READSTATUS            32782
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32784
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
