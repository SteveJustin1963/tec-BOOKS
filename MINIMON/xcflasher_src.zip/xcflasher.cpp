// xcflasher.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "resource.h"
#include <stdio.h>
#include "common.h"
#include "misc.h"
#include "cmd.h"
#include "prefs.h"
#include "sfr.h"
#include "mem.h"
#include "ihex.h"
#include "comm.h"
#include "parse.h"
#include "flash.h"
#include "log.h"

#define MAX_LOADSTRING 256

#define FILEWINDOW_PERCENT 30
#define FILEWINDOW_TEXTCOLOR1 0x00800000;
#define FILEWINDOW_TEXTCOLOR2 0x00A00000;
#define FILEWINDOW_BACKCOLOR 0x00FFC0C0;
#define FILEWINDOW_ROWHEIGHT 20
#define FILEWINDOW_COLWIDTH 20

#define LOGWINDOW_LINEHEIGHT 15
#define LOGWINDOW_PERCENT 70
#define LOGWINDOW_TEXTCOLOR 0x00800000;
#define LOGWINDOW_LINECOLOR1 0x00A00000;
#define LOGWINDOW_LINECOLOR2 0x00500000;
#define LOGWINDOW_BACKCOLOR 0x00C0FFFF;

#define DIALOG_ERASE 1
#define DIALOG_WRITEPROTECTION_ENABLE 2
#define DIALOG_WRITEPROTECTION_DISABLE 3
#define DIALOG_READPROTECTION_ENABLE 4
#define DIALOG_READPROTECTION_DISABLE 5
#define DIALOG_WRITEPROTECTION_ENABLE_SECTORS 6 


void xcflasher_writelog(HWND hWnd,HDC hdc);
void xcflasher_displayfile(HWND hWnd,HDC hdc);
void xcflasher_drawfilescroll(void);
void xcflasher_preparewindows(HWND hWnd,HDC hdc);
int xcflasher_parsesectors(char *sectorstring,int sectors);
void xcflasher_extendpassword(void);
void xcflasher_recalc_scrollbarrange(void);
void xcflasher_setpath(void);

RECT xcflasher_logwindow;
RECT xcflasher_filewindow;
int xcflasher_windowsinitialized=0;
int xcflasher_inputmode;

HWND xcflasher_hWnd;
char xcflasher_filename[MAX_LOADSTRING];
int  xcflasher_fileselected = 0;
HWND xcflasher_hWndScroll;
int  xcflasher_scrollbarvisible = 0;
int  xcflasher_lastscollbarvalue = 0;

int xcflasher_sector[32];
int xcflasher_sectors;
char xcflasher_password[9];

char xcflasher_path[255];

// Global Variables:
HINSTANCE hInst;								// current instance
TCHAR szTitle[MAX_LOADSTRING];								// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];								// The title bar text
OPENFILENAME ofn;       // common dialog box structure


// Foward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK InputBox(HWND, UINT, WPARAM, LPARAM);

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
 	// TODO: Place code here
	t_rs232settings comsettings;
	int result;
	char temp[255];

	// this initializations have to be done before reading the preference file

	xcflasher_setpath();
	prefs_init();
	sfr_init();
	mem_init();
	cmd_init();
	comm_init();
	log_init();

	result = prefs_load(DEFAULT_PREFSFILE);
	if (result)
	{
		sprintf(temp,"PREFERENCEFILE NOT SUCCESSFULLY LOADED: errorcode(%d)",result);
		log_write(MODULE_XCF,temp);
		MessageBox(0,temp,"XCFLASHER",0);
		return 1;
	}

	// this initializations have to be done after reading the preference file
	flash_init();
	prefs_getrs232settings(&comsettings);
	result = rs232_init(&comsettings);
	if (result)
	{
		sprintf(temp,"ERROR OPENING COM PORT: errorcode(%d)",result);
		log_write(MODULE_XCF,temp);
		MessageBox(0,temp,"XCFLASHER",0);
		return result;
	}

	// open COM port
	result=rs232_open();
	if (result)
	{
		sprintf(temp,"ERROR OPENING COM PORT: errorcode(%d)",result);
		log_write(MODULE_XCF,temp);
		MessageBox(0,temp,"XCFLASHER",0);
		rs232_close();
		return result;
	}

	MSG msg;
	HACCEL hAccelTable;

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_XCFLASHER, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_XCFLASHER);

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		if (strlen(lpCmdLine)>0)
		{
			// command line mode
			result = parse_commandline(lpCmdLine);
			if (result)
			{
				sprintf(temp,"XCFLASHER not successfully terminated: errorcode(%d)",result);
				log_write(MODULE_XCF,temp);
			}
			else
			{
				log_write(MODULE_XCF,"XCFLASHER successfully terminated");
			}
			rs232_close();
			return 0;
		}

		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) 
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return msg.wParam;
}



//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function and its usage is only necessary if you want this code
//    to be compatible with Win32 systems prior to the 'RegisterClassEx'
//    function that was added to Windows 95. It is important to call this function
//    so that the application will get 'well formed' small icons associated
//    with it.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, (LPCTSTR)IDI_XCFLASHER);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= (LPCSTR)IDC_XCFLASHER;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);

	return RegisterClassEx(&wcex);
}

//
//   FUNCTION: InitInstance(HANDLE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   HWND hWnd;

   hInst = hInstance; // Store instance handle in our global variable

   hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

   xcflasher_hWndScroll = CreateWindowEx( 
    0L,                          // no extended styles 
    "SCROLLBAR",                 // scroll bar control class 
    (LPSTR) NULL,                // text for window title bar 
    WS_CHILD | SBS_VERT,         // scroll bar styles 
    0,                           // horizontal position 
    0,                           // vertical position 
    20,                         // width of the scroll bar 
    200,               // default height 
    hWnd,                   // handle to main window 
    (HMENU) NULL,           // no menu for a scroll bar 
    hInstance,                  // instance owning this window 
    (LPVOID) NULL           // pointer not needed 
   ); 

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   xcflasher_hWnd = hWnd;

   return TRUE;
}

//
//  FUNCTION: WndProc(HWND, unsigned, WORD, LONG)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	int result;
	int nScrollCode;

	switch (message) 
	{
		case WM_COMMAND:
			wmId    = LOWORD(wParam); 
			wmEvent = HIWORD(wParam); 
			// Parse the menu selections:
			switch (wmId)
			{
				case IDM_ABOUT:
				   DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);
				   break;
				case ID_FILE_LOAD:
					// MessageBox(xcflasher_hWnd,"File","File",0);

					// Initialize OPENFILENAME
					ZeroMemory(&ofn, sizeof(OPENFILENAME));
					ofn.lStructSize = sizeof(OPENFILENAME);
					ofn.hwndOwner = hWnd;
					ofn.lpstrFile = xcflasher_filename;
					ofn.nMaxFile = 256;
					ofn.lpstrFilter = "All\0*.*\0Hex Files\0";
					ofn.nFilterIndex = 1;
					ofn.lpstrFileTitle = NULL;
					ofn.nMaxFileTitle = 0;
					ofn.lpstrInitialDir = NULL;
					ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;

					// Display the Open dialog box. 

					if (GetOpenFileName(&ofn)==TRUE)
					{
						result = ihex_read(xcflasher_filename);
						if (result)
						{
							MessageBox(xcflasher_hWnd,"Error while opening file","XCFLASHER",0);
						}
						else
						{							
							xcflasher_recalc_scrollbarrange();
							xcflasher_fileselected = 1;
							xcflasher_redraw();
						}

					}
					else
					{
						MessageBox(xcflasher_hWnd,"Error while opening file","XCFLASHER",0);
					}

				   break;
				case ID_TARGET_CONNECT:
					//MessageBox(xcflasher_hWnd,"Connect","Target",0);
					cmd_init();
					cmd_add("c",0,"","");
						result= cmd_execute(0);
					if (result)
					{
						MessageBox(xcflasher_hWnd,"Error while connecting","XCFLASHER",0);
					}
				   break;
				case ID_TARGET_ERASE:

					xcflasher_inputmode = DIALOG_ERASE;
					DialogBox(hInst, (LPCTSTR)IDD_INPUTBOX, hWnd, (DLGPROC)InputBox);

					// MessageBox(0,"Erase","Target",0);
				   break;
				case ID_TARGET_PROGRAM:
					// MessageBox(0,"Program","Target",0);
					if (!xcflasher_fileselected)
						MessageBox(xcflasher_hWnd,"Please load a file first","XCFLASHER",0);
					else
					{
						cmd_init();
						cmd_add("p",0,xcflasher_filename,"");
						result= cmd_execute(0);
						if (result)
						{
							MessageBox(0,"Error while programming","XCFLASHER",0);
						}
					}

				   break;
				case ID_TARGET_VERIFY:
					// MessageBox(0,"Verify","Target",0);
					if (!xcflasher_fileselected)
						MessageBox(xcflasher_hWnd,"Please load a file first","XCFLASHER",0);
					else
					{
						cmd_init();
						cmd_add("v",0,xcflasher_filename,"");
						result= cmd_execute(0);
						if (result)
						{
							MessageBox(xcflasher_hWnd,"Error while verifying","XCFLASHER",0);
						}
					}
				   break;

				case ID_TARGET_WRITEPROTECTION_ENABLE:
					xcflasher_inputmode = DIALOG_WRITEPROTECTION_ENABLE;
					DialogBox(hInst, (LPCTSTR)IDD_INPUTBOX, hWnd, (DLGPROC)InputBox);
					// MessageBox(0,"Write Protection not implemented ","Target",0);
					break;
				case ID_TARGET_WRITEPROTECTION_DISABLE:
					xcflasher_inputmode = DIALOG_WRITEPROTECTION_DISABLE;
					DialogBox(hInst, (LPCTSTR)IDD_INPUTBOX, hWnd, (DLGPROC)InputBox);
					// MessageBox(0,"Write Protection not implemented ","Target",0);
				   break;
				case ID_TARGET_READPROTECTION_ENABLE:
					xcflasher_inputmode = DIALOG_READPROTECTION_ENABLE;
					DialogBox(hInst, (LPCTSTR)IDD_INPUTBOX, hWnd, (DLGPROC)InputBox);
					// MessageBox(0,"Read Protection not implemented ","Target",0);
				   break;
				case ID_TARGET_READPROTECTION_DISABLE:
					xcflasher_inputmode = DIALOG_READPROTECTION_DISABLE;
					DialogBox(hInst, (LPCTSTR)IDD_INPUTBOX, hWnd, (DLGPROC)InputBox);
					// MessageBox(0,"Read Protection not implemented ","Target",0);
				   break;
				case ID_TARGET_MARGINTEST:
					MessageBox(0,"Margintest not implemented ","Target",0);
				   break;
				case ID_TARGET_READSTATUS:

					cmd_init();
					cmd_add("s",0,"","");
					result = cmd_executeall();
					if (result)
					{
						MessageBox(xcflasher_hWnd,"Error while reading status","XCFLASHER",0);
					}
					break;
				case IDM_EXIT:
				   DestroyWindow(hWnd);
				   break;
				default:
				   return DefWindowProc(hWnd, message, wParam, lParam);
			}
			break;

		case WM_SIZE:
			xcflasher_windowsinitialized = 0;
			break;


		case WM_VSCROLL:

			int min1,max1;
			int	cols,rows;

			nScrollCode = (int) LOWORD(wParam); // scroll bar value 
			cols = ((xcflasher_filewindow.right-xcflasher_filewindow.left-80)/FILEWINDOW_COLWIDTH / 16)*16;
			if (cols<16) cols = 16;
			rows = (xcflasher_filewindow.bottom-xcflasher_filewindow.top)/FILEWINDOW_ROWHEIGHT-2;
			
			result = GetScrollRange(xcflasher_hWndScroll,SB_CTL,&min1,&max1);
	
			if ((nScrollCode == SB_THUMBPOSITION) || (nScrollCode == SB_THUMBTRACK))
			{
				xcflasher_lastscollbarvalue = (short int) HIWORD(wParam);  // scroll box position 
			}

			switch (nScrollCode)
			{
				case SB_BOTTOM: xcflasher_lastscollbarvalue = max1; 
				break;
				case SB_TOP: xcflasher_lastscollbarvalue = min1;
				break;
				case SB_PAGEDOWN: if (xcflasher_lastscollbarvalue<max1-rows) xcflasher_lastscollbarvalue+=rows; else xcflasher_lastscollbarvalue=max1; 
				break;
				case SB_PAGEUP: if (xcflasher_lastscollbarvalue>min1+rows) xcflasher_lastscollbarvalue-=rows; else xcflasher_lastscollbarvalue=min1; 
				break;
				case SB_LINEDOWN: if (xcflasher_lastscollbarvalue<max1-1) xcflasher_lastscollbarvalue++; else xcflasher_lastscollbarvalue=max1; 
				break;
				case SB_LINEUP: if (xcflasher_lastscollbarvalue>min1+1) xcflasher_lastscollbarvalue--; else xcflasher_lastscollbarvalue=min1; 
				break;

			}

			if (nScrollCode != SB_ENDSCROLL)
			{
				SetScrollPos(xcflasher_hWndScroll,SB_CTL,xcflasher_lastscollbarvalue,TRUE);
				xcflasher_redraw();
			}

			break;

		case WM_PAINT:

			PAINTSTRUCT ps;
			HDC hdc;

			// prepare drawing context
			hdc = BeginPaint(hWnd, &ps);
			// if (!xcflasher_windowsinitialized)
			xcflasher_preparewindows(hWnd,hdc);
			xcflasher_displayfile(hWnd,hdc);
			xcflasher_writelog(hWnd,hdc);
			EndPaint(hWnd, &ps);
			xcflasher_recalc_scrollbarrange();
			xcflasher_drawfilescroll();

			break;
		case WM_CREATE:
			break;
		case WM_DESTROY:
			PostQuitMessage(0);
			rs232_close();
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
   }
   return 0;
}

// Mesage handler for about box.
LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{

	switch (message)
	{
		case WM_INITDIALOG:
				return TRUE;

		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
			{
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}
			break;
	}
    return FALSE;
}

// Mesage handler for input box.
LRESULT CALLBACK InputBox(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	char temp[255];
	int result;
	int i;
	unsigned short sectors;

	t_memory *pflashmem;
	pflashmem = prefs_getflashinfos();

	switch (message)
	{
		case WM_INITDIALOG:

			switch (xcflasher_inputmode)
			{
				case DIALOG_ERASE: // erase
					
					sprintf(temp,"Please input the flash sector number(s) you want to erase:\n (e.g. 2 or 0-%d or 2,4,5)",pflashmem->sector_count-1);
					SetDlgItemText(hDlg,IDC_PROMPT,temp);
					sprintf(temp,"0-%d",pflashmem->sector_count-1);
					SetDlgItemText(hDlg,IDC_TEXT,temp);
				break;
				case DIALOG_WRITEPROTECTION_ENABLE: // write protection enable
					strcpy(temp,"Please input the write protection password: \n(max. 8 Characters)");
					SetDlgItemText(hDlg,IDC_PROMPT,temp);
				break;
				case DIALOG_WRITEPROTECTION_DISABLE: // write protection disable
					strcpy(temp,"Please input the write protection password: \n(max. 8 Characters)");
					SetDlgItemText(hDlg,IDC_PROMPT,temp);
				break;
				case DIALOG_READPROTECTION_ENABLE: // read protection enable
					strcpy(temp,"Please input the read protection password: \n(max. 8 Characters)");
					SetDlgItemText(hDlg,IDC_PROMPT,temp);
				break;
				case DIALOG_READPROTECTION_DISABLE: // read protection enable
					strcpy(temp,"Please input the read protection password: \n(max. 8 Characters)");
					SetDlgItemText(hDlg,IDC_PROMPT,temp);
				break;
			}


				return TRUE;

		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK)
			{

				GetDlgItemText(hDlg,IDC_TEXT,temp,255);
				
				switch (xcflasher_inputmode)
				{
					case DIALOG_ERASE: // erase
						// parse string for sectors
						result = xcflasher_parsesectors(temp,pflashmem->sector_count);
						if (result)
						{
							SetDlgItemText(hDlg,IDC_TEXT,"");

							return TRUE;
						}

						cmd_init();
						for (i=0;i<xcflasher_sectors;i++)
						{
							cmd_add("es",xcflasher_sector[i],"","");
						}
						result = cmd_executeall();
						if (result)
						{
							MessageBox(xcflasher_hWnd,"Error while erasing","XCFLASHER",0);
						}

					break;
					case DIALOG_WRITEPROTECTION_ENABLE:
							

							if (strlen(temp)>8)
							{
								// password too long
								SetDlgItemText(hDlg,IDC_TEXT,"");
								return TRUE;
							}

							strcpy(xcflasher_password,temp);
							xcflasher_extendpassword();
							
							sprintf(temp,"Please input the flash sector number(s) you want to protect: \n(0-%d)",pflashmem->protection_sectors-1);
							xcflasher_inputmode = DIALOG_WRITEPROTECTION_ENABLE_SECTORS;
							SetDlgItemText(hDlg,IDC_PROMPT,temp);
							sprintf(temp,"0-%d",pflashmem->protection_sectors-1);
							SetDlgItemText(hDlg,IDC_TEXT,temp);

							return TRUE;

							 
					break;
					case DIALOG_WRITEPROTECTION_DISABLE:

							if (strlen(temp)>8)
							{
								// password too long
								SetDlgItemText(hDlg,IDC_TEXT,"");
								return TRUE;
							}

							strcpy(xcflasher_password,temp);
							xcflasher_extendpassword();

							cmd_init();
							cmd_add("w-",0,"",xcflasher_password);
							result = cmd_executeall();
							if (result)
							{
								MessageBox(xcflasher_hWnd,"Error while disabling write protection","XCFLASHER",0);
							}


							// strcpy(temp,"Please input the flash sector number(s) you want to unprotect:");
							// xcflasher_inputmode = DIALOG_WRITEPROTECTION_DISABLE_SECTORS;
							// SetDlgItemText(hDlg,IDC_PROMPT,temp);
							// SetDlgItemText(hDlg,IDC_TEXT,"");
							// return TRUE;

							// MessageBox(xcflasher_hWnd,temp,"DIALOG_WRITEPROTECTION_DISABLE",0);
							// ToDo: Call Write Protection Off Function
					break;

					case DIALOG_WRITEPROTECTION_ENABLE_SECTORS:
						// parse string for sectors

						result = xcflasher_parsesectors(temp,pflashmem->protection_sectors);
						if (result)
						{
							SetDlgItemText(hDlg,IDC_TEXT,"");

							return TRUE;
						}

						// sprintf(temp,"Password: %s! Sectors: %d",xcflasher_password,xcflasher_sectors);
						// MessageBox(xcflasher_hWnd,temp,"DIALOG_WRITEPROTECTION_ENABLE_SECTORS",0);
						sectors=0;
						for (i=0;i<xcflasher_sectors;i++)
						{
							sectors = sectors | (1 << xcflasher_sector[i]);
						}
						cmd_init();
						cmd_add("ws+",sectors,"",xcflasher_password);
						result = cmd_executeall();
						if (result)
						{
							MessageBox(xcflasher_hWnd,"Error while enabling write protection","XCFLASHER",0);
						}



					break;


					case DIALOG_READPROTECTION_ENABLE:
							if (strlen(temp)>8)
							{
								// password too long
								SetDlgItemText(hDlg,IDC_TEXT,"");
								return TRUE;
							}

							strcpy(xcflasher_password,temp);
							xcflasher_extendpassword();

							// sprintf(temp,"Password: %s!",xcflasher_password);
							// MessageBox(xcflasher_hWnd,temp,"DIALOG_READPROTECTION_ENABLE",0);
							cmd_init();
							cmd_add("r+",0,"",xcflasher_password);
							result = cmd_executeall();
							if (result)
							{
								MessageBox(xcflasher_hWnd,"Error while enabling write protection","XCFLASHER",0);
							}


					break;
					case DIALOG_READPROTECTION_DISABLE:

							if (strlen(temp)>8)
							{
								// password too long
								SetDlgItemText(hDlg,IDC_TEXT,"");
								return TRUE;
							}

							strcpy(xcflasher_password,temp);
							xcflasher_extendpassword();
							
							// sprintf(temp,"Password: %s!",xcflasher_password);
							// MessageBox(xcflasher_hWnd,temp,"DIALOG_READPROTECTION_DISABLE",0);
							cmd_init();
							cmd_add("r-",0,"",xcflasher_password);
							result = cmd_executeall();
					break;

				}

				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}

			if (LOWORD(wParam) == IDCANCEL)
			{
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}

			break;
	}
    return FALSE;
}


int testcounter = 0;

void xcflasher_redraw(void)
{
	RECT rt;

	GetClientRect(xcflasher_hWnd, &rt);
	InvalidateRect(xcflasher_hWnd, &rt,FALSE);
	UpdateWindow(xcflasher_hWnd);
}


void xcflasher_displayfile(HWND hWnd,HDC hdc)
{
	RECT rt,rt2;
	COLORREF color;
	HFONT textfont;
	char fontname[30];
	int filewindow_height;
	int rows;
	int cols;
	int i,j;
	unsigned long row_address;
	unsigned long row_startaddress;
	char temp[255];
	unsigned char buffer[64];



	if (!xcflasher_fileselected)
	{
		strcpy(xcflasher_filename,"NO FILE SELECTED");
	}

	// get file window rectangle 
	rt = xcflasher_filewindow;	

	// prepare font
	color = FILEWINDOW_TEXTCOLOR2;
	SetTextColor(hdc,color);
	color = FILEWINDOW_BACKCOLOR;
	SetBkColor(hdc,color);
	strcpy(fontname,"ARIAL");
	textfont=CreateFont(12,6,0,0,FW_NORMAL,0,0,0,ANSI_CHARSET,0,0,0,0,fontname);
	SelectObject(hdc,textfont);
	rt.left = 5;
	rt.top = rt.top+5;

	// write filename
	DrawText(hdc, xcflasher_filename, strlen(xcflasher_filename), &rt,DT_LEFT);

	if (xcflasher_fileselected)
	{

		rt.top = 30;
		rt.bottom = rt.bottom-5;
		rt.right = rt.right-5;
		filewindow_height = rt.bottom-rt.top;
		rows = filewindow_height / FILEWINDOW_ROWHEIGHT;

		cols = ((rt.right-rt.left-80)/FILEWINDOW_COLWIDTH / 16)*16;
		if (cols<16) cols=16;

		row_startaddress = mem_getlowestaddress()+ GetScrollPos(xcflasher_hWndScroll,SB_CTL)*cols;

		for (i=0;i<rows;i++)
		{
			rt2.left = rt.left;
			rt2.right = rt2.left+80;
			rt2.top = rt.top+i*FILEWINDOW_ROWHEIGHT;
			rt2.bottom = rt2.top+FILEWINDOW_ROWHEIGHT;
			row_address = row_startaddress+i*cols;
			sprintf(temp,"%08X: ",row_address);
			DrawText(hdc, temp, strlen(temp), &rt2,DT_LEFT);

			mem_read(row_address,cols,buffer);

			rt2.left+= 80;
			rt2.right+= 80;

			for (j=0;j<cols;j++)
			{
				sprintf(temp,"%02X",buffer[j]);
				DrawText(hdc, temp, 2, &rt2,DT_LEFT);
				rt2.left+=FILEWINDOW_COLWIDTH;
				rt2.right+=FILEWINDOW_COLWIDTH;
			}
		}


	}

}



void xcflasher_drawfilescroll(void)
{
	if (xcflasher_fileselected)
	{
		SetWindowPos(xcflasher_hWndScroll,HWND_TOP,xcflasher_filewindow.right-20,0,20,xcflasher_filewindow.bottom-5,0);
		if (!xcflasher_scrollbarvisible)
		{
			ShowWindow(xcflasher_hWndScroll, 1);
 			UpdateWindow(xcflasher_hWndScroll);

			xcflasher_scrollbarvisible = 1;
		}
	}
	else
	{
		ShowWindow(xcflasher_hWndScroll, 0);
 		UpdateWindow(xcflasher_hWndScroll);
		xcflasher_scrollbarvisible = 0;
	}
}

void xcflasher_writelog(HWND hWnd,HDC hdc)
{
	char *logtext;
	RECT rt;
	HBRUSH hbr;
	int currentlogindex;
	int currentline=0;
	COLORREF color;
	HFONT textfont;
	char fontname[30];
	int logwindow_height;
	int textlines;

	// read log text from module text
	logtext = log_getlogtext(0);


	logwindow_height = xcflasher_logwindow.bottom-xcflasher_logwindow.top;
	textlines = logwindow_height / LOGWINDOW_LINEHEIGHT-1;
	
	
	// draw line
	rt = xcflasher_logwindow;
	rt.bottom = xcflasher_logwindow.top+4;
	color = LOGWINDOW_LINECOLOR1;
	hbr= CreateSolidBrush(color);
	FillRect(hdc,&rt,hbr);

	rt = xcflasher_logwindow;
	rt.top = xcflasher_logwindow.top+3;
	rt.bottom = xcflasher_logwindow.top+4;
	color = LOGWINDOW_LINECOLOR2;
	hbr= CreateSolidBrush(color);
	FillRect(hdc,&rt,hbr);


	// prepare font
	color = LOGWINDOW_TEXTCOLOR;
	SetTextColor(hdc,color);
	color = LOGWINDOW_BACKCOLOR;
	SetBkColor(hdc,color);
	strcpy(fontname,"ARIAL");
	textfont=CreateFont(12,6,0,0,FW_NORMAL,0,0,0,ANSI_CHARSET,0,0,0,0,fontname);
	SelectObject(hdc,textfont);
	rt = xcflasher_logwindow;
	rt.left = 5;

	if ((currentlogindex = log_getlogbuffercount())<textlines)
		currentlogindex = 0;
	else
		currentlogindex = currentlogindex-textlines;

	while ((logtext = log_getlogtext(currentlogindex++))!=0)
	{
		DrawText(hdc, logtext, strlen(logtext), &rt,DT_LEFT);
		currentline++;
		rt.top = rt.top+LOGWINDOW_LINEHEIGHT;
		rt.bottom = rt.top+LOGWINDOW_LINEHEIGHT+10;
	}

}



void xcflasher_preparewindows(HWND hWnd,HDC hdc)
{
	HBRUSH hbr;
	COLORREF color;
	int totalwindowheight;

	// prepeare filewindow
	GetClientRect(hWnd, &xcflasher_filewindow);
	totalwindowheight = xcflasher_filewindow.bottom-xcflasher_filewindow.top;
	xcflasher_filewindow.bottom = totalwindowheight*(FILEWINDOW_PERCENT)/100;
	color = FILEWINDOW_BACKCOLOR;
	hbr= CreateSolidBrush(color);
	FillRect(hdc,&xcflasher_filewindow,hbr);

	// prepeare logwindow
	GetClientRect(hWnd, &xcflasher_logwindow);
	totalwindowheight = xcflasher_logwindow.bottom-xcflasher_logwindow.top;
	xcflasher_logwindow.top = totalwindowheight*(100-LOGWINDOW_PERCENT)/100;
	color = LOGWINDOW_BACKCOLOR;
	hbr= CreateSolidBrush(color);
	FillRect(hdc,&xcflasher_logwindow,hbr);

	xcflasher_windowsinitialized = 1;
}

void xcflasher_selectfile(char *filename)
{
	strcpy(xcflasher_filename,filename);
	xcflasher_fileselected = 1;
	SetScrollRange(xcflasher_hWndScroll,SB_CTL,1,100,TRUE);
}


int xcflasher_parsesectors(char *sectorstring, int sectors)
{
	int i=0;
	int j=0;
	char *currentvalstring;
	int prevvalue=-1;
	int currvalue=0;
	char separator;

	// first look for other chars than 0-9,- and ,
	while ((sectorstring[i]!=0) && (((sectorstring[i]>=48) && (sectorstring[i]<=57)) || (sectorstring[i]==',') || (sectorstring[i]=='-')))
		i++;

	if (sectorstring[i]!=0)
		return 1;

	if (sectorstring[0]=='-')
		return 2;

	if (sectorstring[0]==0)
		return 3;


	xcflasher_sectors = 0;
	eliminatespaces(sectorstring);
	// xcflasher_sector[xcflasher_sectors++]=atoi(sectorstring);
	currentvalstring = sectorstring;
	i=0;
	while (sectorstring[i]!=0)
	{
		if ((sectorstring[i]==',') || (sectorstring[i]=='-'))
		{
			separator = sectorstring[i];
			sectorstring[i]=0;
			
			currvalue = atoi(currentvalstring);

			if (prevvalue>=0)
			{
				for (j=prevvalue;j<=currvalue;j++)
					xcflasher_sector[xcflasher_sectors++]=j;

				prevvalue=-1;
			}
			else
			{
				if (separator=='-')
					prevvalue = currvalue;
				else
				{
					xcflasher_sector[xcflasher_sectors++]=currvalue;
					prevvalue=-1;
				}
			}
			currentvalstring = &sectorstring[i+1];

		}

		i++;
	}

	currvalue = atoi(currentvalstring);

	if ((currvalue<0) || (currvalue>=sectors))
		return 4;

	if (prevvalue>=0)
	{
		for (j=prevvalue;j<=currvalue;j++)
			xcflasher_sector[xcflasher_sectors++]=j;
	}
	else
	{
		xcflasher_sector[xcflasher_sectors++]=currvalue;
	}
	
	return 0;
}

void xcflasher_extendpassword(void)
{
	// fill up with spaces
	int i;
	for (i=strlen(xcflasher_password);i<8;i++)
		xcflasher_password[i]=' ';

	xcflasher_password[8] = 0;

}

void xcflasher_recalc_scrollbarrange(void)
{
	int	cols = ((xcflasher_filewindow.right-xcflasher_filewindow.left-80)/FILEWINDOW_COLWIDTH / 16)*16;
	int rows = (xcflasher_filewindow.bottom-xcflasher_filewindow.top)/FILEWINDOW_ROWHEIGHT;
	int min = 0;
	int max = 0;
	if (cols<16) cols = 16;
	max = (mem_getusedlength()+cols)/cols-rows+2;
	SetScrollRange(xcflasher_hWndScroll,SB_CTL,min,max,TRUE);

}

void xcflasher_setpath(void)
{
	unsigned int i=0;
	strcpy(xcflasher_path,GetCommandLine()+1);
	
	// search for end of string or the first space
	while ((i<strlen(xcflasher_path)) && (xcflasher_path[i]!=' '))
		i++;

	// search for last backslash 
	while ((i>0) && (xcflasher_path[i]!='\\'))
		i--;

	xcflasher_path[i+1]=0;


}


char full[255];

char *xcflasher_extendfullpath(char *filename)
{
	
	if (strstr(filename,":")!=NULL)
		return filename;
	else
	{
		strcpy(full,xcflasher_path);
		strcat(full,filename);
		return full;
	}
}


