/*****************************************************************************/
/* XC FLASHER                                                                */
/* cmd.cpp : command queue and command execution                             */
/*****************************************************************************/
/* program, erase, protect, unprotect and test flashes                       */
/* for the c167, xc167 microcontroller family                                */
/*                                                                           */
/* (c) 2003 by Infineon                                                      */
/* Christian Perschl                                                         */
/*****************************************************************************/

#include "stdafx.h"
#include "cmd.h"
#include "comm.h"
#include "rs232.h"
#include "flash.h"
#include "log.h"
#include "common.h"
#include "prefs.h"


t_cmd cmd_queue[MAXCMD];
int cmd_count;

/*****************************************************************************/
/* cmd_init                                                                  */
/*---------------------------------------------------------------------------*/
/* initializes and clears command queue                                      */
/*****************************************************************************/
void cmd_init(void)
{
	int i;

	for (i=0;i<MAXCMD;i++)
	{
		cmd_queue[i].cmd=0;
		cmd_queue[i].sector=ALLSECTORS;
		cmd_queue[i].filename=0;
		cmd_queue[i].password=0;
	}
	cmd_count = 0;
}

/*****************************************************************************/
/* cmd_add                                                                   */
/*---------------------------------------------------------------------------*/
/* adds a command to command queue                                           */
/*****************************************************************************/
void cmd_add(char *cmd, int sector, char *filename, char *password)
{
	cmd_queue[cmd_count].cmd=cmd;
	cmd_queue[cmd_count].sector=sector;
	cmd_queue[cmd_count].filename=filename;
	cmd_queue[cmd_count].password=password;
	cmd_count++;
}

/*****************************************************************************/
/* cmd_print                                                                 */
/*---------------------------------------------------------------------------*/
/* displays all commands currently in command queue                          */
/*****************************************************************************/
void cmd_print(void)
{
	char temp[255];
	int i;
	
	log_write(MODULE_CMD,"commands in queue:");
	for (i=0;i<cmd_count;i++)
	{
		sprintf(temp,"       command: %s sector: %d filename: %s password: %s",cmd_queue[i].cmd,cmd_queue[i].sector,cmd_queue[i].filename,cmd_queue[i].password);
		log_write(MODULE_CMD,temp);
	}
}

/*****************************************************************************/
/* cmd_executeall                                                            */
/*---------------------------------------------------------------------------*/
/* executes all commands currently in command queue                          */
/*****************************************************************************/
int cmd_executeall(void)
{
	int i = 0;
	int result = 0;

	while ((i<cmd_count) && (!result))
	{
		result = cmd_execute(i);
		i++;
	}

	return result;
}

/*****************************************************************************/
/* cmd_execute                                                               */
/*---------------------------------------------------------------------------*/
/* executes a specific commands out from command queue                       */
/*****************************************************************************/
int cmd_execute(int cmd_number)
{
	int result;
	int i;
	char temp[255];
	char *loader;
	char *minimon;
	unsigned short regbuffer[64];
	unsigned short regcount;


	sprintf(temp,"Executing command '%s'...",cmd_queue[cmd_number].cmd);
	log_write(MODULE_CMD,temp);

	// connect command
	if (strcmp(cmd_queue[cmd_number].cmd,"c")==0)
	{
		loader=prefs_getloaderfilename();
		minimon=prefs_getminimonfilename();
		result=comm_connect(loader,minimon);
	}

	// verify command
	if (strcmp(cmd_queue[cmd_number].cmd,"v")==0)
	{
		xcflasher_selectfile(cmd_queue[cmd_number].filename);
		result=flash_verify(cmd_queue[cmd_number].filename);
	}

	// program command
	if (strcmp(cmd_queue[cmd_number].cmd,"p")==0)
	{
		xcflasher_selectfile(cmd_queue[cmd_number].filename);
		result=flash_program(cmd_queue[cmd_number].filename);
	}

	// erase all command
	if (strcmp(cmd_queue[cmd_number].cmd,"e")==0)
	{
		result=flash_eraseall();
	}

	// erase sector command
	if (strcmp(cmd_queue[cmd_number].cmd,"es")==0)
	{
		result=flash_erasesector(cmd_queue[cmd_number].sector);
	}

	// enable sector write protection command
	if (strcmp(cmd_queue[cmd_number].cmd,"ws+")==0)
	{
		result=flash_writeprotection_enable(cmd_queue[cmd_number].sector,cmd_queue[cmd_number].password);
		log_write(MODULE_CMD,"Please check flash status registers to prove the protection enabling");
	}

	// disable sector write protection command
	if (strcmp(cmd_queue[cmd_number].cmd,"w-")==0)
	{
		result=flash_writeprotection_disable(cmd_queue[cmd_number].password);
		log_write(MODULE_CMD,"Please check flash status registers to prove the protection disabling");
	}

	// enable read protection command
	if (strcmp(cmd_queue[cmd_number].cmd,"r+")==0)
	{
		result=flash_readprotection_enable(cmd_queue[cmd_number].password);
		log_write(MODULE_CMD,"Please check flash status registers to prove the protection enabling");
	}

	// disable read protection command
	if (strcmp(cmd_queue[cmd_number].cmd,"r-")==0)
	{
		result=flash_readprotection_disable(cmd_queue[cmd_number].password);
		log_write(MODULE_CMD,"Please check flash status registers to prove the protection disabling");
	}

	// read status register
	if (strcmp(cmd_queue[cmd_number].cmd,"s")==0)
	{
		result=flash_getstatus(regbuffer,&regcount);
		t_memory *pflashmem;
		pflashmem = prefs_getflashinfos();

		if (result==0)
		{
			for (i=0;i<regcount;i++)
			{
				sprintf(temp,"Flash Status Register (%d): %s=%04X",i,pflashmem->statusreg[i].name,regbuffer[i]);
				log_write(MODULE_CMD,temp);
			}
		}
	}

	if (result)
	{
		sprintf(temp,"ERROR: errorcode(%d)",result);
		log_write(MODULE_CMD,temp);
	}
	else
		log_write(MODULE_CMD,"successful");

	return result;
}


/*****************************************************************************/
/* cmd_bringup                                                               */
/*---------------------------------------------------------------------------*/
/* connects to a target and executes several commands                        */
/*****************************************************************************/
int cmd_bringup(void)
{
	unsigned char tdata[20];
	unsigned char tdata2[20];
	unsigned short data16;
	unsigned short data16b;
	unsigned short registers1[8];
	unsigned short registers2[8];
	int result;
	int i;


	// 1. Connect
	result = comm_connect("Mcprog\\Load.hex","Mcprog\\Minimon.hex");
	// sprintf(temp,"Connect: %d",result);
	// log_write(temp);
	if (result)
		return 1;

	// 2. Write 16 Bytes
	strcpy((char *) tdata,"HALLO DUMMERCHEN");
	result = comm_write(0x00F600,16,tdata);
	// sprintf(line,"Write: %d",result);
	// log_write(temp);
	if (result)
		return 2;

	// 3. Readback 16 Bytes
	result = comm_read(0x00F600,16,tdata2);
	tdata2[16] = 0;
	// sprintf(line,"Read: %d %s",result,tdata2);
	// log_write(temp);
	if (result)
		return 3;
	if (strcmp((char *) tdata,(char *) tdata2)!=0)
		return 4;

	// 4. Write Word
	data16 = 0x1234;
	result = comm_writeword(0x00F700,data16);
	// sprintf(line,"Writeword: %d",result);
	// log_write(temp);
	if (result)
		return 5;

	// 5. Readback Word
	result = comm_read(0x00F700,2,(unsigned char*) &data16b);
	// sprintf(line,"Read: %d %04X",result,data16);
	// log_write(temp);
	if (result)
		return 6;
	if (data16!=data16b)
		return 7;

	// 6. EINIT
	result = comm_einit();
	if (result)
		return 8;

	// 7. TEST
	result = comm_test();
	if (result)
		return 9;

	// 8. CALL
	// load a little subroutine into internal ram at 0xF800
	// which increments the parameters R8-R15 by 1 and returns
	// 8.1 set up subroutine
    tdata[0]=0x08;
	tdata[1]=0x81;
	tdata[2]=0x08;
	tdata[3]=0x91;
	tdata[4]=0x08;
	tdata[5]=0xA1;
	tdata[6]=0x08;
	tdata[7]=0xB1;
	tdata[8]=0x08;
	tdata[9]=0xC1;
	tdata[10]=0x08;
	tdata[11]=0xD1;
	tdata[12]=0x08;
	tdata[13]=0xE1;
	tdata[14]=0x08;
	tdata[15]=0xF1;
	tdata[16]=0xDB;
	tdata[17]=0x00;
	// 8.2. download subroutine
	result = comm_write(0x00F800,18,tdata);
	// 8.3. prepare registers
	registers1[0] = 0x0001;
	registers1[1] = 0x0022;
	registers1[2] = 0x1234;
	registers1[3] = 0x5555;
	registers1[4] = 0x8382;
	registers1[5] = 0x2367;
	registers1[6] = 0x9999;
	registers1[7] = 0x0000;
	// 8.4. call subroutine
	result = comm_call(0xF800, registers1, registers2);
	if (result)
		return 10;
	for (i=0;i<8;i++)
		if (registers1[i]!=registers2[i]-1)
			return 11;

	// 9. SRST
	result = comm_srst();
	if (result)
		return 12;


	rs232_close();

	return 0;
}





