/*****************************************************************************/
/* XC FLASHER                                                                */
/* parse.h : command queue and command execution                             */
/*****************************************************************************/
/* program, erase, protect, unprotect and test flashes                       */
/* for the c167, xc167 microcontroller family                                */
/*                                                                           */
/* (c) 2003 by Infineon                                                      */
/* Christian Perschl                                                         */
/*****************************************************************************/

int parse_commandline(char *string);
void parser_extendpassword(char *password);