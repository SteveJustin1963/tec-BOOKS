/*****************************************************************************/
/* XC FLASHER                                                                */
/* mem.cpp : buffering for files (imaging of hardware memory)                */
/*****************************************************************************/
/* program, erase, protect, unprotect and test flashes                       */
/* for the c167, xc167 microcontroller family                                */
/*                                                                           */
/* (c) 2003 by Infineon                                                      */
/* Christian Perschl                                                         */
/*****************************************************************************/

#include "stdafx.h"
#include "mem.h"
#include "log.h"
#include <stdio.h>
#include "common.h"

unsigned char mem_buffer[MAXBUFFERSIZE];
unsigned long mem_lowestaddress;
unsigned long mem_highestaddress;


t_selection mem_selection[MAXSELECTIONS];
int mem_selectioncount;

/*****************************************************************************/
/* mem_init                                                                  */
/*---------------------------------------------------------------------------*/
/* initializes and clears mem module                                         */
/*****************************************************************************/
void mem_init(void)
{
   mem_fill(0);
   mem_lowestaddress = 0xFFFFFFFF;
   mem_highestaddress = 0x00000000;
   mem_selectioncount = 0;
}

/*****************************************************************************/
/* mem_write                                                                 */
/*---------------------------------------------------------------------------*/
/* writes data into buffer                                                   */
/*****************************************************************************/
void mem_write(unsigned long startaddress, unsigned long length, unsigned char *srcbuf)
{
	memcpy(mem_buffer+startaddress,srcbuf,length);

	if (mem_lowestaddress>startaddress)
		mem_lowestaddress = startaddress;

	if (mem_highestaddress<startaddress+length-1)
		mem_highestaddress = startaddress+length-1;
}

/*****************************************************************************/
/* mem_read                                                                  */
/*---------------------------------------------------------------------------*/
/* reads data from buffer                                                    */
/*****************************************************************************/
void mem_read(unsigned long startaddress, unsigned long length, unsigned char *dstbuf)
{
	memcpy(dstbuf,mem_buffer+startaddress,length);
}

/*****************************************************************************/
/* mem_getbufferaddress                                                      */
/*---------------------------------------------------------------------------*/
/* reads data from buffer                                                    */
/*****************************************************************************/
unsigned char* mem_getbufferaddress(void)
{
	return mem_buffer;
}

/*****************************************************************************/
/* mem_fill                                                                  */
/*---------------------------------------------------------------------------*/
/* fills buffer with fillchar                                                */
/*****************************************************************************/
void mem_fill(unsigned char fillchar)
{
	memset((void *) mem_buffer,fillchar,MAXBUFFERSIZE);
}

/*****************************************************************************/
/* mem_readused                                                              */
/*---------------------------------------------------------------------------*/
/* fills buffer with fillchar                                                */
/*****************************************************************************/
unsigned long mem_readused(unsigned char *dstbuf)
{
	memcpy(dstbuf,mem_buffer+mem_lowestaddress,mem_highestaddress-mem_lowestaddress+1);
	return mem_highestaddress-mem_lowestaddress+1;
}

/*****************************************************************************/
/* mem_getlowestaddress                                                      */
/*---------------------------------------------------------------------------*/
/* returns the lowest used address                                           */
/*****************************************************************************/
unsigned long mem_getlowestaddress(void)
{
	return mem_lowestaddress;
}

/*****************************************************************************/
/* mem_getusedlength                                                         */
/*---------------------------------------------------------------------------*/
/* returns the totaly used length                                            */
/*****************************************************************************/
unsigned long mem_getusedlength(void)
{
	return mem_highestaddress-mem_lowestaddress+1;
}


/*****************************************************************************/
/* mem_addselection                                                          */
/*---------------------------------------------------------------------------*/
/* add selection                                                             */
/*****************************************************************************/
void mem_addselection(unsigned long startaddress, unsigned long length)
{
	if (mem_selectioncount == 0)
	{
		mem_selection[mem_selectioncount].startaddress = startaddress;
		mem_selection[mem_selectioncount].length = length;
		mem_selectioncount++;
	}
	else
	{
		// before adding, a simple optimization:
		// look if this selection connects to the previous selection
		if (startaddress==mem_selection[mem_selectioncount-1].startaddress+
			mem_selection[mem_selectioncount-1].length)
		{
			mem_selection[mem_selectioncount-1].length+= length;
		}
		else
		{
			mem_selection[mem_selectioncount].startaddress = startaddress;
			mem_selection[mem_selectioncount].length = length;
			mem_selectioncount++;
		}
	}
}

/*****************************************************************************/
/* mem_addselection                                                          */
/*---------------------------------------------------------------------------*/
/* optimize selections by sorting and concenating                            */
/*****************************************************************************/
void mem_optimizeselections(void)
{
	int i;
	int j;
	t_selection temp;

	// 1. sort selections by startaddress and length
	for (i=0;i<mem_selectioncount;i++)
		for (j=0;j<mem_selectioncount;j++)
		{
			if ((mem_selection[i].startaddress<mem_selection[j].startaddress) ||
				((mem_selection[i].startaddress==mem_selection[j].startaddress) &&
				 (mem_selection[i].length<mem_selection[j].length)))
			{
				// swap
				temp = mem_selection[i];
				mem_selection[i] = mem_selection[j];
				mem_selection[j] = temp;
			}

		}

	// 2. concenate overlapping selections
	for (i=0;i<mem_selectioncount-1;i++)
	{

		// look if this and the next selection overlap or are located side by side
		while ((i<mem_selectioncount-1) && (mem_selection[i].startaddress+mem_selection[i].length>=mem_selection[i+1].startaddress))
		{
			//they overlap
			// -> concenate
			mem_selection[i].length = mem_selection[i+1].startaddress-mem_selection[i].startaddress+mem_selection[i+1].length;

			// remove the following selection
			// by shifting all afterfollowing selections
			for (j=i+1;j<mem_selectioncount-1;j++)
			{
				mem_selection[j]=mem_selection[j+1];
			}
			mem_selectioncount--;

			// maybe further selections overlap
			// therefore continue at position i
		}
	}


}



/*****************************************************************************/
/* mem_clearselections                                                       */
/*---------------------------------------------------------------------------*/
/* clear all selections                                                      */
/*****************************************************************************/
void mem_clearselections(void)
{
   mem_selectioncount = 0;
}

/*****************************************************************************/
/* mem_getselection                                                          */
/*---------------------------------------------------------------------------*/
/* return next selection                                                     */
/*****************************************************************************/
t_selection *mem_getselection(t_selection *startsel)
{
	int selindex=0;

	if ((startsel == NULL) && (mem_selectioncount>0))
	{
		return &mem_selection[0];
	}
	{
		while ((selindex<mem_selectioncount) && (&mem_selection[selindex]!=startsel))
			selindex++;
	}

	if (selindex+1<mem_selectioncount)
	{
		// next selection found
		return &mem_selection[selindex+1];
	}
	else
		return 0;

}



/*****************************************************************************/
/* mem_print                                                                 */
/*---------------------------------------------------------------------------*/
/* displays buffer content                                                   */
/*****************************************************************************/
void mem_print(unsigned long startaddress, unsigned long length)
{
	unsigned long i;
	unsigned long j;
	unsigned int cols;
	char temp[255];

	for (i=0;i<length;i+=16)
	{
		sprintf(temp,"\n %08X: ",startaddress+i);
		log_write(MODULE_MEM,temp);
		if (i+16<length)
			cols = 16;
		else
			cols = length - i;
		for (j=0;j<cols;j++)
		{
			sprintf(temp,"%02X ",mem_buffer[startaddress+i+j]);
			log_write(MODULE_MEM,temp);
		}
	}
	
	sprintf(temp,"lowestaddress: 0x%08X highestaddress: 0x%08X",mem_lowestaddress,mem_highestaddress);
	log_write(MODULE_MEM,temp);
}


/*****************************************************************************/
/* mem_printselections                                                       */
/*---------------------------------------------------------------------------*/
/* lists all selections                                                      */
/*****************************************************************************/
void mem_printselections(void)
{
	int i;
	char temp[255];

	for (i=0;i<mem_selectioncount;i++)
	{
		sprintf(temp,"Selection %2d: Startaddress=0x%08X Length=0x%08X",i,mem_selection[i].startaddress,mem_selection[i].length);
		log_write(MODULE_MEM,temp);
	}
	
	sprintf(temp,"%d Selections at all",mem_selectioncount);
	log_write(MODULE_MEM,temp);
}













