/*****************************************************************************/
/* XC FLASHER                                                                */
/* misc.h   : miscellaneous and universal functions                          */
/*****************************************************************************/
/* program, erase, protect, unprotect and test flashes                       */
/* for the c167, xc167 microcontroller family                                */
/*                                                                           */
/* (c) 2003 by Infineon                                                      */
/* Christian Perschl                                                         */
/*****************************************************************************/


#if !defined(MISC_H_INCLUDED)
#define MISC_H_INCLUDED


int fileexists(char *filename);
void eliminatespaces(char *string);


#endif
