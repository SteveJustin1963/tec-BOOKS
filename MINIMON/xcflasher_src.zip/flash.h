/*****************************************************************************/
/* XC FLASHER                                                                */
/* flash.h : the flash routines                                              */
/*****************************************************************************/
/* program, erase, protect, unprotect and test flashes                       */
/* for the c167, xc167 microcontroller family                                */
/*                                                                           */
/* (c) 2003 by Infineon                                                      */
/* Christian Perschl                                                         */
/*****************************************************************************/

#include "stdafx.h"
#include "comm.h"
#include "rs232.h"
#include "mem.h"
#include "ihex.h"
#include <stdio.h>

#if !defined(FLASH_H_INCLUDED)
#define FLASH_H_INCLUDED


#define FLASH_PROGRAM     0x00
#define FLASH_ERASESECTOR 0x01
#define FLASH_ERASEALL    0x02
#define FLASH_STATUS      0x06
#define FLASH_PROTECT     0x20
#define FLASH_UNPROTECT   0x21
#define FLASH_LOCK        0x10
#define FLASH_UNLOCK      0x11
#define FLASH_SETTIMING   0x04


void flash_init(void);
int flash_isfeature(char *feature);
int flash_loaddriver(void);
void flash_invalidatedriver(void);

int flash_eraseall(void);
int flash_program(char *filename);
int flash_verify(char *filename);
int flash_erasesector(int sectornr);
int flash_writeprotection_enable(int sectornr, char *password);
int flash_writeprotection_disable(char *password);
int flash_readprotection_enable(char *password);
int flash_readprotection_disable(char *password);
int flash_getstatus(unsigned short *regbuffer,unsigned short *regnumbers);

#endif




