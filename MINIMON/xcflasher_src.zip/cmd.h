/*****************************************************************************/
/* XC FLASHER                                                                */
/* cmd.h : command queue and command execution                               */
/*****************************************************************************/
/* program, erase, protect, unprotect and test flashes                       */
/* for the c167, xc167 microcontroller family                                */
/*                                                                           */
/* (c) 2003 by Infineon                                                      */
/* Christian Perschl                                                         */
/*****************************************************************************/


#if !defined(CMD_H_INCLUDED)
#define CMD_H_INCLUDED

#define MAXCMD 32
#define ALLSECTORS 255

struct t_cmd
{
	char* cmd;
	int sector;
	char* filename;
	char* password;
};

void cmd_init(void);
void cmd_add(char *cmd, int sector, char *filename, char *password);
void cmd_print(void);
int cmd_executeall(void);
int cmd_execute(int cmd_number);
int cmd_bringup(void);

#endif
