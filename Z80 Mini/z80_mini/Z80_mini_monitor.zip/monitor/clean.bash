#! /bin/bash
find . -name "*.log" -exec rm {} \;
find . -name "*.rom" -exec rm {} \;
find . -name "*.hex" -exec rm {} \;
