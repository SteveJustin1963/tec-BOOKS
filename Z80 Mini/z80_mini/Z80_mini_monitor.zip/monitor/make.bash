#!/bin/bash
zasm -2vwx $1
