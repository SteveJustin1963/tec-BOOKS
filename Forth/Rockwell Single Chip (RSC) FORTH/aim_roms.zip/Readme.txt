The filenames correspond to the identification markings on the original
chips. The factory numbers appear to relate to the component designation
on the planar. R3225 and R3226 are the BASIC interpreter. R3224 is the
AIM assembler. R3223 is the AIM monitor. R3222 is not labeled and I
have not gone back to the manuals to check it out.

The sillicon used was a 2532 (4k x 8) part with a 450nS access time. I
believe that the programming voltage is 25v. Some later AIM boards
allowed the use of 2532 or 2732 parts by changing about 6 jumpers. All
but one of my boards is non-configurable. The one that's configurable is
made by Dynatech for Rockwell. It must be a really late model since
Rockwell didn't manufacture it.

