RAM images for the PB-1000 emulator.
