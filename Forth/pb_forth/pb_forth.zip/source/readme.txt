Source files for the PB-1000 Forth

1. Assemble the files FORTH.S and FORTHDIC.S with the assembler HD61 available
 at http://www.geocities.jp/hd61700lab/

2. Transfer the files FORTH.EXE, FORTHDIC.BIN and FORTH.FOR to the PB-1000

3. Launch the program FORTH.EXE then type the command LOAD FORTH.FOR to add
 to the dictionary file FORTHDIC.BIN remaining words defined in Forth.

4. Exit Forth with the command MON, then delete the file FORTH.FOR
