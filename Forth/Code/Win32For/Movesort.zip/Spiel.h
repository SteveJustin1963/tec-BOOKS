#define IDB_FLAGGEN     195
#define G_EINGABEN      103
#define T_TEILUNG2      120
#define T_MISCHEN2      121
#define T_REPRO         122
#define G_ERGEBNIS      107
#define T_ABSCHLUSS     123
#define T_SORTUEBER     109
#define T_SORTIERUNG    124
#define G_VERBRAUCH     111
#define T_ZUEGE2        125
#define B_SCHLIESSEN    106
#define B_NOCH_EINMAL   101
#define T_SEKUNDEN      126
#define T_TEILUNG4      130
#define T_TEILUNG       102
#define T_MISCHEN3      132
#define T_MISCHEN       131
#define R_REPRO         104
#define B_BEGINNEN      105
#define T_TEILUNG3      130
#define ID_NEUES_SPIEL  100

#define DO_NEUES_SPIEL  180
#define DO_STATISTIC    190
#define ID_STATISTIK    119

