/*
    Mark 1 FORTH Computer Simulator
    Copyright (c) Andrew Holme 2006

    Usage: sim <filename.4th>
*/

#include <process.h>
#include <assert.h>
#include <stdio.h>

#define UART_DATA   0xE000
#define UART_STATUS 0xE001

static union {
    unsigned char _w[2];
    unsigned short w;
};

static union {
    unsigned char _ip[2];
    unsigned short ip;
};

unsigned char op, psp, rsp;
unsigned char ps[512], rs[512];
unsigned char micro[2048], macro[32768];
unsigned char alu_a, alu_b, alu_func;
unsigned char alu_cin;

short pc=0;

int cycles;
FILE *fin;


void Quit()
{
    fprintf(stderr, "\n%d cycles\n", cycles);
    exit(0);
}


char Peek(unsigned addr)
{
    int ch;

    switch (addr) {
        case UART_DATA:
            ch = fgetc(fin);
            if (ch==EOF) Quit();
            return ch=='\n' ? 13 : ch;

        case UART_STATUS:
            return 3; // tx empty, rx full
    }
    return macro[addr];
}


void Poke(unsigned addr, char byte)
{
    if (addr==UART_DATA)
        putchar(byte);
    else
        if (addr>=0x2000 && addr<0x8000)
            macro[addr] = byte;
}


char Adder(unsigned char *cout,
           unsigned char a,
           unsigned char b,
           unsigned char cin)
{
    union {
        short s;
        struct { unsigned f:8; unsigned cout:1; } out;
    };

    s = a+b+cin;
    *cout = out.cout;
    return out.f;
}


char ALU(unsigned char *cout)
{
    switch (alu_func) {
        // Arithmetic
        case 0x0: return Adder(cout, alu_a,  alu_b, 0);         // ADD
        case 0x1: return Adder(cout, alu_a,  alu_b, alu_cin);   // ADC
        case 0x2: return Adder(cout, alu_a, ~alu_b, 1);         // SUB
        case 0x3: return Adder(cout, alu_a, ~alu_b, alu_cin);   // SBB
        case 0x4: return Adder(cout, alu_a,  alu_a, 0);         // ASL
        case 0x5: return Adder(cout, alu_a,  alu_a, alu_cin);   // ROL
    }
    *cout=0;
    switch (alu_func) {
        // Logic
        case 0xA: return alu_a & alu_b;         // AND
        case 0xB: return alu_a | alu_b;         // OR
        case 0xC: return ~alu_a;                // NOT
        case 0xD: return alu_a ^ alu_b;         // XOR
    }

    fprintf(stderr, "\nUnsupported ALU function\n");
    exit(-1);
}


void Step()
{
    unsigned char temp, flag_pl, flag_ne, flag_cs;

    union {
        unsigned char u;
        struct { unsigned dest:3; unsigned src:3; unsigned hl:1; } move;
        struct { unsigned dist:4; unsigned test:2; } skip;
    };

    // Fetch microcode instruction
    u = micro[pc++];

    switch (u >> 6) {
        case 0:
        case 1:
            // Move
            switch (move.src) {
                case 0: temp =  _w[move.hl];        break;  // W
                case 1: temp = _ip[move.hl];        break;  // IP
                case 2: temp = ps[2*psp+move.hl];   break;  // TOS
                case 3: temp = rs[2*rsp+move.hl];   break;  // R
                case 4: temp = Peek(w);             break;  // Memory[W]
                case 5: temp = Peek(ip);            break;  // Memory[IP]
                case 6: temp = 0;                   break;  // Zero
                case 7: temp = ALU(&flag_cs);       break;  // ALU out
            }

            switch (move.dest) {
                case 0:  _w[move.hl] = temp;        break;  // W
                case 1: _ip[move.hl] = temp;        break;  // IP
                case 2: ps[2*psp+move.hl] = temp;   break;  // TOS
                case 3: rs[2*rsp+move.hl] = temp;   break;  // R
                case 4: Poke(w, temp);              break;  // Memory[W]
                case 5: op = temp;                  break;  // OP
                case 6: alu_a = temp;               break;  // ALU A
                case 7: alu_b = temp;               break;  // ALU B
            }
            break;

        case 2:
            switch (u >> 4) {
                case 0x8:
                    // Increment/decrement
                    switch (u & 0xF) {
                        case 0x0:   w--;    break;
                        case 0x1:  ip--;    break; 
                        case 0x2: psp--;    break;
                        case 0x3: rsp--;    break;
                        case 0x8:   w++;    break;
                        case 0x9:  ip++;    break;
                        case 0xA: psp++;    break;
                        case 0xB: rsp++;    break;
                    }
                    break;

                case 0x9:
                    // Jump direct
                    pc = u & 0xF;
                    break;

                case 0xA:                   
                    ALU(&alu_cin);      // Latch previous carry
                    alu_func = u & 0xF; // Set new ALU function
                    break;

                case 0xB:
                    // Jump indirect (XOP)
                    pc = op<<4;
            }
            break;

        case 3:
            // Skip (branch)
            temp = ALU(&flag_cs);

            // PL/NE mnemonics make sense using ALU function 0xC (NOT)
            flag_pl = temp >> 7;    // alu_a is positive (plus)
            flag_ne = temp != 0xFF; // alu_a not equal to zero

            switch (skip.test) {
                case 0: if (flag_pl) pc += skip.dist, cycles += skip.dist; break;
                case 1: if (flag_cs) pc += skip.dist, cycles += skip.dist; break;
                case 2: if (flag_ne) pc += skip.dist, cycles += skip.dist; break;
                case 3: break; // IRQ not supported
            }
    }
}


int Digit(char *s)
{
    if (*s>='a' && *s<='f') return *s-'a'+10;
    if (*s>='A' && *s<='F') return *s-'A'+10;
    return *s-'0';
}


#define Byte(s) (0x10*Digit(s) + Digit(s+1))
#define Word(s) (0x100*Byte(s) + Byte(s+2))


void Load(unsigned char *buf, char *fname)
{
    unsigned a, n, i;
    char s[80];
    FILE *fp;

    fp = fopen(fname, "r");
    assert(fp);

    while (fgets(s, 80, fp)) {
        n = Byte(s+1);
        a = Word(s+3);
        for (i=0; i<n; i++) buf[a+i] = Byte(s+2*i+9);
    }
    fclose(fp);
}


void main(int argc, char *argv[])
{
    if (argc==2) {
        fin = fopen(argv[1], "r");
        if (!fin) {
            fprintf(stderr, "Can't open: %s\n", argv[1]);
            return;
        }
    } else
        fin = stdin;

    Load(micro, "ROM.HEX");
    Load(macro, "Forth.HEX");

    for (;; cycles++) Step();
}
