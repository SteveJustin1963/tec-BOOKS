: x dup dup drop ;
: y drop 3 ;
: z drop 0 ;
