$800 org

: x ;

$1000 org

: y begin 0 0 bit-set? if x then again ;