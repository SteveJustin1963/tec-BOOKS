variable x1
variable x2

: x x1 @ x2 -! ;
