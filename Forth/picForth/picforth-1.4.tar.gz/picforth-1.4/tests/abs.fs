: x abs ;
