: timer ( n -- ) invert tmr0 ! ;
