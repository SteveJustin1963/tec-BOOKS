: x1 ;
: x2 ;
: xe ;

: x case
	1 of x1 endof
	2 of x2 endof
	xe
    endcase
;
