include ../libstrings.fs
: type ;
$ffd org
: fred ;
main : test c" hello" type fred c" world" type ;
