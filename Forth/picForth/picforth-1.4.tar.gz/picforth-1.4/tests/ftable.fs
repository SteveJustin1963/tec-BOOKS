ftable some-data
  table> 7 8 9 1
  table> 17 18 19 11
end-table

