: a ;
:: x ( n -- flag ) 3 < if a then ;