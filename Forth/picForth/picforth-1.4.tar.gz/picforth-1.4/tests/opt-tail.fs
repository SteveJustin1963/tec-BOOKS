: x ;
: y ;
: z x y ;
