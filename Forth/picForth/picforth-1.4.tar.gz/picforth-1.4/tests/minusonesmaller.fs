: x ;
: y -1 < if x then ;
