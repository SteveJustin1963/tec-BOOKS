: x ;
: y ;

: z x dup if y then ;