: sometest 1 ;
: dosomething ;
: unreachable ;
: test exit sometest if dosomething then unreachable ;
