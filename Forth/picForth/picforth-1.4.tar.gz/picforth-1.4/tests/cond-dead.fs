: test
         dup 1 = if
                 drop -1 exit
         else
                 2 = if
                         0 exit
                 then
         then
;
