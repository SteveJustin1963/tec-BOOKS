code foo
  porta adjust-bank ,f clrf
  eedata adjust-bank ,f clrf
  restore-bank
  return
end-code
