variable current
variable next

: x current @ 1+ 7 and next ! ;