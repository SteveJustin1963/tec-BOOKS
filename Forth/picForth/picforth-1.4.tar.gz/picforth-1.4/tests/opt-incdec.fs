: action ;
: action-times ( n -- ) begin action 1- dup while repeat drop ;