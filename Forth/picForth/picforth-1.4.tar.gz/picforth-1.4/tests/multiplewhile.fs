: y ; : z ; 
: x begin y while z while repeat ;
