: x 9 and ;
: y dup 9 and if x then ;
