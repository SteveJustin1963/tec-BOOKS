: x dup 0<> ;
