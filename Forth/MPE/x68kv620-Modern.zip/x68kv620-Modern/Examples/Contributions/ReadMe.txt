Contributions directory README.TXT

This directory contains code contributed by users for others to use,
and MPE thanks the contributors.

The contents of this directory are untouched by MPE who provide no
warranty at all on this code. Sorry about that.
