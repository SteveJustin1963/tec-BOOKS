
#include "omake.no"
#include "version.h"

#define  DEBUG_BOX_WORDS 0

/*

19980706 MSD014 Attempt to correct the behaviour of OMAKE when compiled with
                Watcom and Microsoft compilers.  Neither versions seem to
                want to re-build the .EXE when a .C is re-compiled.  The
                Borland version did do the Right Thing...  (Not flagged.)
                Also, allow setting of the SLEEP() time between creation of
                child processes when compiled as a Windows application,
                default that SLEEP() time to zero and change the SLEEP()
                time between looking at the status of the child process to
                100ms.

19980601 MSD013 There was code in OMAKE to change back to the "default"
                directory after each command was executed.  This stopped a
                build sequence from, say, changing to a sub-directory,
                fiddling about and then changing back.  I assume that this
                was disabled for a good reason, so I have altered the
                *default* behaviour, but put a switch in ('-y') to allow the
                change directory inhibition to be resurrected if need be.
                The version is 3.01.000.  Also, a bit of tidying up was done
                inhibit some of the warning messages that were being produced.

19980406 MSD012 Version number changed to 3.00.000.  Also, a small bug was
                fixed: the -V "print version number" option wasn't working.
                (I inserted a blank line at the start of the help text and
                it was *that* which was being used as the version number
                text. Not any more, it ain't...)

19971112 MSD011 Cosmetic changes to the help text.

19970806 MSD010 Added extra diagnostics.

19970725 MSD009 Added extra diagnostics to the "-d" option.  Not flagged.

19970724 MSD008 Added the "-m" option that causes the rebuilding if the target
                and dependant have the *same* date.  (Compare with the default
                where re-building is done only if the dependant is *newer* than
                the target.)

19970724 MSD007 Remove the "lies" from the help screen and the associated
                (un-used) baggage from the (non-operating) -D option.  These
                changes are not "flagged" since they consist of just line
                deletions.  Also, a bit of cosmetic hacking which *is* flagged.

19970721 MSD006 Altered to try *all* paths to generate a target.  Before this
                change, it would try to use the first implicit rule to make a
                target and, if it couldn't apply *that* rule, it wouldn't try
                any *other* implicit rules until it succeded.

19970519 MSD005 Add .EXTENSIONS targets.  (Compatibility with WMAKE.)

19970515 MSD004 Altered to try the default rules on the *prerequisites of a
                default rule.  Thus, default rules will be applied even if this
                means applying several default rules in a row to attain the
                generation of the required target.

19970514 MSD003 Altered to MPE version number scheme.

19970508 MSD002 Add .BEFORE and .AFTER targets.  (Compatibility with WMAKE.)

19970429 MSD001 Altered to return error code when an attempt was made to open
                a non-existant make file.

*/

/*------------------------------------------------------------------------*/

/*
 * make.c       An imitation of the Unix MAKE facility
 *
 * 88-10-01 v1.0         created by greg yachuk, placed in the public domain
 * 88-10-06 v1.1         changed prerequisite list handling
 * 88-11-17 v1.2  AB     added lots of options
 * 89-04-30 v1.3  AB     added environment flag MAKEFLAGS=
 * 89-06-16 v1.4  AB lib response file not working
 * 97-04-09 V1.0  MSD    Massage into an OTA make facility.
 * 98-04-09 V1.0  MSD    Massage into a PRACTICAL make facility.
 *
 */

/*------------------------------------------------------------------------*/

#if defined( __NT__ ) || defined( __WINDOWS__ ) || defined( __WINDOWS_386__ ) || defined( __CHEAP_WINDOWS__ ) || defined( _WIN32 ) || defined( __WIN32__ )
  #define FOR_WINDOWS 1
#else
  #define FOR_WINDOWS 0
#endif

#if     FOR_WINDOWS                                                                 /* MSD014 */
  #define VERSIONTYPE "for Windows"                                            /* MSD014 */
#else                                                                           /* MSD014 */
  #define VERSIONTYPE "for MS-DOS"                                             /* MSD014 */
#endif                                                                          /* MSD014 */

/*------------------------------------------------------------------------*/

#define FOR_BORLAND   0
#define FOR_MICROSOFT 0
#define FOR_WATCOM    0

#if defined(__BORLANDC__)
  #undef FOR_BORLAND
  #define FOR_BORLAND 1
  #define COMPILER "Borland"
#endif

#if defined(_MSC_VER)
  #undef FOR_MICROSOFT
  #define FOR_MICROSOFT 1
  #define COMPILER "Microsoft"
#endif

#if defined(__WATCOMC__)
  #undef FOR_WATCOM
  #define FOR_WATCOM 1
  #define COMPILER "Watcom"
#endif

#ifndef COMPILER
  #define COMPILER "Unknown"
#endif

/*------------------------------------------------------------------------*/

#if     FOR_WINDOWS
  #include <windows.h>
#endif

#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <memory.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <process.h>
#include <dos.h>
#include <io.h>
#include <direct.h>

#if     FOR_BORLAND
  #include <utime.h>
#else
  #include <sys/utime.h>
#endif

#if     FOR_MICROSOFT && !FOR_WINDOWS
  #include <time.h>
#endif

#include "Omake.h"
#include "Omstr.h"
#include "Omdec.h"

#define ZERO    0
#define ONE     1
#define TWO     2
#define DOUBLEQUOTE     ( '"' )
#define SPACE           ( ' ' )
#define EOS             ( '\0' )

#define PATH_SEPARATOR  ";"
#define FILE_SEPARATOR  "/\\"
#define RD_PERM         4                       /* access() function */

#define BOOL int

#define MAKEINI "default.mak"

FILE *fopenp( char *fname, char *type );
void add_metas( char *basename, char *preqname, char *targname );
void touch_file( char *targname );
void build( REGISTER shellptr *shellp );
void new_make( char **argv );
void usage( void );
void display_prereq( int location, char *targname, long targtime, char *preqname, long preqtime ); /* MSD010 */
void make_args( int argc, char **argv );
void display_datim( long when );

char  **resp_cmds;                              /* .RESPONSE commands */
char   *shell_cmds[] = {
        "dir", "type", "rem", "pause", "date", "time", "ren", "rename",
        "ver", "vol", "break", "verify", "mkdir", "md", "exit", "ctty",
        "echo", "if", "cls", "ch", "chdir", "rmdir", "rd", "copy", "del",
        "erase", "set", "for", "prompt", "path",
        NULL,
};

char    *makelist[] =                           /* List of possible makefile names */
{
        "makefile",
        "Makefile",
        NULL
};

static char version[] = { "OMAKE " VERSION };                                            /* MSD012 */

char    *usage_str[] =
{
  "",
  version,                                                                      /* MSD012 */
  "",
  "Usage : OMAKE [-f filename] [options] [target ...] [macro=value ...]",       /* MSD011 */
  "",
  "Options:",
  "",
  "    -f      The next argument is the name of a makefile",                    /* MSD011 */
  "    -C      Force forking shell for building target",                        /* MSD011 */
  "    -y      Inhibit directory changes by commands being executed",           /* MSD013 */
  "    -d      Show target dependencies",                                       /* MSD011 */
  "    -e      Environment variables override macro assignments",               /* MSD011 */
  "    -a      Force target updates",                                           /* MSD011 */
#if     FOR_WINDOWS
  "    -p<num> Set time to sleep between tasks ",                               /* MSD014 */
  "    -q<num> Set time to sleep at end",                                       /* MSD014 */
  "    -u<num> Set time to sleep after shell-launched child",                   /* MSD014 */
#endif  /* !FOR_WINDOWS */
  "    -i      Ignore error codes retunred by commands",                        /* MSD011 */
  "    -k      On error, abandon building current target, continue with others",/* MSD011 */
  "    -m      Rebuild if the dependant is the *same* date as the target",      /* MSD011 *//* MSD008 */
  "    -n      Don't execute, list actions",                                    /* MSD011 */
  "    -r      Don't use builtin rules from DEFAULT.MAK",                       /* MSD011 */
  "    -s      Run silently without listing actions",                           /* MSD011 */
  "    -S      Undo the effect of the -k option",                               /* MSD011 */
  "    -t      Touch the target files (bring them up to date)",                 /* MSD011 */
  "    -V      List the current program version",                               /* MSD011 */
  "",
  "Special target usage:",                                                      /* MSD011 */
  "",
  ".DEFAULT                Define default rule to build target",
  ".DONE / .BEFORE         Target to build, after all other targets are built",
  ".IGNORE                 Ignore all error codes during building of targets",
  ".INIT / .AFTER          First target to build, before any target is built",
  ".SILENT                 Do not echo commands",
  ".SUFFIXES / .EXTENSIONS The list for selecting implicit rules",
  NULL
};


targptr target_list;            /* list of target nodes */
fileptr file_list;                      /* list of file nodes */
symptr  symbol_list;            /* list of symbol nodes */
shellptr shell_list;            /* list of shell nodes */

targptr first_targ = NULL;      /* first target, in case nothing explicit */
targptr suffix_targ = NULL;     /* .SUFFIXES target pointer */

char  **tlist = NULL;           /* command line targets */
char  **flist = NULL;           /* command line make files */
char  **mlist = NULL;           /* command line macros */

int     tmax = 0;               /* max size of tlist */
int     fmax = 0;               /* max size of flist */
int     mmax = 0;               /* max size of mlist */

#define DEBUG_WANTACCESS        1
#define DEBUG_WANTSTRUCT        2
#define DEBUG_DEEP              9
short   debug = 0;              /* -d option */

short   forceshell = 0;         /* -C option */
short   inhibitCD = 0;          /* -y option */                                 /* MSD013 */
short   touchenv = 1;           /* -e option */
short   ignore = 0;             /* -i option */
short   single_ign = 0;         /* -k option */
short   noexec = 0;             /* -n option */
short   silent = 0;             /* -s option */
short   touch = 0;              /* -t option */
short   readdef = 1;            /* -r option */
short   force = 0;              /* -F option */
short   samedate = 0;           /* -m option */                                 /* MSD008 */

short   verprinted = 0;         /* Number of times version number printed.   */ /* MSD014 */
long    now;                    /* time at startup */

#if     FOR_WINDOWS                                                             /* MSD014 */
                                                                                /* MSD014 */
int     sleeptime  = 0;         /* MS to sleep between child processes. */      /* MSD014 */
int     qsleeptime = 0;         /* MS to sleep between child processes. */      /* MSD014 */
int     dsleeptime = 500;       /* MS to sleep between COMMAND.COM processes. *//* MSD014 */
                                                                                /* MSD014 */
#endif  /* FOR_WINDOWS */                                                       /* MSD014 */

void    Dprintf(                char    *func,
                                char    *name,
                                char    *text )
{
        if      ( debug >= DEBUG_WANTSTRUCT )
        {
                printf("@%s - ",func);

                if      ( text == NULL )
                        printf("%s = <NULL>\n",name);
                else
                        printf("%s = '%s'\n",name,text);
        }
}

void    Dprintfd(               char    *func,                                  /* MSD010 */
                                char    *name,                                  /* MSD010 */
                                int     number )                                /* MSD010 */
{                                                                               /* MSD010 */
        if      ( debug >= DEBUG_WANTSTRUCT )                                   /* MSD010 */
                printf("@%s - %s = %d\n",func,name,number);                     /* MSD010 */
}                                                                               /* MSD010 */

main(argc, argv)
int     argc;
char  **argv;
{
REGISTER int i;
REGISTER targptr targp;
targptr resp_targ;              /* file list for long command lines>response file */
int     done = 0;
char    **makefile;
char    *envargs, **eargv;

        /* get current date & time */

        now = curr_time();

        /* initialize the various global lists */

        target_list = NULL;
        file_list = NULL;
        symbol_list = NULL;
        shell_list = NULL;

        /* allocate space for command line targets, files and macros */

        tlist = grow_list(NULL, &tmax);
        flist = grow_list(NULL, &fmax);
        mlist = grow_list(NULL, &mmax);

        add_symbol("MAKE", "make");     /* Default $(MAKE) macro */

        if ( (envargs=getenv("MAKEFLAGS")) != NULL )                            /* MSD013 */
                {
                eargv = tokenize(tstrcpy(envargs));
                make_args(-1, eargv);
                tfree(eargv);
                }

        make_args(--argc, ++argv);              /* process command line options */

        if ( debug >= DEBUG_WANTACCESS )
        {
                printf("*** Current date and time is ");
                display_datim(now);
                printf("\n");
        }

        if (noexec)
                silent = touch = 0;             /* -n always displays; never touches */

        first_targ = NULL;                      /* used in parse() */

        if (readdef)
                parse(fopenp(MAKEINI, "r"), 0); /* read in `default.mk' */

        first_targ = NULL;                      /* get first target in `makefile' */

        /* parse the makefiles given on command line */
        for(i = 0; flist[i] != NULL; i++)
                if ( !parse(fopen(flist[i], "r"), 0) )
                        terror(1, tstrcat("Can't open ",flist[i]));

        /* no makefiles specified, so use "makefile" */
        if (i == 0)
                {
                for ( makefile = makelist; !done && *makefile; makefile++ )
                        {
                        if ( debug >= DEBUG_WANTACCESS )
                                printf("*** Accessing makefile '%s'\n", *makefile);
                        done = !access(*makefile, RD_PERM);                     /* MSD013 */
                        if ( done )                                             /* MSD013 */
                                {
                                if ( debug )
                                        printf("*** Reading %s\n", *makefile);
                                if ( !parse(fopen(*makefile, "r"), 0) )
                                        terror(1, tstrcat("Can't open ",*makefile));
                                }
                        }
                }

        tfree(flist);                           /* all done with makefile's */

        for(i = 0; mlist[i] != NULL; i++)
                add_macro(mlist[i]);    /* add command line macros */

        tfree(mlist);                           /* all done with macros */

        if ( (resp_targ=get_target(".RESPONSE")) != NULL )                      /* MSD013 */
                resp_cmds = tokenize(breakout((*resp_targ->tshell)->scmd));

        if ((targp = get_target(".BEFORE")) != NULL)
                build(targp->tshell);   /* process the .BEFORE rule */

        if ((targp = get_target(".INIT")) != NULL)
                build(targp->tshell);   /* process the .INIT rule */

        for (i = 0; tlist[i] != NULL; i++)
                make(tlist[i], 1);              /* process command line targets */

        tfree(tlist);                           /* all done with targets */

        /* if no targets specified, make the first one */
        if (i == 0 && first_targ)
                make(first_targ->tfile->fname, 1);

        if ((targp = get_target(".DONE")) != NULL)
                build(targp->tshell);   /* process the .DONE rule */

        if ((targp = get_target(".AFTER")) != NULL)
                build(targp->tshell);   /* process the .AFTER rule */

        Dprintf("MAIN","before FFLUSH(NULL)","ZERO");

        fflush(NULL);

#if     FOR_WINDOWS                                                             /* MSD014 */
                                                                                /* MSD014 */
        if ( qsleeptime > ZERO ) Sleep(qsleeptime);                             /* MSD014 */
                                                                                /* MSD014 */
#endif  /* FOR_WINDOWS */                                                       /* MSD014 */

        Dprintf("MAIN","returns","ZERO");
        return (0);                                     /* not exit(); see new_make() */
}

/* Work-around for (apparent) Borland compiler bug - am I missing something
 * here?  ISDIGIT() works for Watcom and Microsoft compilers...  Perhaps I've
 * got the command-line parameters wrong for the Borland compiler?
 */

int xisdigit( int c )
{
        return ( '0' <= c && c <= '9' );
}

/* NEW FUNCTION */                                                              /*MSD014 */

void printversionnumber( void )
{
        switch  ( ++verprinted )
        {
        case 1: printf("\n%s %s\n",version,VERSIONTYPE);                break;
        case 2: printf("Built via %s compiler\n",COMPILER);             break;
        case 3: printf("Built on " __DATE__ " at " __TIME__ "\n");      break;
        }
}

/*      decode all command line & environment options   */
/*      no -f option accepted from env, argc set neg    */

void make_args(argc, argv)
int             argc;
char  **argv;
{
static  int tlen = 0;
static  int flen = 0;
static  int mlen = 0;
char    no_k = 0;

        for ( ; *argv && argc ; ++argv, --argc )
                {
                /* look for macros and targets */
                if ( **argv != '-' )
                        {
                        if ( strchr(*argv, '=') )
                                {               /* store as a macro */
                                if (mlen == mmax)
                                        mlist = grow_list(mlist, &mmax);
                                mlist[mlen++] = *argv;
                                }
                        else
                                {               /* store as a target */
                                if ( tlen == tmax )
                                        tlist = grow_list(tlist, &tmax);
                                tlist[tlen++] = *argv;
                                }
                        continue;
                        }

                while ( *argv && *++*argv )
                        {
                        switch (**argv)
                                {
                                case 'C':               /* force shell forking for target */
                                        forceshell = 1;
                                        break;

                                case 'd':               /* show dependencies */
                                        if ( xisdigit(*(*argv + 1)) )
                                                debug = *(++(*argv)) - '0';
                                        else
                                                debug++;
                                        break;

                                case 'e':               /* environment overrides assignments */
                                        touchenv = 0;
                                        break;

                                case 'f':               /* new makefile name */
                                        if ( argc > 0 )
                                                {
                                                if (argc < 2)
                                                        usage();
                                                if (flen == fmax)
                                                        flist = grow_list(flist, &fmax);
                                                flist[flen++] = *(++argv);
                                                }
                                        else
                                                {
                                                printf("Illegal -f option in environment, ignored\n");
                                                ++argv;
                                                }
                                        --argc;
                                        *argv = NULL;
                                        break;

                                case 'i':               /* ignore errors */
                                        ignore = 1;
                                        break;

                                case 'k':               /* ignore single target errors only */
                                        single_ign = 1;
                                        break;

                                case 'm':               /* same date re-build *//* MSD008 */
                                        samedate = 1;                           /* MSD008 */
                                        break;                                  /* MSD008 */

                                case 'n':               /* don't execute commands */
                                        noexec = 1;
                                        break;

                                case 'r':               /* don't read default.mk */
                                        readdef = 0;
                                        break;

                                case 's':               /* don't echo commands */
                                        silent = 1;
                                        break;

                                case 'S':               /* undo the -k option */
                                        no_k = 1;
                                        break;

                                case 't':               /* touch files, don't build */
                                        touch = 1;
                                        break;

                                case 'a':               /* ignore target date, force make */
                                        force = 1;
                                        break;
#if     FOR_WINDOWS                                                             /* MSD014 */
                                case 'p':               /* Set SLEEP() time */  /* MSD014 */
                                        sleeptime = atoi(*argv+1);              /* MSD014 */
                                        *(*argv+1) = '\0';                      /* MSD014 */
                                        break;                                  /* MSD014 */
                                                                                /* MSD014 */
                                case 'q':               /* Set quit SLEEP() time *//* MSD014 */
                                        qsleeptime = atoi(*argv+1);             /* MSD014 */
                                        *(*argv+1) = '\0';                      /* MSD014 */
                                        break;                                  /* MSD014 */
                                                                                /* MSD014 */
                                case 'u':               /* Set shell SLEEP() time *//* MSD014 */
                                        dsleeptime = atoi(*argv+1);             /* MSD014 */
                                        *(*argv+1) = '\0';                      /* MSD014 */
                                        break;                                  /* MSD014 */
#endif  /* FOR_WINDOWS */                                                       /* MSD014 */
                                case 'V':               /* Display version number. */
                                        printversionnumber();                   /* MSD014 */
                                        break;

                                case 'y':               /* Inhibit directory changes */ /*MSD013 */
                                        inhibitCD = -1;                         /*MSD013 */
                                        break;                                  /*MSD013 */

                                default:
                                        usage();
                                }
                        }
                }

        if ( no_k )
                single_ign = 0;

        /* terminate all lists with a NULL pointer */

        tlist[tlen] = NULL;
        flist[flen] = NULL;
        mlist[mlen] = NULL;
}


/*
 * grow_list    - expand the list of pointers by a factor of two
 */
char **grow_list(list, len)
char    **list;
int             *len;
{
REGISTER int l;

        l = *len;               /* get current length */

        /* if list is NULL, start off with a default list */

        if ( list == NULL )
                list = (char **)talloc(((l=1)+1) * sizeof(char *));
        else
                list = (char **) trealloc((char *)list, ((l <<=1)+1)*sizeof(char *));

        if ( list == NULL )
                terror(1, "too many options");

        /* if we are initially allocating it, set first pointer to NULL */

        if ( l == 1 )
                *list = NULL;

        *len = l;               /* update current length */
        return (list);
}


/*
 * fopenp       - open file in current directory or along PATH
 */
FILE *fopenp(fname, type)
char   *fname;
char   *type;
{
REGISTER char *fpath;
FILE   *fd;

        /* if the filename is -, use stdin */
        if (equal(fname, "-"))
                return (stdin);

        fpath = talloc(256 + strlen(fname) + 2);

        _searchenv(fname, "PATH", fpath);

        /* try to open file relative to current directory */

        if ( strlen(fpath) == 0 )
                fd = NULL;
        else
        {
                if      ( (fd = fopen(fpath, type)) != NULL && debug )
                        printf("*** Reading default rules from %s\n", fpath);
        }

        tfree(fpath);

        return (fd);
}


int                                                                             /* MSD008 */
wantbuild( int  forcebuild,                                                     /* MSD008 */
           long preqtime,                                                       /* MSD008 */
           long targtime )                                                      /* MSD008 */
{                                                                               /* MSD008 */
        if ( forcebuild ) return 1;                                             /* MSD008 */
                                                                                /* MSD008 */
        if ( preqtime > targtime ) return 1;                                    /* MSD008 */
                                                                                /* MSD008 */
        if      ( samedate && ( preqtime == targtime ) )                        /* MSD008 */
                return 1;                                                       /* MSD008 */
                                                                                /* MSD008 */
        return 0;                                                               /* MSD008 */
}                                                                               /* MSD008 */


/*
 * make         - guts of the make command
 *              - make all pre-requisites, and if necessary, build target
 *
 *      returns -1 target was already up to date w.r.t. pre-requisites
 *               0 target has not been built
 *               1 target is now built (and up to date)
 */
make(targname, worry)
char   *targname;
int     worry;          /* if set, it is an error to NOT build this */
{
        REGISTER targptr targp;
        REGISTER fileptr *preqp;
        fileptr filep;
        long    targtime;
        long    preqtime;

        Dprintf("MAKE","TARGNAME",targname);
        Dprintfd("MAKE","WORRY",worry);                                         /* MSD010 */

        /* if recorded time of file is not default, we've already built it */
        filep = get_file(targname);
        if (filep && filep->ftime != MAXNEGTIME)
                return (-1);

        targp = get_target(targname);   /* find the target node */

        if ( targp == NULL )
                Dprintf("MAKE","TARGP",NULL);

        if (targp == NULL)
                return (default_rule(targname, worry, 0));

        targtime = file_time(targname); /* keep actual time of current target */

        /* must build non-existant files, even with no pre-requisites */
        preqtime = MAXNEGTIME + 1;

        /* make all pre-requisites */
        preqp = targp->tpreq;
        while ( ( preqp != NULL ) && *preqp )
        {
                make((*preqp)->fname, worry);

                /* keep track of newest pre-requisite */
                if (preqtime < (*preqp)->ftime)
                        preqtime = (*preqp)->ftime;

                /* display as necessary */
                if (debug)                                                      /* MSD007 */
                {
                        display_prereq(1, targname, targtime, (*preqp)->fname,  /* MSD010 */
                                       (*preqp)->ftime);
                }

                ++preqp;
        }

        if (targp->tshell == NULL)      /* try default rules anyway */
                return (default_rule(targname,0,                                /* MSD008 */
                                        wantbuild(force,preqtime,targtime)));   /* MSD008 */

        if ( wantbuild(force,preqtime,targtime) )                               /* MSD008 */
        {
                if (touch)              /* won't be set when `noexec' */
                        touch_file(targname);
                else
                {
                        add_metas("", "", targname);
                        Dprintf("MAKE","before build",targname);
                        build(targp->tshell);
                        Dprintf("MAKE","after build",targname);
                }

                targp->tfile->ftime = (noexec) ? now : file_time(targname);
                return (1);
        }

        targp->tfile->ftime = targtime;

        return (-1);
}

/*
 * default_rule - try the .SUFFIXES when we don't have an explicit target
 *              - if `worry' is set, it is an ERROR to NOT build this target
 *              - `mustbuild' is set if make() has out-of-date prereq's
 *                 but no explicit shell rules
 */
default_rule(targname, worry, mustbuild)
char   *targname;
int     worry;
int     mustbuild;
{
REGISTER targptr targp;
REGISTER fileptr *preqp;
fileptr filep;
char   *ext;
char   *basename;
char   *preqname;
long    targtime;
long    preqtime;
int     built;
char    suffrule[80];

        Dprintf("DEFAULT_RULE","TARGNAME",targname);
        Dprintfd("DEFAULT_RULE","WORRY",worry);                                 /* MSD010 */
        Dprintfd("DEFAULT_RULE","MUSTBUILD",mustbuild);                         /* MSD010 */

        /* find the extension */
        ext = strrchr(targname, '.');

        Dprintf("DEFAULT_RULE","EXT(1)",ext);

        if (ext == NULL)
                ext = targname + strlen(targname);

        Dprintf("DEFAULT_RULE","EXT(2)",ext);

        /* find the base name */
        basename = tstrncpy(targname, ext - targname);

        Dprintf("DEFAULT_RULE","BASENAME",basename);

        targtime = file_time(targname);

        if      ( suffix_targ == NULL )
                Dprintf("DEFAULT_RULE","SUFFIX_TARG",NULL);

        /* suffix_targ is used to (slightly) speed up this function */
        preqp = suffix_targ ? suffix_targ->tpreq : NULL;

        if ( preqp == NULL )
                Dprintf("DEFAULT_RULE","PREQP",NULL);

        built = 0;

        while (preqp && *preqp && !built)
                {
                /* look for a default rule from SUFFIX to `ext' */
                strcat(strcpy(suffrule, (*preqp)->fname), ext);

                Dprintf("DEFAULT_RULE","SUFFRULE",suffrule);

                targp = get_target(suffrule);   /* e.g. `.c.o' */

                if (targp != NULL)
                        {
                        /* found a rule; see if file exists */
                        preqname = tstrcat(basename, (*preqp)->fname);
                        preqtime = file_time(preqname);

                        Dprintf("DEFAULT_RULE","PREQNAME",preqname);

                        /*
                         * don't bother recursive makes unless necessary
                         * e.g. we have .c.o and .l.c, but also .l.o!
                         * we want to use .l.o if a .c file does not exist
                         */
/* TSE                         if (preqtime != MAXNEGTIME || mustbuild) TSE */
/* TSE                                 built = make(preqname, 0); TSE */

                        if ( preqtime == MAXNEGTIME )
                                built = default_rule(preqname,FALSE,mustbuild); /* MSD006 */
                        else
                                if ( mustbuild ) built = make(preqname,0);

                        /* check if pre-req file exists and is newer */
                        preqtime = file_time(preqname);
                        if ( wantbuild(mustbuild && built,preqtime,targtime) )  /* MSD008 */
                                {
                                if (debug)
                                        display_prereq(2, targname, targtime,   /* MSD010 */
                                                       preqname, preqtime);     /* MSD010 */

                                if (touch)      /* won't be set when `noexec' */
                                        touch_file(targname);
                                else
                                        {
                                        add_metas(basename, preqname, targname);
                                        build(targp->tshell);
                                        }
                                built = 1;
                                }
                        else if (debug && preqtime != MAXNEGTIME)
                                display_prereq(3, targname, targtime,           /* MSD010 */
                                               preqname, preqtime);             /* MSD010 */

                        tfree(preqname);
                        }

                ++preqp;                /* try next .SUFFIXES rule */
                }

        if (!built)
        {
                /* didn't find anything; try the default rule */
                targp = get_target(".DEFAULT");
                if (targp != NULL)
                {
                        add_metas(basename, "", targname);
                        build(targp->tshell);
                        built = 1;
                }
                else
                     if (targtime == MAXNEGTIME && worry)
                        terror(1, tstrcat("Don't know how to make ", targname));
        }

        tfree(basename);

        /* record the current file time */
        if ((filep = get_file(targname)) != NULL)
        {
                filep->ftime = (built == 1 && noexec) ? now
                                                      : file_time(targname);
        }

        return (built ? built : ((targtime == MAXNEGTIME) ? 0 : -1));
}


/*
 * add_metas    - add symbols for $*, $< and $@
 */
void add_metas(basename, preqname, targname)
char   *basename;
char   *preqname;
char   *targname;
{
        add_symbol("*", basename);
        add_symbol("<", preqname);
        add_symbol("@", targname);
}


/*
 * touch_file   - set the MODIFICATION time of the file to NOW
 */
void touch_file(targname)
char   *targname;
{
        REGISTER int handle;
        handle = utime(targname, NULL);
        fputs("*** touching : ", stdout);
        puts(targname);

        if (handle == 0)
                return;

        /* create the file, if it did not exist */
        if (errno == ENOENT)
        {
                handle = open(targname, O_CREAT | O_TRUNC, S_IWRITE);
                if (handle != -1)
                {
                        close(handle);
                        return;
                }
        }

        perror("make");
        exit (1);
}


#if     FOR_WINDOWS

BOOL    IsPresent(              char    *s )
{
        return ( strlen(s) > ZERO );
}


char    *strdel(                char    *s,
                                int     pos,
                                int     num )
{
        int     len = strlen(s);

        if      ( ( len > 0 ) && ( num > 0 ) && ( pos < len ) )
                if      ( num > ( len - pos + 1 ) )     /* Then deleting to */
                        s[pos] = EOS;                   /* the end of "s".  */
                else
                        strcpy(s+pos,s+pos+num);        /* Else just copy   */
                                                        /* the rest down.   */
        return  ( s );
}


void    StripTrailChar(         char    *s,
                                char    c )
{
        while   ( IsPresent(s) && ( s[strlen(s)-ONE] == c ) )
                strdel(s,strlen(s)-ONE,ONE);
}


void    StripLeadChar(          char    *s,
                                char    c )
{
        while   ( IsPresent(s) && ( s[ZERO] == c ) )
                strdel(s,ZERO,ONE);
}


/* Returns position of char C in string S.  Returns -1 if it can't find C. */

int     strpos(                 char    *s,
                                char    c )
{
        int i;
        int len = strlen(s);

        for     ( i=ZERO ; i<len ; i++ )
                if      ( s[i] == c )
                        return i;
        return -ONE;
}


BOOL    FindFullProgName(       char    *DefaultDir,
                                char    *CommandLine,
                                char    *FullProgName )
{
        char      PartProgName[MAX_PATH];
        int       StartPos = ZERO;
        int       EndPos;
        HINSTANCE Result;

        if      ( debug >= DEBUG_DEEP )
        {
                Dprintf("FINDFULLPROGNAME","DEFAULTDIR",DefaultDir);
                Dprintf("FINDFULLPROGNAME","COMMANDLINE",CommandLine);
        }

        if      ( CommandLine[ZERO] == DOUBLEQUOTE )
                StartPos = ONE,
                EndPos   = strpos(CommandLine+ONE,DOUBLEQUOTE) - ONE;
        else
        {
                EndPos = strpos(CommandLine,SPACE) - ONE;

                if      ( EndPos < ZERO )
                        EndPos = strlen(CommandLine) - ONE,
                        CommandLine[EndPos+TWO] = EOS;
        }

        if ( EndPos < StartPos ) return FALSE;

        strncpy(PartProgName,CommandLine+StartPos,EndPos-StartPos+ONE);
        PartProgName[EndPos-StartPos+ONE] = EOS;

        if      ( debug >= DEBUG_DEEP )
        {
                Dprintf("FINDFULLPROGNAME","PARTPROGNAME",PartProgName);
                Dprintf("FINDFULLPROGNAME","DEFAULTDIR",DefaultDir);
        }

        Result = FindExecutable(PartProgName,DefaultDir,FullProgName);

        if      ( debug >= DEBUG_DEEP )
                Dprintfd("FINDFULLPROGNAME","RESULT",(int)Result);

        if ( (int) Result < 32 ) return FALSE;

        strdel(CommandLine,ZERO,EndPos+TWO);

        return TRUE;
}

/*------------------------------------------------------------------------*/

#if     DEBUG_BOX_WORDS

static  int GLEnumber;

void    Box(                    char    *message )
{
        GLEnumber = GetLastError();

        MessageBox(NULL,message,version,MB_OK);                                 /* MSD012 */
}


void    BoxTxt(                 char    *message,
                                char    *txt )
{
        char Text[128];

        GLEnumber = GetLastError();

        sprintf(Text,"%s: '%s'",message, txt==NULL ? "<null>" : txt);
        MessageBox(NULL,Text,version,MB_OK);                                    /* MSD012 */
}


void    BoxInt(                 char    *message,
                                int     value )
{
        char Text[128];

        GLEnumber = GetLastError();

        sprintf(Text,"%s: %d = 0x%X",message,value,value);
        MessageBox(NULL,Text,version,MB_OK);                                    /* MSD012 */
}


void    BoxErrNo(               int     ErrNo )
{
        char Text[32];

        sprintf(Text,"Error number: %d = 0x%X",ErrNo,ErrNo);
        MessageBox(NULL,Text,version,MB_OK);                                    /* MSD012 */
}

/*      You must have previously called BOX(), BOXTXT() or BOXINT() so that
 *      GLENUMBER has already been set up with the value from GETLASTERROR().
 */


void    BoxErrGLE(              void )
{
        BoxInt("GetLastError",GLEnumber);
}

#endif  /* DEBUG_BOX_WORDS */

#endif  /* FOR_WINDOWS */

/*------------------------------------------------------------------------*/

/*
 * build        - process the shell commands
 */
void build(shellp)
REGISTER shellptr *shellp;
{
REGISTER char **argv;           /* argified version of scmd */
int             runst = 0;      /* exec return status */
char   *scmd;                   /* command with symbols broken out */
char   *tcmd;                   /* copy of scmd for `tokenize' */
char   *mk;                     /* builtin make macro */
char  **shcp;                   /* pointer to shell command list */
symptr  symp;                   /* points to macro definition */
int             resp_file;      /* response file possible */
char    cwd[512];               /* current work directory */
char    swd[512];               /* process start work directory */
FILE    *fd;                    /* temporary file (if needed) */
char    *fname = NULL, *comma;  /* temporary name pointers (if needed) */
int     i;
BOOL    UseShell;

#if     FOR_WINDOWS

#define COMSPEC "COMSPEC"

  STARTUPINFO         Start;
  PROCESS_INFORMATION ProcInfo;
  SECURITY_ATTRIBUTES Security;
  char ComSpec[MAX_PATH];
  char CmdLine[1024];
  char Orders[256];
  DWORD ExitCode;
  BOOL UsedShell;                                                               /* MSD014 */

#endif  /* FOR_WINDOWS */

        symp = get_symbol("MAKE");
        mk = symp->svalue;

        getcwd(cwd,sizeof(cwd));  /* where are we ? */

        for (;*shellp != NULL && runst == 0;
             tfree(scmd), tfree(tcmd), tfree(argv), ++shellp)
        {
                fflush(stdout);
                fflush(stderr);

                /* breakout runtime symbols (e.g. $* $@ $<) */
                scmd = breakout((*shellp)->scmd);

                Dprintf("BUILD","SCMD",scmd);

                if (!(*shellp)->s_silent && !silent)
                        printf("%s\n",scmd);

                /* make a copy because tokenize litters '\0's */
                tcmd = tstrcpy(scmd);
                argv = tokenize(tcmd);

                /* check for .RESPONSE command */
                shcp = resp_cmds;

                for ( resp_file = 0; !resp_file && (shcp!=NULL) && *shcp; ++shcp)
                        resp_file = equal(*shcp, argv[0]);

                if ( !noexec && resp_file && strlen(scmd) > 128 )
                        {                               /* Create temporary response file */
                        strcpy(fname,"OMAKE.$$$");
                                {
                                fd = fopen(fname, "w");

                                for ( i = 1; argv[i]; i++ )
                                        {
                                        for ( comma = argv[i];
                                              *comma && (comma=strchr(comma,',')) != NULL ; /*MSD013*/
                                              argv[i] = comma )
                                                {
                                                *comma++ = '\0';
                                                fprintf(fd, "%s,\n", argv[i]);
                                                }
                                        fprintf(fd, "%s +\n", argv[i]);
                                        }
                                fputc(';', fd);
                                fputc('\n', fd);
                                fclose(fd);
                                argv[1] = tstrcat("@", fname);
                                argv[2] = NULL;
                                }
                        }
                else
                        resp_file = 0;

                if ( equal(argv[0], mk) )
                        {
                        /* call ourselves recursively */
                        new_make(argv);
                        continue;
                        }

                if      ( !inhibitCD
                &&        ( equal(argv[0],"cd") || equal(argv[0],"chdir") ) )
                {
                        chdir(argv[1]);
                        continue;
                }

                if (noexec) continue;

                /* any indirection MUST be handled by the shell */
                if (!(*shellp)->s_shell && strpbrk(scmd, "<|>"))
                        (*shellp)->s_shell = 1;

                /* likewise, check for COMMAND.COM builtin commands */

                for (shcp = shell_cmds; !(*shellp)->s_shell && *shcp; ++shcp)
                        (*shellp)->s_shell = equal(*shcp, argv[0]);

                UseShell = forceshell || (*shellp)->s_shell;

                if ( debug >= DEBUG_DEEP ) Dprintfd("BUILD","USESHELL",UseShell);

                fflush(stdout);
                fflush(stderr);

#if     FOR_WINDOWS
                GetStartupInfo(&Start);

                Start.dwFlags     = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
                Start.hStdOutput  = GetStdHandle(STD_OUTPUT_HANDLE);
                Start.hStdError   = GetStdHandle(STD_ERROR_HANDLE);
                Start.wShowWindow = SW_SHOWMINNOACTIVE;

                Security.nLength              = sizeof Security;
                Security.lpSecurityDescriptor = NULL;
                Security.bInheritHandle       = TRUE;

                strcpy(Orders,scmd);

                if      ( inhibitCD )
                        strcpy(swd,cwd);
                else
                        getcwd(swd,sizeof(swd));

                UsedShell = UseShell || !FindFullProgName(swd,Orders,ComSpec);  /* MSD014 */
                                                                                /* MSD014 */
                if ( debug >= DEBUG_DEEP ) Dprintfd("BUILD","USEDSHELL",UsedShell);/* MSD014 */
                                                                                /* MSD014 */
                if      ( !UsedShell )                                          /* MSD014 */
                        sprintf(CmdLine,"%s %s",ComSpec,Orders);
                else
                {
                       if (GetEnvironmentVariable(COMSPEC,ComSpec,sizeof ComSpec)==0)
                       {
                                sprintf(CmdLine,"Command processor not found: '%s'",COMSPEC);
                                terror(1,CmdLine);
                       }

                        sprintf(CmdLine,"%s /c %s",ComSpec,Orders);
                }

                StripLeadChar(CmdLine,SPACE);
                StripTrailChar(CmdLine,SPACE);

                if ( debug >= DEBUG_DEEP ) Dprintf("BUILD","CMDLINE",CmdLine);

                if      ( !CreateProcess(NULL,CmdLine,&Security,&Security,TRUE,0,NULL,
                                         swd,&Start,&ProcInfo) )
                {
                        sprintf(CmdLine,"Can't create process; GLE=%d",GetLastError());
                        terror(1,CmdLine);
                }

                for     ( ExitCode=STILL_ACTIVE ; ExitCode == STILL_ACTIVE ; Sleep(100) )       /* MSD014 */
                {
                        if  ( !GetExitCodeProcess(ProcInfo.hProcess,&ExitCode) )
                        {
                                sprintf(CmdLine,"Can't get exit code; GLE=%d",
                                                        GetLastError());
                                terror(1,CmdLine);
                        }

                        if      ( debug >= DEBUG_DEEP )
                                printf("GECP() returns %ld=0x%08X\n",
                                                             ExitCode,ExitCode);
                }

                runst = (int) ExitCode;
#else   /* !FOR_WINDOWS */
                /* run without COMMAND.COM if possible, 'cause it uses RAM */
                if      ( UseShell )
                        runst = system(scmd);
                else
                        runst = spawnvp(P_WAIT, argv[0], argv);

#endif  /* !FOR_WINDOWS */

                fflush(stdout);
                fflush(stderr);

#if     FOR_WINDOWS                                                             /* MSD014 */
                                                                                /* MSD014 */
                if ( sleeptime > ZERO ) Sleep(sleeptime);                       /* MSD014 */
                if ( UsedShell && dsleeptime > ZERO ) Sleep(dsleeptime);        /* MSD014 */
                                                                                /* MSD014 */
#endif  /* FOR_WINDOWS */                                                       /* MSD014 */

                if ( debug >= DEBUG_DEEP ) Dprintfd("BUILD","RUNST",runst);                                         /* MSD010 */

                if ( inhibitCD  ) chdir(cwd);   /* back to work directory */    /* MSD013 */

                if ( resp_file )                /* free temporary file argument */
                        {
                        remove(fname);
                        tfree(argv[2]);
                        free(fname);
                        }

                if (runst == 0)
                        continue;

                /* uh-oh, an error */
                if (runst == -1)
                        perror("make");

                itoa(runst, scmd, 10);

                if ( !single_ign && (ignore || (*shellp)->s_ignore) )
                        strcat(scmd, " (ignored)");
                else if ( single_ign && !(ignore || (*shellp)->s_ignore) )
                        strcat(scmd, " (target aborted)");
                terror(0, tstrcat("\n\n*** Error code ",scmd));
                printf("\n");

                if (!single_ign && !ignore && !(*shellp)->s_ignore)
                        exit(1);
                else if ( !single_ign )
                        runst = 0;
        }
}


/*
 * new_make     - save current environment
 *              - call make() recursively (actually main())
 *              - clean up new environment
 *              - restore environment
 */
void new_make(argv)
char  **argv;
{
        targptr thead, tnext;
        fileptr fhead, fnext;
        symptr  shead, snext;
        shellptr shhead, shnext;
        char  **ttlist;
        long    tnow;
        int     i;

        /* save all the globals */
        thead = target_list;
        fhead = file_list;
        shead = symbol_list;
        shhead = shell_list;
        ttlist = tlist;
        tnow = now;

        /* count the arguments */
        for (i = 0; argv[i]; ++i);

        /* call ourselves recursively; this inherits flags */
        main(i, argv);

        /* we're back, so gotta clean up and dispose of a few things */
        while (target_list)
        {
                tnext = target_list->tnext;
                if (target_list->tpreq)
                        tfree(target_list->tpreq);
                if (target_list->tshell)
                        tfree(target_list->tshell);
                tfree(target_list);
                target_list = tnext;
        }

        while (file_list)
        {
                fnext = file_list->fnext;
                tfree(file_list->fname);
                tfree(file_list);
                file_list = fnext;
        }

        while (symbol_list)
        {
                snext = symbol_list->snext;
                tfree(symbol_list->sname);
                tfree(symbol_list->svalue);
                tfree(symbol_list);
                symbol_list = snext;
        }

        while (shell_list)
        {
                shnext = shell_list->slink;
                tfree(shell_list->scmd);
                tfree(shell_list);
                shell_list = shnext;
        }

        /* restore our original globals */
        target_list = thead;
        file_list = fhead;
        symbol_list = shead;
        shell_list = shhead;
        tlist = ttlist;
        now = tnow;
}


void usage( void )
{
char    **us_str;
int             i;

        for ( i = 1, us_str = usage_str; *us_str; puts(*us_str++), i++ ) ;
        exit(1);
}


void display_datim( long when )
{
        if      ( debug >= DEBUG_WANTSTRUCT )
        {
                printf("%08lX",when);
                printf("=");
        }

        if      ( when == MAXNEGTIME )
                printf("<maxnegtime>  ");
        else
        {
                printf("%04d", ( 0x7F & ( when >> 25 ) ) + 1980 ); /* Year.   */
                printf("%02d",   0x0F & ( when >> 21 ) );          /* Month.  */
                printf("%02d",   0x1F & ( when >> 16 ) );          /* Day.    */
                printf("%02d",   0x1F & ( when >> 11 ) );          /* Hour.   */
                printf("%02d",   0x3F & ( when >>  5 ) );          /* Minute. */
                printf("%02d",   0x3F & ( when <<  1 ) );          /* Second. */
        }
}

void display_prereq(location, targname, targtime, preqname, preqtime)           /* MSD010 */
int     location;                                                               /* MSD010 */
char   *targname;
long    targtime;
char   *preqname;
long    preqtime;
{
        printf("[%d] ",location);

        display_datim(targtime);
        printf(" %-20s",targname);

        if      ( targtime == preqtime )
                printf(" = ");
        else
                printf( targtime < preqtime ? " < " : " > " );

        display_datim(preqtime);
        printf(" %-20s",preqname);

        printf("\n");
}


long file_time(fname)
char   *fname;
{
        long Result;

#if     FOR_WINDOWS

        HANDLE   Hand;
        FILETIME WhenGMT,WhenLocal;
        WORD     Date = ZERO;
        WORD     Time = ZERO;
        BOOL     Ok;

        Hand = CreateFile(fname,GENERIC_READ,ZERO,NULL,OPEN_EXISTING,
                          FILE_ATTRIBUTE_NORMAL,NULL);

        Ok = ( Hand != INVALID_HANDLE_VALUE );

        if      ( Ok )
        {
                if      ( debug >= DEBUG_DEEP )
                {
                        printf("File size is %d\n",GetFileSize(Hand,NULL));
                        printf("File type is %X\n",GetFileType(Hand));
                }

                Ok = GetFileTime(Hand,NULL,NULL,&WhenGMT);
                Ok = Ok && FileTimeToLocalFileTime(&WhenGMT,&WhenLocal);
                Ok = Ok && FileTimeToDosDateTime(&WhenLocal,&Date,&Time);
                Ok = CloseHandle(Hand) && Ok;
        }

        Result = Ok ? ( Date << 16 ) | Time : MAXNEGTIME;

#else   /* !FOR_WINDOWS */

        REGISTER int handle;
        struct stat sbuf;

        handle = open(fname, O_RDONLY);

        if      (handle == -1)
                Result = MAXNEGTIME;
        else
        {
                fstat(handle, &sbuf);
                close(handle);
                Result = sbuf.st_mtime;
        }

#endif  /* !FOR_WINDOWS */

        if      ( debug >= DEBUG_DEEP )
        {
                printf("Datim for '%s' is ",fname);
                display_datim(Result);
                printf("\n");
        }

        return Result;
}


#define TODOS(yyyy,oo,dd,hh,mm,ss) \
        ((long)(((yyyy-1980)<<25)|(oo<<21)|(dd<<16)|(hh<<11)|(mm<<5)|(ss>>1)))

/*
 * curr_time    - return current time in same format as file_time()
 *                              - used with the `-n' option
 */
long
curr_time()
{
        long Result;

#if     FOR_WINDOWS

        SYSTEMTIME W;

        GetLocalTime(&W);

        if      ( debug >= DEBUG_DEEP )
                printf("DATIM = %d/%d/%d @ %d:%d:%d\n",
                        W.wYear,W.wMonth,W.wDay,
                        W.wHour,W.wMinute,W.wSecond);

        Result = TODOS(W.wYear,W.wMonth,W.wDay,W.wHour,W.wMinute,W.wSecond);

#else   /* !FOR_WINDOWS */

#if     FOR_MICROSOFT

        Result = time(NULL);

#else   /* !FOR_MICROSOFT */

        struct dosdate_t date;
        struct dostime_t time;

        _dos_getdate(&date);
        _dos_gettime(&time);

        Result =
        TODOS(date.year,date.month,date.day,time.hour,time.minute,time.second);

#endif  /* !FOR_MICROSOFT */

#endif  /* !FOR_WINDOWS */

        if      ( debug >= DEBUG_DEEP )
        {
                printf("Current datim is ");
                display_datim(Result);
                printf("\n");
        }

        return Result;
}
