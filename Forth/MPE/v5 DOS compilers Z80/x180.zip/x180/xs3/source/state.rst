[edit-]
screen=80 25
toggles=1 1 0 1 0 0
srch=cursor
src=
rpl=
file=c:\xs3\source\comms 1 1 1 1
[brief]
file=c:\xs3\source\comms 1 1 1 1 1 22 78 1 c=1
file=c:\xs3\source\release.fth 1 1 13 15
file=c:\xs3\source\dosops.fth 1 2543 1 2559
file=c:\xs3\source\vars.fth 1 99 1 104
file=c:\xs3\source\keys.fth 1 129 19 131
file=c:\xs3\source\help.txt 1 1 1 1
file=c:\xs3\source\xs3 1 1 1 1
file=c:\xs3\source\xshell 1 1 1 1
file=c:\xs3\source\uf.fth 1 1 1 8
file=c:\xs3\source\start.fth 1 142 23 149
[shared-]
pmark=c:\xs3\source\comms 1 1
