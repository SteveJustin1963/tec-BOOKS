[edit-]
screen=80 25
toggles=1 0 0 1 0 0
srch=receive-m
src=s\>d
rpl=0
file=d:\xcomp5\x180\compiler\source\temp\host-end.fth 1 134 1 141
[brief]
file=d:\xcomp5\x180\compiler\source\temp\host-end.fth 1 134 1 141 1 22 78 1 c=0
file=d:\xcomp5\x180\compiler\source\host-end.fth 1 198 1 1
file=d:\xcomp5\x180\compiler\source\temp\uforth.fth 1 120 13 120
file=d:\xcomp5\x180\compiler\source\uforth.fth 1 274 4 278
file=d:\xcomp5\x180\compiler\source\host-end.bak 1 112 2 121
file=d:\xcomp5\x180\compiler\source\uforth.bak 1 217 1 226
[shared-]
pmark=d:\xcomp5\x180\compiler\source\temp\host-end.fth 1 141
