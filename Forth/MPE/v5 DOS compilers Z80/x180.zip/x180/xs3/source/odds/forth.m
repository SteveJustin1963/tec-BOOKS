;*************************** FORTH MACROS ************************
;                            Revision 3.0
;                (c) MicroProcessor Engineering Ltd, 1991
;*****************************************************************


;** page down macro
;** page down low-level macro
(macro sub_pgdn
   (
      (int line column counter)
      (global counter)
      (right)
      (if  (!= (search_fwd "" 0 0 0) 0)
           (
               (inq_position line column) 
               (set_top_left line column)
               (++ counter)
           )
      ;else
           (left)
      )
    )
)		

;** page down main macro
(macro pgdn
   (
      (sub_pgdn)
      (message "Page: %d" counter)
   )
)


;** goto_page macro
(macro goto_page
   (
      (int result goto_counter required)
      (get_parm NULL required "Enter page number: ")
      (top_of_buffer)
      (for  (= goto_counter 1)
            (< goto_counter required)
            (++ goto_counter)
            (
               (message "Page: %d" goto_counter)
               (sub_pgdn)
            )
      )
      (= counter goto_counter)
      (message "Page: %d" counter)
   )   
)

;** pgup macro
(macro pgup
   (
      (int line column test)
      (string test_string)
      (= test_string (read 1))
      (= test 0)
      (if (== test_string "")
          (= test 1)
      )
      (up)
      (if (!= (search_back "" 0 0 0) 0)
          (
              (inq_position line column)
              (set_top_left line column)
              (if (== test 1)
                  (-- counter)
              )
         )
      ;else
          (
              (= counter 1)
              (top_of_buffer)
          )
      )
      (message "Page: %d" counter)
   )
)


;** what_page macro
(macro what_page
   (
      (int line column what_counter result curr_line)
      (down)
      (pgup)
      (inq_position line column)
      (top_of_buffer)
      (= what_counter 1)
      (inq_position curr_line)
      (while (< curr_line line)
             (
               (down)
               (= result (search_fwd "" 0 0 0))
               (inq_position curr_line)
               (if (!= result 0)
                   (
                     (++ what_counter)
                     (message "Page: %d" what_counter)
                   )
		         )
             )
      )
      (set_top_left line column)
      (= counter what_counter)
   )
)

;** date code macro
(macro insert_date
   (
      (int day month year)
		(string output)
      (date year month day)
		(sprintf output "%d" day)
		(insert output)
      (insert "/")
		(sprintf output "%d" month)
		(insert output)
      (insert "/")
      (%= year 100)
		(sprintf output "%d" year)
		(insert output)
   )
)
 
;** page_break macro
(macro page_break
   (
      (string initials)
      (global initials)
      (insert "\n")
      (insert "\\ -----End of Page-----")
      (insert "\n")
      (insert "\\ -- ")
      (insert initials)
      (insert " -- ")
      (insert_date)
      (insert " --  ")
   )
)


;** <Cr> word
(macro smart
   (
      (int line smart_on curr_line count no_indents)
		(string match_string)
      (global smart_on no_indents)
      (if (== smart_on 1)
          (
             (save_position)
             (inq_position line)
             (drop_anchor)
             (= match_string "{[ \n\t]{if}|{do}|{begin}|{case}}|{<{:}|{code}}")
      		 (beginning_of_line)
      		 (if (!= (search_fwd match_string 1 0 1) 0)
	          	 (
   		          (inq_position curr_line)
         		    (if (== curr_line line)
							  (+= no_indents 1)
						 )
            	 )
          	 )
      		 (beginning_of_line)
             (= match_string "{[ \n\t]{endif}|{loop}|{repeat}|{until}|{again}|{endcase}}|{<{;}|{end\-code}}")
      		 (if (!= (search_fwd match_string 1 0 1) 0)
	          	 (
   		          (inq_position curr_line)
         		    (if (== curr_line line)
							  (-= no_indents 1)
						 )
            	 )
          	 )
             (restore_position)
             (raise_anchor)
 			 )
      )
      (insert "\n")
      (while (< count no_indents)
             (
                (insert "  ")
                (++ count)
             )
		)
   )
)

;** whether to perform smart indent
(macro toggle_smart
   (
      (beep)
      (= no_indents 0)
      (if (== smart_on 1)
          (
             (message "Forth-smart indenting disabled")
             (= smart_on 0)
          )
      ;else
          (
             (message "Forth-smart indenting enabled")
             (= smart_on 1)
          )
		)
   )
)

;**	DOS function macro -- returns result in window
(macro do_dos
	(
		(string command_string dos_file)
		(= dos_file "DOS.LOG")
		(get_parm NULL command_string "Enter DOS command: " 80)
		(get_parm NULL dos_file "Enter log name: " 12 dos_file)
		(message "Executing, please wait ........ ")
		(+= command_string " >& ")
		(+= command_string dos_file)
		(dos command_string)
		(beep)
		(if (create_edge 2)
          (edit_file dos_file)
		;else
			(message "Can't open new window")
		)
	)
)

;** new Ctrl-E (edit-file) macro
(macro edit_fth
	(
		(int err_mess)
		(string file_name file_name_ext)
		(pause_on_error)
		(get_parm NULL file_name "File: ")
		(if (== 0 (exist file_name))
			 (
			   (= file_name_ext file_name)
				(+= file_name_ext ".fth")
				(if (exist file_name_ext)
					 (= file_name file_name_ext)
				;else
					 (
  					 	(message "New file: (unable to open %s)" file_name)
						(= err_mess (inq_msg_level))
						(set_msg_level 3)
					 )					
				)
			 )
		)
   	(edit_file file_name)
		(set_msg_level err_mess)
	)
)

;** QC macro
(macro qc
	(
		(int curr_line curr_col current_win qc_win counter)
		(string output)
		(= counter 1)
		(message "Indexing, please wait......")
		(beginning_of_line)
		(inq_position curr_line)
		(= current_win (inq_window))
		(create_edge 2)
		(edit_file "NUL")
		(= qc_win (inq_window))
		(if (== 0 (first_time))
			(
				(top_of_buffer)
				(drop_anchor 1)
				(end_of_buffer)
				(delete_block)
				(raise_anchor)
			)
		)
		(top_of_buffer)
		(set_window current_win)
		(top_of_buffer)
		(drop_anchor 1)
		(search_fwd "\n" 1 0 0)
		(copy)
		(raise_anchor)
		(set_window qc_win)
		(sprintf output "%d  " counter)
		(insert output)
		(++ counter)
		(paste)
		(set_window current_win)
		(while (!= 0 (search_fwd "" 0 0 0))
			(
				(next_char)
				(drop_anchor 1)
				(search_fwd "\n" 1 0 0)
				(copy)
				(raise_anchor)
				(set_window qc_win)
				(sprintf output "%d  " counter)
				(insert output)
				(++ counter)
				(paste)
				(set_window current_win)
			)
		)
		(set_window current_win)
		(goto_line curr_line)
		(inq_position curr_line curr_col)
		(set_top_left curr_line curr_col)
	)
)

;** glossary generator macro
(macro glossary
	(
		(int spaces count current_win glo_win curr_line curr_col new_line new_col tmp_buff)
		(string glo_file sort_file dos_command)
		(= glo_file "FTH.TMP")
		(= sort_file "FTH.GLO")
		(get_parm NULL glo_file "Enter glossary temp. name: " 12 glo_file)
		(get_parm NULL sort_file "Enter sorted name: " 12 sort_file)
		(message "Building glossary, please wait......")
		(beginning_of_line)
		(inq_position curr_line)
		(top_of_buffer)
		(= current_win (inq_window))
		(create_edge 2)
		(edit_file glo_file)
		(= glo_win (inq_window))
		(set_window current_win)
		(while (!= 0 (search_fwd "<:" 1 0 0))
			(
				(next_char)
				(search_fwd "[~ \t]" 1 0 0)
				(drop_anchor 1)
				(search_fwd "[ \t\n]" 1 0 0)
				(prev_char)
				(copy)
				(raise_anchor)
				(set_window glo_win)
				(paste)
				(inq_position new_line new_col)
				(= count 0)
				(= spaces (- 40 new_col))
				(while (< count spaces)
					    (
							(insert " ")
							(++ count)
						 )
				)
				(insert "Colon       ")
				(set_window current_win)
				(next_char)
				(search_fwd "[~ \t]" 1 0 0)
				(drop_anchor 1)
				(search_fwd "\n" 1 0 0)
				(copy)
				(raise_anchor)
				(set_window glo_win)
				(paste)
				(set_window current_win)
			)
		)
		(set_window current_win)
		(top_of_buffer)
		(while (!= 0 (search_fwd "<code" 1 0 0))
			(
				(next_char)
				(search_fwd "[ \t]" 1 0 0)
				(search_fwd "[~ \t]" 1 0 0)
				(drop_anchor 1)
				(search_fwd "[ \t\n]" 1 0 0)
				(prev_char)
				(copy)
				(raise_anchor)
				(set_window glo_win)
				(paste)
				(inq_position new_line new_col)
				(= count 0)
				(= spaces (- 40 new_col))
				(while (< count spaces)
					    (
							(insert " ")
							(++ count)
						 )
				)
				(insert "Code        ")
				(set_window current_win)
				(next_char)
				(search_fwd "[~ \t]" 1 0 0)
				(drop_anchor 1)
				(search_fwd "\n" 1 0 0)
				(copy)
				(raise_anchor)
				(set_window glo_win)
				(paste)
				(set_window current_win)
			)
		)
		(set_window current_win)
		(top_of_buffer)
		(while (!= 0 (search_fwd "<variable" 1 0 0))
			(
				(next_char)
				(search_fwd "[ \t]" 1 0 0)
				(search_fwd "[~ \t]" 1 0 0)
				(drop_anchor 1)
				(search_fwd "[ \t\n]" 1 0 0)
				(prev_char)
				(copy)
				(raise_anchor)
				(set_window glo_win)
				(paste)
				(inq_position new_line new_col)
				(= count 0)
				(while (< count (- 40 new_col))
					    (
							(insert " ")
							(++ count)
						 )
				)
				(insert "Variable\n")
				(set_window current_win)
			)
		)
		(set_window current_win)
		(top_of_buffer)
		(while (!= 0 (search_fwd "<l:" 1 0 0))
			(
				(next_char)
				(search_fwd "[ \t]" 1 0 0)
				(search_fwd "[~ \t]" 1 0 0)
				(drop_anchor 1)
				(search_fwd "[ \t\n]" 1 0 0)
				(prev_char)
				(copy)
				(raise_anchor)
				(set_window glo_win)
				(paste)
				(inq_position new_line new_col)
				(= count 0)
				(while (< count (- 40 new_col))
					    (
							(insert " ")
							(++ count)
						 )
				)
				(insert "Label\n")
				(set_window current_win)
			)
		)
		(set_window current_win)
		(top_of_buffer)
		(while (!= 0 (search_fwd "constant" 1 0 0))
			(
				(next_char)
				(search_fwd "[ \t]" 1 0 0)
				(search_fwd "[~ \t]" 1 0 0)
				(drop_anchor 1)
				(search_fwd "[ \t\n]" 1 0 0)
				(prev_char)
				(copy)
				(raise_anchor)
				(set_window glo_win)
				(paste)
				(inq_position new_line new_col)
				(= count 0)
				(while (< count (- 40 new_col))
					    (
							(insert " ")
							(++ count)
						 )
				)
				(insert "Constant\n")
				(set_window current_win)
			)
		)
		(set_window current_win)
		(top_of_buffer)
		(while (!= 0 (search_fwd "equ[ \t]" 1 0 0))
			(
				(next_char)
				(search_fwd "[ \t]" 1 0 0)
				(search_fwd "[~ \t]" 1 0 0)
				(drop_anchor 1)
				(search_fwd "[ \t\n]" 1 0 0)
				(prev_char)
				(copy)
				(raise_anchor)
				(set_window glo_win)
				(paste)
				(inq_position new_line new_col)
				(= count 0)
				(while (< count (- 40 new_col))
					    (
							(insert " ")
							(++ count)
						 )
				)
				(insert "Equate\n")
				(set_window current_win)
			)
		)
		(beep)
		(message "Sorting, please wait ........ ")
		(set_window glo_win)
		(write_buffer)
		(= tmp_buff (inq_buffer))
		(set_window current_win)
		(= dos_command "sort < ")
		(+= dos_command glo_file)
		(+= dos_command " >& ")
		(+= dos_command sort_file)
		(dos dos_command )
		(delete_edge 2)
		(delete_buffer tmp_buff)
		(del glo_file)
		(create_edge 2)
		(edit_file sort_file)
		(top_of_buffer)
		(top_of_window)
		(set_window current_win)
		(goto_line curr_line)
		(inq_position curr_line curr_col)
		(set_top_left curr_line curr_col)
	)
)

(macro new_stamp
  (
		(save_position)
		(search_back "" 0 0 0)
		(search_fwd "\n" 1 0 0)
		(drop_anchor)
		(beginning_of_line)
		(search_fwd "[0-9]" 1 0 1)
		(drop_anchor)
		(search_fwd " " 0 0 0)
      (delete_block)
		(raise_anchor)
		(insert_date)
      (insert " ")
		(raise_anchor)
		(restore_position)
  )
)

;**	Initials macro.
;**	Use this macro for additional customization.
(macro XXX
	(
      (= initials "X.X.X.")
      (= smart_on 0)
      (= no_indents 0)
		(assign_to_key "<Ctrl-S>" "new_stamp")
		(assign_to_key "<Ctrl-G>" "glossary")
		(assign_to_key "<Ctrl-Q>" "qc")
		(assign_to_key "<Alt-E>" "edit_fth")
		(assign_to_key "<F11>" "do_dos")
      (assign_to_key "<Enter>" "smart")
      (assign_to_key "<Ctrl-I>" "toggle_smart")
      (assign_to_key "<Ctrl-P>" "what_page")
      (assign_to_key "<Alt-P>" "goto_page")
      (assign_to_key "<Ctrl-Enter>" "page_break")
      (assign_to_key "<PgDn>" "pgdn")
      (assign_to_key "<PgUp>" "pgup")
      (assign_to_key "<Ctrl-PgDn>" "page_down")
      (assign_to_key "<Ctrl-PgUp>" "page_up")
		(return)
	)
)

;**	File Extension Macros, etc.
;**	Macros marked "Overwritable" may be overwritten by SETUP.


;**	Overwritable by Setup
(macro default
	(
		(tabs 9 17)
	)
)

;**	Overwritable by Setup
(macro .fth
	(
		(tabs 5 10 15 20 25 30 35 40 45)
	)
)
