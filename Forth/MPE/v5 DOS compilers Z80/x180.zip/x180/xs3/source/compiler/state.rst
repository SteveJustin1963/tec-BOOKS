[edit-]
screen=80 25
toggles=1 1 0 1 0 0
srch=
src=
rpl=
file=c:\xs3\source\compiler\baux.fth 1 1 1 18
[brief]
file=c:\xs3\source\compiler\baux.fth 1 1 1 18 1 22 78 1 c=0
file=c:\xs3\source\compiler\bmain.fth 1 1 15 13
[shared-]
pmark=c:\xs3\source\compiler\baux.fth 1 18
