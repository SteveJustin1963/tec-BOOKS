[edit-]
screen=80 25
toggles=1 1 0 1 0 0
srch=
src=
rpl=
file=c:\xs3\xs3man\titles.doc 1 56 1 77
[brief]
file=c:\xs3\xs3man\titles.doc 1 56 1 77 1 22 78 1 c=0
[shared-]
pmark=c:\xs3\xs3man\titles.doc 1 77
