#include <iostream>
#include <fstream>
#include <string.h>

//#include <string>
#include <cstdio>
#include <cstdlib>
using namespace std;

int main(int argc, char* argv[])
{
    if (argc<3){
    cout << "Usage:" << endl;
    cout << "  MsxHeader [InFile] [OutFile] [FileBeginHex]" << endl;

    return 0;

    }
    cout << "MsxHeader" << endl;
    std::cout << "File:" << argv[1]<< std::endl;
//    std::cout << "ExecutePos:" << argv[2]<< std::endl;

    char x='x';
    char check=123;
    streampos begin,end;
    ifstream infile;
    infile.open(argv[1], ios::binary | ios::in);
    int bytecount=0;

    do{
        infile.read(&x, sizeof(char)); // reads 7 bytes into a cell that is either 2 or 4

       if (!infile.eof()) {
         bytecount++;
       }
    } while  (!infile.eof());

    //infile.seekg (0, ios::end);


    infile.close();
    infile.open(argv[1], ios::binary | ios::in);
    ofstream outfile;
    outfile.open(argv[2], ios::binary | ios::out);

    //; MSX HEADER BLOAD header, before the ORG so that the header isn't counted
	//db &FE     ; magic number
	//dw FileBegin    ; begin address
	//dw FileEnd - 1  ; end address
	//dw Execute  ; program execution address (for ,R option)




    x=254;    outfile.write(&x, sizeof(char));

    unsigned int startpos = strtoul(argv[3], NULL, 16);
    std::cout << "StartPos:" << startpos << std::endl;
    int thislen=bytecount;

    x=(startpos)%256;     outfile.write(&x, sizeof(char));check=check+x;
    x=(startpos)/256;     outfile.write(&x, sizeof(char));check=check+x;

    x=(startpos+thislen)%256;     outfile.write(&x, sizeof(char));check=check+x;
    x=(startpos+thislen)/256;     outfile.write(&x, sizeof(char));check=check+x;

    x=(startpos)%256;     outfile.write(&x, sizeof(char));check=check+x;
    x=(startpos)/256;     outfile.write(&x, sizeof(char));check=check+x;

    /*
    x=1;     outfile.write(&x, sizeof(char));
    x=0;     outfile.write(&x, sizeof(char));

    x=0;     outfile.write(&x, sizeof(char));
    x=0;     outfile.write(&x, sizeof(char));
    x=3;     outfile.write(&x, sizeof(char));
    thislen=bytecount;
    x=thislen%256;     outfile.write(&x, sizeof(char));check=check+x;
    x=thislen/256;     outfile.write(&x, sizeof(char));check=check+x;
    x=0;     outfile.write(&x, sizeof(char));
    x=128;     outfile.write(&x, sizeof(char));
    x=0;     outfile.write(&x, sizeof(char));
    x=128;     outfile.write(&x, sizeof(char));
    for (int i=0;i<105;i++){
        x=0;     outfile.write(&x, sizeof(char));

    }
    x=check;     outfile.write(&x, sizeof(char));
    */
    do {
        infile.read(&x, sizeof(char)); // reads 7 bytes into a cell that is either 2 or 4
       if (!infile.eof()) outfile.write(&x, sizeof(char)); // sizeof can take a type
    } while (!infile.eof());
    infile.close();
    outfile.close();
return 0;




}
