﻿namespace AkuSpriteEditor
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.picPreview = new System.Windows.Forms.PictureBox();
            this.trkzoom = new System.Windows.Forms.TrackBar();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabEditor = new System.Windows.Forms.TabPage();
            this.btnVector = new System.Windows.Forms.Button();
            this.btnOnlineHelp = new System.Windows.Forms.Button();
            this.btnHelp = new System.Windows.Forms.Button();
            this.btnTileCopy = new System.Windows.Forms.Button();
            this.btnColorSwap2 = new System.Windows.Forms.Button();
            this.btnZXpaint2 = new System.Windows.Forms.Button();
            this.btnToolPixelPaint = new System.Windows.Forms.Button();
            this.btnRedo = new System.Windows.Forms.Button();
            this.btnUndo = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnFloodFill = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.rdoBnk32 = new System.Windows.Forms.RadioButton();
            this.rdoBnk8 = new System.Windows.Forms.RadioButton();
            this.rdoBnk16 = new System.Windows.Forms.RadioButton();
            this.rdoBnk4 = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cbo4colorDither = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.grpSpriteSize = new System.Windows.Forms.GroupBox();
            this.rdoVGA = new System.Windows.Forms.RadioButton();
            this.rdoSprWide = new System.Windows.Forms.RadioButton();
            this.rdospr512 = new System.Windows.Forms.RadioButton();
            this.rdospr256 = new System.Windows.Forms.RadioButton();
            this.GrpFrameOverlay = new System.Windows.Forms.GroupBox();
            this.rdoFrameLast = new System.Windows.Forms.RadioButton();
            this.rdoFrameNext = new System.Windows.Forms.RadioButton();
            this.rdoFrameNone = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rdo8Color = new System.Windows.Forms.RadioButton();
            this.rdoChannel = new System.Windows.Forms.RadioButton();
            this.rdoRGBA = new System.Windows.Forms.RadioButton();
            this.chkTransparency = new System.Windows.Forms.CheckBox();
            this.rdoMSX1Color = new System.Windows.Forms.RadioButton();
            this.rdoDispEnt256 = new System.Windows.Forms.RadioButton();
            this.rdoDisplay256 = new System.Windows.Forms.RadioButton();
            this.rdoULAplus = new System.Windows.Forms.RadioButton();
            this.RdoDisplayEGX = new System.Windows.Forms.RadioButton();
            this.rdoVic20MultiColor = new System.Windows.Forms.RadioButton();
            this.rdoHalfWidthFourColor = new System.Windows.Forms.RadioButton();
            this.rdoAppleColor = new System.Windows.Forms.RadioButton();
            this.rdoC64_4Color = new System.Windows.Forms.RadioButton();
            this.rdoCPCdither = new System.Windows.Forms.RadioButton();
            this.rdoSpecDither = new System.Windows.Forms.RadioButton();
            this.RdoTIquarter = new System.Windows.Forms.RadioButton();
            this.rdoCPCpairs = new System.Windows.Forms.RadioButton();
            this.rdoDisplayCPC0 = new System.Windows.Forms.RadioButton();
            this.rdoDisplaySpeccy = new System.Windows.Forms.RadioButton();
            this.rdoDisplayCPC = new System.Windows.Forms.RadioButton();
            this.rdoDisplayMSX = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdoGuide16_32_64 = new System.Windows.Forms.RadioButton();
            this.rdoC64Sprite = new System.Windows.Forms.RadioButton();
            this.rdoGuide7_14_28 = new System.Windows.Forms.RadioButton();
            this.rdoGuide4_8_32 = new System.Windows.Forms.RadioButton();
            this.rdoGuide4_8_24 = new System.Windows.Forms.RadioButton();
            this.rdoGuideNone = new System.Windows.Forms.RadioButton();
            this.chkStrongGrid = new System.Windows.Forms.CheckBox();
            this.ChkBackgroundTestDots = new System.Windows.Forms.CheckBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.txtSaveTileCount = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.chkSaveMultiRaw = new System.Windows.Forms.CheckBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txtHspriteH = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtHspriteW = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.lblMaxSpritesByOffset = new System.Windows.Forms.Label();
            this.txtSpriteDataOffSet = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtNeoSprSkip = new System.Windows.Forms.TextBox();
            this.txtNeoSprHeight = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtFixedFileSize = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.chkHasDosHeader = new System.Windows.Forms.CheckBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnExportTilelist = new System.Windows.Forms.Button();
            this.btnExportInfo = new System.Windows.Forms.Button();
            this.lstSprites = new System.Windows.Forms.ListBox();
            this.tabNotes = new System.Windows.Forms.TabPage();
            this.txtNotes = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cboTileFormat = new System.Windows.Forms.ComboBox();
            this.txtNextTile = new System.Windows.Forms.TextBox();
            this.lblNextTile = new System.Windows.Forms.Label();
            this.txtFirstTile = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.lblSpriteInfo = new System.Windows.Forms.Label();
            this.pnlMSXpal = new System.Windows.Forms.Panel();
            this.pnlNESpal = new System.Windows.Forms.Panel();
            this.pnlC64pal = new System.Windows.Forms.Panel();
            this.pnlZXPalette = new System.Windows.Forms.Panel();
            this.BtnAltPal = new System.Windows.Forms.Button();
            this.tabSpriteTools = new System.Windows.Forms.TabControl();
            this.tabSpriteOptions = new System.Windows.Forms.TabPage();
            this.chkAligned = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSpriteSettings = new System.Windows.Forms.TextBox();
            this.tabPixelPaint = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.cboCheckMode = new System.Windows.Forms.ComboBox();
            this.tabZXPaint = new System.Windows.Forms.TabPage();
            this.label5 = new System.Windows.Forms.Label();
            this.cboZxPaintMode = new System.Windows.Forms.ComboBox();
            this.tabColorSwap = new System.Windows.Forms.TabPage();
            this.label7 = new System.Windows.Forms.Label();
            this.cboFillCheck = new System.Windows.Forms.ComboBox();
            this.cboColorConvertMode = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tabTileCopy = new System.Windows.Forms.TabPage();
            this.btnMatchAll = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.cboDeres = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.BtnClearAdd = new System.Windows.Forms.Button();
            this.tabVector = new System.Windows.Forms.TabPage();
            this.btnZ80Vec = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.CboVectorType = new System.Windows.Forms.ComboBox();
            this.btnVectorClear = new System.Windows.Forms.Button();
            this.btnVectorToClip = new System.Windows.Forms.Button();
            this.txtVectors = new System.Windows.Forms.TextBox();
            this.chkFixedSize = new System.Windows.Forms.CheckBox();
            this.btnNextBank = new System.Windows.Forms.Button();
            this.btnLastBank = new System.Windows.Forms.Button();
            this.btnNextSprite = new System.Windows.Forms.Button();
            this.btnLastSprite = new System.Windows.Forms.Button();
            this.btnSetPal = new System.Windows.Forms.Button();
            this.tmrBackup = new System.Windows.Forms.Timer(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.BtnUlaPalSwap = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.reSaveSpritesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveSpritesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.savePaletteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadPaletteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadPixelsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importBackgroundToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.recentFilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.recent1 = new System.Windows.Forms.ToolStripMenuItem();
            this.recent2 = new System.Windows.Forms.ToolStripMenuItem();
            this.recent3 = new System.Windows.Forms.ToolStripMenuItem();
            this.recent4 = new System.Windows.Forms.ToolStripMenuItem();
            this.recent5 = new System.Windows.Forms.ToolStripMenuItem();
            this.recent6 = new System.Windows.Forms.ToolStripMenuItem();
            this.recent7 = new System.Windows.Forms.ToolStripMenuItem();
            this.recent8 = new System.Windows.Forms.ToolStripMenuItem();
            this.recent9 = new System.Windows.Forms.ToolStripMenuItem();
            this.recent10 = new System.Windows.Forms.ToolStripMenuItem();
            this.importImageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fromFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fromFilewithPaletteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileProcessorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rLECompressPerByteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rLECompressAlternatingBytesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rLECompressFourBytesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveBMPMapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadBMPMaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ViewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mSX16ColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cPC4ColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colorpairsCPCENTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colorditheredCPCENTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zX2ColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colorditheredToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.cPC16ColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eGX416ColorCPCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.highVisToggleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.overlayLastFrameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.overlayNextFrameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripSeparator();
            this.applyViewColorConversionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToClipboardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToClipToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyPreviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.canvasSizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.duplicateFromToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.duplicateOffsetFromToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.makeTilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transformToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.flipXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.flipYToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pxShiftToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pixelShiftRightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pixelShiftUpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pixelShiftDownToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tileShiftXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yInterlaceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.interlaceOddFieldsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.interlaceEvenFieldsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setAllAttribsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.blackBorderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.blackBorderTightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PaletteTint = new System.Windows.Forms.ToolStripMenuItem();
            this.tilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addTilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearTilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addMultipleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deresAllMultipleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.palettesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileToolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.loadFromPALIrfanviewToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToPALirfanviewToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.defauktToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enterprise256ColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mSX1PaletteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.simple4x4x4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.greyScalePaletteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sQLCLX8ColorPaletteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dragonCOCOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.palette0GToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.palette1WCMOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spritesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spriteSpace8x816x16ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.generatePixelMapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.insertBlankSpriteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.halveYToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.z80ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cPCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.loadCPCBinaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveCPCBinaryToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.loadCPCBinaryToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveCPCBinaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SaveCPCRawBmp = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRaw8x8TilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRaw8x8Tiles4ColorZigTileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRaw8x4Tiles4ColorHalfHeightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveCPCZigTileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveCPCSCRToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rLEASMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spriteCompilerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addOneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CpcSpriteConvaddOneDiffToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CpcSpriteCompilerClear = new System.Windows.Forms.ToolStripMenuItem();
            this.saveASMPaletteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mSXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveMSXASMPaletteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveMSXBinaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bMPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveMSXBitmapToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveMSXBitmapWithPaletteToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveMSXBitmapSpritesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rLEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buildRLEASMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveMSXRLEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveMSXRLEPaletteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.saveMSXRLESpritesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRAWBitmapToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRAWMSX1BitmapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRAWMSX1Raw16x16SpriteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawVdpTileBitmapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveMSX2RawYJKBitmapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveMSX2RawYJKABitmapYAEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mSX2PaletteToClipboardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadSpectrumScreenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveSpectrumBinaryToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveSpectrumTilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveSpectrumFontToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRaw8x8TilemapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveSpectrumScreenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.rLEASMToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.rLEASMCOLORToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.fourColor2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.invertZXToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.halfSizeFontToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spriteCompilerToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.addOneToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteZXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileToolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapToolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.tIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveTi83BitmapBWToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveTi8416bitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveTi84Bitmap4bppToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paletteToClipboard15bitBGRToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sAMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRLEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveBinarySpritesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRaw8x8TilesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.paletteToClipboardToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.eNTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRAWBitmapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rLEASMToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.sMSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileToolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.sMSPaletteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gGPaletteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.camputersLynxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapToolStripMenuItem17 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRaw8x8TileBitmapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.specNEXTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveULAScreenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveULAScreenPaletteOnlyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveNEXTPaletteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveNEXT9BitPaletteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveLoResLayerRadasjimianRawBitmap128x96ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.save8bppRawBitmapToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.save4bppRawBitmapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.save2bppRawBitmapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.save2bpp8x8TilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.save4bpp8x8TilesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.save8bpp8x8TilesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.save4bppSpriteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.save8bppSpriteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.save2bpp8x8TilesHalfHeightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paletteToClipboardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.atari5200800ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmap2ColorToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmap4ColorToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.atariLynxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapToolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.save16colorLinearSpriteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.save8colorLinearSpriteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.save16ColorRLESpriteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.save8ColorRLESpriteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.save4ColorRLESpriteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.save2ColorRLESpriteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paletteToClipboardToolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.aToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmap2ColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmap4ColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRaw8x82colorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bBCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapToolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.c64ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmap2ColorToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmap4ColorToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveSprite2ColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveSprite4ColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveSprite4ColorToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.nESFamicomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapToolStripMenuItem14 = new System.Windows.Forms.ToolStripMenuItem();
            this.pCEngineToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapToolStripMenuItem13 = new System.Windows.Forms.ToolStripMenuItem();
            this.savePCESpriteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paletteToClipboardToolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.superNintendoSFCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapToolStripMenuItem15 = new System.Windows.Forms.ToolStripMenuItem();
            this.paletteToClipboardToolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmap2bpp4ColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vic20ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapToolStripMenuItem16 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveDoubleHeightBitmapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.x16ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.save8bppRawBitmapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.save4bppRawBitmalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.save4bpp16x16SpritesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.save8bpp16x16SpritesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paletteToClipboardRGBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.save4bpp8x8TilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.save8bpp8x8TilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.save8bpp16x16TilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paletteToClipboardToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.neoGeoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveFIXFontToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveSpriteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadSpriteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paletteToClipboardToolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveCDSpriteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.atariSTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapToolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRaw8x8BitmapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paletteToClipboardToolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.AmigaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapToolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawSpriteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copperlistPaletteToClipboardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.x68000ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapToolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveSpriteToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.paletteToClipboardToolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.megaDriveGenesisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapToolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawSpriteToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.paletteToClipboardToolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.sinclairQLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.raw8colorBitmapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.raw4colorBitmapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.raw8Color8x8BitmapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paletteToClipboardToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.x86ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wonderSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapToolStripMenuItem18 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmap2bitPlanarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmap4bitLinearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmap2bitLinearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.msDosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapCGAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapEGAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapVGAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paletteToClipboardToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.aRMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.riscOSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRaw4ColorBitmapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRaw256ColorBitmapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gBAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmap4bppToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRaw256ColorBitmap4bppToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paletteToClipboardToolStripMenuItem14 = new System.Windows.Forms.ToolStripMenuItem();
            this.save4bToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.save8bpp8x8TilesToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.nDSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRaw256ColorBitmap8bppToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapToolStripMenuItem20 = new System.Windows.Forms.ToolStripMenuItem();
            this.paletteToClipboardToolStripMenuItem15 = new System.Windows.Forms.ToolStripMenuItem();
            this.save4bpp8x8TilesToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.save8bpp8x8TilesSpriteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paletteToClipboardToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.mIPSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pSXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.save8x8Font16bppToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.n64ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.save8x8Font16bppToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.fM7ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapToolStripMenuItem21 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmap2PlaneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRaw8x8Tiles2PlaneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRaw8x8Tiles3PlaneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dragonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRaw4ColorBitmapToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.savToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tRS80CoCo3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveCoCo46ColorBitmapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tMS9900ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tI99ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pDP11ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uKNCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapToolStripMenuItem19 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmap3BitplanesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.foenixC256ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.savePaletteToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.aToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.paletteToClipboardToolStripMenuItem13 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawSuperHiResBitmapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlApplePal = new System.Windows.Forms.Panel();
            this.bigfont = new System.Windows.Forms.Label();
            this.pnlULAPal = new System.Windows.Forms.Panel();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.chkSimpleSize = new System.Windows.Forms.CheckBox();
            this.tabPalette = new System.Windows.Forms.TabPage();
            this.lblAlpha2 = new System.Windows.Forms.Label();
            this.lblAlpha = new System.Windows.Forms.Label();
            this.trkAlpha = new System.Windows.Forms.TrackBar();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label18 = new System.Windows.Forms.Label();
            this.btnYoutube = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnLearnAsm = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.tmrHideInfo = new System.Windows.Forms.Timer(this.components);
            this.saveHalfHeightRawBitmap8x4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pETToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapToolStripMenuItem22 = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.picPreview)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkzoom)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabEditor.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.grpSpriteSize.SuspendLayout();
            this.GrpFrameOverlay.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabNotes.SuspendLayout();
            this.tabSpriteTools.SuspendLayout();
            this.tabSpriteOptions.SuspendLayout();
            this.tabPixelPaint.SuspendLayout();
            this.tabZXPaint.SuspendLayout();
            this.tabColorSwap.SuspendLayout();
            this.tabTileCopy.SuspendLayout();
            this.tabVector.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.pnlULAPal.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPalette.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trkAlpha)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.AutoScroll = true;
            this.panel1.Location = new System.Drawing.Point(48, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(714, 723);
            this.panel1.TabIndex = 0;
            // 
            // picPreview
            // 
            this.picPreview.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.picPreview.BackColor = System.Drawing.Color.Black;
            this.picPreview.Location = new System.Drawing.Point(781, 298);
            this.picPreview.Name = "picPreview";
            this.picPreview.Size = new System.Drawing.Size(256, 256);
            this.picPreview.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picPreview.TabIndex = 1;
            this.picPreview.TabStop = false;
            // 
            // trkzoom
            // 
            this.trkzoom.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.trkzoom.Location = new System.Drawing.Point(778, 85);
            this.trkzoom.Maximum = 32;
            this.trkzoom.Minimum = 2;
            this.trkzoom.Name = "trkzoom";
            this.trkzoom.Size = new System.Drawing.Size(153, 42);
            this.trkzoom.TabIndex = 2;
            this.trkzoom.TickFrequency = 2;
            this.trkzoom.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.toolTip1.SetToolTip(this.trkzoom, "Zoom drawing area (or Mousewheel)");
            this.trkzoom.Value = 4;
            this.trkzoom.Scroll += new System.EventHandler(this.trkzoom_Scroll);
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabEditor);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabNotes);
            this.tabControl1.Location = new System.Drawing.Point(4, 71);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(773, 762);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tabControl1_KeyDown);
            // 
            // tabEditor
            // 
            this.tabEditor.Controls.Add(this.btnVector);
            this.tabEditor.Controls.Add(this.btnOnlineHelp);
            this.tabEditor.Controls.Add(this.btnHelp);
            this.tabEditor.Controls.Add(this.btnTileCopy);
            this.tabEditor.Controls.Add(this.btnColorSwap2);
            this.tabEditor.Controls.Add(this.btnZXpaint2);
            this.tabEditor.Controls.Add(this.btnToolPixelPaint);
            this.tabEditor.Controls.Add(this.btnRedo);
            this.tabEditor.Controls.Add(this.btnUndo);
            this.tabEditor.Controls.Add(this.btnRefresh);
            this.tabEditor.Controls.Add(this.panel1);
            this.tabEditor.Controls.Add(this.btnFloodFill);
            this.tabEditor.Location = new System.Drawing.Point(4, 21);
            this.tabEditor.Name = "tabEditor";
            this.tabEditor.Padding = new System.Windows.Forms.Padding(3);
            this.tabEditor.Size = new System.Drawing.Size(765, 737);
            this.tabEditor.TabIndex = 0;
            this.tabEditor.Text = "Editor";
            this.tabEditor.UseVisualStyleBackColor = true;
            this.tabEditor.Click += new System.EventHandler(this.tabEditor_Click);
            // 
            // btnVector
            // 
            this.btnVector.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVector.Location = new System.Drawing.Point(0, 252);
            this.btnVector.Name = "btnVector";
            this.btnVector.Size = new System.Drawing.Size(48, 48);
            this.btnVector.TabIndex = 28;
            this.btnVector.Text = "Vectrex\r\nVectors";
            this.btnVector.UseVisualStyleBackColor = true;
            this.btnVector.Click += new System.EventHandler(this.btnVector_Click);
            // 
            // btnOnlineHelp
            // 
            this.btnOnlineHelp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnOnlineHelp.Location = new System.Drawing.Point(0, 626);
            this.btnOnlineHelp.Name = "btnOnlineHelp";
            this.btnOnlineHelp.Size = new System.Drawing.Size(48, 48);
            this.btnOnlineHelp.TabIndex = 13;
            this.btnOnlineHelp.Text = "Online Help";
            this.toolTip1.SetToolTip(this.btnOnlineHelp, "View the Akusprite Editor Documentation online");
            this.btnOnlineHelp.UseVisualStyleBackColor = false;
            this.btnOnlineHelp.Click += new System.EventHandler(this.btnOnlineHelp_Click);
            // 
            // btnHelp
            // 
            this.btnHelp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnHelp.Location = new System.Drawing.Point(0, 680);
            this.btnHelp.Name = "btnHelp";
            this.btnHelp.Size = new System.Drawing.Size(48, 48);
            this.btnHelp.TabIndex = 27;
            this.btnHelp.Text = "Help\r\n[?]";
            this.toolTip1.SetToolTip(this.btnHelp, "Redo (Ctrl-Shift-Z)");
            this.btnHelp.UseVisualStyleBackColor = false;
            this.btnHelp.Click += new System.EventHandler(this.btnHelp_Click);
            // 
            // btnTileCopy
            // 
            this.btnTileCopy.Location = new System.Drawing.Point(0, 150);
            this.btnTileCopy.Name = "btnTileCopy";
            this.btnTileCopy.Size = new System.Drawing.Size(48, 48);
            this.btnTileCopy.TabIndex = 25;
            this.btnTileCopy.Text = "Tile Copy";
            this.btnTileCopy.UseVisualStyleBackColor = true;
            this.btnTileCopy.Click += new System.EventHandler(this.btnTileCopy_Click);
            // 
            // btnColorSwap2
            // 
            this.btnColorSwap2.Location = new System.Drawing.Point(0, 102);
            this.btnColorSwap2.Name = "btnColorSwap2";
            this.btnColorSwap2.Size = new System.Drawing.Size(48, 48);
            this.btnColorSwap2.TabIndex = 24;
            this.btnColorSwap2.Text = "Color Swap";
            this.btnColorSwap2.UseVisualStyleBackColor = true;
            this.btnColorSwap2.Click += new System.EventHandler(this.btnColorSwap_Click_1);
            // 
            // btnZXpaint2
            // 
            this.btnZXpaint2.Location = new System.Drawing.Point(0, 54);
            this.btnZXpaint2.Name = "btnZXpaint2";
            this.btnZXpaint2.Size = new System.Drawing.Size(48, 48);
            this.btnZXpaint2.TabIndex = 22;
            this.btnZXpaint2.Text = "ZX Paint";
            this.btnZXpaint2.UseVisualStyleBackColor = true;
            this.btnZXpaint2.Click += new System.EventHandler(this.btnZXpaint2_Click);
            // 
            // btnToolPixelPaint
            // 
            this.btnToolPixelPaint.Location = new System.Drawing.Point(0, 3);
            this.btnToolPixelPaint.Name = "btnToolPixelPaint";
            this.btnToolPixelPaint.Size = new System.Drawing.Size(48, 48);
            this.btnToolPixelPaint.TabIndex = 21;
            this.btnToolPixelPaint.Text = "Pixel Paint";
            this.btnToolPixelPaint.UseVisualStyleBackColor = true;
            this.btnToolPixelPaint.Click += new System.EventHandler(this.btnToolPixelPaint_Click);
            // 
            // btnRedo
            // 
            this.btnRedo.Location = new System.Drawing.Point(0, 489);
            this.btnRedo.Name = "btnRedo";
            this.btnRedo.Size = new System.Drawing.Size(48, 48);
            this.btnRedo.TabIndex = 12;
            this.btnRedo.Text = "Redo";
            this.toolTip1.SetToolTip(this.btnRedo, "Redo last action (Ctrl-Shift-Z)");
            this.btnRedo.UseVisualStyleBackColor = true;
            this.btnRedo.Click += new System.EventHandler(this.btnRedo_Click);
            // 
            // btnUndo
            // 
            this.btnUndo.Location = new System.Drawing.Point(0, 435);
            this.btnUndo.Name = "btnUndo";
            this.btnUndo.Size = new System.Drawing.Size(48, 48);
            this.btnUndo.TabIndex = 11;
            this.btnUndo.Text = "Undo";
            this.toolTip1.SetToolTip(this.btnUndo, "Undo last action (Ctrl-Z)");
            this.btnUndo.UseVisualStyleBackColor = true;
            this.btnUndo.Click += new System.EventHandler(this.btnUndo_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(0, 384);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(48, 48);
            this.btnRefresh.TabIndex = 3;
            this.btnRefresh.Text = "Re Fresh";
            this.toolTip1.SetToolTip(this.btnRefresh, "Replaint the Sprite drawing area");
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnFloodFill
            // 
            this.btnFloodFill.Location = new System.Drawing.Point(0, 198);
            this.btnFloodFill.Name = "btnFloodFill";
            this.btnFloodFill.Size = new System.Drawing.Size(48, 48);
            this.btnFloodFill.TabIndex = 26;
            this.btnFloodFill.Text = "Flood Fill";
            this.btnFloodFill.UseVisualStyleBackColor = true;
            this.btnFloodFill.Click += new System.EventHandler(this.btnFloodFill_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox8);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.grpSpriteSize);
            this.tabPage2.Controls.Add(this.GrpFrameOverlay);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 21);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(765, 737);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Settings";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.rdoBnk32);
            this.groupBox8.Controls.Add(this.rdoBnk8);
            this.groupBox8.Controls.Add(this.rdoBnk16);
            this.groupBox8.Controls.Add(this.rdoBnk4);
            this.groupBox8.Location = new System.Drawing.Point(427, 11);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(171, 63);
            this.groupBox8.TabIndex = 17;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "BankCount";
            // 
            // rdoBnk32
            // 
            this.rdoBnk32.AutoSize = true;
            this.rdoBnk32.Location = new System.Drawing.Point(79, 36);
            this.rdoBnk32.Name = "rdoBnk32";
            this.rdoBnk32.Size = new System.Drawing.Size(71, 16);
            this.rdoBnk32.TabIndex = 18;
            this.rdoBnk32.Text = "32 Banks";
            this.toolTip1.SetToolTip(this.rdoBnk32, "Resolution of the Sprite drawing area - Bigger areas slow down the program!");
            this.rdoBnk32.UseVisualStyleBackColor = true;
            this.rdoBnk32.CheckedChanged += new System.EventHandler(this.rdoBnk32_CheckedChanged);
            // 
            // rdoBnk8
            // 
            this.rdoBnk8.AutoSize = true;
            this.rdoBnk8.Location = new System.Drawing.Point(79, 18);
            this.rdoBnk8.Name = "rdoBnk8";
            this.rdoBnk8.Size = new System.Drawing.Size(65, 16);
            this.rdoBnk8.TabIndex = 2;
            this.rdoBnk8.Text = "8 Banks";
            this.toolTip1.SetToolTip(this.rdoBnk8, "Resolution of the Sprite drawing area - Bigger areas slow down the program!");
            this.rdoBnk8.UseVisualStyleBackColor = true;
            this.rdoBnk8.CheckedChanged += new System.EventHandler(this.rdoBnk8_CheckedChanged);
            // 
            // rdoBnk16
            // 
            this.rdoBnk16.AutoSize = true;
            this.rdoBnk16.Location = new System.Drawing.Point(7, 35);
            this.rdoBnk16.Name = "rdoBnk16";
            this.rdoBnk16.Size = new System.Drawing.Size(71, 16);
            this.rdoBnk16.TabIndex = 1;
            this.rdoBnk16.Text = "16 Banks";
            this.toolTip1.SetToolTip(this.rdoBnk16, "Resolution of the Sprite drawing area - Bigger areas slow down the program!");
            this.rdoBnk16.UseVisualStyleBackColor = true;
            this.rdoBnk16.CheckedChanged += new System.EventHandler(this.rdoBnk16_CheckedChanged);
            // 
            // rdoBnk4
            // 
            this.rdoBnk4.AutoSize = true;
            this.rdoBnk4.Checked = true;
            this.rdoBnk4.Location = new System.Drawing.Point(6, 18);
            this.rdoBnk4.Name = "rdoBnk4";
            this.rdoBnk4.Size = new System.Drawing.Size(65, 16);
            this.rdoBnk4.TabIndex = 0;
            this.rdoBnk4.TabStop = true;
            this.rdoBnk4.Text = "4 Banks";
            this.toolTip1.SetToolTip(this.rdoBnk4, "Resolution of the Sprite drawing area - Bigger areas slow down the program!");
            this.rdoBnk4.UseVisualStyleBackColor = true;
            this.rdoBnk4.CheckedChanged += new System.EventHandler(this.rdoBnk4_CheckedChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cbo4colorDither);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Location = new System.Drawing.Point(171, 501);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(245, 106);
            this.groupBox3.TabIndex = 16;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Dither Option";
            // 
            // cbo4colorDither
            // 
            this.cbo4colorDither.FormattingEnabled = true;
            this.cbo4colorDither.Items.AddRange(new object[] {
            "Normal",
            "Alternate"});
            this.cbo4colorDither.Location = new System.Drawing.Point(97, 13);
            this.cbo4colorDither.Name = "cbo4colorDither";
            this.cbo4colorDither.Size = new System.Drawing.Size(132, 20);
            this.cbo4colorDither.TabIndex = 1;
            this.toolTip1.SetToolTip(this.cbo4colorDither, "Dithering mode - change this to tweak dithering settings");
            this.cbo4colorDither.SelectedIndexChanged += new System.EventHandler(this.cbo4colorDither_SelectedIndexChanged);
            this.cbo4colorDither.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cboCheckMode_KeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(16, 21);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(38, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "4Color";
            // 
            // grpSpriteSize
            // 
            this.grpSpriteSize.Controls.Add(this.rdoVGA);
            this.grpSpriteSize.Controls.Add(this.rdoSprWide);
            this.grpSpriteSize.Controls.Add(this.rdospr512);
            this.grpSpriteSize.Controls.Add(this.rdospr256);
            this.grpSpriteSize.Location = new System.Drawing.Point(427, 89);
            this.grpSpriteSize.Name = "grpSpriteSize";
            this.grpSpriteSize.Size = new System.Drawing.Size(171, 63);
            this.grpSpriteSize.TabIndex = 15;
            this.grpSpriteSize.TabStop = false;
            this.grpSpriteSize.Text = "MAX SpriteSize";
            // 
            // rdoVGA
            // 
            this.rdoVGA.AutoSize = true;
            this.rdoVGA.Location = new System.Drawing.Point(79, 36);
            this.rdoVGA.Name = "rdoVGA";
            this.rdoVGA.Size = new System.Drawing.Size(65, 16);
            this.rdoVGA.TabIndex = 18;
            this.rdoVGA.Text = "320x240";
            this.toolTip1.SetToolTip(this.rdoVGA, "Resolution of the Sprite drawing area - Bigger areas slow down the program!");
            this.rdoVGA.UseVisualStyleBackColor = true;
            this.rdoVGA.CheckedChanged += new System.EventHandler(this.rdoVGA_CheckedChanged);
            // 
            // rdoSprWide
            // 
            this.rdoSprWide.AutoSize = true;
            this.rdoSprWide.Location = new System.Drawing.Point(79, 18);
            this.rdoSprWide.Name = "rdoSprWide";
            this.rdoSprWide.Size = new System.Drawing.Size(65, 16);
            this.rdoSprWide.TabIndex = 2;
            this.rdoSprWide.Text = "512x256";
            this.toolTip1.SetToolTip(this.rdoSprWide, "Resolution of the Sprite drawing area - Bigger areas slow down the program!");
            this.rdoSprWide.UseVisualStyleBackColor = true;
            this.rdoSprWide.CheckedChanged += new System.EventHandler(this.rdoSprWide_CheckedChanged);
            // 
            // rdospr512
            // 
            this.rdospr512.AutoSize = true;
            this.rdospr512.Location = new System.Drawing.Point(7, 35);
            this.rdospr512.Name = "rdospr512";
            this.rdospr512.Size = new System.Drawing.Size(65, 16);
            this.rdospr512.TabIndex = 1;
            this.rdospr512.Text = "512x512";
            this.toolTip1.SetToolTip(this.rdospr512, "Resolution of the Sprite drawing area - Bigger areas slow down the program!");
            this.rdospr512.UseVisualStyleBackColor = true;
            this.rdospr512.CheckedChanged += new System.EventHandler(this.rdospr512_CheckedChanged);
            // 
            // rdospr256
            // 
            this.rdospr256.AutoSize = true;
            this.rdospr256.Checked = true;
            this.rdospr256.Location = new System.Drawing.Point(6, 18);
            this.rdospr256.Name = "rdospr256";
            this.rdospr256.Size = new System.Drawing.Size(65, 16);
            this.rdospr256.TabIndex = 0;
            this.rdospr256.TabStop = true;
            this.rdospr256.Text = "256x256";
            this.toolTip1.SetToolTip(this.rdospr256, "Resolution of the Sprite drawing area - Bigger areas slow down the program!");
            this.rdospr256.UseVisualStyleBackColor = true;
            this.rdospr256.CheckedChanged += new System.EventHandler(this.rdospr256_CheckedChanged);
            // 
            // GrpFrameOverlay
            // 
            this.GrpFrameOverlay.Controls.Add(this.rdoFrameLast);
            this.GrpFrameOverlay.Controls.Add(this.rdoFrameNext);
            this.GrpFrameOverlay.Controls.Add(this.rdoFrameNone);
            this.GrpFrameOverlay.Location = new System.Drawing.Point(427, 169);
            this.GrpFrameOverlay.Name = "GrpFrameOverlay";
            this.GrpFrameOverlay.Size = new System.Drawing.Size(144, 113);
            this.GrpFrameOverlay.TabIndex = 14;
            this.GrpFrameOverlay.TabStop = false;
            this.GrpFrameOverlay.Text = "FrameOverlay";
            // 
            // rdoFrameLast
            // 
            this.rdoFrameLast.AutoSize = true;
            this.rdoFrameLast.Location = new System.Drawing.Point(8, 62);
            this.rdoFrameLast.Name = "rdoFrameLast";
            this.rdoFrameLast.Size = new System.Drawing.Size(75, 16);
            this.rdoFrameLast.TabIndex = 16;
            this.rdoFrameLast.Text = "Last Bank";
            this.toolTip1.SetToolTip(this.rdoFrameLast, "Onion Skinning - Show Transparent shadow of other Banks sprite");
            this.rdoFrameLast.UseVisualStyleBackColor = true;
            this.rdoFrameLast.CheckedChanged += new System.EventHandler(this.rdoFrameLast_CheckedChanged);
            // 
            // rdoFrameNext
            // 
            this.rdoFrameNext.AutoSize = true;
            this.rdoFrameNext.Location = new System.Drawing.Point(8, 40);
            this.rdoFrameNext.Name = "rdoFrameNext";
            this.rdoFrameNext.Size = new System.Drawing.Size(77, 16);
            this.rdoFrameNext.TabIndex = 15;
            this.rdoFrameNext.Text = "Next Bank";
            this.toolTip1.SetToolTip(this.rdoFrameNext, "Onion Skinning - Show Transparent shadow of other Banks sprite");
            this.rdoFrameNext.UseVisualStyleBackColor = true;
            this.rdoFrameNext.CheckedChanged += new System.EventHandler(this.rdoFrameNext_CheckedChanged);
            // 
            // rdoFrameNone
            // 
            this.rdoFrameNone.AutoSize = true;
            this.rdoFrameNone.Checked = true;
            this.rdoFrameNone.Location = new System.Drawing.Point(9, 18);
            this.rdoFrameNone.Name = "rdoFrameNone";
            this.rdoFrameNone.Size = new System.Drawing.Size(49, 16);
            this.rdoFrameNone.TabIndex = 15;
            this.rdoFrameNone.TabStop = true;
            this.rdoFrameNone.Text = "None";
            this.toolTip1.SetToolTip(this.rdoFrameNone, "Onion Skinning - Show Transparent shadow of other Banks sprite");
            this.rdoFrameNone.UseVisualStyleBackColor = true;
            this.rdoFrameNone.CheckedChanged += new System.EventHandler(this.rdoFrameNone_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rdo8Color);
            this.groupBox2.Controls.Add(this.rdoChannel);
            this.groupBox2.Controls.Add(this.rdoRGBA);
            this.groupBox2.Controls.Add(this.chkTransparency);
            this.groupBox2.Controls.Add(this.rdoMSX1Color);
            this.groupBox2.Controls.Add(this.rdoDispEnt256);
            this.groupBox2.Controls.Add(this.rdoDisplay256);
            this.groupBox2.Controls.Add(this.rdoULAplus);
            this.groupBox2.Controls.Add(this.RdoDisplayEGX);
            this.groupBox2.Controls.Add(this.rdoVic20MultiColor);
            this.groupBox2.Controls.Add(this.rdoHalfWidthFourColor);
            this.groupBox2.Controls.Add(this.rdoAppleColor);
            this.groupBox2.Controls.Add(this.rdoC64_4Color);
            this.groupBox2.Controls.Add(this.rdoCPCdither);
            this.groupBox2.Controls.Add(this.rdoSpecDither);
            this.groupBox2.Controls.Add(this.RdoTIquarter);
            this.groupBox2.Controls.Add(this.rdoCPCpairs);
            this.groupBox2.Controls.Add(this.rdoDisplayCPC0);
            this.groupBox2.Controls.Add(this.rdoDisplaySpeccy);
            this.groupBox2.Controls.Add(this.rdoDisplayCPC);
            this.groupBox2.Controls.Add(this.rdoDisplayMSX);
            this.groupBox2.Location = new System.Drawing.Point(171, 11);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(249, 484);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "DisplayMode";
            // 
            // rdo8Color
            // 
            this.rdo8Color.AutoSize = true;
            this.rdo8Color.Location = new System.Drawing.Point(6, 414);
            this.rdo8Color.Name = "rdo8Color";
            this.rdo8Color.Size = new System.Drawing.Size(120, 16);
            this.rdo8Color.TabIndex = 32;
            this.rdo8Color.TabStop = true;
            this.rdo8Color.Text = "8 Color (CLX/SQL)";
            this.rdo8Color.UseVisualStyleBackColor = true;
            // 
            // rdoChannel
            // 
            this.rdoChannel.AutoSize = true;
            this.rdoChannel.Location = new System.Drawing.Point(126, 14);
            this.rdoChannel.Name = "rdoChannel";
            this.rdoChannel.Size = new System.Drawing.Size(64, 16);
            this.rdoChannel.TabIndex = 31;
            this.rdoChannel.Text = "Channel";
            this.toolTip1.SetToolTip(this.rdoChannel, "RGBA Color");
            this.rdoChannel.UseVisualStyleBackColor = true;
            // 
            // rdoRGBA
            // 
            this.rdoRGBA.AutoSize = true;
            this.rdoRGBA.Location = new System.Drawing.Point(6, 14);
            this.rdoRGBA.Name = "rdoRGBA";
            this.rdoRGBA.Size = new System.Drawing.Size(114, 16);
            this.rdoRGBA.TabIndex = 30;
            this.rdoRGBA.Text = "4294967296 Color";
            this.toolTip1.SetToolTip(this.rdoRGBA, "RGBA Color");
            this.rdoRGBA.UseVisualStyleBackColor = true;
            this.rdoRGBA.CheckedChanged += new System.EventHandler(this.rdoRGBA_CheckedChanged);
            // 
            // chkTransparency
            // 
            this.chkTransparency.AutoSize = true;
            this.chkTransparency.Location = new System.Drawing.Point(116, 457);
            this.chkTransparency.Name = "chkTransparency";
            this.chkTransparency.Size = new System.Drawing.Size(120, 16);
            this.chkTransparency.TabIndex = 29;
            this.chkTransparency.Text = "TransparencyMask";
            this.toolTip1.SetToolTip(this.chkTransparency, "This function will show \'Transparency Mask\' - Color 16 is transparent (Color 1) a" +
                    "ll other colors are black (Color 0)");
            this.chkTransparency.UseVisualStyleBackColor = true;
            this.chkTransparency.CheckedChanged += new System.EventHandler(this.chkTransparency_CheckedChanged);
            // 
            // rdoMSX1Color
            // 
            this.rdoMSX1Color.AutoSize = true;
            this.rdoMSX1Color.Location = new System.Drawing.Point(6, 392);
            this.rdoMSX1Color.Name = "rdoMSX1Color";
            this.rdoMSX1Color.Size = new System.Drawing.Size(103, 16);
            this.rdoMSX1Color.TabIndex = 28;
            this.rdoMSX1Color.TabStop = true;
            this.rdoMSX1Color.Text = "Msx1 8x1 Color";
            this.rdoMSX1Color.UseVisualStyleBackColor = true;
            // 
            // rdoDispEnt256
            // 
            this.rdoDispEnt256.AutoSize = true;
            this.rdoDispEnt256.Location = new System.Drawing.Point(6, 370);
            this.rdoDispEnt256.Name = "rdoDispEnt256";
            this.rdoDispEnt256.Size = new System.Drawing.Size(132, 16);
            this.rdoDispEnt256.TabIndex = 26;
            this.rdoDispEnt256.Text = "ENT 80x200 256color";
            this.toolTip1.SetToolTip(this.rdoDispEnt256, "256 color");
            this.rdoDispEnt256.UseVisualStyleBackColor = true;
            this.rdoDispEnt256.CheckedChanged += new System.EventHandler(this.rdoDispEnt256_CheckedChanged);
            // 
            // rdoDisplay256
            // 
            this.rdoDisplay256.AutoSize = true;
            this.rdoDisplay256.Location = new System.Drawing.Point(6, 36);
            this.rdoDisplay256.Name = "rdoDisplay256";
            this.rdoDisplay256.Size = new System.Drawing.Size(72, 16);
            this.rdoDisplay256.TabIndex = 27;
            this.rdoDisplay256.Text = "256 Color";
            this.toolTip1.SetToolTip(this.rdoDisplay256, "256 color mode - Enable full palette (in palette tab)");
            this.rdoDisplay256.UseVisualStyleBackColor = true;
            this.rdoDisplay256.CheckedChanged += new System.EventHandler(this.rdoDisplay256_CheckedChanged);
            // 
            // rdoULAplus
            // 
            this.rdoULAplus.AutoSize = true;
            this.rdoULAplus.Location = new System.Drawing.Point(6, 255);
            this.rdoULAplus.Name = "rdoULAplus";
            this.rdoULAplus.Size = new System.Drawing.Size(51, 16);
            this.rdoULAplus.TabIndex = 26;
            this.rdoULAplus.Text = "ULA+";
            this.toolTip1.SetToolTip(this.rdoULAplus, "Spectrum Next ULA option");
            this.rdoULAplus.UseVisualStyleBackColor = true;
            this.rdoULAplus.CheckedChanged += new System.EventHandler(this.rdoULAplus_CheckedChanged);
            // 
            // RdoDisplayEGX
            // 
            this.RdoDisplayEGX.AutoSize = true;
            this.RdoDisplayEGX.Location = new System.Drawing.Point(6, 167);
            this.RdoDisplayEGX.Name = "RdoDisplayEGX";
            this.RdoDisplayEGX.Size = new System.Drawing.Size(131, 16);
            this.RdoDisplayEGX.TabIndex = 25;
            this.RdoDisplayEGX.Text = "CPC/ENT Mode EGX";
            this.toolTip1.SetToolTip(this.RdoDisplayEGX, "Alternate lines Mode 0 / Mode 1");
            this.RdoDisplayEGX.UseVisualStyleBackColor = true;
            // 
            // rdoVic20MultiColor
            // 
            this.rdoVic20MultiColor.AutoSize = true;
            this.rdoVic20MultiColor.Location = new System.Drawing.Point(6, 348);
            this.rdoVic20MultiColor.Name = "rdoVic20MultiColor";
            this.rdoVic20MultiColor.Size = new System.Drawing.Size(106, 16);
            this.rdoVic20MultiColor.TabIndex = 24;
            this.rdoVic20MultiColor.Text = "Vic20 Multicolor";
            this.toolTip1.SetToolTip(this.rdoVic20MultiColor, "4 color");
            this.rdoVic20MultiColor.UseVisualStyleBackColor = true;
            // 
            // rdoHalfWidthFourColor
            // 
            this.rdoHalfWidthFourColor.AutoSize = true;
            this.rdoHalfWidthFourColor.Location = new System.Drawing.Point(6, 327);
            this.rdoHalfWidthFourColor.Name = "rdoHalfWidthFourColor";
            this.rdoHalfWidthFourColor.Size = new System.Drawing.Size(126, 16);
            this.rdoHalfWidthFourColor.TabIndex = 23;
            this.rdoHalfWidthFourColor.Text = "HalfWidth FourColor";
            this.toolTip1.SetToolTip(this.rdoHalfWidthFourColor, "4 color");
            this.rdoHalfWidthFourColor.UseVisualStyleBackColor = true;
            // 
            // rdoAppleColor
            // 
            this.rdoAppleColor.AutoSize = true;
            this.rdoAppleColor.Location = new System.Drawing.Point(6, 306);
            this.rdoAppleColor.Name = "rdoAppleColor";
            this.rdoAppleColor.Size = new System.Drawing.Size(93, 16);
            this.rdoAppleColor.TabIndex = 22;
            this.rdoAppleColor.Text = "Apple 4-color";
            this.toolTip1.SetToolTip(this.rdoAppleColor, "4 color");
            this.rdoAppleColor.UseVisualStyleBackColor = true;
            // 
            // rdoC64_4Color
            // 
            this.rdoC64_4Color.AutoSize = true;
            this.rdoC64_4Color.Location = new System.Drawing.Point(6, 285);
            this.rdoC64_4Color.Name = "rdoC64_4Color";
            this.rdoC64_4Color.Size = new System.Drawing.Size(84, 16);
            this.rdoC64_4Color.TabIndex = 21;
            this.rdoC64_4Color.Text = "C64 4-color";
            this.toolTip1.SetToolTip(this.rdoC64_4Color, "4 color");
            this.rdoC64_4Color.UseVisualStyleBackColor = true;
            // 
            // rdoCPCdither
            // 
            this.rdoCPCdither.AutoSize = true;
            this.rdoCPCdither.Location = new System.Drawing.Point(6, 120);
            this.rdoCPCdither.Name = "rdoCPCdither";
            this.rdoCPCdither.Size = new System.Drawing.Size(221, 16);
            this.rdoCPCdither.TabIndex = 20;
            this.rdoCPCdither.Text = "4 Color (CPC/ENT Mode 1 - Dithered)";
            this.toolTip1.SetToolTip(this.rdoCPCdither, "4 color");
            this.rdoCPCdither.UseVisualStyleBackColor = true;
            this.rdoCPCdither.CheckedChanged += new System.EventHandler(this.rdoCPCdither_CheckedChanged);
            // 
            // rdoSpecDither
            // 
            this.rdoSpecDither.AutoSize = true;
            this.rdoSpecDither.Location = new System.Drawing.Point(6, 213);
            this.rdoSpecDither.Name = "rdoSpecDither";
            this.rdoSpecDither.Size = new System.Drawing.Size(140, 16);
            this.rdoSpecDither.TabIndex = 19;
            this.rdoSpecDither.Text = "Spectrum/TI-83 Dither";
            this.toolTip1.SetToolTip(this.rdoSpecDither, "Spectrum screen - Anything not Color 1 is on");
            this.rdoSpecDither.UseVisualStyleBackColor = true;
            this.rdoSpecDither.CheckedChanged += new System.EventHandler(this.rdoSpecDither_CheckedChanged);
            // 
            // RdoTIquarter
            // 
            this.RdoTIquarter.AutoSize = true;
            this.RdoTIquarter.Location = new System.Drawing.Point(6, 234);
            this.RdoTIquarter.Name = "RdoTIquarter";
            this.RdoTIquarter.Size = new System.Drawing.Size(167, 16);
            this.RdoTIquarter.TabIndex = 18;
            this.RdoTIquarter.Text = "Spectrum/TI-83 QuarterRes";
            this.toolTip1.SetToolTip(this.RdoTIquarter, "Spectrum screen - Anything not Color 1 is on");
            this.RdoTIquarter.UseVisualStyleBackColor = true;
            // 
            // rdoCPCpairs
            // 
            this.rdoCPCpairs.AutoSize = true;
            this.rdoCPCpairs.Location = new System.Drawing.Point(6, 99);
            this.rdoCPCpairs.Name = "rdoCPCpairs";
            this.rdoCPCpairs.Size = new System.Drawing.Size(230, 16);
            this.rdoCPCpairs.TabIndex = 17;
            this.rdoCPCpairs.Text = "4 Color (CPC/ENT Mode 1 - Colorpairs)";
            this.toolTip1.SetToolTip(this.rdoCPCpairs, "4 color");
            this.rdoCPCpairs.UseVisualStyleBackColor = true;
            // 
            // rdoDisplayCPC0
            // 
            this.rdoDisplayCPC0.AutoSize = true;
            this.rdoDisplayCPC0.Location = new System.Drawing.Point(6, 146);
            this.rdoDisplayCPC0.Name = "rdoDisplayCPC0";
            this.rdoDisplayCPC0.Size = new System.Drawing.Size(115, 16);
            this.rdoDisplayCPC0.TabIndex = 16;
            this.rdoDisplayCPC0.Text = "CPC/ENT Mode 0";
            this.toolTip1.SetToolTip(this.rdoDisplayCPC0, "16 color Wide pixels");
            this.rdoDisplayCPC0.UseVisualStyleBackColor = true;
            this.rdoDisplayCPC0.CheckedChanged += new System.EventHandler(this.rdoDisplayCPC0_CheckedChanged);
            // 
            // rdoDisplaySpeccy
            // 
            this.rdoDisplaySpeccy.AutoSize = true;
            this.rdoDisplaySpeccy.Location = new System.Drawing.Point(6, 192);
            this.rdoDisplaySpeccy.Name = "rdoDisplaySpeccy";
            this.rdoDisplaySpeccy.Size = new System.Drawing.Size(105, 16);
            this.rdoDisplaySpeccy.TabIndex = 6;
            this.rdoDisplaySpeccy.Text = "Spectrum/TI-83";
            this.toolTip1.SetToolTip(this.rdoDisplaySpeccy, "Spectrum screen - Anything not Color 1 is on");
            this.rdoDisplaySpeccy.UseVisualStyleBackColor = true;
            this.rdoDisplaySpeccy.CheckedChanged += new System.EventHandler(this.rdoDisplaySpeccy_CheckedChanged);
            // 
            // rdoDisplayCPC
            // 
            this.rdoDisplayCPC.AutoSize = true;
            this.rdoDisplayCPC.Location = new System.Drawing.Point(6, 78);
            this.rdoDisplayCPC.Name = "rdoDisplayCPC";
            this.rdoDisplayCPC.Size = new System.Drawing.Size(174, 16);
            this.rdoDisplayCPC.TabIndex = 5;
            this.rdoDisplayCPC.Text = "4 Color (CPC/ENT/Msx2 G7)";
            this.toolTip1.SetToolTip(this.rdoDisplayCPC, "4 color");
            this.rdoDisplayCPC.UseVisualStyleBackColor = true;
            this.rdoDisplayCPC.CheckedChanged += new System.EventHandler(this.rdoDisplayCPC_CheckedChanged);
            // 
            // rdoDisplayMSX
            // 
            this.rdoDisplayMSX.AutoSize = true;
            this.rdoDisplayMSX.Checked = true;
            this.rdoDisplayMSX.Location = new System.Drawing.Point(6, 57);
            this.rdoDisplayMSX.Name = "rdoDisplayMSX";
            this.rdoDisplayMSX.Size = new System.Drawing.Size(175, 16);
            this.rdoDisplayMSX.TabIndex = 4;
            this.rdoDisplayMSX.TabStop = true;
            this.rdoDisplayMSX.Text = "16 Color (CPC+ / MSX / Etc)";
            this.toolTip1.SetToolTip(this.rdoDisplayMSX, "16 color (normal mode)");
            this.rdoDisplayMSX.UseVisualStyleBackColor = true;
            this.rdoDisplayMSX.CheckedChanged += new System.EventHandler(this.rdoDisplayMSX_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdoGuide16_32_64);
            this.groupBox1.Controls.Add(this.rdoC64Sprite);
            this.groupBox1.Controls.Add(this.rdoGuide7_14_28);
            this.groupBox1.Controls.Add(this.rdoGuide4_8_32);
            this.groupBox1.Controls.Add(this.rdoGuide4_8_24);
            this.groupBox1.Controls.Add(this.rdoGuideNone);
            this.groupBox1.Controls.Add(this.chkStrongGrid);
            this.groupBox1.Controls.Add(this.ChkBackgroundTestDots);
            this.groupBox1.Location = new System.Drawing.Point(4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(161, 220);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Guides";
            // 
            // rdoGuide16_32_64
            // 
            this.rdoGuide16_32_64.AutoSize = true;
            this.rdoGuide16_32_64.Location = new System.Drawing.Point(4, 120);
            this.rdoGuide16_32_64.Name = "rdoGuide16_32_64";
            this.rdoGuide16_32_64.Size = new System.Drawing.Size(63, 16);
            this.rdoGuide16_32_64.TabIndex = 18;
            this.rdoGuide16_32_64.TabStop = true;
            this.rdoGuide16_32_64.Text = "16,32,64";
            this.toolTip1.SetToolTip(this.rdoGuide16_32_64, "Change scale of the background grid");
            this.rdoGuide16_32_64.UseVisualStyleBackColor = true;
            this.rdoGuide16_32_64.CheckedChanged += new System.EventHandler(this.rdoGuide16_32_64_CheckedChanged);
            // 
            // rdoC64Sprite
            // 
            this.rdoC64Sprite.AutoSize = true;
            this.rdoC64Sprite.Location = new System.Drawing.Point(4, 98);
            this.rdoC64Sprite.Name = "rdoC64Sprite";
            this.rdoC64Sprite.Size = new System.Drawing.Size(122, 16);
            this.rdoC64Sprite.TabIndex = 17;
            this.rdoC64Sprite.Text = "7,14,28 (C64 sprite)";
            this.toolTip1.SetToolTip(this.rdoC64Sprite, "Change scale of the background grid");
            this.rdoC64Sprite.UseVisualStyleBackColor = true;
            this.rdoC64Sprite.CheckedChanged += new System.EventHandler(this.rdoC64Sprite_CheckedChanged);
            // 
            // rdoGuide7_14_28
            // 
            this.rdoGuide7_14_28.AutoSize = true;
            this.rdoGuide7_14_28.Location = new System.Drawing.Point(4, 74);
            this.rdoGuide7_14_28.Name = "rdoGuide7_14_28";
            this.rdoGuide7_14_28.Size = new System.Drawing.Size(98, 16);
            this.rdoGuide7_14_28.TabIndex = 16;
            this.rdoGuide7_14_28.Text = "7,14,28 (Apple)";
            this.toolTip1.SetToolTip(this.rdoGuide7_14_28, "Change scale of the background grid");
            this.rdoGuide7_14_28.UseVisualStyleBackColor = true;
            this.rdoGuide7_14_28.CheckedChanged += new System.EventHandler(this.rdoGuide6_12_24_CheckedChanged);
            // 
            // rdoGuide4_8_32
            // 
            this.rdoGuide4_8_32.AutoSize = true;
            this.rdoGuide4_8_32.Location = new System.Drawing.Point(4, 52);
            this.rdoGuide4_8_32.Name = "rdoGuide4_8_32";
            this.rdoGuide4_8_32.Size = new System.Drawing.Size(51, 16);
            this.rdoGuide4_8_32.TabIndex = 4;
            this.rdoGuide4_8_32.Text = "4,8,32";
            this.toolTip1.SetToolTip(this.rdoGuide4_8_32, "Change scale of the background grid");
            this.rdoGuide4_8_32.UseVisualStyleBackColor = true;
            this.rdoGuide4_8_32.CheckedChanged += new System.EventHandler(this.rdoGuide4_8_32_CheckedChanged);
            // 
            // rdoGuide4_8_24
            // 
            this.rdoGuide4_8_24.AutoSize = true;
            this.rdoGuide4_8_24.Checked = true;
            this.rdoGuide4_8_24.Location = new System.Drawing.Point(4, 33);
            this.rdoGuide4_8_24.Name = "rdoGuide4_8_24";
            this.rdoGuide4_8_24.Size = new System.Drawing.Size(51, 16);
            this.rdoGuide4_8_24.TabIndex = 3;
            this.rdoGuide4_8_24.TabStop = true;
            this.rdoGuide4_8_24.Text = "4,8,24";
            this.toolTip1.SetToolTip(this.rdoGuide4_8_24, "Change scale of the background grid");
            this.rdoGuide4_8_24.UseVisualStyleBackColor = true;
            this.rdoGuide4_8_24.CheckedChanged += new System.EventHandler(this.rdoGuide4_8_24_CheckedChanged);
            // 
            // rdoGuideNone
            // 
            this.rdoGuideNone.AutoSize = true;
            this.rdoGuideNone.Location = new System.Drawing.Point(4, 15);
            this.rdoGuideNone.Name = "rdoGuideNone";
            this.rdoGuideNone.Size = new System.Drawing.Size(49, 16);
            this.rdoGuideNone.TabIndex = 2;
            this.rdoGuideNone.Text = "None";
            this.toolTip1.SetToolTip(this.rdoGuideNone, "Change scale of the background grid");
            this.rdoGuideNone.UseVisualStyleBackColor = true;
            this.rdoGuideNone.CheckedChanged += new System.EventHandler(this.rdoGuideNone_CheckedChanged);
            // 
            // chkStrongGrid
            // 
            this.chkStrongGrid.AutoSize = true;
            this.chkStrongGrid.Checked = true;
            this.chkStrongGrid.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStrongGrid.Location = new System.Drawing.Point(4, 151);
            this.chkStrongGrid.Name = "chkStrongGrid";
            this.chkStrongGrid.Size = new System.Drawing.Size(121, 16);
            this.chkStrongGrid.TabIndex = 14;
            this.chkStrongGrid.Text = "High Visibility Grid";
            this.toolTip1.SetToolTip(this.chkStrongGrid, "Make the Grid more visible");
            this.chkStrongGrid.UseVisualStyleBackColor = true;
            this.chkStrongGrid.CheckedChanged += new System.EventHandler(this.chkStrongGrid_CheckedChanged);
            // 
            // ChkBackgroundTestDots
            // 
            this.ChkBackgroundTestDots.AutoSize = true;
            this.ChkBackgroundTestDots.Location = new System.Drawing.Point(4, 173);
            this.ChkBackgroundTestDots.Name = "ChkBackgroundTestDots";
            this.ChkBackgroundTestDots.Size = new System.Drawing.Size(139, 16);
            this.ChkBackgroundTestDots.TabIndex = 15;
            this.ChkBackgroundTestDots.Text = "Background Test Dots";
            this.toolTip1.SetToolTip(this.ChkBackgroundTestDots, "Show dots in all color pixels - used for finding Speccy color attributes that sho" +
                    "uld be black - but aren\'t!");
            this.ChkBackgroundTestDots.UseVisualStyleBackColor = true;
            this.ChkBackgroundTestDots.CheckedChanged += new System.EventHandler(this.ChkBackgroundTestDots_CheckedChanged);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox9);
            this.tabPage5.Controls.Add(this.groupBox7);
            this.tabPage5.Controls.Add(this.groupBox6);
            this.tabPage5.Controls.Add(this.label14);
            this.tabPage5.Controls.Add(this.groupBox5);
            this.tabPage5.Controls.Add(this.groupBox4);
            this.tabPage5.Location = new System.Drawing.Point(4, 21);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(765, 737);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "File Format";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.txtSaveTileCount);
            this.groupBox9.Controls.Add(this.label21);
            this.groupBox9.Controls.Add(this.chkSaveMultiRaw);
            this.groupBox9.Location = new System.Drawing.Point(269, 69);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(259, 72);
            this.groupBox9.TabIndex = 24;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Raw Sprites";
            // 
            // txtSaveTileCount
            // 
            this.txtSaveTileCount.Location = new System.Drawing.Point(138, 40);
            this.txtSaveTileCount.Name = "txtSaveTileCount";
            this.txtSaveTileCount.Size = new System.Drawing.Size(104, 19);
            this.txtSaveTileCount.TabIndex = 2;
            this.txtSaveTileCount.Text = "0";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(17, 42);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(58, 12);
            this.label21.TabIndex = 1;
            this.label21.Text = "Tile Count";
            // 
            // chkSaveMultiRaw
            // 
            this.chkSaveMultiRaw.AutoSize = true;
            this.chkSaveMultiRaw.Checked = true;
            this.chkSaveMultiRaw.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkSaveMultiRaw.Location = new System.Drawing.Point(16, 17);
            this.chkSaveMultiRaw.Name = "chkSaveMultiRaw";
            this.chkSaveMultiRaw.Size = new System.Drawing.Size(133, 16);
            this.chkSaveMultiRaw.TabIndex = 0;
            this.chkSaveMultiRaw.Text = "Save Multiple Sprites";
            this.chkSaveMultiRaw.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.txtHspriteH);
            this.groupBox7.Controls.Add(this.label16);
            this.groupBox7.Controls.Add(this.txtHspriteW);
            this.groupBox7.Controls.Add(this.label15);
            this.groupBox7.Location = new System.Drawing.Point(4, 226);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(177, 103);
            this.groupBox7.TabIndex = 23;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Hardware Sprites";
            // 
            // txtHspriteH
            // 
            this.txtHspriteH.Location = new System.Drawing.Point(88, 46);
            this.txtHspriteH.Name = "txtHspriteH";
            this.txtHspriteH.Size = new System.Drawing.Size(50, 19);
            this.txtHspriteH.TabIndex = 6;
            this.txtHspriteH.Text = "16";
            this.toolTip1.SetToolTip(this.txtHspriteH, "Memory offset of first sprite in binary files");
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(11, 49);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(72, 12);
            this.label16.TabIndex = 5;
            this.label16.Text = "Sprite Height";
            // 
            // txtHspriteW
            // 
            this.txtHspriteW.Location = new System.Drawing.Point(88, 21);
            this.txtHspriteW.Name = "txtHspriteW";
            this.txtHspriteW.Size = new System.Drawing.Size(50, 19);
            this.txtHspriteW.TabIndex = 4;
            this.txtHspriteW.Text = "16";
            this.toolTip1.SetToolTip(this.txtHspriteW, "Memory offset of first sprite in binary files");
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(11, 24);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(67, 12);
            this.label15.TabIndex = 3;
            this.label15.Text = "Sprite Width";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.lblMaxSpritesByOffset);
            this.groupBox6.Controls.Add(this.txtSpriteDataOffSet);
            this.groupBox6.Controls.Add(this.label1);
            this.groupBox6.Location = new System.Drawing.Point(4, 69);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(259, 53);
            this.groupBox6.TabIndex = 22;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Binary Sprites";
            // 
            // lblMaxSpritesByOffset
            // 
            this.lblMaxSpritesByOffset.AutoSize = true;
            this.lblMaxSpritesByOffset.Location = new System.Drawing.Point(166, 21);
            this.lblMaxSpritesByOffset.Name = "lblMaxSpritesByOffset";
            this.lblMaxSpritesByOffset.Size = new System.Drawing.Size(7, 12);
            this.lblMaxSpritesByOffset.TabIndex = 5;
            this.lblMaxSpritesByOffset.Text = ".";
            // 
            // txtSpriteDataOffSet
            // 
            this.txtSpriteDataOffSet.Location = new System.Drawing.Point(110, 18);
            this.txtSpriteDataOffSet.Name = "txtSpriteDataOffSet";
            this.txtSpriteDataOffSet.Size = new System.Drawing.Size(50, 19);
            this.txtSpriteDataOffSet.TabIndex = 4;
            this.txtSpriteDataOffSet.Text = "&180";
            this.toolTip1.SetToolTip(this.txtSpriteDataOffSet, "Memory offset of first sprite in binary files");
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "SpriteDataOffSet";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(21, 171);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(121, 12);
            this.label14.TabIndex = 21;
            this.label14.Text = "SpriteLoad SkipSprites";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txtNeoSprSkip);
            this.groupBox5.Controls.Add(this.txtNeoSprHeight);
            this.groupBox5.Controls.Add(this.label13);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.txtFixedFileSize);
            this.groupBox5.Location = new System.Drawing.Point(4, 128);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(259, 92);
            this.groupBox5.TabIndex = 19;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "NeoGeo";
            // 
            // txtNeoSprSkip
            // 
            this.txtNeoSprSkip.Location = new System.Drawing.Point(150, 63);
            this.txtNeoSprSkip.Name = "txtNeoSprSkip";
            this.txtNeoSprSkip.Size = new System.Drawing.Size(88, 19);
            this.txtNeoSprSkip.TabIndex = 23;
            this.txtNeoSprSkip.Text = "0";
            this.toolTip1.SetToolTip(this.txtNeoSprSkip, "See: https://youtu.be/Wtz1kJaxUgc");
            this.txtNeoSprSkip.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtNeoSprSkip_MouseClick);
            // 
            // txtNeoSprHeight
            // 
            this.txtNeoSprHeight.Location = new System.Drawing.Point(150, 41);
            this.txtNeoSprHeight.Name = "txtNeoSprHeight";
            this.txtNeoSprHeight.Size = new System.Drawing.Size(88, 19);
            this.txtNeoSprHeight.TabIndex = 22;
            this.txtNeoSprHeight.Text = "16";
            this.toolTip1.SetToolTip(this.txtNeoSprHeight, "See: https://youtu.be/Wtz1kJaxUgc");
            this.txtNeoSprHeight.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtNeoSprHeight_MouseClick);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 41);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(96, 12);
            this.label13.TabIndex = 20;
            this.label13.Text = "SpriteLoad Height";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(4, 15);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(140, 12);
            this.label9.TabIndex = 1;
            this.label9.Text = "SpriteSave Fixed File Size";
            // 
            // txtFixedFileSize
            // 
            this.txtFixedFileSize.Location = new System.Drawing.Point(150, 12);
            this.txtFixedFileSize.Name = "txtFixedFileSize";
            this.txtFixedFileSize.Size = new System.Drawing.Size(88, 19);
            this.txtFixedFileSize.TabIndex = 0;
            this.txtFixedFileSize.Text = "&100000";
            this.toolTip1.SetToolTip(this.txtFixedFileSize, "See: https://youtu.be/Wtz1kJaxUgc");
            this.txtFixedFileSize.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtFixedFileSize_MouseClick);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.chkHasDosHeader);
            this.groupBox4.Location = new System.Drawing.Point(4, 13);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(173, 50);
            this.groupBox4.TabIndex = 18;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Binary Files";
            // 
            // chkHasDosHeader
            // 
            this.chkHasDosHeader.AutoSize = true;
            this.chkHasDosHeader.Checked = true;
            this.chkHasDosHeader.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkHasDosHeader.Location = new System.Drawing.Point(6, 18);
            this.chkHasDosHeader.Name = "chkHasDosHeader";
            this.chkHasDosHeader.Size = new System.Drawing.Size(100, 16);
            this.chkHasDosHeader.TabIndex = 6;
            this.chkHasDosHeader.Text = "HasDosHeader";
            this.toolTip1.SetToolTip(this.chkHasDosHeader, "File has a header");
            this.chkHasDosHeader.UseVisualStyleBackColor = true;
            this.chkHasDosHeader.CheckedChanged += new System.EventHandler(this.chkHasDosHeader_CheckedChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnExportTilelist);
            this.tabPage1.Controls.Add(this.btnExportInfo);
            this.tabPage1.Controls.Add(this.lstSprites);
            this.tabPage1.Location = new System.Drawing.Point(4, 21);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(765, 737);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "SpriteList";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnExportTilelist
            // 
            this.btnExportTilelist.Location = new System.Drawing.Point(414, 51);
            this.btnExportTilelist.Name = "btnExportTilelist";
            this.btnExportTilelist.Size = new System.Drawing.Size(114, 41);
            this.btnExportTilelist.TabIndex = 2;
            this.btnExportTilelist.Text = "Export Tilelist";
            this.btnExportTilelist.UseVisualStyleBackColor = true;
            this.btnExportTilelist.Click += new System.EventHandler(this.btnExportTilelist_Click);
            // 
            // btnExportInfo
            // 
            this.btnExportInfo.Location = new System.Drawing.Point(414, 4);
            this.btnExportInfo.Name = "btnExportInfo";
            this.btnExportInfo.Size = new System.Drawing.Size(114, 41);
            this.btnExportInfo.TabIndex = 1;
            this.btnExportInfo.Text = "Export Info";
            this.btnExportInfo.UseVisualStyleBackColor = true;
            this.btnExportInfo.Click += new System.EventHandler(this.btnExportInfo_Click);
            // 
            // lstSprites
            // 
            this.lstSprites.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstSprites.FormattingEnabled = true;
            this.lstSprites.ItemHeight = 14;
            this.lstSprites.Location = new System.Drawing.Point(4, 4);
            this.lstSprites.Name = "lstSprites";
            this.lstSprites.Size = new System.Drawing.Size(404, 368);
            this.lstSprites.TabIndex = 0;
            this.lstSprites.SelectedIndexChanged += new System.EventHandler(this.lstSprites_SelectedIndexChanged);
            // 
            // tabNotes
            // 
            this.tabNotes.Controls.Add(this.txtNotes);
            this.tabNotes.Location = new System.Drawing.Point(4, 21);
            this.tabNotes.Name = "tabNotes";
            this.tabNotes.Size = new System.Drawing.Size(765, 737);
            this.tabNotes.TabIndex = 3;
            this.tabNotes.Text = "Notes";
            this.tabNotes.UseVisualStyleBackColor = true;
            // 
            // txtNotes
            // 
            this.txtNotes.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNotes.Location = new System.Drawing.Point(4, 3);
            this.txtNotes.Multiline = true;
            this.txtNotes.Name = "txtNotes";
            this.txtNotes.Size = new System.Drawing.Size(758, 634);
            this.txtNotes.TabIndex = 0;
            this.txtNotes.Text = "This is a free text box for your notes... it\'s saved with the sprites";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(108, 104);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 12);
            this.label11.TabIndex = 5;
            this.label11.Text = "Format";
            // 
            // cboTileFormat
            // 
            this.cboTileFormat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTileFormat.FormattingEnabled = true;
            this.cboTileFormat.Items.AddRange(new object[] {
            "256+",
            "Nibble"});
            this.cboTileFormat.Location = new System.Drawing.Point(169, 104);
            this.cboTileFormat.Name = "cboTileFormat";
            this.cboTileFormat.Size = new System.Drawing.Size(65, 20);
            this.cboTileFormat.TabIndex = 4;
            // 
            // txtNextTile
            // 
            this.txtNextTile.Location = new System.Drawing.Point(169, 82);
            this.txtNextTile.Name = "txtNextTile";
            this.txtNextTile.Size = new System.Drawing.Size(65, 19);
            this.txtNextTile.TabIndex = 3;
            this.txtNextTile.Text = "0";
            // 
            // lblNextTile
            // 
            this.lblNextTile.AutoSize = true;
            this.lblNextTile.Location = new System.Drawing.Point(108, 82);
            this.lblNextTile.Name = "lblNextTile";
            this.lblNextTile.Size = new System.Drawing.Size(48, 12);
            this.lblNextTile.TabIndex = 2;
            this.lblNextTile.Text = "NextTile";
            // 
            // txtFirstTile
            // 
            this.txtFirstTile.Location = new System.Drawing.Point(169, 61);
            this.txtFirstTile.Name = "txtFirstTile";
            this.txtFirstTile.Size = new System.Drawing.Size(65, 19);
            this.txtFirstTile.TabIndex = 1;
            this.txtFirstTile.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(108, 61);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 12);
            this.label10.TabIndex = 0;
            this.label10.Text = "FirstTile";
            // 
            // lblSpriteInfo
            // 
            this.lblSpriteInfo.AutoSize = true;
            this.lblSpriteInfo.Location = new System.Drawing.Point(9, 76);
            this.lblSpriteInfo.Name = "lblSpriteInfo";
            this.lblSpriteInfo.Size = new System.Drawing.Size(7, 12);
            this.lblSpriteInfo.TabIndex = 6;
            this.lblSpriteInfo.Text = ".";
            // 
            // pnlMSXpal
            // 
            this.pnlMSXpal.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.pnlMSXpal.Location = new System.Drawing.Point(648, 27);
            this.pnlMSXpal.Name = "pnlMSXpal";
            this.pnlMSXpal.Size = new System.Drawing.Size(433, 48);
            this.pnlMSXpal.TabIndex = 29;
            this.pnlMSXpal.Visible = false;
            // 
            // pnlNESpal
            // 
            this.pnlNESpal.BackColor = System.Drawing.SystemColors.Control;
            this.pnlNESpal.Location = new System.Drawing.Point(571, 31);
            this.pnlNESpal.Name = "pnlNESpal";
            this.pnlNESpal.Size = new System.Drawing.Size(433, 48);
            this.pnlNESpal.TabIndex = 28;
            this.pnlNESpal.Visible = false;
            // 
            // pnlC64pal
            // 
            this.pnlC64pal.Location = new System.Drawing.Point(639, 24);
            this.pnlC64pal.Name = "pnlC64pal";
            this.pnlC64pal.Size = new System.Drawing.Size(433, 48);
            this.pnlC64pal.TabIndex = 27;
            this.pnlC64pal.Visible = false;
            // 
            // pnlZXPalette
            // 
            this.pnlZXPalette.Location = new System.Drawing.Point(641, 30);
            this.pnlZXPalette.Name = "pnlZXPalette";
            this.pnlZXPalette.Size = new System.Drawing.Size(433, 48);
            this.pnlZXPalette.TabIndex = 26;
            this.pnlZXPalette.Visible = false;
            // 
            // BtnAltPal
            // 
            this.BtnAltPal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnAltPal.Location = new System.Drawing.Point(991, 85);
            this.BtnAltPal.Name = "BtnAltPal";
            this.BtnAltPal.Size = new System.Drawing.Size(48, 48);
            this.BtnAltPal.TabIndex = 25;
            this.BtnAltPal.Text = "AltPal:  ";
            this.toolTip1.SetToolTip(this.BtnAltPal, "Alternate Palettes - for systems using Color attributes (Experimental)");
            this.BtnAltPal.UseVisualStyleBackColor = true;
            this.BtnAltPal.Click += new System.EventHandler(this.BtnAltPal_Click);
            // 
            // tabSpriteTools
            // 
            this.tabSpriteTools.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tabSpriteTools.Controls.Add(this.tabSpriteOptions);
            this.tabSpriteTools.Controls.Add(this.tabPixelPaint);
            this.tabSpriteTools.Controls.Add(this.tabZXPaint);
            this.tabSpriteTools.Controls.Add(this.tabColorSwap);
            this.tabSpriteTools.Controls.Add(this.tabTileCopy);
            this.tabSpriteTools.Controls.Add(this.tabVector);
            this.tabSpriteTools.Location = new System.Drawing.Point(786, 139);
            this.tabSpriteTools.Name = "tabSpriteTools";
            this.tabSpriteTools.SelectedIndex = 0;
            this.tabSpriteTools.Size = new System.Drawing.Size(251, 153);
            this.tabSpriteTools.TabIndex = 20;
            this.tabSpriteTools.SelectedIndexChanged += new System.EventHandler(this.tabSpriteTools_SelectedIndexChanged);
            // 
            // tabSpriteOptions
            // 
            this.tabSpriteOptions.Controls.Add(this.chkAligned);
            this.tabSpriteOptions.Controls.Add(this.label3);
            this.tabSpriteOptions.Controls.Add(this.label2);
            this.tabSpriteOptions.Controls.Add(this.txtSpriteSettings);
            this.tabSpriteOptions.Location = new System.Drawing.Point(4, 21);
            this.tabSpriteOptions.Name = "tabSpriteOptions";
            this.tabSpriteOptions.Padding = new System.Windows.Forms.Padding(3);
            this.tabSpriteOptions.Size = new System.Drawing.Size(243, 128);
            this.tabSpriteOptions.TabIndex = 0;
            this.tabSpriteOptions.Text = "Settings";
            this.tabSpriteOptions.UseVisualStyleBackColor = true;
            // 
            // chkAligned
            // 
            this.chkAligned.AutoSize = true;
            this.chkAligned.Location = new System.Drawing.Point(68, 13);
            this.chkAligned.Name = "chkAligned";
            this.chkAligned.Size = new System.Drawing.Size(90, 16);
            this.chkAligned.TabIndex = 0;
            this.chkAligned.Text = "Byte Aligned";
            this.toolTip1.SetToolTip(this.chkAligned, "Align to byte boundaries - used by Chibakumas format for Background tiles");
            this.chkAligned.UseVisualStyleBackColor = true;
            this.chkAligned.CheckedChanged += new System.EventHandler(this.chkAligned_CheckedChanged);
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(65, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(168, 52);
            this.label3.TabIndex = 3;
            this.label3.Text = "+128 = PSET\r\n+64 = DblHeight / nocolorZX\r\n+32 = SpeccyTransp\r\n+4/5 = CPC transp\r\n" +
                "";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "Settings";
            // 
            // txtSpriteSettings
            // 
            this.txtSpriteSettings.Location = new System.Drawing.Point(65, 34);
            this.txtSpriteSettings.Name = "txtSpriteSettings";
            this.txtSpriteSettings.Size = new System.Drawing.Size(92, 19);
            this.txtSpriteSettings.TabIndex = 2;
            this.toolTip1.SetToolTip(this.txtSpriteSettings, "Transparency options - Used for Chibiakumas bitmap sprites");
            this.txtSpriteSettings.TextChanged += new System.EventHandler(this.txtSpriteSettings_TextChanged);
            // 
            // tabPixelPaint
            // 
            this.tabPixelPaint.Controls.Add(this.label4);
            this.tabPixelPaint.Controls.Add(this.cboCheckMode);
            this.tabPixelPaint.Location = new System.Drawing.Point(4, 21);
            this.tabPixelPaint.Name = "tabPixelPaint";
            this.tabPixelPaint.Size = new System.Drawing.Size(243, 128);
            this.tabPixelPaint.TabIndex = 2;
            this.tabPixelPaint.Text = "PixelPaint";
            this.tabPixelPaint.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 12);
            this.label4.TabIndex = 1;
            this.label4.Text = "Check Mode";
            // 
            // cboCheckMode
            // 
            this.cboCheckMode.FormattingEnabled = true;
            this.cboCheckMode.Items.AddRange(new object[] {
            "Off",
            "1/3",
            "2/3",
            "3/3"});
            this.cboCheckMode.Location = new System.Drawing.Point(112, 18);
            this.cboCheckMode.Name = "cboCheckMode";
            this.cboCheckMode.Size = new System.Drawing.Size(112, 20);
            this.cboCheckMode.TabIndex = 0;
            this.cboCheckMode.Text = "Off";
            this.toolTip1.SetToolTip(this.cboCheckMode, "\'Checkerboard\' pattern to simulate extra colors via combinations of Foreground/ba" +
                    "ckground color");
            this.cboCheckMode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cboCheckMode_KeyPress);
            // 
            // tabZXPaint
            // 
            this.tabZXPaint.Controls.Add(this.label5);
            this.tabZXPaint.Controls.Add(this.cboZxPaintMode);
            this.tabZXPaint.Location = new System.Drawing.Point(4, 21);
            this.tabZXPaint.Name = "tabZXPaint";
            this.tabZXPaint.Size = new System.Drawing.Size(243, 128);
            this.tabZXPaint.TabIndex = 3;
            this.tabZXPaint.Text = "ZxPaint";
            this.tabZXPaint.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 18);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 12);
            this.label5.TabIndex = 1;
            this.label5.Text = "ZX Paintmode";
            // 
            // cboZxPaintMode
            // 
            this.cboZxPaintMode.FormattingEnabled = true;
            this.cboZxPaintMode.Items.AddRange(new object[] {
            "Normal",
            "Colors",
            "PixelMap"});
            this.cboZxPaintMode.Location = new System.Drawing.Point(111, 15);
            this.cboZxPaintMode.Name = "cboZxPaintMode";
            this.cboZxPaintMode.Size = new System.Drawing.Size(121, 20);
            this.cboZxPaintMode.TabIndex = 0;
            this.cboZxPaintMode.Text = "Colors";
            this.toolTip1.SetToolTip(this.cboZxPaintMode, "Color Attribute / Bitmap drawing option");
            this.cboZxPaintMode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cboCheckMode_KeyPress);
            // 
            // tabColorSwap
            // 
            this.tabColorSwap.Controls.Add(this.label7);
            this.tabColorSwap.Controls.Add(this.cboFillCheck);
            this.tabColorSwap.Controls.Add(this.cboColorConvertMode);
            this.tabColorSwap.Controls.Add(this.label6);
            this.tabColorSwap.Location = new System.Drawing.Point(4, 21);
            this.tabColorSwap.Name = "tabColorSwap";
            this.tabColorSwap.Size = new System.Drawing.Size(243, 128);
            this.tabColorSwap.TabIndex = 4;
            this.tabColorSwap.Text = "ColorSwap";
            this.tabColorSwap.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(10, 39);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 12);
            this.label7.TabIndex = 23;
            this.label7.Text = "Check Mode";
            // 
            // cboFillCheck
            // 
            this.cboFillCheck.FormattingEnabled = true;
            this.cboFillCheck.Items.AddRange(new object[] {
            "Off",
            "1/3",
            "2/3",
            "3/3"});
            this.cboFillCheck.Location = new System.Drawing.Point(105, 36);
            this.cboFillCheck.Name = "cboFillCheck";
            this.cboFillCheck.Size = new System.Drawing.Size(125, 20);
            this.cboFillCheck.TabIndex = 22;
            this.cboFillCheck.Text = "Off";
            this.toolTip1.SetToolTip(this.cboFillCheck, "\'Checkerboard\' pattern to simulate extra colors via combinations of Foreground/ba" +
                    "ckground color");
            // 
            // cboColorConvertMode
            // 
            this.cboColorConvertMode.FormattingEnabled = true;
            this.cboColorConvertMode.Items.AddRange(new object[] {
            "Block",
            "Sprite",
            "AllSprites",
            "8x1"});
            this.cboColorConvertMode.Location = new System.Drawing.Point(105, 10);
            this.cboColorConvertMode.Name = "cboColorConvertMode";
            this.cboColorConvertMode.Size = new System.Drawing.Size(125, 20);
            this.cboColorConvertMode.TabIndex = 21;
            this.cboColorConvertMode.Text = "Block";
            this.toolTip1.SetToolTip(this.cboColorConvertMode, "Size of area to Swap... 8x8 block, sprite, all sprites");
            this.cboColorConvertMode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cboCheckMode_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 12);
            this.label6.TabIndex = 20;
            this.label6.Text = "ColorConversion";
            // 
            // tabTileCopy
            // 
            this.tabTileCopy.Controls.Add(this.btnMatchAll);
            this.tabTileCopy.Controls.Add(this.label20);
            this.tabTileCopy.Controls.Add(this.cboDeres);
            this.tabTileCopy.Controls.Add(this.label11);
            this.tabTileCopy.Controls.Add(this.cboTileFormat);
            this.tabTileCopy.Controls.Add(this.button1);
            this.tabTileCopy.Controls.Add(this.txtNextTile);
            this.tabTileCopy.Controls.Add(this.BtnClearAdd);
            this.tabTileCopy.Controls.Add(this.lblNextTile);
            this.tabTileCopy.Controls.Add(this.txtFirstTile);
            this.tabTileCopy.Controls.Add(this.label10);
            this.tabTileCopy.Location = new System.Drawing.Point(4, 21);
            this.tabTileCopy.Name = "tabTileCopy";
            this.tabTileCopy.Padding = new System.Windows.Forms.Padding(3);
            this.tabTileCopy.Size = new System.Drawing.Size(243, 128);
            this.tabTileCopy.TabIndex = 5;
            this.tabTileCopy.Text = "TileCopy";
            this.tabTileCopy.UseVisualStyleBackColor = true;
            // 
            // btnMatchAll
            // 
            this.btnMatchAll.Location = new System.Drawing.Point(75, 103);
            this.btnMatchAll.Name = "btnMatchAll";
            this.btnMatchAll.Size = new System.Drawing.Size(29, 18);
            this.btnMatchAll.TabIndex = 8;
            this.btnMatchAll.Text = "all";
            this.btnMatchAll.UseVisualStyleBackColor = true;
            this.btnMatchAll.Click += new System.EventHandler(this.btnMatchAll_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(1, 89);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(35, 12);
            this.label20.TabIndex = 7;
            this.label20.Text = "Deres";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cboDeres
            // 
            this.cboDeres.FormattingEnabled = true;
            this.cboDeres.Items.AddRange(new object[] {
            "Off",
            "1/2",
            "1/4",
            "MatchNearest",
            "Match98",
            "Match97",
            "Match96",
            "Match95",
            "Match90",
            "Match80",
            "Match70",
            "Match65",
            "Match50"});
            this.cboDeres.Location = new System.Drawing.Point(3, 102);
            this.cboDeres.Name = "cboDeres";
            this.cboDeres.Size = new System.Drawing.Size(64, 20);
            this.cboDeres.TabIndex = 6;
            this.cboDeres.Text = "Off";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(168, 28);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(69, 28);
            this.button1.TabIndex = 1;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // BtnClearAdd
            // 
            this.BtnClearAdd.Location = new System.Drawing.Point(169, 3);
            this.BtnClearAdd.Name = "BtnClearAdd";
            this.BtnClearAdd.Size = new System.Drawing.Size(68, 28);
            this.BtnClearAdd.TabIndex = 0;
            this.BtnClearAdd.Text = "Clear+Add";
            this.BtnClearAdd.UseVisualStyleBackColor = true;
            this.BtnClearAdd.Click += new System.EventHandler(this.BtnClearAdd_Click);
            // 
            // tabVector
            // 
            this.tabVector.Controls.Add(this.btnZ80Vec);
            this.tabVector.Controls.Add(this.label19);
            this.tabVector.Controls.Add(this.CboVectorType);
            this.tabVector.Controls.Add(this.btnVectorClear);
            this.tabVector.Controls.Add(this.btnVectorToClip);
            this.tabVector.Controls.Add(this.txtVectors);
            this.tabVector.Location = new System.Drawing.Point(4, 21);
            this.tabVector.Name = "tabVector";
            this.tabVector.Size = new System.Drawing.Size(243, 128);
            this.tabVector.TabIndex = 6;
            this.tabVector.Text = "Vectors (Experimental)";
            this.tabVector.UseVisualStyleBackColor = true;
            // 
            // btnZ80Vec
            // 
            this.btnZ80Vec.Location = new System.Drawing.Point(173, 36);
            this.btnZ80Vec.Name = "btnZ80Vec";
            this.btnZ80Vec.Size = new System.Drawing.Size(61, 20);
            this.btnZ80Vec.TabIndex = 5;
            this.btnZ80Vec.Text = "z80 Clip";
            this.btnZ80Vec.UseVisualStyleBackColor = true;
            this.btnZ80Vec.Click += new System.EventHandler(this.btnZ80Vec_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(173, 86);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(43, 12);
            this.label19.TabIndex = 4;
            this.label19.Text = "Format:";
            // 
            // CboVectorType
            // 
            this.CboVectorType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CboVectorType.FormattingEnabled = true;
            this.CboVectorType.Items.AddRange(new object[] {
            "Packet",
            "Duffy",
            "cpacket"});
            this.CboVectorType.Location = new System.Drawing.Point(173, 101);
            this.CboVectorType.Name = "CboVectorType";
            this.CboVectorType.Size = new System.Drawing.Size(61, 20);
            this.CboVectorType.TabIndex = 3;
            this.CboVectorType.SelectedIndexChanged += new System.EventHandler(this.CboVectorType_SelectedIndexChanged);
            // 
            // btnVectorClear
            // 
            this.btnVectorClear.Location = new System.Drawing.Point(172, 62);
            this.btnVectorClear.Name = "btnVectorClear";
            this.btnVectorClear.Size = new System.Drawing.Size(61, 21);
            this.btnVectorClear.TabIndex = 2;
            this.btnVectorClear.Text = "Clear";
            this.btnVectorClear.UseVisualStyleBackColor = true;
            this.btnVectorClear.Click += new System.EventHandler(this.btnVectorClear_Click);
            // 
            // btnVectorToClip
            // 
            this.btnVectorToClip.Location = new System.Drawing.Point(173, 14);
            this.btnVectorToClip.Name = "btnVectorToClip";
            this.btnVectorToClip.Size = new System.Drawing.Size(61, 20);
            this.btnVectorToClip.TabIndex = 1;
            this.btnVectorToClip.Text = "To Clip";
            this.btnVectorToClip.UseVisualStyleBackColor = true;
            this.btnVectorToClip.Click += new System.EventHandler(this.btnVectorToClip_Click);
            // 
            // txtVectors
            // 
            this.txtVectors.Location = new System.Drawing.Point(8, 3);
            this.txtVectors.Multiline = true;
            this.txtVectors.Name = "txtVectors";
            this.txtVectors.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtVectors.Size = new System.Drawing.Size(159, 122);
            this.txtVectors.TabIndex = 0;
            // 
            // chkFixedSize
            // 
            this.chkFixedSize.AutoSize = true;
            this.chkFixedSize.Location = new System.Drawing.Point(116, 102);
            this.chkFixedSize.Name = "chkFixedSize";
            this.chkFixedSize.Size = new System.Drawing.Size(111, 16);
            this.chkFixedSize.TabIndex = 4;
            this.chkFixedSize.Text = "Fixed Size Sprite";
            this.chkFixedSize.UseVisualStyleBackColor = true;
            this.chkFixedSize.MouseUp += new System.Windows.Forms.MouseEventHandler(this.chkFixedSize_MouseUp);
            // 
            // btnNextBank
            // 
            this.btnNextBank.Location = new System.Drawing.Point(187, 6);
            this.btnNextBank.Name = "btnNextBank";
            this.btnNextBank.Size = new System.Drawing.Size(48, 48);
            this.btnNextBank.TabIndex = 17;
            this.btnNextBank.Text = "Next Bank";
            this.toolTip1.SetToolTip(this.btnNextBank, "Last Bank (Cursor Up / Alt+MouseWheel)");
            this.btnNextBank.UseVisualStyleBackColor = true;
            this.btnNextBank.Click += new System.EventHandler(this.btnNextBank_Click);
            // 
            // btnLastBank
            // 
            this.btnLastBank.Location = new System.Drawing.Point(133, 6);
            this.btnLastBank.Name = "btnLastBank";
            this.btnLastBank.Size = new System.Drawing.Size(48, 48);
            this.btnLastBank.TabIndex = 16;
            this.btnLastBank.Text = "Last Bank";
            this.toolTip1.SetToolTip(this.btnLastBank, "Last Bank (Cursor Down / Alt+MouseWheel)");
            this.btnLastBank.UseVisualStyleBackColor = true;
            this.btnLastBank.Click += new System.EventHandler(this.btnLastBank_Click);
            // 
            // btnNextSprite
            // 
            this.btnNextSprite.Location = new System.Drawing.Point(57, 6);
            this.btnNextSprite.Name = "btnNextSprite";
            this.btnNextSprite.Size = new System.Drawing.Size(48, 48);
            this.btnNextSprite.TabIndex = 14;
            this.btnNextSprite.Text = "Next Sprite";
            this.toolTip1.SetToolTip(this.btnNextSprite, "Next Sprite (Cursor Right / Ctrl+MouseWheel)");
            this.btnNextSprite.UseVisualStyleBackColor = true;
            this.btnNextSprite.Click += new System.EventHandler(this.btnNextSprite_Click);
            // 
            // btnLastSprite
            // 
            this.btnLastSprite.Location = new System.Drawing.Point(6, 6);
            this.btnLastSprite.Name = "btnLastSprite";
            this.btnLastSprite.Size = new System.Drawing.Size(48, 48);
            this.btnLastSprite.TabIndex = 13;
            this.btnLastSprite.Text = "Last Sprite";
            this.toolTip1.SetToolTip(this.btnLastSprite, "Last Sprite (Cursor Left / Ctrl+MouseWheel)");
            this.btnLastSprite.UseVisualStyleBackColor = true;
            this.btnLastSprite.Click += new System.EventHandler(this.btnLastSprite_Click);
            // 
            // btnSetPal
            // 
            this.btnSetPal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSetPal.Location = new System.Drawing.Point(937, 85);
            this.btnSetPal.Name = "btnSetPal";
            this.btnSetPal.Size = new System.Drawing.Size(48, 48);
            this.btnSetPal.TabIndex = 4;
            this.btnSetPal.Text = "SetPal  ";
            this.toolTip1.SetToolTip(this.btnSetPal, "Toggle palette option - click on a palette color to change it\'s palette entry");
            this.btnSetPal.UseVisualStyleBackColor = true;
            this.btnSetPal.Click += new System.EventHandler(this.btnSetPal_Click);
            // 
            // tmrBackup
            // 
            this.tmrBackup.Tick += new System.EventHandler(this.tmrBackup_Tick);
            // 
            // BtnUlaPalSwap
            // 
            this.BtnUlaPalSwap.Location = new System.Drawing.Point(6, 6);
            this.BtnUlaPalSwap.Name = "BtnUlaPalSwap";
            this.BtnUlaPalSwap.Size = new System.Drawing.Size(62, 35);
            this.BtnUlaPalSwap.TabIndex = 0;
            this.BtnUlaPalSwap.Text = "Swap";
            this.toolTip1.SetToolTip(this.BtnUlaPalSwap, "Ula Palette swap - Swap colors");
            this.BtnUlaPalSwap.UseVisualStyleBackColor = true;
            this.BtnUlaPalSwap.Click += new System.EventHandler(this.BtnUlaPalSwap_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem2,
            this.ViewToolStripMenuItem,
            this.editToolStripMenuItem,
            this.toolsToolStripMenuItem,
            this.z80ToolStripMenuItem,
            this.toolStripMenuItem2,
            this.toolStripMenuItem1,
            this.x86ToolStripMenuItem,
            this.aRMToolStripMenuItem,
            this.mIPSToolStripMenuItem,
            this.toolStripMenuItem7,
            this.tMS9900ToolStripMenuItem,
            this.pDP11ToolStripMenuItem,
            this.toolStripMenuItem8});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1039, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem2
            // 
            this.fileToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reSaveSpritesToolStripMenuItem,
            this.saveSpritesToolStripMenuItem,
            this.savePaletteToolStripMenuItem,
            this.loadToolStripMenuItem,
            this.loadPaletteToolStripMenuItem,
            this.loadPixelsToolStripMenuItem,
            this.importBackgroundToolStripMenuItem,
            this.recentFilesToolStripMenuItem,
            this.importImageToolStripMenuItem,
            this.fileProcessorToolStripMenuItem,
            this.saveBMPMapToolStripMenuItem,
            this.loadBMPMaToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem2.Name = "fileToolStripMenuItem2";
            this.fileToolStripMenuItem2.Size = new System.Drawing.Size(36, 20);
            this.fileToolStripMenuItem2.Text = "File";
            // 
            // reSaveSpritesToolStripMenuItem
            // 
            this.reSaveSpritesToolStripMenuItem.Enabled = false;
            this.reSaveSpritesToolStripMenuItem.Name = "reSaveSpritesToolStripMenuItem";
            this.reSaveSpritesToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.reSaveSpritesToolStripMenuItem.Text = "ReSave Sprites";
            this.reSaveSpritesToolStripMenuItem.Click += new System.EventHandler(this.reSaveSpritesToolStripMenuItem_Click);
            // 
            // saveSpritesToolStripMenuItem
            // 
            this.saveSpritesToolStripMenuItem.Name = "saveSpritesToolStripMenuItem";
            this.saveSpritesToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.saveSpritesToolStripMenuItem.Text = "Save Sprites As";
            this.saveSpritesToolStripMenuItem.Click += new System.EventHandler(this.saveSpritesToolStripMenuItem_Click);
            // 
            // savePaletteToolStripMenuItem
            // 
            this.savePaletteToolStripMenuItem.Name = "savePaletteToolStripMenuItem";
            this.savePaletteToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.savePaletteToolStripMenuItem.Text = "Save Palette (.txt)";
            this.savePaletteToolStripMenuItem.Click += new System.EventHandler(this.savePaletteToolStripMenuItem_Click);
            // 
            // loadToolStripMenuItem
            // 
            this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
            this.loadToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.loadToolStripMenuItem.Text = "Load (.txt)";
            this.loadToolStripMenuItem.Click += new System.EventHandler(this.loadToolStripMenuItem_Click);
            // 
            // loadPaletteToolStripMenuItem
            // 
            this.loadPaletteToolStripMenuItem.Name = "loadPaletteToolStripMenuItem";
            this.loadPaletteToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.loadPaletteToolStripMenuItem.Text = "Import Palette (.txt)";
            this.loadPaletteToolStripMenuItem.Click += new System.EventHandler(this.loadPaletteToolStripMenuItem_Click);
            // 
            // loadPixelsToolStripMenuItem
            // 
            this.loadPixelsToolStripMenuItem.Name = "loadPixelsToolStripMenuItem";
            this.loadPixelsToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.loadPixelsToolStripMenuItem.Text = "Import Pixels (.txt)";
            this.loadPixelsToolStripMenuItem.Click += new System.EventHandler(this.loadPixelsToolStripMenuItem_Click);
            // 
            // importBackgroundToolStripMenuItem
            // 
            this.importBackgroundToolStripMenuItem.Name = "importBackgroundToolStripMenuItem";
            this.importBackgroundToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.importBackgroundToolStripMenuItem.Text = "Inport ColorAttribs (.txt)";
            this.importBackgroundToolStripMenuItem.Click += new System.EventHandler(this.importBackgroundToolStripMenuItem_Click);
            // 
            // recentFilesToolStripMenuItem
            // 
            this.recentFilesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.recent1,
            this.recent2,
            this.recent3,
            this.recent4,
            this.recent5,
            this.recent6,
            this.recent7,
            this.recent8,
            this.recent9,
            this.recent10});
            this.recentFilesToolStripMenuItem.Name = "recentFilesToolStripMenuItem";
            this.recentFilesToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.recentFilesToolStripMenuItem.Text = "Load Recent (.txt)";
            // 
            // recent1
            // 
            this.recent1.Name = "recent1";
            this.recent1.Size = new System.Drawing.Size(65, 22);
            this.recent1.Click += new System.EventHandler(this.recent1_Click);
            // 
            // recent2
            // 
            this.recent2.Name = "recent2";
            this.recent2.Size = new System.Drawing.Size(65, 22);
            this.recent2.Click += new System.EventHandler(this.recent2_Click);
            // 
            // recent3
            // 
            this.recent3.Name = "recent3";
            this.recent3.Size = new System.Drawing.Size(65, 22);
            this.recent3.Click += new System.EventHandler(this.recent3_Click);
            // 
            // recent4
            // 
            this.recent4.Name = "recent4";
            this.recent4.Size = new System.Drawing.Size(65, 22);
            this.recent4.Click += new System.EventHandler(this.recent4_Click);
            // 
            // recent5
            // 
            this.recent5.Name = "recent5";
            this.recent5.Size = new System.Drawing.Size(65, 22);
            this.recent5.Click += new System.EventHandler(this.recent5_Click);
            // 
            // recent6
            // 
            this.recent6.Name = "recent6";
            this.recent6.Size = new System.Drawing.Size(65, 22);
            this.recent6.Click += new System.EventHandler(this.recent6_Click);
            // 
            // recent7
            // 
            this.recent7.Name = "recent7";
            this.recent7.Size = new System.Drawing.Size(65, 22);
            this.recent7.Click += new System.EventHandler(this.recent7_Click);
            // 
            // recent8
            // 
            this.recent8.Name = "recent8";
            this.recent8.Size = new System.Drawing.Size(65, 22);
            this.recent8.Click += new System.EventHandler(this.recent8_Click);
            // 
            // recent9
            // 
            this.recent9.Name = "recent9";
            this.recent9.Size = new System.Drawing.Size(65, 22);
            this.recent9.Click += new System.EventHandler(this.recent9_Click);
            // 
            // recent10
            // 
            this.recent10.Name = "recent10";
            this.recent10.Size = new System.Drawing.Size(65, 22);
            this.recent10.Click += new System.EventHandler(this.recent10_Click);
            // 
            // importImageToolStripMenuItem
            // 
            this.importImageToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fromFileToolStripMenuItem,
            this.fromFilewithPaletteToolStripMenuItem});
            this.importImageToolStripMenuItem.Name = "importImageToolStripMenuItem";
            this.importImageToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.importImageToolStripMenuItem.Text = "Import Image (gif/bmp/png)";
            // 
            // fromFileToolStripMenuItem
            // 
            this.fromFileToolStripMenuItem.Name = "fromFileToolStripMenuItem";
            this.fromFileToolStripMenuItem.Size = new System.Drawing.Size(329, 22);
            this.fromFileToolStripMenuItem.Text = "From File (Convet to Current Palette)";
            this.fromFileToolStripMenuItem.Click += new System.EventHandler(this.fromFileToolStripMenuItem_Click);
            // 
            // fromFilewithPaletteToolStripMenuItem
            // 
            this.fromFilewithPaletteToolStripMenuItem.Name = "fromFilewithPaletteToolStripMenuItem";
            this.fromFilewithPaletteToolStripMenuItem.Size = new System.Drawing.Size(329, 22);
            this.fromFilewithPaletteToolStripMenuItem.Text = "From File (Import Palette - 16/256 color img only)";
            this.fromFilewithPaletteToolStripMenuItem.Click += new System.EventHandler(this.fromFilewithPaletteToolStripMenuItem_Click);
            // 
            // fileProcessorToolStripMenuItem
            // 
            this.fileProcessorToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rLECompressPerByteToolStripMenuItem,
            this.rLECompressAlternatingBytesToolStripMenuItem,
            this.rLECompressFourBytesToolStripMenuItem});
            this.fileProcessorToolStripMenuItem.Name = "fileProcessorToolStripMenuItem";
            this.fileProcessorToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.fileProcessorToolStripMenuItem.Text = "FileProcessor";
            // 
            // rLECompressPerByteToolStripMenuItem
            // 
            this.rLECompressPerByteToolStripMenuItem.Name = "rLECompressPerByteToolStripMenuItem";
            this.rLECompressPerByteToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.rLECompressPerByteToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.rLECompressPerByteToolStripMenuItem.Text = "RLE Compress (PerByte)";
            this.rLECompressPerByteToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/z80/multiplatform2.php#LessonM11";
            this.rLECompressPerByteToolStripMenuItem.Click += new System.EventHandler(this.rLECompressPerByteToolStripMenuItem_Click);
            // 
            // rLECompressAlternatingBytesToolStripMenuItem
            // 
            this.rLECompressAlternatingBytesToolStripMenuItem.Name = "rLECompressAlternatingBytesToolStripMenuItem";
            this.rLECompressAlternatingBytesToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.rLECompressAlternatingBytesToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.rLECompressAlternatingBytesToolStripMenuItem.Text = "RLE Compress (Split Alternating Bytes)";
            this.rLECompressAlternatingBytesToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/z80/multiplatform2.php#LessonM11";
            this.rLECompressAlternatingBytesToolStripMenuItem.Click += new System.EventHandler(this.rLECompressAlternatingBytesToolStripMenuItem_Click);
            // 
            // rLECompressFourBytesToolStripMenuItem
            // 
            this.rLECompressFourBytesToolStripMenuItem.Name = "rLECompressFourBytesToolStripMenuItem";
            this.rLECompressFourBytesToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.rLECompressFourBytesToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.rLECompressFourBytesToolStripMenuItem.Text = "RLE Compress (Split FourBytes)";
            this.rLECompressFourBytesToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/z80/multiplatform2.php#LessonM11";
            this.rLECompressFourBytesToolStripMenuItem.Click += new System.EventHandler(this.rLECompressFourBytesToolStripMenuItem_Click);
            // 
            // saveBMPMapToolStripMenuItem
            // 
            this.saveBMPMapToolStripMenuItem.Name = "saveBMPMapToolStripMenuItem";
            this.saveBMPMapToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.saveBMPMapToolStripMenuItem.Text = "Save BMP Map (MultiSprite MAP)";
            this.saveBMPMapToolStripMenuItem.Click += new System.EventHandler(this.saveBMPMapToolStripMenuItem_Click);
            // 
            // loadBMPMaToolStripMenuItem
            // 
            this.loadBMPMaToolStripMenuItem.Name = "loadBMPMaToolStripMenuItem";
            this.loadBMPMaToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.loadBMPMaToolStripMenuItem.Text = "Load BMP Map (MultiSprite MAP)";
            this.loadBMPMaToolStripMenuItem.Click += new System.EventHandler(this.loadBMPMaToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // ViewToolStripMenuItem
            // 
            this.ViewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.colorToolStripMenuItem,
            this.mSX16ColorToolStripMenuItem,
            this.cPC4ColorToolStripMenuItem,
            this.colorpairsCPCENTToolStripMenuItem,
            this.colorditheredCPCENTToolStripMenuItem,
            this.zX2ColorToolStripMenuItem,
            this.colorditheredToolStripMenuItem,
            this.toolStripMenuItem4,
            this.cPC16ColorToolStripMenuItem,
            this.eGX416ColorCPCToolStripMenuItem,
            this.toolStripMenuItem3,
            this.highVisToggleToolStripMenuItem,
            this.overlayLastFrameToolStripMenuItem,
            this.overlayNextFrameToolStripMenuItem,
            this.toolStripMenuItem6,
            this.applyViewColorConversionToolStripMenuItem});
            this.ViewToolStripMenuItem.Name = "ViewToolStripMenuItem";
            this.ViewToolStripMenuItem.Size = new System.Drawing.Size(42, 20);
            this.ViewToolStripMenuItem.Text = "View";
            // 
            // colorToolStripMenuItem
            // 
            this.colorToolStripMenuItem.Name = "colorToolStripMenuItem";
            this.colorToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.colorToolStripMenuItem.Text = "256 Color";
            this.colorToolStripMenuItem.Click += new System.EventHandler(this.colorToolStripMenuItem_Click);
            // 
            // mSX16ColorToolStripMenuItem
            // 
            this.mSX16ColorToolStripMenuItem.Name = "mSX16ColorToolStripMenuItem";
            this.mSX16ColorToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.mSX16ColorToolStripMenuItem.Text = "16 Color";
            this.mSX16ColorToolStripMenuItem.Click += new System.EventHandler(this.mSX16ColorToolStripMenuItem_Click);
            // 
            // cPC4ColorToolStripMenuItem
            // 
            this.cPC4ColorToolStripMenuItem.Name = "cPC4ColorToolStripMenuItem";
            this.cPC4ColorToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.cPC4ColorToolStripMenuItem.Text = "4 Color";
            this.cPC4ColorToolStripMenuItem.Click += new System.EventHandler(this.cPC4ColorToolStripMenuItem_Click);
            // 
            // colorpairsCPCENTToolStripMenuItem
            // 
            this.colorpairsCPCENTToolStripMenuItem.Name = "colorpairsCPCENTToolStripMenuItem";
            this.colorpairsCPCENTToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.colorpairsCPCENTToolStripMenuItem.Text = "4 Color (pairs) ";
            this.colorpairsCPCENTToolStripMenuItem.Click += new System.EventHandler(this.colorpairsCPCENTToolStripMenuItem_Click);
            // 
            // colorditheredCPCENTToolStripMenuItem
            // 
            this.colorditheredCPCENTToolStripMenuItem.Name = "colorditheredCPCENTToolStripMenuItem";
            this.colorditheredCPCENTToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.colorditheredCPCENTToolStripMenuItem.Text = "4 Color (dithered)";
            this.colorditheredCPCENTToolStripMenuItem.Click += new System.EventHandler(this.colorditheredCPCENTToolStripMenuItem_Click);
            // 
            // zX2ColorToolStripMenuItem
            // 
            this.zX2ColorToolStripMenuItem.Name = "zX2ColorToolStripMenuItem";
            this.zX2ColorToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.zX2ColorToolStripMenuItem.Text = "2 Color";
            this.zX2ColorToolStripMenuItem.Click += new System.EventHandler(this.zX2ColorToolStripMenuItem_Click);
            // 
            // colorditheredToolStripMenuItem
            // 
            this.colorditheredToolStripMenuItem.Name = "colorditheredToolStripMenuItem";
            this.colorditheredToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.colorditheredToolStripMenuItem.Text = "2 Color (dithered)";
            this.colorditheredToolStripMenuItem.Click += new System.EventHandler(this.colorditheredToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(217, 6);
            // 
            // cPC16ColorToolStripMenuItem
            // 
            this.cPC16ColorToolStripMenuItem.Name = "cPC16ColorToolStripMenuItem";
            this.cPC16ColorToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.cPC16ColorToolStripMenuItem.Text = "HalfWidth 16 Color (CPC)";
            this.cPC16ColorToolStripMenuItem.Click += new System.EventHandler(this.cPC16ColorToolStripMenuItem_Click);
            // 
            // eGX416ColorCPCToolStripMenuItem
            // 
            this.eGX416ColorCPCToolStripMenuItem.Name = "eGX416ColorCPCToolStripMenuItem";
            this.eGX416ColorCPCToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.eGX416ColorCPCToolStripMenuItem.Text = "EGX 4/16 Color (CPC)";
            this.eGX416ColorCPCToolStripMenuItem.Click += new System.EventHandler(this.eGX416ColorCPCToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(217, 6);
            // 
            // highVisToggleToolStripMenuItem
            // 
            this.highVisToggleToolStripMenuItem.Name = "highVisToggleToolStripMenuItem";
            this.highVisToggleToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.highVisToggleToolStripMenuItem.Text = "HighVis Toggle";
            this.highVisToggleToolStripMenuItem.Click += new System.EventHandler(this.highVisToggleToolStripMenuItem_Click);
            // 
            // overlayLastFrameToolStripMenuItem
            // 
            this.overlayLastFrameToolStripMenuItem.Name = "overlayLastFrameToolStripMenuItem";
            this.overlayLastFrameToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.overlayLastFrameToolStripMenuItem.Text = "Overlay LastFrame";
            this.overlayLastFrameToolStripMenuItem.Click += new System.EventHandler(this.overlayLastFrameToolStripMenuItem_Click);
            // 
            // overlayNextFrameToolStripMenuItem
            // 
            this.overlayNextFrameToolStripMenuItem.Name = "overlayNextFrameToolStripMenuItem";
            this.overlayNextFrameToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.overlayNextFrameToolStripMenuItem.Text = "Overlay NextFrame";
            this.overlayNextFrameToolStripMenuItem.Click += new System.EventHandler(this.overlayNextFrameToolStripMenuItem_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(217, 6);
            // 
            // applyViewColorConversionToolStripMenuItem
            // 
            this.applyViewColorConversionToolStripMenuItem.Name = "applyViewColorConversionToolStripMenuItem";
            this.applyViewColorConversionToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.applyViewColorConversionToolStripMenuItem.Text = "Apply View Color Conversion";
            this.applyViewColorConversionToolStripMenuItem.Click += new System.EventHandler(this.applyViewColorConversionToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyToClipboardToolStripMenuItem,
            this.pasteToClipToolStripMenuItem,
            this.copyPreviewToolStripMenuItem,
            this.canvasSizeToolStripMenuItem,
            this.duplicateFromToolStripMenuItem,
            this.duplicateOffsetFromToolStripMenuItem,
            this.makeTilesToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // copyToClipboardToolStripMenuItem
            // 
            this.copyToClipboardToolStripMenuItem.Name = "copyToClipboardToolStripMenuItem";
            this.copyToClipboardToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.copyToClipboardToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.copyToClipboardToolStripMenuItem.Text = "Copy to Clipboard";
            this.copyToClipboardToolStripMenuItem.Click += new System.EventHandler(this.copyToClipboardToolStripMenuItem_Click);
            // 
            // pasteToClipToolStripMenuItem
            // 
            this.pasteToClipToolStripMenuItem.Name = "pasteToClipToolStripMenuItem";
            this.pasteToClipToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.pasteToClipToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.pasteToClipToolStripMenuItem.Text = "Paste from Clipboard";
            this.pasteToClipToolStripMenuItem.Click += new System.EventHandler(this.pasteToClipToolStripMenuItem_Click);
            // 
            // copyPreviewToolStripMenuItem
            // 
            this.copyPreviewToolStripMenuItem.Name = "copyPreviewToolStripMenuItem";
            this.copyPreviewToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift)
                        | System.Windows.Forms.Keys.C)));
            this.copyPreviewToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.copyPreviewToolStripMenuItem.Text = "Copy Preview";
            this.copyPreviewToolStripMenuItem.Click += new System.EventHandler(this.copyPreviewToolStripMenuItem_Click);
            // 
            // canvasSizeToolStripMenuItem
            // 
            this.canvasSizeToolStripMenuItem.Name = "canvasSizeToolStripMenuItem";
            this.canvasSizeToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.canvasSizeToolStripMenuItem.Text = "Canvas Size";
            this.canvasSizeToolStripMenuItem.Click += new System.EventHandler(this.canvasSizeToolStripMenuItem_Click);
            // 
            // duplicateFromToolStripMenuItem
            // 
            this.duplicateFromToolStripMenuItem.Name = "duplicateFromToolStripMenuItem";
            this.duplicateFromToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.duplicateFromToolStripMenuItem.Text = "Duplicate From";
            this.duplicateFromToolStripMenuItem.Click += new System.EventHandler(this.duplicateFromToolStripMenuItem_Click);
            // 
            // duplicateOffsetFromToolStripMenuItem
            // 
            this.duplicateOffsetFromToolStripMenuItem.Name = "duplicateOffsetFromToolStripMenuItem";
            this.duplicateOffsetFromToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.duplicateOffsetFromToolStripMenuItem.Text = "Duplicate Offset From";
            this.duplicateOffsetFromToolStripMenuItem.Click += new System.EventHandler(this.duplicateOffsetFromToolStripMenuItem_Click);
            // 
            // makeTilesToolStripMenuItem
            // 
            this.makeTilesToolStripMenuItem.Name = "makeTilesToolStripMenuItem";
            this.makeTilesToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.makeTilesToolStripMenuItem.Text = "Make Tiles";
            this.makeTilesToolStripMenuItem.Click += new System.EventHandler(this.makeTilesToolStripMenuItem_Click);
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.transformToolStripMenuItem,
            this.yInterlaceToolStripMenuItem,
            this.interlaceOddFieldsToolStripMenuItem,
            this.interlaceEvenFieldsToolStripMenuItem,
            this.setAllAttribsToolStripMenuItem,
            this.blackBorderToolStripMenuItem,
            this.blackBorderTightToolStripMenuItem,
            this.PaletteTint,
            this.tilesToolStripMenuItem,
            this.palettesToolStripMenuItem,
            this.spritesToolStripMenuItem,
            this.deresToolStripMenuItem});
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(45, 20);
            this.toolsToolStripMenuItem.Text = "Tools";
            // 
            // transformToolStripMenuItem
            // 
            this.transformToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.flipXToolStripMenuItem,
            this.flipYToolStripMenuItem,
            this.pxShiftToolStripMenuItem,
            this.pixelShiftRightToolStripMenuItem,
            this.pixelShiftUpToolStripMenuItem,
            this.pixelShiftDownToolStripMenuItem,
            this.tileShiftXToolStripMenuItem});
            this.transformToolStripMenuItem.Name = "transformToolStripMenuItem";
            this.transformToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.transformToolStripMenuItem.Text = "Transform";
            // 
            // flipXToolStripMenuItem
            // 
            this.flipXToolStripMenuItem.Name = "flipXToolStripMenuItem";
            this.flipXToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.flipXToolStripMenuItem.Text = "FlipX";
            this.flipXToolStripMenuItem.Click += new System.EventHandler(this.flipXToolStripMenuItem_Click);
            // 
            // flipYToolStripMenuItem
            // 
            this.flipYToolStripMenuItem.Name = "flipYToolStripMenuItem";
            this.flipYToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.flipYToolStripMenuItem.Text = "FlipY";
            this.flipYToolStripMenuItem.Click += new System.EventHandler(this.flipYToolStripMenuItem_Click);
            // 
            // pxShiftToolStripMenuItem
            // 
            this.pxShiftToolStripMenuItem.Name = "pxShiftToolStripMenuItem";
            this.pxShiftToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.pxShiftToolStripMenuItem.Text = "Pixel Shift Left";
            this.pxShiftToolStripMenuItem.Click += new System.EventHandler(this.pxShiftToolStripMenuItem_Click);
            // 
            // pixelShiftRightToolStripMenuItem
            // 
            this.pixelShiftRightToolStripMenuItem.Name = "pixelShiftRightToolStripMenuItem";
            this.pixelShiftRightToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.pixelShiftRightToolStripMenuItem.Text = "Pixel Shift Right";
            this.pixelShiftRightToolStripMenuItem.Click += new System.EventHandler(this.pixelShiftRightToolStripMenuItem_Click);
            // 
            // pixelShiftUpToolStripMenuItem
            // 
            this.pixelShiftUpToolStripMenuItem.Name = "pixelShiftUpToolStripMenuItem";
            this.pixelShiftUpToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.pixelShiftUpToolStripMenuItem.Text = "Pixel Shift Up";
            this.pixelShiftUpToolStripMenuItem.Click += new System.EventHandler(this.pixelShiftUpToolStripMenuItem_Click);
            // 
            // pixelShiftDownToolStripMenuItem
            // 
            this.pixelShiftDownToolStripMenuItem.Name = "pixelShiftDownToolStripMenuItem";
            this.pixelShiftDownToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.pixelShiftDownToolStripMenuItem.Text = "Pixel Shift Down";
            this.pixelShiftDownToolStripMenuItem.Click += new System.EventHandler(this.pixelShiftDownToolStripMenuItem_Click);
            // 
            // tileShiftXToolStripMenuItem
            // 
            this.tileShiftXToolStripMenuItem.Name = "tileShiftXToolStripMenuItem";
            this.tileShiftXToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.tileShiftXToolStripMenuItem.Text = "TileShiftX";
            this.tileShiftXToolStripMenuItem.Click += new System.EventHandler(this.tileShiftXToolStripMenuItem_Click);
            // 
            // yInterlaceToolStripMenuItem
            // 
            this.yInterlaceToolStripMenuItem.Name = "yInterlaceToolStripMenuItem";
            this.yInterlaceToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.yInterlaceToolStripMenuItem.Text = "Interlace-Y";
            this.yInterlaceToolStripMenuItem.Click += new System.EventHandler(this.yInterlaceToolStripMenuItem_Click);
            // 
            // interlaceOddFieldsToolStripMenuItem
            // 
            this.interlaceOddFieldsToolStripMenuItem.Name = "interlaceOddFieldsToolStripMenuItem";
            this.interlaceOddFieldsToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.interlaceOddFieldsToolStripMenuItem.Text = "Interlace-OddFields";
            this.interlaceOddFieldsToolStripMenuItem.Click += new System.EventHandler(this.interlaceOddFieldsToolStripMenuItem_Click);
            // 
            // interlaceEvenFieldsToolStripMenuItem
            // 
            this.interlaceEvenFieldsToolStripMenuItem.Name = "interlaceEvenFieldsToolStripMenuItem";
            this.interlaceEvenFieldsToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.interlaceEvenFieldsToolStripMenuItem.Text = "Interlace-EvenFields";
            this.interlaceEvenFieldsToolStripMenuItem.Click += new System.EventHandler(this.interlaceEvenFieldsToolStripMenuItem_Click);
            // 
            // setAllAttribsToolStripMenuItem
            // 
            this.setAllAttribsToolStripMenuItem.Name = "setAllAttribsToolStripMenuItem";
            this.setAllAttribsToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.setAllAttribsToolStripMenuItem.Text = "SetAllAttribs";
            this.setAllAttribsToolStripMenuItem.Click += new System.EventHandler(this.setAllAttribsToolStripMenuItem_Click);
            // 
            // blackBorderToolStripMenuItem
            // 
            this.blackBorderToolStripMenuItem.Name = "blackBorderToolStripMenuItem";
            this.blackBorderToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.blackBorderToolStripMenuItem.Text = "BlackBorder";
            this.blackBorderToolStripMenuItem.Click += new System.EventHandler(this.blackBorderToolStripMenuItem_Click);
            // 
            // blackBorderTightToolStripMenuItem
            // 
            this.blackBorderTightToolStripMenuItem.Name = "blackBorderTightToolStripMenuItem";
            this.blackBorderTightToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.blackBorderTightToolStripMenuItem.Text = "BlackBorder Tight";
            this.blackBorderTightToolStripMenuItem.Click += new System.EventHandler(this.blackBorderTightToolStripMenuItem_Click);
            // 
            // PaletteTint
            // 
            this.PaletteTint.Name = "PaletteTint";
            this.PaletteTint.Size = new System.Drawing.Size(176, 22);
            this.PaletteTint.Text = "Palette Tint";
            this.PaletteTint.Click += new System.EventHandler(this.PaletteTint_Click);
            // 
            // tilesToolStripMenuItem
            // 
            this.tilesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addTilesToolStripMenuItem,
            this.clearTilesToolStripMenuItem,
            this.addMultipleToolStripMenuItem,
            this.deresAllMultipleToolStripMenuItem});
            this.tilesToolStripMenuItem.Name = "tilesToolStripMenuItem";
            this.tilesToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.tilesToolStripMenuItem.Text = "Tiles";
            // 
            // addTilesToolStripMenuItem
            // 
            this.addTilesToolStripMenuItem.Name = "addTilesToolStripMenuItem";
            this.addTilesToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.addTilesToolStripMenuItem.Text = "Add Tiles";
            this.addTilesToolStripMenuItem.Click += new System.EventHandler(this.addTilesToolStripMenuItem_Click);
            // 
            // clearTilesToolStripMenuItem
            // 
            this.clearTilesToolStripMenuItem.Name = "clearTilesToolStripMenuItem";
            this.clearTilesToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.clearTilesToolStripMenuItem.Text = "Clear + Add Tiles";
            this.clearTilesToolStripMenuItem.Click += new System.EventHandler(this.clearTilesToolStripMenuItem_Click);
            // 
            // addMultipleToolStripMenuItem
            // 
            this.addMultipleToolStripMenuItem.Name = "addMultipleToolStripMenuItem";
            this.addMultipleToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.addMultipleToolStripMenuItem.Text = "Add Multiple";
            this.addMultipleToolStripMenuItem.Click += new System.EventHandler(this.addMultipleToolStripMenuItem_Click);
            // 
            // deresAllMultipleToolStripMenuItem
            // 
            this.deresAllMultipleToolStripMenuItem.Name = "deresAllMultipleToolStripMenuItem";
            this.deresAllMultipleToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.deresAllMultipleToolStripMenuItem.Text = "Deres All Multiple";
            this.deresAllMultipleToolStripMenuItem.Click += new System.EventHandler(this.deresAllMultipleToolStripMenuItem_Click);
            // 
            // palettesToolStripMenuItem
            // 
            this.palettesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem8,
            this.defauktToolStripMenuItem,
            this.enterprise256ColorToolStripMenuItem,
            this.mSX1PaletteToolStripMenuItem,
            this.simple4x4x4ToolStripMenuItem,
            this.greyScalePaletteToolStripMenuItem,
            this.sQLCLX8ColorPaletteToolStripMenuItem,
            this.dragonCOCOToolStripMenuItem});
            this.palettesToolStripMenuItem.Name = "palettesToolStripMenuItem";
            this.palettesToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.palettesToolStripMenuItem.Text = "Palettes";
            // 
            // fileToolStripMenuItem8
            // 
            this.fileToolStripMenuItem8.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadFromPALIrfanviewToolStripMenuItem1,
            this.saveToPALirfanviewToolStripMenuItem1});
            this.fileToolStripMenuItem8.Name = "fileToolStripMenuItem8";
            this.fileToolStripMenuItem8.Size = new System.Drawing.Size(226, 22);
            this.fileToolStripMenuItem8.Text = "File";
            // 
            // loadFromPALIrfanviewToolStripMenuItem1
            // 
            this.loadFromPALIrfanviewToolStripMenuItem1.Name = "loadFromPALIrfanviewToolStripMenuItem1";
            this.loadFromPALIrfanviewToolStripMenuItem1.Size = new System.Drawing.Size(207, 22);
            this.loadFromPALIrfanviewToolStripMenuItem1.Text = "Load From PAL (Irfanview)";
            this.loadFromPALIrfanviewToolStripMenuItem1.Click += new System.EventHandler(this.loadFromPALIrfanviewToolStripMenuItem1_Click);
            // 
            // saveToPALirfanviewToolStripMenuItem1
            // 
            this.saveToPALirfanviewToolStripMenuItem1.Name = "saveToPALirfanviewToolStripMenuItem1";
            this.saveToPALirfanviewToolStripMenuItem1.Size = new System.Drawing.Size(207, 22);
            this.saveToPALirfanviewToolStripMenuItem1.Text = "Save To PAL (irfanview)";
            this.saveToPALirfanviewToolStripMenuItem1.Click += new System.EventHandler(this.saveToPALirfanviewToolStripMenuItem1_Click);
            // 
            // defauktToolStripMenuItem
            // 
            this.defauktToolStripMenuItem.Name = "defauktToolStripMenuItem";
            this.defauktToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.defauktToolStripMenuItem.Text = "VGA 256 Palette";
            this.defauktToolStripMenuItem.Click += new System.EventHandler(this.defauktToolStripMenuItem_Click);
            // 
            // enterprise256ColorToolStripMenuItem
            // 
            this.enterprise256ColorToolStripMenuItem.Name = "enterprise256ColorToolStripMenuItem";
            this.enterprise256ColorToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.enterprise256ColorToolStripMenuItem.Text = "MSX2 / ENT 256 color Palette";
            this.enterprise256ColorToolStripMenuItem.Click += new System.EventHandler(this.enterprise256ColorToolStripMenuItem_Click);
            // 
            // mSX1PaletteToolStripMenuItem
            // 
            this.mSX1PaletteToolStripMenuItem.Name = "mSX1PaletteToolStripMenuItem";
            this.mSX1PaletteToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.mSX1PaletteToolStripMenuItem.Text = "MSX1 Palette";
            this.mSX1PaletteToolStripMenuItem.Click += new System.EventHandler(this.mSX1PaletteToolStripMenuItem_Click);
            // 
            // simple4x4x4ToolStripMenuItem
            // 
            this.simple4x4x4ToolStripMenuItem.Name = "simple4x4x4ToolStripMenuItem";
            this.simple4x4x4ToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.simple4x4x4ToolStripMenuItem.Text = "Simple 4x4x4 Palette";
            this.simple4x4x4ToolStripMenuItem.Click += new System.EventHandler(this.simple4x4x4ToolStripMenuItem_Click);
            // 
            // greyScalePaletteToolStripMenuItem
            // 
            this.greyScalePaletteToolStripMenuItem.Name = "greyScalePaletteToolStripMenuItem";
            this.greyScalePaletteToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.greyScalePaletteToolStripMenuItem.Text = "GreyScale Palette";
            this.greyScalePaletteToolStripMenuItem.Click += new System.EventHandler(this.greyScalePaletteToolStripMenuItem_Click);
            // 
            // sQLCLX8ColorPaletteToolStripMenuItem
            // 
            this.sQLCLX8ColorPaletteToolStripMenuItem.Name = "sQLCLX8ColorPaletteToolStripMenuItem";
            this.sQLCLX8ColorPaletteToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.sQLCLX8ColorPaletteToolStripMenuItem.Text = "SQL/CLX 8 color palette";
            this.sQLCLX8ColorPaletteToolStripMenuItem.Click += new System.EventHandler(this.sQLCLX8ColorPaletteToolStripMenuItem_Click);
            // 
            // dragonCOCOToolStripMenuItem
            // 
            this.dragonCOCOToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.palette0GToolStripMenuItem,
            this.palette1WCMOToolStripMenuItem});
            this.dragonCOCOToolStripMenuItem.Name = "dragonCOCOToolStripMenuItem";
            this.dragonCOCOToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.dragonCOCOToolStripMenuItem.Text = "Dragon / COCO";
            // 
            // palette0GToolStripMenuItem
            // 
            this.palette0GToolStripMenuItem.Name = "palette0GToolStripMenuItem";
            this.palette0GToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.palette0GToolStripMenuItem.Text = "Palette 0 GYBR";
            this.palette0GToolStripMenuItem.Click += new System.EventHandler(this.palette0GToolStripMenuItem_Click);
            // 
            // palette1WCMOToolStripMenuItem
            // 
            this.palette1WCMOToolStripMenuItem.Name = "palette1WCMOToolStripMenuItem";
            this.palette1WCMOToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.palette1WCMOToolStripMenuItem.Text = "Palette 1 WCMO";
            this.palette1WCMOToolStripMenuItem.Click += new System.EventHandler(this.palette1WCMOToolStripMenuItem_Click);
            // 
            // spritesToolStripMenuItem
            // 
            this.spritesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.spriteSpace8x816x16ToolStripMenuItem,
            this.generatePixelMapToolStripMenuItem,
            this.insertBlankSpriteToolStripMenuItem});
            this.spritesToolStripMenuItem.Name = "spritesToolStripMenuItem";
            this.spritesToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.spritesToolStripMenuItem.Text = "Sprites";
            // 
            // spriteSpace8x816x16ToolStripMenuItem
            // 
            this.spriteSpace8x816x16ToolStripMenuItem.Name = "spriteSpace8x816x16ToolStripMenuItem";
            this.spriteSpace8x816x16ToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.spriteSpace8x816x16ToolStripMenuItem.Text = "SpriteSpace 8x8->16x16";
            this.spriteSpace8x816x16ToolStripMenuItem.Click += new System.EventHandler(this.spriteSpace8x816x16ToolStripMenuItem_Click);
            // 
            // generatePixelMapToolStripMenuItem
            // 
            this.generatePixelMapToolStripMenuItem.Name = "generatePixelMapToolStripMenuItem";
            this.generatePixelMapToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.generatePixelMapToolStripMenuItem.Text = "Generate PixelMap";
            this.generatePixelMapToolStripMenuItem.Click += new System.EventHandler(this.generatePixelMapToolStripMenuItem_Click);
            // 
            // insertBlankSpriteToolStripMenuItem
            // 
            this.insertBlankSpriteToolStripMenuItem.Name = "insertBlankSpriteToolStripMenuItem";
            this.insertBlankSpriteToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.insertBlankSpriteToolStripMenuItem.Text = "Insert Blank Sprite";
            this.insertBlankSpriteToolStripMenuItem.Click += new System.EventHandler(this.insertBlankSpriteToolStripMenuItem_Click);
            // 
            // deresToolStripMenuItem
            // 
            this.deresToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.halveYToolStripMenuItem});
            this.deresToolStripMenuItem.Name = "deresToolStripMenuItem";
            this.deresToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.deresToolStripMenuItem.Text = "Deres";
            // 
            // halveYToolStripMenuItem
            // 
            this.halveYToolStripMenuItem.Name = "halveYToolStripMenuItem";
            this.halveYToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.halveYToolStripMenuItem.Text = "HalveY";
            this.halveYToolStripMenuItem.Click += new System.EventHandler(this.halveYToolStripMenuItem_Click);
            // 
            // z80ToolStripMenuItem
            // 
            this.z80ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cPCToolStripMenuItem,
            this.mSXToolStripMenuItem,
            this.zXToolStripMenuItem,
            this.gBToolStripMenuItem,
            this.tIToolStripMenuItem,
            this.sAMToolStripMenuItem,
            this.eNTToolStripMenuItem,
            this.sMSToolStripMenuItem,
            this.camputersLynxToolStripMenuItem,
            this.specNEXTToolStripMenuItem,
            this.paletteToClipboardToolStripMenuItem});
            this.z80ToolStripMenuItem.Name = "z80ToolStripMenuItem";
            this.z80ToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.z80ToolStripMenuItem.Text = "* Z80 *";
            // 
            // cPCToolStripMenuItem
            // 
            this.cPCToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem3,
            this.spriteCompilerToolStripMenuItem,
            this.saveASMPaletteToolStripMenuItem});
            this.cPCToolStripMenuItem.Name = "cPCToolStripMenuItem";
            this.cPCToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.cPCToolStripMenuItem.Text = "Amstrad CPC";
            // 
            // fileToolStripMenuItem3
            // 
            this.fileToolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadCPCBinaryToolStripMenuItem,
            this.saveCPCBinaryToolStripMenuItem1,
            this.loadCPCBinaryToolStripMenuItem1,
            this.saveCPCBinaryToolStripMenuItem,
            this.SaveCPCRawBmp,
            this.saveRaw8x8TilesToolStripMenuItem,
            this.saveRaw8x8Tiles4ColorZigTileToolStripMenuItem,
            this.saveRaw8x4Tiles4ColorHalfHeightToolStripMenuItem,
            this.saveCPCZigTileToolStripMenuItem,
            this.saveCPCSCRToolStripMenuItem,
            this.rLEASMToolStripMenuItem});
            this.fileToolStripMenuItem3.Name = "fileToolStripMenuItem3";
            this.fileToolStripMenuItem3.Size = new System.Drawing.Size(181, 22);
            this.fileToolStripMenuItem3.Text = "File";
            // 
            // loadCPCBinaryToolStripMenuItem
            // 
            this.loadCPCBinaryToolStripMenuItem.Name = "loadCPCBinaryToolStripMenuItem";
            this.loadCPCBinaryToolStripMenuItem.Size = new System.Drawing.Size(313, 22);
            this.loadCPCBinaryToolStripMenuItem.Text = "Load CPC+ Binary";
            this.loadCPCBinaryToolStripMenuItem.Click += new System.EventHandler(this.loadCPCBinaryToolStripMenuItem_Click);
            // 
            // saveCPCBinaryToolStripMenuItem1
            // 
            this.saveCPCBinaryToolStripMenuItem1.Name = "saveCPCBinaryToolStripMenuItem1";
            this.saveCPCBinaryToolStripMenuItem1.ShortcutKeyDisplayString = "[?]";
            this.saveCPCBinaryToolStripMenuItem1.Size = new System.Drawing.Size(313, 22);
            this.saveCPCBinaryToolStripMenuItem1.Text = "Save CPC+ Binary";
            this.saveCPCBinaryToolStripMenuItem1.ToolTipText = "See: https://www.chibiakumas.com/z80/platform4.php#LessonP32";
            this.saveCPCBinaryToolStripMenuItem1.Click += new System.EventHandler(this.saveCPCBinaryToolStripMenuItem1_Click);
            // 
            // loadCPCBinaryToolStripMenuItem1
            // 
            this.loadCPCBinaryToolStripMenuItem1.Name = "loadCPCBinaryToolStripMenuItem1";
            this.loadCPCBinaryToolStripMenuItem1.Size = new System.Drawing.Size(313, 22);
            this.loadCPCBinaryToolStripMenuItem1.Text = "Load CPC Binary (Chibiakumas format)";
            this.loadCPCBinaryToolStripMenuItem1.Click += new System.EventHandler(this.loadCPCBinaryToolStripMenuItem1_Click);
            // 
            // saveCPCBinaryToolStripMenuItem
            // 
            this.saveCPCBinaryToolStripMenuItem.Name = "saveCPCBinaryToolStripMenuItem";
            this.saveCPCBinaryToolStripMenuItem.Size = new System.Drawing.Size(313, 22);
            this.saveCPCBinaryToolStripMenuItem.Text = "Save CPC Binary Sprites (Chibiakumas format)";
            this.saveCPCBinaryToolStripMenuItem.Click += new System.EventHandler(this.saveCPCBinaryToolStripMenuItem_Click);
            // 
            // SaveCPCRawBmp
            // 
            this.SaveCPCRawBmp.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.SaveCPCRawBmp.Name = "SaveCPCRawBmp";
            this.SaveCPCRawBmp.ShortcutKeyDisplayString = "[?]";
            this.SaveCPCRawBmp.Size = new System.Drawing.Size(313, 22);
            this.SaveCPCRawBmp.Text = "Save RAW Bitmap (4/16 Color)";
            this.SaveCPCRawBmp.ToolTipText = "See: https://www.chibiakumas.com/z80/simplesamples.php#LessonS1";
            this.SaveCPCRawBmp.Click += new System.EventHandler(this.SaveCPCRawBmp_Click);
            // 
            // saveRaw8x8TilesToolStripMenuItem
            // 
            this.saveRaw8x8TilesToolStripMenuItem.Name = "saveRaw8x8TilesToolStripMenuItem";
            this.saveRaw8x8TilesToolStripMenuItem.Size = new System.Drawing.Size(313, 22);
            this.saveRaw8x8TilesToolStripMenuItem.Text = "Save Raw 8x8 Tiles (4/16 color)";
            this.saveRaw8x8TilesToolStripMenuItem.Click += new System.EventHandler(this.saveRaw8x8TilesToolStripMenuItem_Click);
            // 
            // saveRaw8x8Tiles4ColorZigTileToolStripMenuItem
            // 
            this.saveRaw8x8Tiles4ColorZigTileToolStripMenuItem.Name = "saveRaw8x8Tiles4ColorZigTileToolStripMenuItem";
            this.saveRaw8x8Tiles4ColorZigTileToolStripMenuItem.Size = new System.Drawing.Size(313, 22);
            this.saveRaw8x8Tiles4ColorZigTileToolStripMenuItem.Text = "Save Raw 8x8 Tiles (4 color - ZigTile)";
            this.saveRaw8x8Tiles4ColorZigTileToolStripMenuItem.Visible = false;
            this.saveRaw8x8Tiles4ColorZigTileToolStripMenuItem.Click += new System.EventHandler(this.saveRaw8x8Tiles4ColorZigTileToolStripMenuItem_Click);
            // 
            // saveRaw8x4Tiles4ColorHalfHeightToolStripMenuItem
            // 
            this.saveRaw8x4Tiles4ColorHalfHeightToolStripMenuItem.Name = "saveRaw8x4Tiles4ColorHalfHeightToolStripMenuItem";
            this.saveRaw8x4Tiles4ColorHalfHeightToolStripMenuItem.Size = new System.Drawing.Size(313, 22);
            this.saveRaw8x4Tiles4ColorHalfHeightToolStripMenuItem.Text = "Save Raw 8x4 Tiles (4 color) HalfHeight";
            this.saveRaw8x4Tiles4ColorHalfHeightToolStripMenuItem.Click += new System.EventHandler(this.saveRaw8x4Tiles4ColorHalfHeightToolStripMenuItem_Click);
            // 
            // saveCPCZigTileToolStripMenuItem
            // 
            this.saveCPCZigTileToolStripMenuItem.Name = "saveCPCZigTileToolStripMenuItem";
            this.saveCPCZigTileToolStripMenuItem.Size = new System.Drawing.Size(313, 22);
            this.saveCPCZigTileToolStripMenuItem.Text = "Save CPC ZigTile";
            this.saveCPCZigTileToolStripMenuItem.Visible = false;
            this.saveCPCZigTileToolStripMenuItem.Click += new System.EventHandler(this.saveCPCZigTileToolStripMenuItem_Click);
            // 
            // saveCPCSCRToolStripMenuItem
            // 
            this.saveCPCSCRToolStripMenuItem.Name = "saveCPCSCRToolStripMenuItem";
            this.saveCPCSCRToolStripMenuItem.Size = new System.Drawing.Size(313, 22);
            this.saveCPCSCRToolStripMenuItem.Text = "Save CPC SCR";
            this.saveCPCSCRToolStripMenuItem.Click += new System.EventHandler(this.saveCPCSCRToolStripMenuItem_Click);
            // 
            // rLEASMToolStripMenuItem
            // 
            this.rLEASMToolStripMenuItem.Name = "rLEASMToolStripMenuItem";
            this.rLEASMToolStripMenuItem.Size = new System.Drawing.Size(313, 22);
            this.rLEASMToolStripMenuItem.Text = "RLE ASM";
            this.rLEASMToolStripMenuItem.Click += new System.EventHandler(this.rLEASMToolStripMenuItem_Click);
            // 
            // spriteCompilerToolStripMenuItem
            // 
            this.spriteCompilerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addOneToolStripMenuItem,
            this.CpcSpriteConvaddOneDiffToolStripMenuItem,
            this.CpcSpriteCompilerClear});
            this.spriteCompilerToolStripMenuItem.Name = "spriteCompilerToolStripMenuItem";
            this.spriteCompilerToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.spriteCompilerToolStripMenuItem.Text = "SpriteCompiler";
            // 
            // addOneToolStripMenuItem
            // 
            this.addOneToolStripMenuItem.Name = "addOneToolStripMenuItem";
            this.addOneToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.addOneToolStripMenuItem.Text = "AddOne";
            this.addOneToolStripMenuItem.Click += new System.EventHandler(this.addOneToolStripMenuItem_Click);
            // 
            // CpcSpriteConvaddOneDiffToolStripMenuItem
            // 
            this.CpcSpriteConvaddOneDiffToolStripMenuItem.Name = "CpcSpriteConvaddOneDiffToolStripMenuItem";
            this.CpcSpriteConvaddOneDiffToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.CpcSpriteConvaddOneDiffToolStripMenuItem.Text = "AddOneDiff";
            this.CpcSpriteConvaddOneDiffToolStripMenuItem.Click += new System.EventHandler(this.CpcSpriteConvaddOneDiffToolStripMenuItem_Click);
            // 
            // CpcSpriteCompilerClear
            // 
            this.CpcSpriteCompilerClear.Name = "CpcSpriteCompilerClear";
            this.CpcSpriteCompilerClear.Size = new System.Drawing.Size(129, 22);
            this.CpcSpriteCompilerClear.Text = "Clear";
            this.CpcSpriteCompilerClear.Click += new System.EventHandler(this.CpcSpriteCompilerClear_Click);
            // 
            // saveASMPaletteToolStripMenuItem
            // 
            this.saveASMPaletteToolStripMenuItem.Name = "saveASMPaletteToolStripMenuItem";
            this.saveASMPaletteToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.saveASMPaletteToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.saveASMPaletteToolStripMenuItem.Text = "Save ASM Palette";
            this.saveASMPaletteToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/z80/platform2.php#LessonP13";
            this.saveASMPaletteToolStripMenuItem.Click += new System.EventHandler(this.saveASMPaletteToolStripMenuItem_Click);
            // 
            // mSXToolStripMenuItem
            // 
            this.mSXToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem1,
            this.mSX2PaletteToClipboardToolStripMenuItem});
            this.mSXToolStripMenuItem.Name = "mSXToolStripMenuItem";
            this.mSXToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.mSXToolStripMenuItem.Text = "MSX";
            // 
            // fileToolStripMenuItem1
            // 
            this.fileToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveMSXASMPaletteToolStripMenuItem,
            this.saveMSXBinaryToolStripMenuItem,
            this.bMPToolStripMenuItem,
            this.rLEToolStripMenuItem,
            this.saveRAWBitmapToolStripMenuItem3,
            this.saveRAWMSX1BitmapToolStripMenuItem,
            this.saveRAWMSX1Raw16x16SpriteToolStripMenuItem,
            this.saveRawVdpTileBitmapToolStripMenuItem,
            this.saveMSX2RawYJKBitmapToolStripMenuItem,
            this.saveMSX2RawYJKABitmapYAEToolStripMenuItem});
            this.fileToolStripMenuItem1.Name = "fileToolStripMenuItem1";
            this.fileToolStripMenuItem1.Size = new System.Drawing.Size(205, 22);
            this.fileToolStripMenuItem1.Text = "File";
            // 
            // saveMSXASMPaletteToolStripMenuItem
            // 
            this.saveMSXASMPaletteToolStripMenuItem.Name = "saveMSXASMPaletteToolStripMenuItem";
            this.saveMSXASMPaletteToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.saveMSXASMPaletteToolStripMenuItem.Size = new System.Drawing.Size(313, 22);
            this.saveMSXASMPaletteToolStripMenuItem.Text = "Save MSX ASM Palette";
            this.saveMSXASMPaletteToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/z80/platform2.php#LessonP15";
            this.saveMSXASMPaletteToolStripMenuItem.Click += new System.EventHandler(this.saveMSXASMPaletteToolStripMenuItem_Click);
            // 
            // saveMSXBinaryToolStripMenuItem
            // 
            this.saveMSXBinaryToolStripMenuItem.Name = "saveMSXBinaryToolStripMenuItem";
            this.saveMSXBinaryToolStripMenuItem.Size = new System.Drawing.Size(313, 22);
            this.saveMSXBinaryToolStripMenuItem.Text = "Save MSX Binary Sprites (Chibiakumas format)";
            this.saveMSXBinaryToolStripMenuItem.Visible = false;
            this.saveMSXBinaryToolStripMenuItem.Click += new System.EventHandler(this.saveMSXBinaryToolStripMenuItem_Click);
            // 
            // bMPToolStripMenuItem
            // 
            this.bMPToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveMSXBitmapToolStripMenuItem1,
            this.saveMSXBitmapWithPaletteToolStripMenuItem1,
            this.saveMSXBitmapSpritesToolStripMenuItem});
            this.bMPToolStripMenuItem.Name = "bMPToolStripMenuItem";
            this.bMPToolStripMenuItem.Size = new System.Drawing.Size(313, 22);
            this.bMPToolStripMenuItem.Text = "BMP";
            this.bMPToolStripMenuItem.Visible = false;
            // 
            // saveMSXBitmapToolStripMenuItem1
            // 
            this.saveMSXBitmapToolStripMenuItem1.Name = "saveMSXBitmapToolStripMenuItem1";
            this.saveMSXBitmapToolStripMenuItem1.Size = new System.Drawing.Size(228, 22);
            this.saveMSXBitmapToolStripMenuItem1.Text = "save MSX bitmap";
            this.saveMSXBitmapToolStripMenuItem1.Click += new System.EventHandler(this.saveMSXBitmapToolStripMenuItem1_Click);
            // 
            // saveMSXBitmapWithPaletteToolStripMenuItem1
            // 
            this.saveMSXBitmapWithPaletteToolStripMenuItem1.Name = "saveMSXBitmapWithPaletteToolStripMenuItem1";
            this.saveMSXBitmapWithPaletteToolStripMenuItem1.Size = new System.Drawing.Size(228, 22);
            this.saveMSXBitmapWithPaletteToolStripMenuItem1.Text = "Save MSX Bitmap With Palette";
            this.saveMSXBitmapWithPaletteToolStripMenuItem1.Click += new System.EventHandler(this.saveMSXBitmapWithPaletteToolStripMenuItem1_Click);
            // 
            // saveMSXBitmapSpritesToolStripMenuItem
            // 
            this.saveMSXBitmapSpritesToolStripMenuItem.Name = "saveMSXBitmapSpritesToolStripMenuItem";
            this.saveMSXBitmapSpritesToolStripMenuItem.Size = new System.Drawing.Size(228, 22);
            this.saveMSXBitmapSpritesToolStripMenuItem.Text = "save MSX Bitmap Sprites";
            this.saveMSXBitmapSpritesToolStripMenuItem.Click += new System.EventHandler(this.saveMSXBitmapSpritesToolStripMenuItem_Click);
            // 
            // rLEToolStripMenuItem
            // 
            this.rLEToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buildRLEASMToolStripMenuItem,
            this.saveMSXRLEToolStripMenuItem,
            this.saveMSXRLEPaletteToolStripMenuItem,
            this.toolStripMenuItem5,
            this.saveMSXRLESpritesToolStripMenuItem});
            this.rLEToolStripMenuItem.Name = "rLEToolStripMenuItem";
            this.rLEToolStripMenuItem.Size = new System.Drawing.Size(313, 22);
            this.rLEToolStripMenuItem.Text = "RLE";
            // 
            // buildRLEASMToolStripMenuItem
            // 
            this.buildRLEASMToolStripMenuItem.Name = "buildRLEASMToolStripMenuItem";
            this.buildRLEASMToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.buildRLEASMToolStripMenuItem.Text = "Build RLE ASM";
            this.buildRLEASMToolStripMenuItem.Visible = false;
            this.buildRLEASMToolStripMenuItem.Click += new System.EventHandler(this.buildRLEASMToolStripMenuItem_Click);
            // 
            // saveMSXRLEToolStripMenuItem
            // 
            this.saveMSXRLEToolStripMenuItem.Name = "saveMSXRLEToolStripMenuItem";
            this.saveMSXRLEToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.saveMSXRLEToolStripMenuItem.Text = "Save MSX RLE";
            this.saveMSXRLEToolStripMenuItem.Click += new System.EventHandler(this.saveMSXRLEToolStripMenuItem_Click);
            // 
            // saveMSXRLEPaletteToolStripMenuItem
            // 
            this.saveMSXRLEPaletteToolStripMenuItem.Name = "saveMSXRLEPaletteToolStripMenuItem";
            this.saveMSXRLEPaletteToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.saveMSXRLEPaletteToolStripMenuItem.Text = "Save MSX RLE with Palette";
            this.saveMSXRLEPaletteToolStripMenuItem.Click += new System.EventHandler(this.saveMSXRLEPaletteToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(209, 6);
            // 
            // saveMSXRLESpritesToolStripMenuItem
            // 
            this.saveMSXRLESpritesToolStripMenuItem.Name = "saveMSXRLESpritesToolStripMenuItem";
            this.saveMSXRLESpritesToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.saveMSXRLESpritesToolStripMenuItem.Text = "Save MSX RLE Sprites";
            this.saveMSXRLESpritesToolStripMenuItem.Click += new System.EventHandler(this.saveMSXRLESpritesToolStripMenuItem_Click);
            // 
            // saveRAWBitmapToolStripMenuItem3
            // 
            this.saveRAWBitmapToolStripMenuItem3.Name = "saveRAWBitmapToolStripMenuItem3";
            this.saveRAWBitmapToolStripMenuItem3.ShortcutKeyDisplayString = "[?]";
            this.saveRAWBitmapToolStripMenuItem3.Size = new System.Drawing.Size(313, 22);
            this.saveRAWBitmapToolStripMenuItem3.Text = "Save MSX2 RAW Bitmap (4/16/256 Color)";
            this.saveRAWBitmapToolStripMenuItem3.ToolTipText = "See: https://www.chibiakumas.com/z80/simplesamples.php#LessonS5";
            this.saveRAWBitmapToolStripMenuItem3.Click += new System.EventHandler(this.saveRAWBitmapToolStripMenuItem3_Click);
            // 
            // saveRAWMSX1BitmapToolStripMenuItem
            // 
            this.saveRAWMSX1BitmapToolStripMenuItem.Name = "saveRAWMSX1BitmapToolStripMenuItem";
            this.saveRAWMSX1BitmapToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.saveRAWMSX1BitmapToolStripMenuItem.Size = new System.Drawing.Size(313, 22);
            this.saveRAWMSX1BitmapToolStripMenuItem.Text = "Save RAW MSX1 Bitmap / 8x8 sprite";
            this.saveRAWMSX1BitmapToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/z80/simplesamples.php#LessonS6";
            this.saveRAWMSX1BitmapToolStripMenuItem.Click += new System.EventHandler(this.saveRAWMSX1BitmapToolStripMenuItem_Click);
            // 
            // saveRAWMSX1Raw16x16SpriteToolStripMenuItem
            // 
            this.saveRAWMSX1Raw16x16SpriteToolStripMenuItem.Name = "saveRAWMSX1Raw16x16SpriteToolStripMenuItem";
            this.saveRAWMSX1Raw16x16SpriteToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.saveRAWMSX1Raw16x16SpriteToolStripMenuItem.Size = new System.Drawing.Size(313, 22);
            this.saveRAWMSX1Raw16x16SpriteToolStripMenuItem.Text = "Save RAW MSX1 16x16 Sprite";
            this.saveRAWMSX1Raw16x16SpriteToolStripMenuItem.ToolTipText = "See: http://www.chibiakumas.com/z80/platform4.php#LessonP31";
            this.saveRAWMSX1Raw16x16SpriteToolStripMenuItem.Click += new System.EventHandler(this.saveRAWMSX1Raw16x16SpriteToolStripMenuItem_Click);
            // 
            // saveRawVdpTileBitmapToolStripMenuItem
            // 
            this.saveRawVdpTileBitmapToolStripMenuItem.Name = "saveRawVdpTileBitmapToolStripMenuItem";
            this.saveRawVdpTileBitmapToolStripMenuItem.Size = new System.Drawing.Size(313, 22);
            this.saveRawVdpTileBitmapToolStripMenuItem.Text = "Save Raw MSX2 VdpTile Bitmap";
            this.saveRawVdpTileBitmapToolStripMenuItem.Click += new System.EventHandler(this.saveRawVdpTileBitmapToolStripMenuItem_Click);
            // 
            // saveMSX2RawYJKBitmapToolStripMenuItem
            // 
            this.saveMSX2RawYJKBitmapToolStripMenuItem.Name = "saveMSX2RawYJKBitmapToolStripMenuItem";
            this.saveMSX2RawYJKBitmapToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.saveMSX2RawYJKBitmapToolStripMenuItem.Size = new System.Drawing.Size(313, 22);
            this.saveMSX2RawYJKBitmapToolStripMenuItem.Text = "Save MSX2+ Raw YJK Bitmap";
            this.saveMSX2RawYJKBitmapToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/z80/platform6.php#LessonP50";
            this.saveMSX2RawYJKBitmapToolStripMenuItem.Click += new System.EventHandler(this.saveMSX2RawYJKBitmapToolStripMenuItem_Click);
            // 
            // saveMSX2RawYJKABitmapYAEToolStripMenuItem
            // 
            this.saveMSX2RawYJKABitmapYAEToolStripMenuItem.Name = "saveMSX2RawYJKABitmapYAEToolStripMenuItem";
            this.saveMSX2RawYJKABitmapYAEToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.saveMSX2RawYJKABitmapYAEToolStripMenuItem.Size = new System.Drawing.Size(313, 22);
            this.saveMSX2RawYJKABitmapYAEToolStripMenuItem.Text = "Save MSX2+ Raw YJKA Bitmap (YAE)";
            this.saveMSX2RawYJKABitmapYAEToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/z80/platform6.php#LessonP50";
            this.saveMSX2RawYJKABitmapYAEToolStripMenuItem.Click += new System.EventHandler(this.saveMSX2RawYJKABitmapYAEToolStripMenuItem_Click);
            // 
            // mSX2PaletteToClipboardToolStripMenuItem
            // 
            this.mSX2PaletteToClipboardToolStripMenuItem.Name = "mSX2PaletteToClipboardToolStripMenuItem";
            this.mSX2PaletteToClipboardToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.mSX2PaletteToClipboardToolStripMenuItem.Text = "MSX2 Palette to Clipboard";
            this.mSX2PaletteToClipboardToolStripMenuItem.Click += new System.EventHandler(this.mSX2PaletteToClipboardToolStripMenuItem_Click);
            // 
            // zXToolStripMenuItem
            // 
            this.zXToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.toolsToolStripMenuItem1,
            this.spriteCompilerToolStripMenuItem2,
            this.pasteZXToolStripMenuItem});
            this.zXToolStripMenuItem.Name = "zXToolStripMenuItem";
            this.zXToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.zXToolStripMenuItem.Text = "ZX Spectrum";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadSpectrumScreenToolStripMenuItem,
            this.saveSpectrumBinaryToolStripMenuItem1,
            this.saveSpectrumTilesToolStripMenuItem,
            this.saveSpectrumFontToolStripMenuItem,
            this.saveRaw8x8TilemapToolStripMenuItem,
            this.saveSpectrumScreenToolStripMenuItem,
            this.saveRawBitmapToolStripMenuItem4,
            this.rLEASMToolStripMenuItem1,
            this.rLEASMCOLORToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // loadSpectrumScreenToolStripMenuItem
            // 
            this.loadSpectrumScreenToolStripMenuItem.Name = "loadSpectrumScreenToolStripMenuItem";
            this.loadSpectrumScreenToolStripMenuItem.Size = new System.Drawing.Size(338, 22);
            this.loadSpectrumScreenToolStripMenuItem.Text = "Load Spectrum Screen";
            this.loadSpectrumScreenToolStripMenuItem.Click += new System.EventHandler(this.loadSpectrumScreenToolStripMenuItem_Click);
            // 
            // saveSpectrumBinaryToolStripMenuItem1
            // 
            this.saveSpectrumBinaryToolStripMenuItem1.Name = "saveSpectrumBinaryToolStripMenuItem1";
            this.saveSpectrumBinaryToolStripMenuItem1.Size = new System.Drawing.Size(338, 22);
            this.saveSpectrumBinaryToolStripMenuItem1.Text = "Save Spectrum Binary Sprites (Chibiakumas format)";
            this.saveSpectrumBinaryToolStripMenuItem1.Click += new System.EventHandler(this.saveSpectrumBinaryToolStripMenuItem1_Click);
            // 
            // saveSpectrumTilesToolStripMenuItem
            // 
            this.saveSpectrumTilesToolStripMenuItem.Name = "saveSpectrumTilesToolStripMenuItem";
            this.saveSpectrumTilesToolStripMenuItem.Size = new System.Drawing.Size(338, 22);
            this.saveSpectrumTilesToolStripMenuItem.Text = "Save Spectrum Tiles";
            this.saveSpectrumTilesToolStripMenuItem.Click += new System.EventHandler(this.saveSpectrumTilesToolStripMenuItem_Click);
            // 
            // saveSpectrumFontToolStripMenuItem
            // 
            this.saveSpectrumFontToolStripMenuItem.Name = "saveSpectrumFontToolStripMenuItem";
            this.saveSpectrumFontToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.saveSpectrumFontToolStripMenuItem.Size = new System.Drawing.Size(338, 22);
            this.saveSpectrumFontToolStripMenuItem.Text = "Save 2 Bit Spectrum Font";
            this.saveSpectrumFontToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/z80/multiplatform.php#LessonM7";
            this.saveSpectrumFontToolStripMenuItem.Click += new System.EventHandler(this.saveSpectrumFontToolStripMenuItem_Click);
            // 
            // saveRaw8x8TilemapToolStripMenuItem
            // 
            this.saveRaw8x8TilemapToolStripMenuItem.Name = "saveRaw8x8TilemapToolStripMenuItem";
            this.saveRaw8x8TilemapToolStripMenuItem.Size = new System.Drawing.Size(338, 22);
            this.saveRaw8x8TilemapToolStripMenuItem.Text = "Save Raw 8x8 Tilemap";
            this.saveRaw8x8TilemapToolStripMenuItem.Click += new System.EventHandler(this.saveRaw8x8TilemapToolStripMenuItem_Click);
            // 
            // saveSpectrumScreenToolStripMenuItem
            // 
            this.saveSpectrumScreenToolStripMenuItem.Name = "saveSpectrumScreenToolStripMenuItem";
            this.saveSpectrumScreenToolStripMenuItem.Size = new System.Drawing.Size(338, 22);
            this.saveSpectrumScreenToolStripMenuItem.Text = "Save Spectrum Screen";
            this.saveSpectrumScreenToolStripMenuItem.Click += new System.EventHandler(this.saveSpectrumScreenToolStripMenuItem_Click);
            // 
            // saveRawBitmapToolStripMenuItem4
            // 
            this.saveRawBitmapToolStripMenuItem4.Name = "saveRawBitmapToolStripMenuItem4";
            this.saveRawBitmapToolStripMenuItem4.ShortcutKeyDisplayString = "[?]";
            this.saveRawBitmapToolStripMenuItem4.Size = new System.Drawing.Size(338, 22);
            this.saveRawBitmapToolStripMenuItem4.Text = "Save Raw Bitmap";
            this.saveRawBitmapToolStripMenuItem4.ToolTipText = "See: https://www.chibiakumas.com/z80/simplesamples.php#LessonS2";
            this.saveRawBitmapToolStripMenuItem4.Click += new System.EventHandler(this.saveRawBitmapToolStripMenuItem4_Click);
            // 
            // rLEASMToolStripMenuItem1
            // 
            this.rLEASMToolStripMenuItem1.Name = "rLEASMToolStripMenuItem1";
            this.rLEASMToolStripMenuItem1.Size = new System.Drawing.Size(338, 22);
            this.rLEASMToolStripMenuItem1.Text = "RLE ASM";
            this.rLEASMToolStripMenuItem1.Visible = false;
            // 
            // rLEASMCOLORToolStripMenuItem
            // 
            this.rLEASMCOLORToolStripMenuItem.Name = "rLEASMCOLORToolStripMenuItem";
            this.rLEASMCOLORToolStripMenuItem.Size = new System.Drawing.Size(338, 22);
            this.rLEASMCOLORToolStripMenuItem.Text = "RLE ASM COLOR";
            this.rLEASMCOLORToolStripMenuItem.Click += new System.EventHandler(this.rLEASMCOLORToolStripMenuItem_Click);
            // 
            // toolsToolStripMenuItem1
            // 
            this.toolsToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fourColor2ToolStripMenuItem,
            this.invertZXToolStripMenuItem1,
            this.halfSizeFontToolStripMenuItem});
            this.toolsToolStripMenuItem1.Name = "toolsToolStripMenuItem1";
            this.toolsToolStripMenuItem1.Size = new System.Drawing.Size(145, 22);
            this.toolsToolStripMenuItem1.Text = "Tools";
            // 
            // fourColor2ToolStripMenuItem
            // 
            this.fourColor2ToolStripMenuItem.Name = "fourColor2ToolStripMenuItem";
            this.fourColor2ToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.fourColor2ToolStripMenuItem.Text = "4 Color->2 ";
            this.fourColor2ToolStripMenuItem.Click += new System.EventHandler(this.fourColor2ToolStripMenuItem_Click);
            // 
            // invertZXToolStripMenuItem1
            // 
            this.invertZXToolStripMenuItem1.Name = "invertZXToolStripMenuItem1";
            this.invertZXToolStripMenuItem1.Size = new System.Drawing.Size(135, 22);
            this.invertZXToolStripMenuItem1.Text = "Invert ZX";
            this.invertZXToolStripMenuItem1.Click += new System.EventHandler(this.invertZXToolStripMenuItem1_Click);
            // 
            // halfSizeFontToolStripMenuItem
            // 
            this.halfSizeFontToolStripMenuItem.Name = "halfSizeFontToolStripMenuItem";
            this.halfSizeFontToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.halfSizeFontToolStripMenuItem.Text = "HalfSizeFont";
            this.halfSizeFontToolStripMenuItem.Click += new System.EventHandler(this.halfSizeFontToolStripMenuItem_Click);
            // 
            // spriteCompilerToolStripMenuItem2
            // 
            this.spriteCompilerToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addOneToolStripMenuItem2});
            this.spriteCompilerToolStripMenuItem2.Name = "spriteCompilerToolStripMenuItem2";
            this.spriteCompilerToolStripMenuItem2.Size = new System.Drawing.Size(145, 22);
            this.spriteCompilerToolStripMenuItem2.Text = "SpriteCompiler";
            // 
            // addOneToolStripMenuItem2
            // 
            this.addOneToolStripMenuItem2.Name = "addOneToolStripMenuItem2";
            this.addOneToolStripMenuItem2.Size = new System.Drawing.Size(110, 22);
            this.addOneToolStripMenuItem2.Text = "AddOne";
            this.addOneToolStripMenuItem2.Click += new System.EventHandler(this.addOneToolStripMenuItem2_Click);
            // 
            // pasteZXToolStripMenuItem
            // 
            this.pasteZXToolStripMenuItem.Name = "pasteZXToolStripMenuItem";
            this.pasteZXToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
            this.pasteZXToolStripMenuItem.Text = "Paste ZX";
            this.pasteZXToolStripMenuItem.Click += new System.EventHandler(this.pasteZXToolStripMenuItem_Click);
            // 
            // gBToolStripMenuItem
            // 
            this.gBToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem7});
            this.gBToolStripMenuItem.Name = "gBToolStripMenuItem";
            this.gBToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.gBToolStripMenuItem.Text = "GameBoy / GBC";
            // 
            // fileToolStripMenuItem7
            // 
            this.fileToolStripMenuItem7.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmapToolStripMenuItem6});
            this.fileToolStripMenuItem7.Name = "fileToolStripMenuItem7";
            this.fileToolStripMenuItem7.Size = new System.Drawing.Size(89, 22);
            this.fileToolStripMenuItem7.Text = "File";
            // 
            // saveRawBitmapToolStripMenuItem6
            // 
            this.saveRawBitmapToolStripMenuItem6.Name = "saveRawBitmapToolStripMenuItem6";
            this.saveRawBitmapToolStripMenuItem6.ShortcutKeyDisplayString = "[?]";
            this.saveRawBitmapToolStripMenuItem6.Size = new System.Drawing.Size(179, 22);
            this.saveRawBitmapToolStripMenuItem6.Text = "Save Raw Bitmap";
            this.saveRawBitmapToolStripMenuItem6.ToolTipText = "See: https://www.chibiakumas.com/z80/simplesamples.php#LessonS9";
            this.saveRawBitmapToolStripMenuItem6.Click += new System.EventHandler(this.saveRawBitmapToolStripMenuItem6_Click);
            // 
            // tIToolStripMenuItem
            // 
            this.tIToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveTi83BitmapBWToolStripMenuItem,
            this.saveTi8416bitToolStripMenuItem,
            this.saveTi84Bitmap4bppToolStripMenuItem,
            this.paletteToClipboard15bitBGRToolStripMenuItem});
            this.tIToolStripMenuItem.Name = "tIToolStripMenuItem";
            this.tIToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.tIToolStripMenuItem.Text = "TI-83 / TI-84 CE";
            // 
            // saveTi83BitmapBWToolStripMenuItem
            // 
            this.saveTi83BitmapBWToolStripMenuItem.Name = "saveTi83BitmapBWToolStripMenuItem";
            this.saveTi83BitmapBWToolStripMenuItem.Size = new System.Drawing.Size(240, 22);
            this.saveTi83BitmapBWToolStripMenuItem.Text = "Save Ti-83 Bitmap (BW)";
            this.saveTi83BitmapBWToolStripMenuItem.Click += new System.EventHandler(this.saveTi83BitmapBWToolStripMenuItem_Click);
            // 
            // saveTi8416bitToolStripMenuItem
            // 
            this.saveTi8416bitToolStripMenuItem.Name = "saveTi8416bitToolStripMenuItem";
            this.saveTi8416bitToolStripMenuItem.Size = new System.Drawing.Size(240, 22);
            this.saveTi8416bitToolStripMenuItem.Text = "Save Ti-84 Bitmap (15bit BGR)";
            this.saveTi8416bitToolStripMenuItem.Click += new System.EventHandler(this.saveTi8416bitToolStripMenuItem_Click);
            // 
            // saveTi84Bitmap4bppToolStripMenuItem
            // 
            this.saveTi84Bitmap4bppToolStripMenuItem.Name = "saveTi84Bitmap4bppToolStripMenuItem";
            this.saveTi84Bitmap4bppToolStripMenuItem.Size = new System.Drawing.Size(240, 22);
            this.saveTi84Bitmap4bppToolStripMenuItem.Text = "Save Ti-84 Bitmap (4bpp)";
            this.saveTi84Bitmap4bppToolStripMenuItem.Click += new System.EventHandler(this.saveTi84Bitmap4bppToolStripMenuItem_Click);
            // 
            // paletteToClipboard15bitBGRToolStripMenuItem
            // 
            this.paletteToClipboard15bitBGRToolStripMenuItem.Name = "paletteToClipboard15bitBGRToolStripMenuItem";
            this.paletteToClipboard15bitBGRToolStripMenuItem.Size = new System.Drawing.Size(240, 22);
            this.paletteToClipboard15bitBGRToolStripMenuItem.Text = "Palette To Clipboard (15bit BGR)";
            this.paletteToClipboard15bitBGRToolStripMenuItem.Click += new System.EventHandler(this.paletteToClipboard15bitBGRToolStripMenuItem_Click);
            // 
            // sAMToolStripMenuItem
            // 
            this.sAMToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem5,
            this.paletteToClipboardToolStripMenuItem5});
            this.sAMToolStripMenuItem.Name = "sAMToolStripMenuItem";
            this.sAMToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.sAMToolStripMenuItem.Text = "Sam Coupe";
            // 
            // fileToolStripMenuItem5
            // 
            this.fileToolStripMenuItem5.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmapToolStripMenuItem2,
            this.saveRLEToolStripMenuItem,
            this.saveBinarySpritesToolStripMenuItem,
            this.saveRaw8x8TilesToolStripMenuItem1});
            this.fileToolStripMenuItem5.Name = "fileToolStripMenuItem5";
            this.fileToolStripMenuItem5.Size = new System.Drawing.Size(175, 22);
            this.fileToolStripMenuItem5.Text = "File";
            // 
            // saveRawBitmapToolStripMenuItem2
            // 
            this.saveRawBitmapToolStripMenuItem2.Name = "saveRawBitmapToolStripMenuItem2";
            this.saveRawBitmapToolStripMenuItem2.ShortcutKeyDisplayString = "[?]";
            this.saveRawBitmapToolStripMenuItem2.Size = new System.Drawing.Size(288, 22);
            this.saveRawBitmapToolStripMenuItem2.Text = "Save Raw Bitmap";
            this.saveRawBitmapToolStripMenuItem2.ToolTipText = "See: https://www.chibiakumas.com/z80/simplesamples.php#LessonS4";
            this.saveRawBitmapToolStripMenuItem2.Click += new System.EventHandler(this.saveRawBitmapToolStripMenuItem2_Click);
            // 
            // saveRLEToolStripMenuItem
            // 
            this.saveRLEToolStripMenuItem.Name = "saveRLEToolStripMenuItem";
            this.saveRLEToolStripMenuItem.Size = new System.Drawing.Size(288, 22);
            this.saveRLEToolStripMenuItem.Text = "Save RLE ASM";
            this.saveRLEToolStripMenuItem.Click += new System.EventHandler(this.saveRLEToolStripMenuItem_Click);
            // 
            // saveBinarySpritesToolStripMenuItem
            // 
            this.saveBinarySpritesToolStripMenuItem.Name = "saveBinarySpritesToolStripMenuItem";
            this.saveBinarySpritesToolStripMenuItem.Size = new System.Drawing.Size(288, 22);
            this.saveBinarySpritesToolStripMenuItem.Text = "Save Binary Sprites (ChibiAkumas format)";
            this.saveBinarySpritesToolStripMenuItem.Click += new System.EventHandler(this.saveBinarySpritesToolStripMenuItem_Click);
            // 
            // saveRaw8x8TilesToolStripMenuItem1
            // 
            this.saveRaw8x8TilesToolStripMenuItem1.Name = "saveRaw8x8TilesToolStripMenuItem1";
            this.saveRaw8x8TilesToolStripMenuItem1.Size = new System.Drawing.Size(288, 22);
            this.saveRaw8x8TilesToolStripMenuItem1.Text = "Save Raw 8x8 Tiles";
            this.saveRaw8x8TilesToolStripMenuItem1.Click += new System.EventHandler(this.saveRaw8x8TilesToolStripMenuItem1_Click);
            // 
            // paletteToClipboardToolStripMenuItem5
            // 
            this.paletteToClipboardToolStripMenuItem5.Name = "paletteToClipboardToolStripMenuItem5";
            this.paletteToClipboardToolStripMenuItem5.Size = new System.Drawing.Size(175, 22);
            this.paletteToClipboardToolStripMenuItem5.Text = "Palette To Clipboard";
            this.paletteToClipboardToolStripMenuItem5.Click += new System.EventHandler(this.paletteToClipboardToolStripMenuItem5_Click);
            // 
            // eNTToolStripMenuItem
            // 
            this.eNTToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem4});
            this.eNTToolStripMenuItem.Name = "eNTToolStripMenuItem";
            this.eNTToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.eNTToolStripMenuItem.Text = "Elan Enterprise";
            // 
            // fileToolStripMenuItem4
            // 
            this.fileToolStripMenuItem4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRAWBitmapToolStripMenuItem,
            this.rLEASMToolStripMenuItem2});
            this.fileToolStripMenuItem4.Name = "fileToolStripMenuItem4";
            this.fileToolStripMenuItem4.Size = new System.Drawing.Size(89, 22);
            this.fileToolStripMenuItem4.Text = "File";
            // 
            // saveRAWBitmapToolStripMenuItem
            // 
            this.saveRAWBitmapToolStripMenuItem.Name = "saveRAWBitmapToolStripMenuItem";
            this.saveRAWBitmapToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.saveRAWBitmapToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.saveRAWBitmapToolStripMenuItem.Text = "Save RAW Bitmap (4/16/256 Color)";
            this.saveRAWBitmapToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/z80/simplesamples.php#LessonS3";
            this.saveRAWBitmapToolStripMenuItem.Click += new System.EventHandler(this.saveRAWBitmapToolStripMenuItem_Click);
            // 
            // rLEASMToolStripMenuItem2
            // 
            this.rLEASMToolStripMenuItem2.Name = "rLEASMToolStripMenuItem2";
            this.rLEASMToolStripMenuItem2.Size = new System.Drawing.Size(273, 22);
            this.rLEASMToolStripMenuItem2.Text = "RLE ASM";
            this.rLEASMToolStripMenuItem2.Click += new System.EventHandler(this.rLEASMToolStripMenuItem2_Click);
            // 
            // sMSToolStripMenuItem
            // 
            this.sMSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem6,
            this.sMSPaletteToolStripMenuItem,
            this.gGPaletteToolStripMenuItem});
            this.sMSToolStripMenuItem.Name = "sMSToolStripMenuItem";
            this.sMSToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.sMSToolStripMenuItem.Text = "Master System / GameGear";
            // 
            // fileToolStripMenuItem6
            // 
            this.fileToolStripMenuItem6.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmapToolStripMenuItem5,
            this.saveHalfHeightRawBitmap8x4ToolStripMenuItem});
            this.fileToolStripMenuItem6.Name = "fileToolStripMenuItem6";
            this.fileToolStripMenuItem6.Size = new System.Drawing.Size(152, 22);
            this.fileToolStripMenuItem6.Text = "File";
            // 
            // saveRawBitmapToolStripMenuItem5
            // 
            this.saveRawBitmapToolStripMenuItem5.Name = "saveRawBitmapToolStripMenuItem5";
            this.saveRawBitmapToolStripMenuItem5.ShortcutKeyDisplayString = "[?]";
            this.saveRawBitmapToolStripMenuItem5.Size = new System.Drawing.Size(241, 22);
            this.saveRawBitmapToolStripMenuItem5.Text = "Save Raw Bitmap";
            this.saveRawBitmapToolStripMenuItem5.ToolTipText = "See: https://www.chibiakumas.com/z80/simplesamples.php#LessonS10";
            this.saveRawBitmapToolStripMenuItem5.Click += new System.EventHandler(this.saveRawBitmapToolStripMenuItem5_Click);
            // 
            // sMSPaletteToolStripMenuItem
            // 
            this.sMSPaletteToolStripMenuItem.Name = "sMSPaletteToolStripMenuItem";
            this.sMSPaletteToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.sMSPaletteToolStripMenuItem.Text = "SMS Palette";
            this.sMSPaletteToolStripMenuItem.Click += new System.EventHandler(this.sMSPaletteToolStripMenuItem_Click);
            // 
            // gGPaletteToolStripMenuItem
            // 
            this.gGPaletteToolStripMenuItem.Name = "gGPaletteToolStripMenuItem";
            this.gGPaletteToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.gGPaletteToolStripMenuItem.Text = "GG Palette";
            this.gGPaletteToolStripMenuItem.Click += new System.EventHandler(this.gGPaletteToolStripMenuItem_Click);
            // 
            // camputersLynxToolStripMenuItem
            // 
            this.camputersLynxToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmapToolStripMenuItem17,
            this.saveRaw8x8TileBitmapToolStripMenuItem});
            this.camputersLynxToolStripMenuItem.Name = "camputersLynxToolStripMenuItem";
            this.camputersLynxToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.camputersLynxToolStripMenuItem.Text = "Camputers Lynx";
            // 
            // saveRawBitmapToolStripMenuItem17
            // 
            this.saveRawBitmapToolStripMenuItem17.Name = "saveRawBitmapToolStripMenuItem17";
            this.saveRawBitmapToolStripMenuItem17.ShortcutKeyDisplayString = "[?]";
            this.saveRawBitmapToolStripMenuItem17.Size = new System.Drawing.Size(206, 22);
            this.saveRawBitmapToolStripMenuItem17.Text = "Save Raw Bitmap";
            this.saveRawBitmapToolStripMenuItem17.ToolTipText = "See: https://www.chibiakumas.com/z80/simplesamples.php#LessonS7";
            this.saveRawBitmapToolStripMenuItem17.Click += new System.EventHandler(this.saveRawBitmapToolStripMenuItem17_Click);
            // 
            // saveRaw8x8TileBitmapToolStripMenuItem
            // 
            this.saveRaw8x8TileBitmapToolStripMenuItem.Name = "saveRaw8x8TileBitmapToolStripMenuItem";
            this.saveRaw8x8TileBitmapToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.saveRaw8x8TileBitmapToolStripMenuItem.Text = "Save Raw 8x8 Tile Bitmap";
            this.saveRaw8x8TileBitmapToolStripMenuItem.Click += new System.EventHandler(this.saveRaw8x8TileBitmapToolStripMenuItem_Click);
            // 
            // specNEXTToolStripMenuItem
            // 
            this.specNEXTToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveULAScreenToolStripMenuItem,
            this.saveULAScreenPaletteOnlyToolStripMenuItem,
            this.saveNEXTPaletteToolStripMenuItem,
            this.saveNEXT9BitPaletteToolStripMenuItem,
            this.saveLoResLayerRadasjimianRawBitmap128x96ToolStripMenuItem,
            this.save8bppRawBitmapToolStripMenuItem1,
            this.save4bppRawBitmapToolStripMenuItem,
            this.save2bppRawBitmapToolStripMenuItem,
            this.save2bpp8x8TilesToolStripMenuItem,
            this.save4bpp8x8TilesToolStripMenuItem1,
            this.save8bpp8x8TilesToolStripMenuItem1,
            this.save4bppSpriteToolStripMenuItem,
            this.save8bppSpriteToolStripMenuItem,
            this.save2bpp8x8TilesHalfHeightToolStripMenuItem});
            this.specNEXTToolStripMenuItem.Name = "specNEXTToolStripMenuItem";
            this.specNEXTToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.specNEXTToolStripMenuItem.Text = "SpecNEXT";
            // 
            // saveULAScreenToolStripMenuItem
            // 
            this.saveULAScreenToolStripMenuItem.Name = "saveULAScreenToolStripMenuItem";
            this.saveULAScreenToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.saveULAScreenToolStripMenuItem.Size = new System.Drawing.Size(363, 22);
            this.saveULAScreenToolStripMenuItem.Text = "Save ULA Next Screen";
            this.saveULAScreenToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/z80/platform5.php#LessonP43";
            this.saveULAScreenToolStripMenuItem.Click += new System.EventHandler(this.saveULAScreenToolStripMenuItem_Click);
            // 
            // saveULAScreenPaletteOnlyToolStripMenuItem
            // 
            this.saveULAScreenPaletteOnlyToolStripMenuItem.Name = "saveULAScreenPaletteOnlyToolStripMenuItem";
            this.saveULAScreenPaletteOnlyToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.saveULAScreenPaletteOnlyToolStripMenuItem.Size = new System.Drawing.Size(363, 22);
            this.saveULAScreenPaletteOnlyToolStripMenuItem.Text = "Save ULA Next Screen Colors Only";
            this.saveULAScreenPaletteOnlyToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/z80/platform5.php#LessonP43";
            this.saveULAScreenPaletteOnlyToolStripMenuItem.Click += new System.EventHandler(this.saveULAScreenPaletteOnlyToolStripMenuItem_Click);
            // 
            // saveNEXTPaletteToolStripMenuItem
            // 
            this.saveNEXTPaletteToolStripMenuItem.Name = "saveNEXTPaletteToolStripMenuItem";
            this.saveNEXTPaletteToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.saveNEXTPaletteToolStripMenuItem.Size = new System.Drawing.Size(363, 22);
            this.saveNEXTPaletteToolStripMenuItem.Text = "Save NEXT palette";
            this.saveNEXTPaletteToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/z80/SpectrumNext.php";
            this.saveNEXTPaletteToolStripMenuItem.Click += new System.EventHandler(this.saveNEXTPaletteToolStripMenuItem_Click);
            // 
            // saveNEXT9BitPaletteToolStripMenuItem
            // 
            this.saveNEXT9BitPaletteToolStripMenuItem.Name = "saveNEXT9BitPaletteToolStripMenuItem";
            this.saveNEXT9BitPaletteToolStripMenuItem.Size = new System.Drawing.Size(363, 22);
            this.saveNEXT9BitPaletteToolStripMenuItem.Text = "Save NEXT 9 bit palette";
            this.saveNEXT9BitPaletteToolStripMenuItem.Click += new System.EventHandler(this.saveNEXT9BitPaletteToolStripMenuItem_Click);
            // 
            // saveLoResLayerRadasjimianRawBitmap128x96ToolStripMenuItem
            // 
            this.saveLoResLayerRadasjimianRawBitmap128x96ToolStripMenuItem.Name = "saveLoResLayerRadasjimianRawBitmap128x96ToolStripMenuItem";
            this.saveLoResLayerRadasjimianRawBitmap128x96ToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.saveLoResLayerRadasjimianRawBitmap128x96ToolStripMenuItem.Size = new System.Drawing.Size(363, 22);
            this.saveLoResLayerRadasjimianRawBitmap128x96ToolStripMenuItem.Text = "Save LoRes Layer/Radasjimian Raw Bitmap (128x96)";
            this.saveLoResLayerRadasjimianRawBitmap128x96ToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/z80/platform5.php#LessonP44";
            this.saveLoResLayerRadasjimianRawBitmap128x96ToolStripMenuItem.Click += new System.EventHandler(this.saveLoResLayerRadasjimianRawBitmap128x96ToolStripMenuItem_Click);
            // 
            // save8bppRawBitmapToolStripMenuItem1
            // 
            this.save8bppRawBitmapToolStripMenuItem1.Name = "save8bppRawBitmapToolStripMenuItem1";
            this.save8bppRawBitmapToolStripMenuItem1.ShortcutKeyDisplayString = "";
            this.save8bppRawBitmapToolStripMenuItem1.Size = new System.Drawing.Size(363, 22);
            this.save8bppRawBitmapToolStripMenuItem1.Text = "Save 8bpp Raw Bitmap";
            this.save8bppRawBitmapToolStripMenuItem1.Click += new System.EventHandler(this.save8bppRawBitmapToolStripMenuItem1_Click);
            // 
            // save4bppRawBitmapToolStripMenuItem
            // 
            this.save4bppRawBitmapToolStripMenuItem.Name = "save4bppRawBitmapToolStripMenuItem";
            this.save4bppRawBitmapToolStripMenuItem.ShortcutKeyDisplayString = "";
            this.save4bppRawBitmapToolStripMenuItem.Size = new System.Drawing.Size(363, 22);
            this.save4bppRawBitmapToolStripMenuItem.Text = "Save 4bpp Raw Bitmap";
            this.save4bppRawBitmapToolStripMenuItem.Click += new System.EventHandler(this.save4bppRawBitmapToolStripMenuItem_Click);
            // 
            // save2bppRawBitmapToolStripMenuItem
            // 
            this.save2bppRawBitmapToolStripMenuItem.Name = "save2bppRawBitmapToolStripMenuItem";
            this.save2bppRawBitmapToolStripMenuItem.Size = new System.Drawing.Size(363, 22);
            this.save2bppRawBitmapToolStripMenuItem.Text = "Save 2bpp Raw Bitmap";
            this.save2bppRawBitmapToolStripMenuItem.Click += new System.EventHandler(this.save2bppRawBitmapToolStripMenuItem_Click);
            // 
            // save2bpp8x8TilesToolStripMenuItem
            // 
            this.save2bpp8x8TilesToolStripMenuItem.Name = "save2bpp8x8TilesToolStripMenuItem";
            this.save2bpp8x8TilesToolStripMenuItem.Size = new System.Drawing.Size(363, 22);
            this.save2bpp8x8TilesToolStripMenuItem.Text = "Save 2bpp 8x8 Tiles";
            this.save2bpp8x8TilesToolStripMenuItem.Click += new System.EventHandler(this.save2bpp8x8TilesToolStripMenuItem_Click);
            // 
            // save4bpp8x8TilesToolStripMenuItem1
            // 
            this.save4bpp8x8TilesToolStripMenuItem1.Name = "save4bpp8x8TilesToolStripMenuItem1";
            this.save4bpp8x8TilesToolStripMenuItem1.ShortcutKeyDisplayString = "[?]";
            this.save4bpp8x8TilesToolStripMenuItem1.Size = new System.Drawing.Size(363, 22);
            this.save4bpp8x8TilesToolStripMenuItem1.Text = "Save 4bpp 8x8 Tiles";
            this.save4bpp8x8TilesToolStripMenuItem1.ToolTipText = "See: https://www.chibiakumas.com/z80/platform5.php#LessonP46";
            this.save4bpp8x8TilesToolStripMenuItem1.Click += new System.EventHandler(this.save4bpp8x8TilesToolStripMenuItem1_Click);
            // 
            // save8bpp8x8TilesToolStripMenuItem1
            // 
            this.save8bpp8x8TilesToolStripMenuItem1.Name = "save8bpp8x8TilesToolStripMenuItem1";
            this.save8bpp8x8TilesToolStripMenuItem1.Size = new System.Drawing.Size(363, 22);
            this.save8bpp8x8TilesToolStripMenuItem1.Text = "Save 8bpp 8x8 Tiles";
            this.save8bpp8x8TilesToolStripMenuItem1.Click += new System.EventHandler(this.save8bpp8x8TilesToolStripMenuItem1_Click);
            // 
            // save4bppSpriteToolStripMenuItem
            // 
            this.save4bppSpriteToolStripMenuItem.Name = "save4bppSpriteToolStripMenuItem";
            this.save4bppSpriteToolStripMenuItem.Size = new System.Drawing.Size(363, 22);
            this.save4bppSpriteToolStripMenuItem.Text = "Save 4bpp Sprite";
            this.save4bppSpriteToolStripMenuItem.Click += new System.EventHandler(this.save4bppSpriteToolStripMenuItem_Click);
            // 
            // save8bppSpriteToolStripMenuItem
            // 
            this.save8bppSpriteToolStripMenuItem.Name = "save8bppSpriteToolStripMenuItem";
            this.save8bppSpriteToolStripMenuItem.Size = new System.Drawing.Size(363, 22);
            this.save8bppSpriteToolStripMenuItem.Text = "Save 8bpp Sprite";
            this.save8bppSpriteToolStripMenuItem.Click += new System.EventHandler(this.save8bppSpriteToolStripMenuItem_Click);
            // 
            // save2bpp8x8TilesHalfHeightToolStripMenuItem
            // 
            this.save2bpp8x8TilesHalfHeightToolStripMenuItem.Name = "save2bpp8x8TilesHalfHeightToolStripMenuItem";
            this.save2bpp8x8TilesHalfHeightToolStripMenuItem.Size = new System.Drawing.Size(363, 22);
            this.save2bpp8x8TilesHalfHeightToolStripMenuItem.Text = "Save 2bpp 8x4 Tiles HalfHeight";
            this.save2bpp8x8TilesHalfHeightToolStripMenuItem.Click += new System.EventHandler(this.save2bpp8x8TilesHalfHeightToolStripMenuItem_Click);
            // 
            // paletteToClipboardToolStripMenuItem
            // 
            this.paletteToClipboardToolStripMenuItem.Name = "paletteToClipboardToolStripMenuItem";
            this.paletteToClipboardToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.paletteToClipboardToolStripMenuItem.Text = "Palette To Clipboard";
            this.paletteToClipboardToolStripMenuItem.Click += new System.EventHandler(this.paletteToClipboardToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.atari5200800ToolStripMenuItem,
            this.atariLynxToolStripMenuItem,
            this.aToolStripMenuItem,
            this.bBCToolStripMenuItem,
            this.c64ToolStripMenuItem,
            this.nESFamicomToolStripMenuItem,
            this.pCEngineToolStripMenuItem,
            this.superNintendoSFCToolStripMenuItem,
            this.vic20ToolStripMenuItem,
            this.pETToolStripMenuItem,
            this.x16ToolStripMenuItem,
            this.paletteToClipboardToolStripMenuItem1});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(61, 20);
            this.toolStripMenuItem2.Text = "* 6502 *";
            // 
            // atari5200800ToolStripMenuItem
            // 
            this.atari5200800ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmap2ColorToolStripMenuItem1,
            this.saveRawBitmap4ColorToolStripMenuItem1});
            this.atari5200800ToolStripMenuItem.Name = "atari5200800ToolStripMenuItem";
            this.atari5200800ToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.atari5200800ToolStripMenuItem.Text = "Atari 5200/800";
            // 
            // saveRawBitmap2ColorToolStripMenuItem1
            // 
            this.saveRawBitmap2ColorToolStripMenuItem1.Name = "saveRawBitmap2ColorToolStripMenuItem1";
            this.saveRawBitmap2ColorToolStripMenuItem1.ShortcutKeyDisplayString = "[?]";
            this.saveRawBitmap2ColorToolStripMenuItem1.Size = new System.Drawing.Size(228, 22);
            this.saveRawBitmap2ColorToolStripMenuItem1.Text = "Save Raw Bitmap (2 Color)";
            this.saveRawBitmap2ColorToolStripMenuItem1.ToolTipText = "See: https://www.chibiakumas.com/6502/simplesamples.php#LessonS4";
            this.saveRawBitmap2ColorToolStripMenuItem1.Click += new System.EventHandler(this.saveRawBitmap2ColorToolStripMenuItem1_Click);
            // 
            // saveRawBitmap4ColorToolStripMenuItem1
            // 
            this.saveRawBitmap4ColorToolStripMenuItem1.Name = "saveRawBitmap4ColorToolStripMenuItem1";
            this.saveRawBitmap4ColorToolStripMenuItem1.ShortcutKeyDisplayString = "[?]";
            this.saveRawBitmap4ColorToolStripMenuItem1.Size = new System.Drawing.Size(228, 22);
            this.saveRawBitmap4ColorToolStripMenuItem1.Text = "Save Raw Bitmap (4 Color)";
            this.saveRawBitmap4ColorToolStripMenuItem1.ToolTipText = "See: https://www.chibiakumas.com/6502/simplesamples.php#LessonS4";
            this.saveRawBitmap4ColorToolStripMenuItem1.Click += new System.EventHandler(this.saveRawBitmap4ColorToolStripMenuItem1_Click);
            // 
            // atariLynxToolStripMenuItem
            // 
            this.atariLynxToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmapToolStripMenuItem11,
            this.save16colorLinearSpriteToolStripMenuItem,
            this.save8colorLinearSpriteToolStripMenuItem,
            this.sToolStripMenuItem,
            this.sToolStripMenuItem1,
            this.save16ColorRLESpriteToolStripMenuItem,
            this.save8ColorRLESpriteToolStripMenuItem,
            this.save4ColorRLESpriteToolStripMenuItem,
            this.save2ColorRLESpriteToolStripMenuItem,
            this.paletteToClipboardToolStripMenuItem7});
            this.atariLynxToolStripMenuItem.Name = "atariLynxToolStripMenuItem";
            this.atariLynxToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.atariLynxToolStripMenuItem.Text = "Atari Lynx";
            // 
            // saveRawBitmapToolStripMenuItem11
            // 
            this.saveRawBitmapToolStripMenuItem11.Name = "saveRawBitmapToolStripMenuItem11";
            this.saveRawBitmapToolStripMenuItem11.ShortcutKeyDisplayString = "[?]";
            this.saveRawBitmapToolStripMenuItem11.Size = new System.Drawing.Size(230, 22);
            this.saveRawBitmapToolStripMenuItem11.Text = "Save Raw Bitmap";
            this.saveRawBitmapToolStripMenuItem11.ToolTipText = "See: https://www.chibiakumas.com/6502/simplesamples.php#LessonS6";
            this.saveRawBitmapToolStripMenuItem11.Click += new System.EventHandler(this.saveRawBitmapToolStripMenuItem11_Click);
            // 
            // save16colorLinearSpriteToolStripMenuItem
            // 
            this.save16colorLinearSpriteToolStripMenuItem.Name = "save16colorLinearSpriteToolStripMenuItem";
            this.save16colorLinearSpriteToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.save16colorLinearSpriteToolStripMenuItem.Size = new System.Drawing.Size(230, 22);
            this.save16colorLinearSpriteToolStripMenuItem.Text = "Save 16 Color Literal Sprite";
            this.save16colorLinearSpriteToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/6502/platform4.php#LessonP32";
            this.save16colorLinearSpriteToolStripMenuItem.Click += new System.EventHandler(this.save16colorLinearSpriteToolStripMenuItem_Click);
            // 
            // save8colorLinearSpriteToolStripMenuItem
            // 
            this.save8colorLinearSpriteToolStripMenuItem.Name = "save8colorLinearSpriteToolStripMenuItem";
            this.save8colorLinearSpriteToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.save8colorLinearSpriteToolStripMenuItem.Size = new System.Drawing.Size(230, 22);
            this.save8colorLinearSpriteToolStripMenuItem.Text = "Save  8 Color Literal Sprite";
            this.save8colorLinearSpriteToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/6502/platform4.php#LessonP32";
            this.save8colorLinearSpriteToolStripMenuItem.Click += new System.EventHandler(this.save8colorLinearSpriteToolStripMenuItem_Click);
            // 
            // sToolStripMenuItem
            // 
            this.sToolStripMenuItem.Name = "sToolStripMenuItem";
            this.sToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.sToolStripMenuItem.Size = new System.Drawing.Size(230, 22);
            this.sToolStripMenuItem.Text = "Save  4 Color Literal Sprite";
            this.sToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/6502/platform4.php#LessonP32";
            this.sToolStripMenuItem.Click += new System.EventHandler(this.sToolStripMenuItem_Click);
            // 
            // sToolStripMenuItem1
            // 
            this.sToolStripMenuItem1.Name = "sToolStripMenuItem1";
            this.sToolStripMenuItem1.ShortcutKeyDisplayString = "[?]";
            this.sToolStripMenuItem1.Size = new System.Drawing.Size(230, 22);
            this.sToolStripMenuItem1.Text = "Save  2 Color Literal Sprite";
            this.sToolStripMenuItem1.ToolTipText = "See: https://www.chibiakumas.com/6502/platform4.php#LessonP32";
            this.sToolStripMenuItem1.Click += new System.EventHandler(this.sToolStripMenuItem1_Click);
            // 
            // save16ColorRLESpriteToolStripMenuItem
            // 
            this.save16ColorRLESpriteToolStripMenuItem.Name = "save16ColorRLESpriteToolStripMenuItem";
            this.save16ColorRLESpriteToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.save16ColorRLESpriteToolStripMenuItem.Size = new System.Drawing.Size(230, 22);
            this.save16ColorRLESpriteToolStripMenuItem.Text = "Save 16 Color RLE Sprite";
            this.save16ColorRLESpriteToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/6502/platform4.php#LessonP32";
            this.save16ColorRLESpriteToolStripMenuItem.Click += new System.EventHandler(this.save16ColorRLESpriteToolStripMenuItem_Click);
            // 
            // save8ColorRLESpriteToolStripMenuItem
            // 
            this.save8ColorRLESpriteToolStripMenuItem.Name = "save8ColorRLESpriteToolStripMenuItem";
            this.save8ColorRLESpriteToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.save8ColorRLESpriteToolStripMenuItem.Size = new System.Drawing.Size(230, 22);
            this.save8ColorRLESpriteToolStripMenuItem.Text = "Save  8 Color RLE Sprite";
            this.save8ColorRLESpriteToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/6502/platform4.php#LessonP32";
            this.save8ColorRLESpriteToolStripMenuItem.Click += new System.EventHandler(this.save8ColorRLESpriteToolStripMenuItem_Click);
            // 
            // save4ColorRLESpriteToolStripMenuItem
            // 
            this.save4ColorRLESpriteToolStripMenuItem.Name = "save4ColorRLESpriteToolStripMenuItem";
            this.save4ColorRLESpriteToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.save4ColorRLESpriteToolStripMenuItem.Size = new System.Drawing.Size(230, 22);
            this.save4ColorRLESpriteToolStripMenuItem.Text = "Save  4 Color RLE Sprite";
            this.save4ColorRLESpriteToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/6502/platform4.php#LessonP32";
            this.save4ColorRLESpriteToolStripMenuItem.Click += new System.EventHandler(this.save4ColorRLESpriteToolStripMenuItem_Click);
            // 
            // save2ColorRLESpriteToolStripMenuItem
            // 
            this.save2ColorRLESpriteToolStripMenuItem.Name = "save2ColorRLESpriteToolStripMenuItem";
            this.save2ColorRLESpriteToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.save2ColorRLESpriteToolStripMenuItem.Size = new System.Drawing.Size(230, 22);
            this.save2ColorRLESpriteToolStripMenuItem.Text = "Save  2 Color RLE Sprite";
            this.save2ColorRLESpriteToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/6502/platform4.php#LessonP32";
            this.save2ColorRLESpriteToolStripMenuItem.Click += new System.EventHandler(this.save2ColorRLESpriteToolStripMenuItem_Click);
            // 
            // paletteToClipboardToolStripMenuItem7
            // 
            this.paletteToClipboardToolStripMenuItem7.Name = "paletteToClipboardToolStripMenuItem7";
            this.paletteToClipboardToolStripMenuItem7.Size = new System.Drawing.Size(230, 22);
            this.paletteToClipboardToolStripMenuItem7.Text = "Palette to Clipboard";
            this.paletteToClipboardToolStripMenuItem7.Click += new System.EventHandler(this.paletteToClipboardToolStripMenuItem7_Click);
            // 
            // aToolStripMenuItem
            // 
            this.aToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmap2ColorToolStripMenuItem,
            this.saveRawBitmap4ColorToolStripMenuItem,
            this.saveRaw8x82colorToolStripMenuItem});
            this.aToolStripMenuItem.Name = "aToolStripMenuItem";
            this.aToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.aToolStripMenuItem.Text = "Apple II";
            // 
            // saveRawBitmap2ColorToolStripMenuItem
            // 
            this.saveRawBitmap2ColorToolStripMenuItem.Name = "saveRawBitmap2ColorToolStripMenuItem";
            this.saveRawBitmap2ColorToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.saveRawBitmap2ColorToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.saveRawBitmap2ColorToolStripMenuItem.Text = "Save Raw Bitmap (2 color)";
            this.saveRawBitmap2ColorToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/6502/simplesamples.php#LessonS5";
            this.saveRawBitmap2ColorToolStripMenuItem.Click += new System.EventHandler(this.saveRawBitmap2ColorToolStripMenuItem_Click);
            // 
            // saveRawBitmap4ColorToolStripMenuItem
            // 
            this.saveRawBitmap4ColorToolStripMenuItem.Name = "saveRawBitmap4ColorToolStripMenuItem";
            this.saveRawBitmap4ColorToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.saveRawBitmap4ColorToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.saveRawBitmap4ColorToolStripMenuItem.Text = "Save Raw Bitmap (4 color)";
            this.saveRawBitmap4ColorToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/6502/simplesamples.php#LessonS5";
            this.saveRawBitmap4ColorToolStripMenuItem.Click += new System.EventHandler(this.saveRawBitmap4ColorToolStripMenuItem_Click);
            // 
            // saveRaw8x82colorToolStripMenuItem
            // 
            this.saveRaw8x82colorToolStripMenuItem.Name = "saveRaw8x82colorToolStripMenuItem";
            this.saveRaw8x82colorToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.saveRaw8x82colorToolStripMenuItem.Text = "Save Raw 8x8 2color";
            this.saveRaw8x82colorToolStripMenuItem.Click += new System.EventHandler(this.saveRaw8x82colorToolStripMenuItem_Click);
            // 
            // bBCToolStripMenuItem
            // 
            this.bBCToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmapToolStripMenuItem12});
            this.bBCToolStripMenuItem.Name = "bBCToolStripMenuItem";
            this.bBCToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.bBCToolStripMenuItem.Text = "BBC";
            // 
            // saveRawBitmapToolStripMenuItem12
            // 
            this.saveRawBitmapToolStripMenuItem12.Name = "saveRawBitmapToolStripMenuItem12";
            this.saveRawBitmapToolStripMenuItem12.ShortcutKeyDisplayString = "[?]";
            this.saveRawBitmapToolStripMenuItem12.Size = new System.Drawing.Size(179, 22);
            this.saveRawBitmapToolStripMenuItem12.Text = "Save Raw Bitmap";
            this.saveRawBitmapToolStripMenuItem12.ToolTipText = "See: https://www.chibiakumas.com/6502/simplesamples.php#LessonS1";
            this.saveRawBitmapToolStripMenuItem12.Click += new System.EventHandler(this.saveRawBitmapToolStripMenuItem12_Click);
            // 
            // c64ToolStripMenuItem
            // 
            this.c64ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmap2ColorToolStripMenuItem2,
            this.saveRawBitmap4ColorToolStripMenuItem2,
            this.saveSprite2ColorToolStripMenuItem,
            this.saveSprite4ColorToolStripMenuItem,
            this.saveSprite4ColorToolStripMenuItem1});
            this.c64ToolStripMenuItem.Name = "c64ToolStripMenuItem";
            this.c64ToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.c64ToolStripMenuItem.Text = "C64";
            // 
            // saveRawBitmap2ColorToolStripMenuItem2
            // 
            this.saveRawBitmap2ColorToolStripMenuItem2.Name = "saveRawBitmap2ColorToolStripMenuItem2";
            this.saveRawBitmap2ColorToolStripMenuItem2.ShortcutKeyDisplayString = "[?]";
            this.saveRawBitmap2ColorToolStripMenuItem2.Size = new System.Drawing.Size(259, 22);
            this.saveRawBitmap2ColorToolStripMenuItem2.Text = "Save Raw Bitmap (2 Color)";
            this.saveRawBitmap2ColorToolStripMenuItem2.ToolTipText = "See: https://www.chibiakumas.com/6502/platform.php#LessonP9";
            this.saveRawBitmap2ColorToolStripMenuItem2.Click += new System.EventHandler(this.saveRawBitmap2ColorToolStripMenuItem2_Click);
            // 
            // saveRawBitmap4ColorToolStripMenuItem2
            // 
            this.saveRawBitmap4ColorToolStripMenuItem2.Name = "saveRawBitmap4ColorToolStripMenuItem2";
            this.saveRawBitmap4ColorToolStripMenuItem2.ShortcutKeyDisplayString = "[?]";
            this.saveRawBitmap4ColorToolStripMenuItem2.Size = new System.Drawing.Size(259, 22);
            this.saveRawBitmap4ColorToolStripMenuItem2.Text = "Save Raw Bitmap (4 Color)";
            this.saveRawBitmap4ColorToolStripMenuItem2.ToolTipText = "See: https://www.chibiakumas.com/6502/platform.php#LessonP9";
            this.saveRawBitmap4ColorToolStripMenuItem2.Click += new System.EventHandler(this.saveRawBitmap4ColorToolStripMenuItem2_Click);
            // 
            // saveSprite2ColorToolStripMenuItem
            // 
            this.saveSprite2ColorToolStripMenuItem.Name = "saveSprite2ColorToolStripMenuItem";
            this.saveSprite2ColorToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.saveSprite2ColorToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.saveSprite2ColorToolStripMenuItem.Text = "Save Sprite (2 Color)";
            this.saveSprite2ColorToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/6502/platform4.php#LessonP36";
            this.saveSprite2ColorToolStripMenuItem.Click += new System.EventHandler(this.saveSprite2ColorToolStripMenuItem_Click);
            // 
            // saveSprite4ColorToolStripMenuItem
            // 
            this.saveSprite4ColorToolStripMenuItem.Name = "saveSprite4ColorToolStripMenuItem";
            this.saveSprite4ColorToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.saveSprite4ColorToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.saveSprite4ColorToolStripMenuItem.Text = "Save Sprite (4 Color - HalfWidth)";
            this.saveSprite4ColorToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/6502/platform4.php#LessonP36";
            this.saveSprite4ColorToolStripMenuItem.Click += new System.EventHandler(this.saveSprite4ColorToolStripMenuItem_Click);
            // 
            // saveSprite4ColorToolStripMenuItem1
            // 
            this.saveSprite4ColorToolStripMenuItem1.Name = "saveSprite4ColorToolStripMenuItem1";
            this.saveSprite4ColorToolStripMenuItem1.Size = new System.Drawing.Size(259, 22);
            this.saveSprite4ColorToolStripMenuItem1.Text = "Save Sprite (4 Color)";
            this.saveSprite4ColorToolStripMenuItem1.Click += new System.EventHandler(this.saveSprite4ColorToolStripMenuItem1_Click);
            // 
            // nESFamicomToolStripMenuItem
            // 
            this.nESFamicomToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmapToolStripMenuItem14});
            this.nESFamicomToolStripMenuItem.Name = "nESFamicomToolStripMenuItem";
            this.nESFamicomToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.nESFamicomToolStripMenuItem.Text = "NES/Famicom";
            // 
            // saveRawBitmapToolStripMenuItem14
            // 
            this.saveRawBitmapToolStripMenuItem14.Name = "saveRawBitmapToolStripMenuItem14";
            this.saveRawBitmapToolStripMenuItem14.ShortcutKeyDisplayString = "[?]";
            this.saveRawBitmapToolStripMenuItem14.Size = new System.Drawing.Size(179, 22);
            this.saveRawBitmapToolStripMenuItem14.Text = "Save Raw Bitmap";
            this.saveRawBitmapToolStripMenuItem14.ToolTipText = "See: https://www.chibiakumas.com/6502/simplesamples.php#LessonS7";
            this.saveRawBitmapToolStripMenuItem14.Click += new System.EventHandler(this.saveRawBitmapToolStripMenuItem14_Click);
            // 
            // pCEngineToolStripMenuItem
            // 
            this.pCEngineToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmapToolStripMenuItem13,
            this.savePCESpriteToolStripMenuItem,
            this.paletteToClipboardToolStripMenuItem8});
            this.pCEngineToolStripMenuItem.Name = "pCEngineToolStripMenuItem";
            this.pCEngineToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.pCEngineToolStripMenuItem.Text = "PC Engine";
            // 
            // saveRawBitmapToolStripMenuItem13
            // 
            this.saveRawBitmapToolStripMenuItem13.Name = "saveRawBitmapToolStripMenuItem13";
            this.saveRawBitmapToolStripMenuItem13.ShortcutKeyDisplayString = "[?]";
            this.saveRawBitmapToolStripMenuItem13.Size = new System.Drawing.Size(179, 22);
            this.saveRawBitmapToolStripMenuItem13.Text = "Save Raw Bitmap";
            this.saveRawBitmapToolStripMenuItem13.ToolTipText = "See: https://www.chibiakumas.com/6502/platform.php#LessonP5";
            this.saveRawBitmapToolStripMenuItem13.Click += new System.EventHandler(this.saveRawBitmapToolStripMenuItem13_Click);
            // 
            // savePCESpriteToolStripMenuItem
            // 
            this.savePCESpriteToolStripMenuItem.Name = "savePCESpriteToolStripMenuItem";
            this.savePCESpriteToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.savePCESpriteToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.savePCESpriteToolStripMenuItem.Text = "Save PCE Sprite";
            this.savePCESpriteToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/6502/platform4.php#LessonP33";
            this.savePCESpriteToolStripMenuItem.Click += new System.EventHandler(this.savePCESpriteToolStripMenuItem_Click);
            // 
            // paletteToClipboardToolStripMenuItem8
            // 
            this.paletteToClipboardToolStripMenuItem8.Name = "paletteToClipboardToolStripMenuItem8";
            this.paletteToClipboardToolStripMenuItem8.Size = new System.Drawing.Size(179, 22);
            this.paletteToClipboardToolStripMenuItem8.Text = "Palette to Clipboard";
            this.paletteToClipboardToolStripMenuItem8.Click += new System.EventHandler(this.paletteToClipboardToolStripMenuItem8_Click);
            // 
            // superNintendoSFCToolStripMenuItem
            // 
            this.superNintendoSFCToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmapToolStripMenuItem15,
            this.paletteToClipboardToolStripMenuItem6,
            this.saveRawBitmap2bpp4ColorToolStripMenuItem});
            this.superNintendoSFCToolStripMenuItem.Name = "superNintendoSFCToolStripMenuItem";
            this.superNintendoSFCToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.superNintendoSFCToolStripMenuItem.Text = "Super Nintendo/SFC";
            // 
            // saveRawBitmapToolStripMenuItem15
            // 
            this.saveRawBitmapToolStripMenuItem15.Name = "saveRawBitmapToolStripMenuItem15";
            this.saveRawBitmapToolStripMenuItem15.ShortcutKeyDisplayString = "[?]";
            this.saveRawBitmapToolStripMenuItem15.Size = new System.Drawing.Size(260, 22);
            this.saveRawBitmapToolStripMenuItem15.Text = "Save Raw Bitmap 4bpp (16 color)";
            this.saveRawBitmapToolStripMenuItem15.ToolTipText = "See: https://www.chibiakumas.com/6502/simplesamples.php#LessonS8";
            this.saveRawBitmapToolStripMenuItem15.Click += new System.EventHandler(this.saveRawBitmapToolStripMenuItem15_Click);
            // 
            // paletteToClipboardToolStripMenuItem6
            // 
            this.paletteToClipboardToolStripMenuItem6.Name = "paletteToClipboardToolStripMenuItem6";
            this.paletteToClipboardToolStripMenuItem6.Size = new System.Drawing.Size(260, 22);
            this.paletteToClipboardToolStripMenuItem6.Text = "Palette to Clipboard";
            this.paletteToClipboardToolStripMenuItem6.Click += new System.EventHandler(this.paletteToClipboardToolStripMenuItem6_Click);
            // 
            // saveRawBitmap2bpp4ColorToolStripMenuItem
            // 
            this.saveRawBitmap2bpp4ColorToolStripMenuItem.Name = "saveRawBitmap2bpp4ColorToolStripMenuItem";
            this.saveRawBitmap2bpp4ColorToolStripMenuItem.Size = new System.Drawing.Size(260, 22);
            this.saveRawBitmap2bpp4ColorToolStripMenuItem.Text = "Save Raw Bitmap 2bpp (4 color)";
            this.saveRawBitmap2bpp4ColorToolStripMenuItem.Click += new System.EventHandler(this.saveRawBitmap2bpp4ColorToolStripMenuItem_Click);
            // 
            // vic20ToolStripMenuItem
            // 
            this.vic20ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmapToolStripMenuItem16,
            this.saveDoubleHeightBitmapToolStripMenuItem});
            this.vic20ToolStripMenuItem.Name = "vic20ToolStripMenuItem";
            this.vic20ToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.vic20ToolStripMenuItem.Text = "Vic 20";
            // 
            // saveRawBitmapToolStripMenuItem16
            // 
            this.saveRawBitmapToolStripMenuItem16.Name = "saveRawBitmapToolStripMenuItem16";
            this.saveRawBitmapToolStripMenuItem16.ShortcutKeyDisplayString = "[?]";
            this.saveRawBitmapToolStripMenuItem16.Size = new System.Drawing.Size(207, 22);
            this.saveRawBitmapToolStripMenuItem16.Text = "Save Raw Bitmap";
            this.saveRawBitmapToolStripMenuItem16.ToolTipText = "See: https://www.chibiakumas.com/6502/simplesamples.php#LessonS3";
            this.saveRawBitmapToolStripMenuItem16.Click += new System.EventHandler(this.saveRawBitmapToolStripMenuItem16_Click);
            // 
            // saveDoubleHeightBitmapToolStripMenuItem
            // 
            this.saveDoubleHeightBitmapToolStripMenuItem.Name = "saveDoubleHeightBitmapToolStripMenuItem";
            this.saveDoubleHeightBitmapToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.saveDoubleHeightBitmapToolStripMenuItem.Text = "Save DoubleHeight Bitmap";
            this.saveDoubleHeightBitmapToolStripMenuItem.Click += new System.EventHandler(this.saveDoubleHeightBitmapToolStripMenuItem_Click);
            // 
            // x16ToolStripMenuItem
            // 
            this.x16ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.save8bppRawBitmapToolStripMenuItem,
            this.save4bppRawBitmalToolStripMenuItem,
            this.save4bpp16x16SpritesToolStripMenuItem,
            this.save8bpp16x16SpritesToolStripMenuItem,
            this.paletteToClipboardRGBToolStripMenuItem,
            this.save4bpp8x8TilesToolStripMenuItem,
            this.saToolStripMenuItem,
            this.save8bpp8x8TilesToolStripMenuItem,
            this.save8bpp16x16TilesToolStripMenuItem});
            this.x16ToolStripMenuItem.Name = "x16ToolStripMenuItem";
            this.x16ToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.x16ToolStripMenuItem.Text = "Commander x16";
            // 
            // save8bppRawBitmapToolStripMenuItem
            // 
            this.save8bppRawBitmapToolStripMenuItem.Name = "save8bppRawBitmapToolStripMenuItem";
            this.save8bppRawBitmapToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.save8bppRawBitmapToolStripMenuItem.Size = new System.Drawing.Size(264, 22);
            this.save8bppRawBitmapToolStripMenuItem.Text = "Save 8bpp Raw Bitmap";
            this.save8bppRawBitmapToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/6502/commanderx16.php#X16_2";
            this.save8bppRawBitmapToolStripMenuItem.Click += new System.EventHandler(this.save8bppRawBitmapToolStripMenuItem_Click);
            // 
            // save4bppRawBitmalToolStripMenuItem
            // 
            this.save4bppRawBitmalToolStripMenuItem.Name = "save4bppRawBitmalToolStripMenuItem";
            this.save4bppRawBitmalToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.save4bppRawBitmalToolStripMenuItem.Size = new System.Drawing.Size(264, 22);
            this.save4bppRawBitmalToolStripMenuItem.Text = "Save 4bpp Raw Bitmap";
            this.save4bppRawBitmalToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/6502/commanderx16.php#X16_2";
            this.save4bppRawBitmalToolStripMenuItem.Click += new System.EventHandler(this.save4bppRawBitmalToolStripMenuItem_Click);
            // 
            // save4bpp16x16SpritesToolStripMenuItem
            // 
            this.save4bpp16x16SpritesToolStripMenuItem.Name = "save4bpp16x16SpritesToolStripMenuItem";
            this.save4bpp16x16SpritesToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.save4bpp16x16SpritesToolStripMenuItem.Size = new System.Drawing.Size(264, 22);
            this.save4bpp16x16SpritesToolStripMenuItem.Text = "Save 4bpp Sprites (Default 16x16)";
            this.save4bpp16x16SpritesToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/6502/commanderx16.php#X16_3";
            this.save4bpp16x16SpritesToolStripMenuItem.Click += new System.EventHandler(this.save4bpp16x16SpritesToolStripMenuItem_Click);
            // 
            // save8bpp16x16SpritesToolStripMenuItem
            // 
            this.save8bpp16x16SpritesToolStripMenuItem.Name = "save8bpp16x16SpritesToolStripMenuItem";
            this.save8bpp16x16SpritesToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.save8bpp16x16SpritesToolStripMenuItem.Size = new System.Drawing.Size(264, 22);
            this.save8bpp16x16SpritesToolStripMenuItem.Text = "Save 8bpp Sprites (Default 16x16)";
            this.save8bpp16x16SpritesToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/6502/commanderx16.php#X16_3";
            this.save8bpp16x16SpritesToolStripMenuItem.Click += new System.EventHandler(this.save8bpp16x16SpritesToolStripMenuItem_Click);
            // 
            // paletteToClipboardRGBToolStripMenuItem
            // 
            this.paletteToClipboardRGBToolStripMenuItem.Name = "paletteToClipboardRGBToolStripMenuItem";
            this.paletteToClipboardRGBToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.paletteToClipboardRGBToolStripMenuItem.Size = new System.Drawing.Size(264, 22);
            this.paletteToClipboardRGBToolStripMenuItem.Text = "Palette To Clipboard (-RGB)";
            this.paletteToClipboardRGBToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/6502/commanderx16.php#LessonX1";
            this.paletteToClipboardRGBToolStripMenuItem.Click += new System.EventHandler(this.paletteToClipboardRGBToolStripMenuItem_Click);
            // 
            // save4bpp8x8TilesToolStripMenuItem
            // 
            this.save4bpp8x8TilesToolStripMenuItem.Name = "save4bpp8x8TilesToolStripMenuItem";
            this.save4bpp8x8TilesToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.save4bpp8x8TilesToolStripMenuItem.Size = new System.Drawing.Size(264, 22);
            this.save4bpp8x8TilesToolStripMenuItem.Text = "Save 4bpp 8x8 Tiles";
            this.save4bpp8x8TilesToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/6502/commanderx16.php#X16_4";
            this.save4bpp8x8TilesToolStripMenuItem.Click += new System.EventHandler(this.save4bpp8x8TilesToolStripMenuItem_Click);
            // 
            // saToolStripMenuItem
            // 
            this.saToolStripMenuItem.Name = "saToolStripMenuItem";
            this.saToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.saToolStripMenuItem.Size = new System.Drawing.Size(264, 22);
            this.saToolStripMenuItem.Text = "Save 4bpp 16x16 Tiles";
            this.saToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/6502/commanderx16.php#X16_4";
            this.saToolStripMenuItem.Click += new System.EventHandler(this.saToolStripMenuItem_Click);
            // 
            // save8bpp8x8TilesToolStripMenuItem
            // 
            this.save8bpp8x8TilesToolStripMenuItem.Name = "save8bpp8x8TilesToolStripMenuItem";
            this.save8bpp8x8TilesToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.save8bpp8x8TilesToolStripMenuItem.Size = new System.Drawing.Size(264, 22);
            this.save8bpp8x8TilesToolStripMenuItem.Text = "Save 8bpp 8x8 Tiles";
            this.save8bpp8x8TilesToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/6502/commanderx16.php#X16_4";
            this.save8bpp8x8TilesToolStripMenuItem.Click += new System.EventHandler(this.save8bpp8x8TilesToolStripMenuItem_Click);
            // 
            // save8bpp16x16TilesToolStripMenuItem
            // 
            this.save8bpp16x16TilesToolStripMenuItem.Name = "save8bpp16x16TilesToolStripMenuItem";
            this.save8bpp16x16TilesToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.save8bpp16x16TilesToolStripMenuItem.Size = new System.Drawing.Size(264, 22);
            this.save8bpp16x16TilesToolStripMenuItem.Text = "Save 8bpp 16x16 Tiles";
            this.save8bpp16x16TilesToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/6502/commanderx16.php#X16_4";
            this.save8bpp16x16TilesToolStripMenuItem.Click += new System.EventHandler(this.save8bpp16x16TilesToolStripMenuItem_Click);
            // 
            // paletteToClipboardToolStripMenuItem1
            // 
            this.paletteToClipboardToolStripMenuItem1.Name = "paletteToClipboardToolStripMenuItem1";
            this.paletteToClipboardToolStripMenuItem1.Size = new System.Drawing.Size(176, 22);
            this.paletteToClipboardToolStripMenuItem1.Text = "Palette to Clipboard";
            this.paletteToClipboardToolStripMenuItem1.Click += new System.EventHandler(this.paletteToClipboardToolStripMenuItem1_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.neoGeoToolStripMenuItem,
            this.atariSTToolStripMenuItem,
            this.AmigaToolStripMenuItem,
            this.x68000ToolStripMenuItem,
            this.megaDriveGenesisToolStripMenuItem,
            this.sinclairQLToolStripMenuItem,
            this.paletteToClipboardToolStripMenuItem2});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(67, 20);
            this.toolStripMenuItem1.Text = "* 68000 *";
            // 
            // neoGeoToolStripMenuItem
            // 
            this.neoGeoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveFIXFontToolStripMenuItem,
            this.saveSpriteToolStripMenuItem,
            this.loadSpriteToolStripMenuItem,
            this.paletteToClipboardToolStripMenuItem12,
            this.saveCDSpriteToolStripMenuItem});
            this.neoGeoToolStripMenuItem.Name = "neoGeoToolStripMenuItem";
            this.neoGeoToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.neoGeoToolStripMenuItem.Text = "NeoGeo";
            // 
            // saveFIXFontToolStripMenuItem
            // 
            this.saveFIXFontToolStripMenuItem.Name = "saveFIXFontToolStripMenuItem";
            this.saveFIXFontToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.saveFIXFontToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.saveFIXFontToolStripMenuItem.Text = "Save FIX Bitmap";
            this.saveFIXFontToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/68000/platform.php#LessonP3";
            this.saveFIXFontToolStripMenuItem.Click += new System.EventHandler(this.saveFIXFontToolStripMenuItem_Click);
            // 
            // saveSpriteToolStripMenuItem
            // 
            this.saveSpriteToolStripMenuItem.Name = "saveSpriteToolStripMenuItem";
            this.saveSpriteToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.saveSpriteToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.saveSpriteToolStripMenuItem.Text = "Save Sprite";
            this.saveSpriteToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/68000/platform3.php#LessonP25";
            this.saveSpriteToolStripMenuItem.Click += new System.EventHandler(this.saveSpriteToolStripMenuItem_Click);
            // 
            // loadSpriteToolStripMenuItem
            // 
            this.loadSpriteToolStripMenuItem.Name = "loadSpriteToolStripMenuItem";
            this.loadSpriteToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.loadSpriteToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.loadSpriteToolStripMenuItem.Text = "Load Sprite";
            this.loadSpriteToolStripMenuItem.ToolTipText = "See: https://youtu.be/Wtz1kJaxUgc";
            this.loadSpriteToolStripMenuItem.Click += new System.EventHandler(this.loadSpriteToolStripMenuItem_Click);
            // 
            // paletteToClipboardToolStripMenuItem12
            // 
            this.paletteToClipboardToolStripMenuItem12.Name = "paletteToClipboardToolStripMenuItem12";
            this.paletteToClipboardToolStripMenuItem12.Size = new System.Drawing.Size(174, 22);
            this.paletteToClipboardToolStripMenuItem12.Text = "Palette to Clipboard";
            this.paletteToClipboardToolStripMenuItem12.Click += new System.EventHandler(this.paletteToClipboardToolStripMenuItem12_Click);
            // 
            // saveCDSpriteToolStripMenuItem
            // 
            this.saveCDSpriteToolStripMenuItem.Name = "saveCDSpriteToolStripMenuItem";
            this.saveCDSpriteToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.saveCDSpriteToolStripMenuItem.Text = "Save CD Sprite";
            this.saveCDSpriteToolStripMenuItem.Click += new System.EventHandler(this.saveCDSpriteToolStripMenuItem_Click);
            // 
            // atariSTToolStripMenuItem
            // 
            this.atariSTToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmapToolStripMenuItem7,
            this.saveRaw8x8BitmapToolStripMenuItem,
            this.paletteToClipboardToolStripMenuItem11});
            this.atariSTToolStripMenuItem.Name = "atariSTToolStripMenuItem";
            this.atariSTToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.atariSTToolStripMenuItem.Text = "Atari ST";
            // 
            // saveRawBitmapToolStripMenuItem7
            // 
            this.saveRawBitmapToolStripMenuItem7.Name = "saveRawBitmapToolStripMenuItem7";
            this.saveRawBitmapToolStripMenuItem7.ShortcutKeyDisplayString = "[?]";
            this.saveRawBitmapToolStripMenuItem7.Size = new System.Drawing.Size(183, 22);
            this.saveRawBitmapToolStripMenuItem7.Text = "Save Raw Bitmap";
            this.saveRawBitmapToolStripMenuItem7.ToolTipText = "See: https://www.chibiakumas.com/68000/platform.php#LessonP2";
            this.saveRawBitmapToolStripMenuItem7.Click += new System.EventHandler(this.saveRawBitmapToolStripMenuItem7_Click);
            // 
            // saveRaw8x8BitmapToolStripMenuItem
            // 
            this.saveRaw8x8BitmapToolStripMenuItem.Name = "saveRaw8x8BitmapToolStripMenuItem";
            this.saveRaw8x8BitmapToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.saveRaw8x8BitmapToolStripMenuItem.Text = "Save Raw 8x8 Bitmap";
            this.saveRaw8x8BitmapToolStripMenuItem.Click += new System.EventHandler(this.saveRaw8x8BitmapToolStripMenuItem_Click);
            // 
            // paletteToClipboardToolStripMenuItem11
            // 
            this.paletteToClipboardToolStripMenuItem11.Name = "paletteToClipboardToolStripMenuItem11";
            this.paletteToClipboardToolStripMenuItem11.Size = new System.Drawing.Size(183, 22);
            this.paletteToClipboardToolStripMenuItem11.Text = "PaletteToClipboard";
            this.paletteToClipboardToolStripMenuItem11.Click += new System.EventHandler(this.paletteToClipboardToolStripMenuItem11_Click);
            // 
            // AmigaToolStripMenuItem
            // 
            this.AmigaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmapToolStripMenuItem8,
            this.saveRawSpriteToolStripMenuItem,
            this.copperlistPaletteToClipboardToolStripMenuItem});
            this.AmigaToolStripMenuItem.Name = "AmigaToolStripMenuItem";
            this.AmigaToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.AmigaToolStripMenuItem.Text = "Amiga";
            // 
            // saveRawBitmapToolStripMenuItem8
            // 
            this.saveRawBitmapToolStripMenuItem8.Name = "saveRawBitmapToolStripMenuItem8";
            this.saveRawBitmapToolStripMenuItem8.ShortcutKeyDisplayString = "[?]";
            this.saveRawBitmapToolStripMenuItem8.Size = new System.Drawing.Size(228, 22);
            this.saveRawBitmapToolStripMenuItem8.Text = "SaveRawBitmap";
            this.saveRawBitmapToolStripMenuItem8.ToolTipText = "See: https://www.chibiakumas.com/68000/platform.php#LessonP6";
            this.saveRawBitmapToolStripMenuItem8.Click += new System.EventHandler(this.saveRawBitmapToolStripMenuItem8_Click);
            // 
            // saveRawSpriteToolStripMenuItem
            // 
            this.saveRawSpriteToolStripMenuItem.Name = "saveRawSpriteToolStripMenuItem";
            this.saveRawSpriteToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.saveRawSpriteToolStripMenuItem.Size = new System.Drawing.Size(228, 22);
            this.saveRawSpriteToolStripMenuItem.Text = "Save Raw Sprite";
            this.saveRawSpriteToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/68000/platform3.php#LessonP28";
            this.saveRawSpriteToolStripMenuItem.Click += new System.EventHandler(this.saveRawSpriteToolStripMenuItem_Click);
            // 
            // copperlistPaletteToClipboardToolStripMenuItem
            // 
            this.copperlistPaletteToClipboardToolStripMenuItem.Name = "copperlistPaletteToClipboardToolStripMenuItem";
            this.copperlistPaletteToClipboardToolStripMenuItem.Size = new System.Drawing.Size(228, 22);
            this.copperlistPaletteToClipboardToolStripMenuItem.Text = "Copperlist Palette to Clipboard";
            this.copperlistPaletteToClipboardToolStripMenuItem.Click += new System.EventHandler(this.copperlistPaletteToClipboardToolStripMenuItem_Click);
            // 
            // x68000ToolStripMenuItem
            // 
            this.x68000ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmapToolStripMenuItem9,
            this.saveSpriteToolStripMenuItem1,
            this.paletteToClipboardToolStripMenuItem9});
            this.x68000ToolStripMenuItem.Name = "x68000ToolStripMenuItem";
            this.x68000ToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.x68000ToolStripMenuItem.Text = "X68000";
            // 
            // saveRawBitmapToolStripMenuItem9
            // 
            this.saveRawBitmapToolStripMenuItem9.Name = "saveRawBitmapToolStripMenuItem9";
            this.saveRawBitmapToolStripMenuItem9.ShortcutKeyDisplayString = "[?]";
            this.saveRawBitmapToolStripMenuItem9.Size = new System.Drawing.Size(179, 22);
            this.saveRawBitmapToolStripMenuItem9.Text = "Save Raw Bitmap";
            this.saveRawBitmapToolStripMenuItem9.ToolTipText = "See: https://www.chibiakumas.com/68000/platform.php#LessonP1";
            this.saveRawBitmapToolStripMenuItem9.Click += new System.EventHandler(this.saveRawBitmapToolStripMenuItem9_Click);
            // 
            // saveSpriteToolStripMenuItem1
            // 
            this.saveSpriteToolStripMenuItem1.Name = "saveSpriteToolStripMenuItem1";
            this.saveSpriteToolStripMenuItem1.ShortcutKeyDisplayString = "[?]";
            this.saveSpriteToolStripMenuItem1.Size = new System.Drawing.Size(179, 22);
            this.saveSpriteToolStripMenuItem1.Text = "Save Sprite";
            this.saveSpriteToolStripMenuItem1.ToolTipText = "See: https://www.chibiakumas.com/68000/platform3.php#LessonP24";
            this.saveSpriteToolStripMenuItem1.Click += new System.EventHandler(this.saveSpriteToolStripMenuItem1_Click);
            // 
            // paletteToClipboardToolStripMenuItem9
            // 
            this.paletteToClipboardToolStripMenuItem9.Name = "paletteToClipboardToolStripMenuItem9";
            this.paletteToClipboardToolStripMenuItem9.Size = new System.Drawing.Size(179, 22);
            this.paletteToClipboardToolStripMenuItem9.Text = "Palette to Clipboard";
            this.paletteToClipboardToolStripMenuItem9.Click += new System.EventHandler(this.paletteToClipboardToolStripMenuItem9_Click);
            // 
            // megaDriveGenesisToolStripMenuItem
            // 
            this.megaDriveGenesisToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmapToolStripMenuItem10,
            this.saveRawSpriteToolStripMenuItem1,
            this.paletteToClipboardToolStripMenuItem10});
            this.megaDriveGenesisToolStripMenuItem.Name = "megaDriveGenesisToolStripMenuItem";
            this.megaDriveGenesisToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.megaDriveGenesisToolStripMenuItem.Text = "MegaDrive/Genesis";
            // 
            // saveRawBitmapToolStripMenuItem10
            // 
            this.saveRawBitmapToolStripMenuItem10.Name = "saveRawBitmapToolStripMenuItem10";
            this.saveRawBitmapToolStripMenuItem10.ShortcutKeyDisplayString = "[?]";
            this.saveRawBitmapToolStripMenuItem10.Size = new System.Drawing.Size(179, 22);
            this.saveRawBitmapToolStripMenuItem10.Text = "Save Raw Bitmap";
            this.saveRawBitmapToolStripMenuItem10.ToolTipText = "See: http://www.chibiakumas.com/68000/platform.php#LessonP5";
            this.saveRawBitmapToolStripMenuItem10.Click += new System.EventHandler(this.saveRawBitmapToolStripMenuItem10_Click);
            // 
            // saveRawSpriteToolStripMenuItem1
            // 
            this.saveRawSpriteToolStripMenuItem1.Name = "saveRawSpriteToolStripMenuItem1";
            this.saveRawSpriteToolStripMenuItem1.ShortcutKeyDisplayString = "[?]";
            this.saveRawSpriteToolStripMenuItem1.Size = new System.Drawing.Size(179, 22);
            this.saveRawSpriteToolStripMenuItem1.Text = "Save Raw Sprite";
            this.saveRawSpriteToolStripMenuItem1.ToolTipText = "See: https://www.chibiakumas.com/68000/platform3.php#LessonP27";
            this.saveRawSpriteToolStripMenuItem1.Click += new System.EventHandler(this.saveRawSpriteToolStripMenuItem1_Click);
            // 
            // paletteToClipboardToolStripMenuItem10
            // 
            this.paletteToClipboardToolStripMenuItem10.Name = "paletteToClipboardToolStripMenuItem10";
            this.paletteToClipboardToolStripMenuItem10.Size = new System.Drawing.Size(179, 22);
            this.paletteToClipboardToolStripMenuItem10.Text = "Palette to Clipboard";
            this.paletteToClipboardToolStripMenuItem10.Click += new System.EventHandler(this.paletteToClipboardToolStripMenuItem10_Click);
            // 
            // sinclairQLToolStripMenuItem
            // 
            this.sinclairQLToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.raw8colorBitmapToolStripMenuItem,
            this.raw4colorBitmapToolStripMenuItem,
            this.raw8Color8x8BitmapToolStripMenuItem});
            this.sinclairQLToolStripMenuItem.Name = "sinclairQLToolStripMenuItem";
            this.sinclairQLToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.sinclairQLToolStripMenuItem.Text = "Sinclair QL";
            // 
            // raw8colorBitmapToolStripMenuItem
            // 
            this.raw8colorBitmapToolStripMenuItem.Name = "raw8colorBitmapToolStripMenuItem";
            this.raw8colorBitmapToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.raw8colorBitmapToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.raw8colorBitmapToolStripMenuItem.Text = "Raw 8color Bitmap";
            this.raw8colorBitmapToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/68000/platform.php#LessonP4";
            this.raw8colorBitmapToolStripMenuItem.Click += new System.EventHandler(this.raw8colorBitmapToolStripMenuItem_Click);
            // 
            // raw4colorBitmapToolStripMenuItem
            // 
            this.raw4colorBitmapToolStripMenuItem.Name = "raw4colorBitmapToolStripMenuItem";
            this.raw4colorBitmapToolStripMenuItem.ShortcutKeyDisplayString = "[?]";
            this.raw4colorBitmapToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.raw4colorBitmapToolStripMenuItem.Text = "Raw 4color Bitmap";
            this.raw4colorBitmapToolStripMenuItem.ToolTipText = "See: https://www.chibiakumas.com/68000/platform.php#LessonP4";
            this.raw4colorBitmapToolStripMenuItem.Click += new System.EventHandler(this.raw4colorBitmapToolStripMenuItem_Click);
            // 
            // raw8Color8x8BitmapToolStripMenuItem
            // 
            this.raw8Color8x8BitmapToolStripMenuItem.Name = "raw8Color8x8BitmapToolStripMenuItem";
            this.raw8Color8x8BitmapToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.raw8Color8x8BitmapToolStripMenuItem.Text = "Raw 8 color 8x8 bitmap";
            this.raw8Color8x8BitmapToolStripMenuItem.Click += new System.EventHandler(this.raw8Color8x8BitmapToolStripMenuItem_Click);
            // 
            // paletteToClipboardToolStripMenuItem2
            // 
            this.paletteToClipboardToolStripMenuItem2.Name = "paletteToClipboardToolStripMenuItem2";
            this.paletteToClipboardToolStripMenuItem2.Size = new System.Drawing.Size(172, 22);
            this.paletteToClipboardToolStripMenuItem2.Text = "Palette to Clipboard";
            this.paletteToClipboardToolStripMenuItem2.Click += new System.EventHandler(this.paletteToClipboardToolStripMenuItem2_Click);
            // 
            // x86ToolStripMenuItem
            // 
            this.x86ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.wonderSToolStripMenuItem,
            this.msDosToolStripMenuItem,
            this.paletteToClipboardToolStripMenuItem3});
            this.x86ToolStripMenuItem.Name = "x86ToolStripMenuItem";
            this.x86ToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.x86ToolStripMenuItem.Text = "* x86 *";
            // 
            // wonderSToolStripMenuItem
            // 
            this.wonderSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmapToolStripMenuItem18,
            this.saveRawBitmap2bitPlanarToolStripMenuItem,
            this.saveRawBitmap4bitLinearToolStripMenuItem,
            this.saveRawBitmap2bitLinearToolStripMenuItem});
            this.wonderSToolStripMenuItem.Name = "wonderSToolStripMenuItem";
            this.wonderSToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.wonderSToolStripMenuItem.Text = "WonderSwan";
            // 
            // saveRawBitmapToolStripMenuItem18
            // 
            this.saveRawBitmapToolStripMenuItem18.Name = "saveRawBitmapToolStripMenuItem18";
            this.saveRawBitmapToolStripMenuItem18.Size = new System.Drawing.Size(227, 22);
            this.saveRawBitmapToolStripMenuItem18.Text = "Save Raw Bitmap (4bit planar)";
            this.saveRawBitmapToolStripMenuItem18.Click += new System.EventHandler(this.saveRawBitmapToolStripMenuItem18_Click);
            // 
            // saveRawBitmap2bitPlanarToolStripMenuItem
            // 
            this.saveRawBitmap2bitPlanarToolStripMenuItem.Name = "saveRawBitmap2bitPlanarToolStripMenuItem";
            this.saveRawBitmap2bitPlanarToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.saveRawBitmap2bitPlanarToolStripMenuItem.Text = "Save Raw Bitmap (2bit planar)";
            this.saveRawBitmap2bitPlanarToolStripMenuItem.Click += new System.EventHandler(this.saveRawBitmap2bitPlanarToolStripMenuItem_Click);
            // 
            // saveRawBitmap4bitLinearToolStripMenuItem
            // 
            this.saveRawBitmap4bitLinearToolStripMenuItem.Name = "saveRawBitmap4bitLinearToolStripMenuItem";
            this.saveRawBitmap4bitLinearToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.saveRawBitmap4bitLinearToolStripMenuItem.Text = "Save Raw Bitmap (4bit Linear)";
            this.saveRawBitmap4bitLinearToolStripMenuItem.Click += new System.EventHandler(this.saveRawBitmap4bitLinearToolStripMenuItem_Click);
            // 
            // saveRawBitmap2bitLinearToolStripMenuItem
            // 
            this.saveRawBitmap2bitLinearToolStripMenuItem.Name = "saveRawBitmap2bitLinearToolStripMenuItem";
            this.saveRawBitmap2bitLinearToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.saveRawBitmap2bitLinearToolStripMenuItem.Text = "Save Raw Bitmap (2bit Linear)";
            this.saveRawBitmap2bitLinearToolStripMenuItem.Click += new System.EventHandler(this.saveRawBitmap2bitLinearToolStripMenuItem_Click);
            // 
            // msDosToolStripMenuItem
            // 
            this.msDosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmapCGAToolStripMenuItem,
            this.saveRawBitmapEGAToolStripMenuItem,
            this.saveRawBitmapVGAToolStripMenuItem});
            this.msDosToolStripMenuItem.Name = "msDosToolStripMenuItem";
            this.msDosToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.msDosToolStripMenuItem.Text = "MsDos";
            // 
            // saveRawBitmapCGAToolStripMenuItem
            // 
            this.saveRawBitmapCGAToolStripMenuItem.Name = "saveRawBitmapCGAToolStripMenuItem";
            this.saveRawBitmapCGAToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.saveRawBitmapCGAToolStripMenuItem.Text = "Save Raw Bitmap (CGA)";
            this.saveRawBitmapCGAToolStripMenuItem.Click += new System.EventHandler(this.saveRawBitmapCGAToolStripMenuItem_Click);
            // 
            // saveRawBitmapEGAToolStripMenuItem
            // 
            this.saveRawBitmapEGAToolStripMenuItem.Name = "saveRawBitmapEGAToolStripMenuItem";
            this.saveRawBitmapEGAToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.saveRawBitmapEGAToolStripMenuItem.Text = "Save Raw Bitmap (EGA)";
            this.saveRawBitmapEGAToolStripMenuItem.Click += new System.EventHandler(this.saveRawBitmapEGAToolStripMenuItem_Click);
            // 
            // saveRawBitmapVGAToolStripMenuItem
            // 
            this.saveRawBitmapVGAToolStripMenuItem.Name = "saveRawBitmapVGAToolStripMenuItem";
            this.saveRawBitmapVGAToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.saveRawBitmapVGAToolStripMenuItem.Text = "Save Raw Bitmap (VGA)";
            this.saveRawBitmapVGAToolStripMenuItem.Click += new System.EventHandler(this.saveRawBitmapVGAToolStripMenuItem_Click);
            // 
            // paletteToClipboardToolStripMenuItem3
            // 
            this.paletteToClipboardToolStripMenuItem3.Name = "paletteToClipboardToolStripMenuItem3";
            this.paletteToClipboardToolStripMenuItem3.Size = new System.Drawing.Size(172, 22);
            this.paletteToClipboardToolStripMenuItem3.Text = "Palette to Clipboard";
            this.paletteToClipboardToolStripMenuItem3.Click += new System.EventHandler(this.paletteToClipboardToolStripMenuItem3_Click);
            // 
            // aRMToolStripMenuItem
            // 
            this.aRMToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.riscOSToolStripMenuItem,
            this.gBAToolStripMenuItem,
            this.nDSToolStripMenuItem,
            this.paletteToClipboardToolStripMenuItem4});
            this.aRMToolStripMenuItem.Name = "aRMToolStripMenuItem";
            this.aRMToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.aRMToolStripMenuItem.Text = "* ARM *";
            // 
            // riscOSToolStripMenuItem
            // 
            this.riscOSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRaw4ColorBitmapToolStripMenuItem,
            this.saveRaw256ColorBitmapToolStripMenuItem});
            this.riscOSToolStripMenuItem.Name = "riscOSToolStripMenuItem";
            this.riscOSToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.riscOSToolStripMenuItem.Text = "RiscOS";
            // 
            // saveRaw4ColorBitmapToolStripMenuItem
            // 
            this.saveRaw4ColorBitmapToolStripMenuItem.Name = "saveRaw4ColorBitmapToolStripMenuItem";
            this.saveRaw4ColorBitmapToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.saveRaw4ColorBitmapToolStripMenuItem.Text = "Save Raw 16 Color Bitmap";
            this.saveRaw4ColorBitmapToolStripMenuItem.Click += new System.EventHandler(this.saveRaw4ColorBitmapToolStripMenuItem_Click);
            // 
            // saveRaw256ColorBitmapToolStripMenuItem
            // 
            this.saveRaw256ColorBitmapToolStripMenuItem.Name = "saveRaw256ColorBitmapToolStripMenuItem";
            this.saveRaw256ColorBitmapToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.saveRaw256ColorBitmapToolStripMenuItem.Text = "Save Raw 256 Color Bitmap";
            this.saveRaw256ColorBitmapToolStripMenuItem.Click += new System.EventHandler(this.saveRaw256ColorBitmapToolStripMenuItem_Click);
            // 
            // gBAToolStripMenuItem
            // 
            this.gBAToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmap4bppToolStripMenuItem,
            this.saveRaw256ColorBitmap4bppToolStripMenuItem,
            this.paletteToClipboardToolStripMenuItem14,
            this.save4bToolStripMenuItem,
            this.save8bpp8x8TilesToolStripMenuItem2});
            this.gBAToolStripMenuItem.Name = "gBAToolStripMenuItem";
            this.gBAToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.gBAToolStripMenuItem.Text = "GBA";
            // 
            // saveRawBitmap4bppToolStripMenuItem
            // 
            this.saveRawBitmap4bppToolStripMenuItem.Name = "saveRawBitmap4bppToolStripMenuItem";
            this.saveRawBitmap4bppToolStripMenuItem.Size = new System.Drawing.Size(266, 22);
            this.saveRawBitmap4bppToolStripMenuItem.Text = "Save Raw 256 color Bitmap (8bpp)";
            this.saveRawBitmap4bppToolStripMenuItem.Click += new System.EventHandler(this.saveRawBitmap4bppToolStripMenuItem_Click);
            // 
            // saveRaw256ColorBitmap4bppToolStripMenuItem
            // 
            this.saveRaw256ColorBitmap4bppToolStripMenuItem.Name = "saveRaw256ColorBitmap4bppToolStripMenuItem";
            this.saveRaw256ColorBitmap4bppToolStripMenuItem.Size = new System.Drawing.Size(266, 22);
            this.saveRaw256ColorBitmap4bppToolStripMenuItem.Text = "Save Raw 32768 color Bitmap (16bpp)";
            this.saveRaw256ColorBitmap4bppToolStripMenuItem.Click += new System.EventHandler(this.saveRaw256ColorBitmap4bppToolStripMenuItem_Click);
            // 
            // paletteToClipboardToolStripMenuItem14
            // 
            this.paletteToClipboardToolStripMenuItem14.Name = "paletteToClipboardToolStripMenuItem14";
            this.paletteToClipboardToolStripMenuItem14.Size = new System.Drawing.Size(266, 22);
            this.paletteToClipboardToolStripMenuItem14.Text = "Palette to clipboard";
            this.paletteToClipboardToolStripMenuItem14.Click += new System.EventHandler(this.paletteToClipboardToolStripMenuItem14_Click);
            // 
            // save4bToolStripMenuItem
            // 
            this.save4bToolStripMenuItem.Name = "save4bToolStripMenuItem";
            this.save4bToolStripMenuItem.Size = new System.Drawing.Size(266, 22);
            this.save4bToolStripMenuItem.Text = "Save 4bpp 8x8 tiles / sprite";
            this.save4bToolStripMenuItem.Click += new System.EventHandler(this.save4bToolStripMenuItem_Click);
            // 
            // save8bpp8x8TilesToolStripMenuItem2
            // 
            this.save8bpp8x8TilesToolStripMenuItem2.Name = "save8bpp8x8TilesToolStripMenuItem2";
            this.save8bpp8x8TilesToolStripMenuItem2.Size = new System.Drawing.Size(266, 22);
            this.save8bpp8x8TilesToolStripMenuItem2.Text = "Save 8bpp 8x8 tiles / sprite";
            this.save8bpp8x8TilesToolStripMenuItem2.Click += new System.EventHandler(this.save8bpp8x8TilesToolStripMenuItem2_Click);
            // 
            // nDSToolStripMenuItem
            // 
            this.nDSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRaw256ColorBitmap8bppToolStripMenuItem,
            this.saveRawBitmapToolStripMenuItem20,
            this.paletteToClipboardToolStripMenuItem15,
            this.save4bpp8x8TilesToolStripMenuItem2,
            this.save8bpp8x8TilesSpriteToolStripMenuItem});
            this.nDSToolStripMenuItem.Name = "nDSToolStripMenuItem";
            this.nDSToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.nDSToolStripMenuItem.Text = "NDS";
            // 
            // saveRaw256ColorBitmap8bppToolStripMenuItem
            // 
            this.saveRaw256ColorBitmap8bppToolStripMenuItem.Name = "saveRaw256ColorBitmap8bppToolStripMenuItem";
            this.saveRaw256ColorBitmap8bppToolStripMenuItem.Size = new System.Drawing.Size(266, 22);
            this.saveRaw256ColorBitmap8bppToolStripMenuItem.Text = "Save Raw 256 color Bitmap (8bpp)";
            this.saveRaw256ColorBitmap8bppToolStripMenuItem.Click += new System.EventHandler(this.saveRaw256ColorBitmap8bppToolStripMenuItem_Click);
            // 
            // saveRawBitmapToolStripMenuItem20
            // 
            this.saveRawBitmapToolStripMenuItem20.Name = "saveRawBitmapToolStripMenuItem20";
            this.saveRawBitmapToolStripMenuItem20.Size = new System.Drawing.Size(266, 22);
            this.saveRawBitmapToolStripMenuItem20.Text = "Save Raw 32768 color Bitmap (16bpp)";
            this.saveRawBitmapToolStripMenuItem20.Click += new System.EventHandler(this.saveRawBitmapToolStripMenuItem20_Click);
            // 
            // paletteToClipboardToolStripMenuItem15
            // 
            this.paletteToClipboardToolStripMenuItem15.Name = "paletteToClipboardToolStripMenuItem15";
            this.paletteToClipboardToolStripMenuItem15.Size = new System.Drawing.Size(266, 22);
            this.paletteToClipboardToolStripMenuItem15.Text = "Palette to clipboard";
            this.paletteToClipboardToolStripMenuItem15.Click += new System.EventHandler(this.paletteToClipboardToolStripMenuItem15_Click);
            // 
            // save4bpp8x8TilesToolStripMenuItem2
            // 
            this.save4bpp8x8TilesToolStripMenuItem2.Name = "save4bpp8x8TilesToolStripMenuItem2";
            this.save4bpp8x8TilesToolStripMenuItem2.Size = new System.Drawing.Size(266, 22);
            this.save4bpp8x8TilesToolStripMenuItem2.Text = "Save 4bpp 8x8 tiles / sprite";
            this.save4bpp8x8TilesToolStripMenuItem2.Click += new System.EventHandler(this.save4bpp8x8TilesToolStripMenuItem2_Click);
            // 
            // save8bpp8x8TilesSpriteToolStripMenuItem
            // 
            this.save8bpp8x8TilesSpriteToolStripMenuItem.Name = "save8bpp8x8TilesSpriteToolStripMenuItem";
            this.save8bpp8x8TilesSpriteToolStripMenuItem.Size = new System.Drawing.Size(266, 22);
            this.save8bpp8x8TilesSpriteToolStripMenuItem.Text = "Save 8bpp 8x8 tiles / sprite";
            this.save8bpp8x8TilesSpriteToolStripMenuItem.Click += new System.EventHandler(this.save8bpp8x8TilesSpriteToolStripMenuItem_Click);
            // 
            // paletteToClipboardToolStripMenuItem4
            // 
            this.paletteToClipboardToolStripMenuItem4.Name = "paletteToClipboardToolStripMenuItem4";
            this.paletteToClipboardToolStripMenuItem4.Size = new System.Drawing.Size(172, 22);
            this.paletteToClipboardToolStripMenuItem4.Text = "Palette to Clipboard";
            this.paletteToClipboardToolStripMenuItem4.Click += new System.EventHandler(this.paletteToClipboardToolStripMenuItem4_Click);
            // 
            // mIPSToolStripMenuItem
            // 
            this.mIPSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pSXToolStripMenuItem,
            this.n64ToolStripMenuItem});
            this.mIPSToolStripMenuItem.Name = "mIPSToolStripMenuItem";
            this.mIPSToolStripMenuItem.Size = new System.Drawing.Size(63, 20);
            this.mIPSToolStripMenuItem.Text = "* MIPS *";
            // 
            // pSXToolStripMenuItem
            // 
            this.pSXToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.save8x8Font16bppToolStripMenuItem});
            this.pSXToolStripMenuItem.Name = "pSXToolStripMenuItem";
            this.pSXToolStripMenuItem.Size = new System.Drawing.Size(91, 22);
            this.pSXToolStripMenuItem.Text = "PSX";
            // 
            // save8x8Font16bppToolStripMenuItem
            // 
            this.save8x8Font16bppToolStripMenuItem.Name = "save8x8Font16bppToolStripMenuItem";
            this.save8x8Font16bppToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.save8x8Font16bppToolStripMenuItem.Text = "Save 8x8 Font (16bpp)";
            this.save8x8Font16bppToolStripMenuItem.Click += new System.EventHandler(this.save8x8Font16bppToolStripMenuItem_Click);
            // 
            // n64ToolStripMenuItem
            // 
            this.n64ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.save8x8Font16bppToolStripMenuItem1});
            this.n64ToolStripMenuItem.Name = "n64ToolStripMenuItem";
            this.n64ToolStripMenuItem.Size = new System.Drawing.Size(91, 22);
            this.n64ToolStripMenuItem.Text = "N64";
            this.n64ToolStripMenuItem.Click += new System.EventHandler(this.n64ToolStripMenuItem_Click);
            // 
            // save8x8Font16bppToolStripMenuItem1
            // 
            this.save8x8Font16bppToolStripMenuItem1.Name = "save8x8Font16bppToolStripMenuItem1";
            this.save8x8Font16bppToolStripMenuItem1.Size = new System.Drawing.Size(186, 22);
            this.save8x8Font16bppToolStripMenuItem1.Text = "Save 8x8 Font (16bpp)";
            this.save8x8Font16bppToolStripMenuItem1.Click += new System.EventHandler(this.save8x8Font16bppToolStripMenuItem1_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fM7ToolStripMenuItem,
            this.dragonToolStripMenuItem,
            this.tRS80CoCo3ToolStripMenuItem});
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(61, 20);
            this.toolStripMenuItem7.Text = "* 6809 *";
            this.toolStripMenuItem7.Click += new System.EventHandler(this.toolStripMenuItem7_Click);
            // 
            // fM7ToolStripMenuItem
            // 
            this.fM7ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmapToolStripMenuItem21,
            this.saveRawBitmap2PlaneToolStripMenuItem,
            this.saveRaw8x8Tiles2PlaneToolStripMenuItem,
            this.saveRaw8x8Tiles3PlaneToolStripMenuItem});
            this.fM7ToolStripMenuItem.Name = "fM7ToolStripMenuItem";
            this.fM7ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.fM7ToolStripMenuItem.Text = "FM-7";
            // 
            // saveRawBitmapToolStripMenuItem21
            // 
            this.saveRawBitmapToolStripMenuItem21.Name = "saveRawBitmapToolStripMenuItem21";
            this.saveRawBitmapToolStripMenuItem21.Size = new System.Drawing.Size(260, 22);
            this.saveRawBitmapToolStripMenuItem21.Text = "Save Raw Bitmap (3 Plane - 8 color)";
            this.saveRawBitmapToolStripMenuItem21.Click += new System.EventHandler(this.saveRawBitmapToolStripMenuItem21_Click);
            // 
            // saveRawBitmap2PlaneToolStripMenuItem
            // 
            this.saveRawBitmap2PlaneToolStripMenuItem.Name = "saveRawBitmap2PlaneToolStripMenuItem";
            this.saveRawBitmap2PlaneToolStripMenuItem.Size = new System.Drawing.Size(260, 22);
            this.saveRawBitmap2PlaneToolStripMenuItem.Text = "Save Raw Bitmap (2 plane - 4 color)";
            this.saveRawBitmap2PlaneToolStripMenuItem.Click += new System.EventHandler(this.saveRawBitmap2PlaneToolStripMenuItem_Click);
            // 
            // saveRaw8x8Tiles2PlaneToolStripMenuItem
            // 
            this.saveRaw8x8Tiles2PlaneToolStripMenuItem.Name = "saveRaw8x8Tiles2PlaneToolStripMenuItem";
            this.saveRaw8x8Tiles2PlaneToolStripMenuItem.Size = new System.Drawing.Size(260, 22);
            this.saveRaw8x8Tiles2PlaneToolStripMenuItem.Text = "Save Raw 8x8 Tiles (2 plane)";
            this.saveRaw8x8Tiles2PlaneToolStripMenuItem.Click += new System.EventHandler(this.saveRaw8x8Tiles2PlaneToolStripMenuItem_Click);
            // 
            // saveRaw8x8Tiles3PlaneToolStripMenuItem
            // 
            this.saveRaw8x8Tiles3PlaneToolStripMenuItem.Name = "saveRaw8x8Tiles3PlaneToolStripMenuItem";
            this.saveRaw8x8Tiles3PlaneToolStripMenuItem.Size = new System.Drawing.Size(260, 22);
            this.saveRaw8x8Tiles3PlaneToolStripMenuItem.Text = "Save Raw 8x8 Tiles (3 plane)";
            this.saveRaw8x8Tiles3PlaneToolStripMenuItem.Click += new System.EventHandler(this.saveRaw8x8Tiles3PlaneToolStripMenuItem_Click);
            // 
            // dragonToolStripMenuItem
            // 
            this.dragonToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRaw4ColorBitmapToolStripMenuItem1,
            this.savToolStripMenuItem});
            this.dragonToolStripMenuItem.Name = "dragonToolStripMenuItem";
            this.dragonToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.dragonToolStripMenuItem.Text = "Dragon/CoCo";
            // 
            // saveRaw4ColorBitmapToolStripMenuItem1
            // 
            this.saveRaw4ColorBitmapToolStripMenuItem1.Name = "saveRaw4ColorBitmapToolStripMenuItem1";
            this.saveRaw4ColorBitmapToolStripMenuItem1.Size = new System.Drawing.Size(200, 22);
            this.saveRaw4ColorBitmapToolStripMenuItem1.Text = "Save Raw 4 color Bitmap";
            this.saveRaw4ColorBitmapToolStripMenuItem1.Click += new System.EventHandler(this.saveRaw4ColorBitmapToolStripMenuItem1_Click);
            // 
            // savToolStripMenuItem
            // 
            this.savToolStripMenuItem.Name = "savToolStripMenuItem";
            this.savToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.savToolStripMenuItem.Text = "Save Raw 2 color Bitmap";
            this.savToolStripMenuItem.Click += new System.EventHandler(this.savToolStripMenuItem_Click);
            // 
            // tRS80CoCo3ToolStripMenuItem
            // 
            this.tRS80CoCo3ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveCoCo46ColorBitmapToolStripMenuItem});
            this.tRS80CoCo3ToolStripMenuItem.Name = "tRS80CoCo3ToolStripMenuItem";
            this.tRS80CoCo3ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.tRS80CoCo3ToolStripMenuItem.Text = "TRS-80 CoCo 3";
            // 
            // saveCoCo46ColorBitmapToolStripMenuItem
            // 
            this.saveCoCo46ColorBitmapToolStripMenuItem.Name = "saveCoCo46ColorBitmapToolStripMenuItem";
            this.saveCoCo46ColorBitmapToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.saveCoCo46ColorBitmapToolStripMenuItem.Text = "Save 4/16 color Bitmap";
            this.saveCoCo46ColorBitmapToolStripMenuItem.Click += new System.EventHandler(this.saveCoCo46ColorBitmapToolStripMenuItem_Click);
            // 
            // tMS9900ToolStripMenuItem
            // 
            this.tMS9900ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tI99ToolStripMenuItem});
            this.tMS9900ToolStripMenuItem.Name = "tMS9900ToolStripMenuItem";
            this.tMS9900ToolStripMenuItem.Size = new System.Drawing.Size(84, 20);
            this.tMS9900ToolStripMenuItem.Text = "* TMS9900 *";
            // 
            // tI99ToolStripMenuItem
            // 
            this.tI99ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmapToolStripMenuItem1});
            this.tI99ToolStripMenuItem.Name = "tI99ToolStripMenuItem";
            this.tI99ToolStripMenuItem.Size = new System.Drawing.Size(98, 22);
            this.tI99ToolStripMenuItem.Text = "TI-99";
            // 
            // saveRawBitmapToolStripMenuItem1
            // 
            this.saveRawBitmapToolStripMenuItem1.Name = "saveRawBitmapToolStripMenuItem1";
            this.saveRawBitmapToolStripMenuItem1.Size = new System.Drawing.Size(161, 22);
            this.saveRawBitmapToolStripMenuItem1.Text = "Save Raw Bitmap";
            this.saveRawBitmapToolStripMenuItem1.Click += new System.EventHandler(this.saveRawBitmapToolStripMenuItem1_Click_1);
            // 
            // pDP11ToolStripMenuItem
            // 
            this.pDP11ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uKNCToolStripMenuItem});
            this.pDP11ToolStripMenuItem.Name = "pDP11ToolStripMenuItem";
            this.pDP11ToolStripMenuItem.Size = new System.Drawing.Size(77, 20);
            this.pDP11ToolStripMenuItem.Text = "* PDP-11 *";
            this.pDP11ToolStripMenuItem.Click += new System.EventHandler(this.pDP11ToolStripMenuItem_Click);
            // 
            // uKNCToolStripMenuItem
            // 
            this.uKNCToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmapToolStripMenuItem19,
            this.saveRawBitmap3BitplanesToolStripMenuItem});
            this.uKNCToolStripMenuItem.Name = "uKNCToolStripMenuItem";
            this.uKNCToolStripMenuItem.Size = new System.Drawing.Size(101, 22);
            this.uKNCToolStripMenuItem.Text = "UKNC";
            // 
            // saveRawBitmapToolStripMenuItem19
            // 
            this.saveRawBitmapToolStripMenuItem19.Name = "saveRawBitmapToolStripMenuItem19";
            this.saveRawBitmapToolStripMenuItem19.Size = new System.Drawing.Size(231, 22);
            this.saveRawBitmapToolStripMenuItem19.Text = "Save Raw Bitmap";
            this.saveRawBitmapToolStripMenuItem19.Click += new System.EventHandler(this.saveRawBitmapToolStripMenuItem19_Click);
            // 
            // saveRawBitmap3BitplanesToolStripMenuItem
            // 
            this.saveRawBitmap3BitplanesToolStripMenuItem.Name = "saveRawBitmap3BitplanesToolStripMenuItem";
            this.saveRawBitmap3BitplanesToolStripMenuItem.Size = new System.Drawing.Size(231, 22);
            this.saveRawBitmap3BitplanesToolStripMenuItem.Text = "Save Raw Bitmap (3 Bitplanes)";
            this.saveRawBitmap3BitplanesToolStripMenuItem.Click += new System.EventHandler(this.saveRawBitmap3BitplanesToolStripMenuItem_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.foenixC256ToolStripMenuItem,
            this.aToolStripMenuItem1,
            this.toolStripMenuItem9});
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(67, 20);
            this.toolStripMenuItem8.Text = "* 65816 *";
            // 
            // foenixC256ToolStripMenuItem
            // 
            this.foenixC256ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.savePaletteToolStripMenuItem1});
            this.foenixC256ToolStripMenuItem.Name = "foenixC256ToolStripMenuItem";
            this.foenixC256ToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.foenixC256ToolStripMenuItem.Text = "Foenix C256";
            // 
            // savePaletteToolStripMenuItem1
            // 
            this.savePaletteToolStripMenuItem1.Name = "savePaletteToolStripMenuItem1";
            this.savePaletteToolStripMenuItem1.Size = new System.Drawing.Size(175, 22);
            this.savePaletteToolStripMenuItem1.Text = "Palette To Clipboard";
            this.savePaletteToolStripMenuItem1.Click += new System.EventHandler(this.savePaletteToolStripMenuItem1_Click);
            // 
            // aToolStripMenuItem1
            // 
            this.aToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.paletteToClipboardToolStripMenuItem13,
            this.saveRawSuperHiResBitmapToolStripMenuItem});
            this.aToolStripMenuItem1.Name = "aToolStripMenuItem1";
            this.aToolStripMenuItem1.Size = new System.Drawing.Size(202, 22);
            this.aToolStripMenuItem1.Text = "Apple IIgs";
            // 
            // paletteToClipboardToolStripMenuItem13
            // 
            this.paletteToClipboardToolStripMenuItem13.Name = "paletteToClipboardToolStripMenuItem13";
            this.paletteToClipboardToolStripMenuItem13.Size = new System.Drawing.Size(231, 22);
            this.paletteToClipboardToolStripMenuItem13.Text = "Palette to Clipboard";
            this.paletteToClipboardToolStripMenuItem13.Click += new System.EventHandler(this.paletteToClipboardToolStripMenuItem13_Click);
            // 
            // saveRawSuperHiResBitmapToolStripMenuItem
            // 
            this.saveRawSuperHiResBitmapToolStripMenuItem.Name = "saveRawSuperHiResBitmapToolStripMenuItem";
            this.saveRawSuperHiResBitmapToolStripMenuItem.Size = new System.Drawing.Size(231, 22);
            this.saveRawSuperHiResBitmapToolStripMenuItem.Text = "Save Raw SuperHi-Res Bitmap";
            this.saveRawSuperHiResBitmapToolStripMenuItem.Click += new System.EventHandler(this.saveRawSuperHiResBitmapToolStripMenuItem_Click);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem11,
            this.toolStripMenuItem10});
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.ShortcutKeyDisplayString = "[?]";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(202, 22);
            this.toolStripMenuItem9.Text = "Super Nintendo / SFC";
            this.toolStripMenuItem9.ToolTipText = "See: https://www.chibiakumas.com/6502/simplesamples.php#LessonS8";
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(179, 22);
            this.toolStripMenuItem11.Text = "Palette to Clipboard";
            this.toolStripMenuItem11.Click += new System.EventHandler(this.toolStripMenuItem11_Click);
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.ShortcutKeyDisplayString = "[?]";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(179, 22);
            this.toolStripMenuItem10.Text = "Save Raw Bitmap";
            this.toolStripMenuItem10.ToolTipText = "See: https://www.chibiakumas.com/6502/simplesamples.php#LessonS8";
            this.toolStripMenuItem10.Click += new System.EventHandler(this.toolStripMenuItem10_Click);
            // 
            // pnlApplePal
            // 
            this.pnlApplePal.BackColor = System.Drawing.SystemColors.Control;
            this.pnlApplePal.Location = new System.Drawing.Point(590, 27);
            this.pnlApplePal.Name = "pnlApplePal";
            this.pnlApplePal.Size = new System.Drawing.Size(433, 48);
            this.pnlApplePal.TabIndex = 30;
            this.pnlApplePal.Visible = false;
            // 
            // bigfont
            // 
            this.bigfont.AutoSize = true;
            this.bigfont.Font = new System.Drawing.Font("MS UI Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.bigfont.Location = new System.Drawing.Point(6, 57);
            this.bigfont.Name = "bigfont";
            this.bigfont.Size = new System.Drawing.Size(14, 19);
            this.bigfont.TabIndex = 31;
            this.bigfont.Text = ".";
            this.bigfont.Visible = false;
            // 
            // pnlULAPal
            // 
            this.pnlULAPal.BackColor = System.Drawing.SystemColors.Control;
            this.pnlULAPal.Controls.Add(this.BtnUlaPalSwap);
            this.pnlULAPal.Location = new System.Drawing.Point(587, 28);
            this.pnlULAPal.Name = "pnlULAPal";
            this.pnlULAPal.Size = new System.Drawing.Size(433, 48);
            this.pnlULAPal.TabIndex = 29;
            this.pnlULAPal.Visible = false;
            // 
            // tabControl2
            // 
            this.tabControl2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Controls.Add(this.tabPalette);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Location = new System.Drawing.Point(786, 560);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(249, 261);
            this.tabControl2.TabIndex = 32;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.chkSimpleSize);
            this.tabPage3.Controls.Add(this.chkFixedSize);
            this.tabPage3.Controls.Add(this.bigfont);
            this.tabPage3.Controls.Add(this.lblSpriteInfo);
            this.tabPage3.Controls.Add(this.btnLastSprite);
            this.tabPage3.Controls.Add(this.btnNextSprite);
            this.tabPage3.Controls.Add(this.btnNextBank);
            this.tabPage3.Controls.Add(this.btnLastBank);
            this.tabPage3.Location = new System.Drawing.Point(4, 21);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(241, 236);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "Info";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // chkSimpleSize
            // 
            this.chkSimpleSize.AutoSize = true;
            this.chkSimpleSize.Checked = true;
            this.chkSimpleSize.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkSimpleSize.Location = new System.Drawing.Point(3, 102);
            this.chkSimpleSize.Name = "chkSimpleSize";
            this.chkSimpleSize.Size = new System.Drawing.Size(104, 16);
            this.chkSimpleSize.TabIndex = 32;
            this.chkSimpleSize.Text = "Size to 8x8 grid";
            this.chkSimpleSize.UseVisualStyleBackColor = true;
            // 
            // tabPalette
            // 
            this.tabPalette.Controls.Add(this.lblAlpha2);
            this.tabPalette.Controls.Add(this.lblAlpha);
            this.tabPalette.Controls.Add(this.trkAlpha);
            this.tabPalette.Location = new System.Drawing.Point(4, 21);
            this.tabPalette.Name = "tabPalette";
            this.tabPalette.Padding = new System.Windows.Forms.Padding(3);
            this.tabPalette.Size = new System.Drawing.Size(241, 236);
            this.tabPalette.TabIndex = 1;
            this.tabPalette.Text = "Palette";
            this.tabPalette.UseVisualStyleBackColor = true;
            // 
            // lblAlpha2
            // 
            this.lblAlpha2.AutoSize = true;
            this.lblAlpha2.Location = new System.Drawing.Point(3, 245);
            this.lblAlpha2.Name = "lblAlpha2";
            this.lblAlpha2.Size = new System.Drawing.Size(102, 12);
            this.lblAlpha2.TabIndex = 2;
            this.lblAlpha2.Text = "Alpha: (32 bit only)";
            this.lblAlpha2.Visible = false;
            // 
            // lblAlpha
            // 
            this.lblAlpha.AutoSize = true;
            this.lblAlpha.Location = new System.Drawing.Point(199, 258);
            this.lblAlpha.Name = "lblAlpha";
            this.lblAlpha.Size = new System.Drawing.Size(23, 12);
            this.lblAlpha.TabIndex = 1;
            this.lblAlpha.Text = "255";
            this.lblAlpha.Visible = false;
            // 
            // trkAlpha
            // 
            this.trkAlpha.Cursor = System.Windows.Forms.Cursors.Default;
            this.trkAlpha.Location = new System.Drawing.Point(0, 258);
            this.trkAlpha.Maximum = 255;
            this.trkAlpha.Name = "trkAlpha";
            this.trkAlpha.Size = new System.Drawing.Size(201, 42);
            this.trkAlpha.TabIndex = 0;
            this.trkAlpha.TickFrequency = 5;
            this.trkAlpha.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trkAlpha.Value = 255;
            this.trkAlpha.Visible = false;
            this.trkAlpha.Scroll += new System.EventHandler(this.trkAlpha_Scroll);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.Black;
            this.tabPage4.Controls.Add(this.label18);
            this.tabPage4.Controls.Add(this.btnYoutube);
            this.tabPage4.Controls.Add(this.label17);
            this.tabPage4.Controls.Add(this.pictureBox1);
            this.tabPage4.Controls.Add(this.btnLearnAsm);
            this.tabPage4.Controls.Add(this.label12);
            this.tabPage4.Location = new System.Drawing.Point(4, 21);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(241, 236);
            this.tabPage4.TabIndex = 2;
            this.tabPage4.Text = "About";
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label18.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label18.Location = new System.Drawing.Point(65, 33);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(163, 15);
            this.label18.TabIndex = 34;
            this.label18.Text = "http://www.learnasm.net";
            this.label18.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // btnYoutube
            // 
            this.btnYoutube.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnYoutube.FlatAppearance.BorderColor = System.Drawing.Color.Red;
            this.btnYoutube.FlatAppearance.BorderSize = 3;
            this.btnYoutube.Font = new System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnYoutube.ForeColor = System.Drawing.Color.Black;
            this.btnYoutube.Location = new System.Drawing.Point(127, 150);
            this.btnYoutube.Name = "btnYoutube";
            this.btnYoutube.Size = new System.Drawing.Size(106, 82);
            this.btnYoutube.TabIndex = 37;
            this.btnYoutube.Text = "Subscribe to my Youtube for Programming Videos";
            this.btnYoutube.UseVisualStyleBackColor = false;
            this.btnYoutube.Click += new System.EventHandler(this.btnYoutube_Click);
            // 
            // label17
            // 
            this.label17.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label17.ForeColor = System.Drawing.Color.Yellow;
            this.label17.Location = new System.Drawing.Point(58, 15);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(179, 18);
            this.label17.TabIndex = 36;
            this.label17.Text = "AkuSprite Editor";
            this.label17.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::AkuSpriteEditor.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(5, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(54, 56);
            this.pictureBox1.TabIndex = 35;
            this.pictureBox1.TabStop = false;
            // 
            // btnLearnAsm
            // 
            this.btnLearnAsm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnLearnAsm.FlatAppearance.BorderColor = System.Drawing.Color.Red;
            this.btnLearnAsm.FlatAppearance.BorderSize = 3;
            this.btnLearnAsm.Font = new System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnLearnAsm.ForeColor = System.Drawing.Color.Black;
            this.btnLearnAsm.Location = new System.Drawing.Point(7, 150);
            this.btnLearnAsm.Name = "btnLearnAsm";
            this.btnLearnAsm.Size = new System.Drawing.Size(106, 82);
            this.btnLearnAsm.TabIndex = 34;
            this.btnLearnAsm.Text = "Check out the Assembly tutorials online!";
            this.btnLearnAsm.UseVisualStyleBackColor = false;
            this.btnLearnAsm.Click += new System.EventHandler(this.btnLearnAsm_Click);
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label12.ForeColor = System.Drawing.Color.Cyan;
            this.label12.Location = new System.Drawing.Point(6, 74);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(232, 73);
            this.label12.TabIndex = 33;
            this.label12.Text = "This program is FREE and Open Source...\r\n\r\nUse the \'Help\' button at the bottom le" +
                "ft to get online help!";
            this.label12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // tmrHideInfo
            // 
            this.tmrHideInfo.Enabled = true;
            this.tmrHideInfo.Interval = 10000;
            this.tmrHideInfo.Tick += new System.EventHandler(this.tmrHideInfo_Tick);
            // 
            // saveHalfHeightRawBitmap8x4ToolStripMenuItem
            // 
            this.saveHalfHeightRawBitmap8x4ToolStripMenuItem.Name = "saveHalfHeightRawBitmap8x4ToolStripMenuItem";
            this.saveHalfHeightRawBitmap8x4ToolStripMenuItem.Size = new System.Drawing.Size(241, 22);
            this.saveHalfHeightRawBitmap8x4ToolStripMenuItem.Text = "Save HalfHeight Raw Bitmap 8x4";
            this.saveHalfHeightRawBitmap8x4ToolStripMenuItem.Click += new System.EventHandler(this.saveHalfHeightRawBitmap8x4ToolStripMenuItem_Click);
            // 
            // pETToolStripMenuItem
            // 
            this.pETToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmapToolStripMenuItem22});
            this.pETToolStripMenuItem.Name = "pETToolStripMenuItem";
            this.pETToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.pETToolStripMenuItem.Text = "PET";
            // 
            // saveRawBitmapToolStripMenuItem22
            // 
            this.saveRawBitmapToolStripMenuItem22.Name = "saveRawBitmapToolStripMenuItem22";
            this.saveRawBitmapToolStripMenuItem22.Size = new System.Drawing.Size(161, 22);
            this.saveRawBitmapToolStripMenuItem22.Text = "Save Raw Bitmap";
            this.saveRawBitmapToolStripMenuItem22.Click += new System.EventHandler(this.saveRawBitmapToolStripMenuItem22_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1039, 833);
            this.Controls.Add(this.tabControl2);
            this.Controls.Add(this.pnlULAPal);
            this.Controls.Add(this.pnlNESpal);
            this.Controls.Add(this.pnlApplePal);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.trkzoom);
            this.Controls.Add(this.pnlMSXpal);
            this.Controls.Add(this.picPreview);
            this.Controls.Add(this.BtnAltPal);
            this.Controls.Add(this.pnlC64pal);
            this.Controls.Add(this.pnlZXPalette);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btnSetPal);
            this.Controls.Add(this.tabSpriteTools);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "AkuSprite Editor";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.picPreview)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkzoom)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabEditor.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.grpSpriteSize.ResumeLayout(false);
            this.grpSpriteSize.PerformLayout();
            this.GrpFrameOverlay.ResumeLayout(false);
            this.GrpFrameOverlay.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabNotes.ResumeLayout(false);
            this.tabNotes.PerformLayout();
            this.tabSpriteTools.ResumeLayout(false);
            this.tabSpriteOptions.ResumeLayout(false);
            this.tabSpriteOptions.PerformLayout();
            this.tabPixelPaint.ResumeLayout(false);
            this.tabPixelPaint.PerformLayout();
            this.tabZXPaint.ResumeLayout(false);
            this.tabZXPaint.PerformLayout();
            this.tabColorSwap.ResumeLayout(false);
            this.tabColorSwap.PerformLayout();
            this.tabTileCopy.ResumeLayout(false);
            this.tabTileCopy.PerformLayout();
            this.tabVector.ResumeLayout(false);
            this.tabVector.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.pnlULAPal.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPalette.ResumeLayout(false);
            this.tabPalette.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trkAlpha)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox picPreview;
        private System.Windows.Forms.TrackBar trkzoom;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabEditor;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdoGuideNone;
        private System.Windows.Forms.RadioButton rdoGuide4_8_24;
        private System.Windows.Forms.RadioButton rdoGuide4_8_32;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.ListBox lstSprites;
        private System.Windows.Forms.Button btnSetPal;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rdoDisplaySpeccy;
        private System.Windows.Forms.RadioButton rdoDisplayCPC;
        private System.Windows.Forms.RadioButton rdoDisplayMSX;
        private System.Windows.Forms.Timer tmrBackup;
        private System.Windows.Forms.Button btnUndo;
        private System.Windows.Forms.Button btnRedo;
        private System.Windows.Forms.Button btnNextSprite;
        private System.Windows.Forms.Button btnLastSprite;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem cPCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mSXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadSpectrumScreenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveSpectrumBinaryToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saveMSXASMPaletteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveMSXBinaryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem pasteZXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyPreviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem canvasSizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem loadCPCBinaryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadCPCBinaryToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saveCPCBinaryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveSpritesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem savePaletteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyToClipboardToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteToClipToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem fourColor2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem invertZXToolStripMenuItem1;
        private System.Windows.Forms.CheckBox chkStrongGrid;
        private System.Windows.Forms.ToolStripMenuItem saveSpectrumScreenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rLEASMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rLEASMToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem rLEASMCOLORToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bMPToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveMSXBitmapToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saveMSXBitmapWithPaletteToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saveMSXBitmapSpritesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rLEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buildRLEASMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveMSXRLEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem spriteCompilerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addOneToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem spriteCompilerToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem addOneToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem duplicateFromToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transformToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem flipXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem flipYToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ViewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mSX16ColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cPC4ColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zX2ColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem highVisToggleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reSaveSpritesToolStripMenuItem;
        private System.Windows.Forms.Button btnNextBank;
        private System.Windows.Forms.Button btnLastBank;
        private System.Windows.Forms.ToolStripMenuItem duplicateOffsetFromToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveMSXRLEPaletteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveMSXRLESpritesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yInterlaceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setAllAttribsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveSpectrumTilesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pxShiftToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem blackBorderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pixelShiftRightToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pixelShiftDownToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pixelShiftUpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveASMPaletteToolStripMenuItem;
        private System.Windows.Forms.GroupBox GrpFrameOverlay;
        private System.Windows.Forms.RadioButton rdoFrameNext;
        private System.Windows.Forms.RadioButton rdoFrameNone;
        private System.Windows.Forms.RadioButton rdoFrameLast;
        private System.Windows.Forms.ToolStripMenuItem overlayLastFrameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem overlayNextFrameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem makeTilesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tileShiftXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem blackBorderTightToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem PaletteTint;
        private System.Windows.Forms.ToolStripMenuItem saveSpectrumFontToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem halfSizeFontToolStripMenuItem;
        private System.Windows.Forms.CheckBox ChkBackgroundTestDots;
        private System.Windows.Forms.ToolStripMenuItem saveCPCBinaryToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sAMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eNTToolStripMenuItem;
        private System.Windows.Forms.GroupBox grpSpriteSize;
        private System.Windows.Forms.RadioButton rdospr512;
        private System.Windows.Forms.RadioButton rdospr256;
        private System.Windows.Forms.ToolStripMenuItem SaveCPCRawBmp;
        private System.Windows.Forms.RadioButton rdoDisplayCPC0;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem saveRAWBitmapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem saveRAWBitmapToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem saveCPCZigTileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sMSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem saveRLEToolStripMenuItem;
        private System.Windows.Forms.RadioButton rdoCPCpairs;
        private System.Windows.Forms.RadioButton RdoTIquarter;
        private System.Windows.Forms.ToolStripMenuItem saveRAWMSX1BitmapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRawVdpTileBitmapToolStripMenuItem;
        private System.Windows.Forms.RadioButton rdoSpecDither;
        private System.Windows.Forms.RadioButton rdoCPCdither;
        private System.Windows.Forms.ToolStripMenuItem saveCPCSCRToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapToolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem z80ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem neoGeoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveFIXFontToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem CpcSpriteCompilerClear;
        private System.Windows.Forms.ToolStripMenuItem CpcSpriteConvaddOneDiffToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem atariSTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapToolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem AmigaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapToolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem x68000ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapToolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem atari5200800ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem megaDriveGenesisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapToolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem aToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem atariLynxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bBCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem c64ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nESFamicomToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pCEngineToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem superNintendoSFCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vic20ToolStripMenuItem;
        private System.Windows.Forms.Button btnToolPixelPaint;
        private System.Windows.Forms.Button btnZXpaint2;
        private System.Windows.Forms.Button btnColorSwap2;
        private System.Windows.Forms.TabControl tabSpriteTools;
        private System.Windows.Forms.TabPage tabSpriteOptions;
        private System.Windows.Forms.Label lblSpriteInfo;
        private System.Windows.Forms.CheckBox chkFixedSize;
        private System.Windows.Forms.CheckBox chkAligned;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSpriteSettings;
        private System.Windows.Forms.TabPage tabPixelPaint;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabPage tabZXPaint;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cboZxPaintMode;
        private System.Windows.Forms.TabPage tabColorSwap;
        private System.Windows.Forms.ComboBox cboColorConvertMode;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel pnlZXPalette;
        private System.Windows.Forms.Button BtnAltPal;
        private System.Windows.Forms.Panel pnlC64pal;
        private System.Windows.Forms.Panel pnlNESpal;
        private System.Windows.Forms.Panel pnlMSXpal;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cboFillCheck;
        private System.Windows.Forms.ToolStripMenuItem cPC16ColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem colorpairsCPCENTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colorditheredCPCENTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colorditheredToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox cbo4colorDither;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem applyViewColorConversionToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem rLEASMToolStripMenuItem2;
        private System.Windows.Forms.RadioButton rdoGuide7_14_28;
        private System.Windows.Forms.ToolStripMenuItem loadPaletteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadPixelsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importBackgroundToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmap2ColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmap4ColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmap4ColorToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmap2ColorToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapToolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapToolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmap4ColorToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapToolStripMenuItem13;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapToolStripMenuItem14;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapToolStripMenuItem15;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapToolStripMenuItem16;
        private System.Windows.Forms.ToolStripMenuItem saveBMPMapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadBMPMaToolStripMenuItem;
        private System.Windows.Forms.RadioButton rdoC64_4Color;
        private System.Windows.Forms.Panel pnlApplePal;
        private System.Windows.Forms.RadioButton rdoAppleColor;
        private System.Windows.Forms.Label bigfont;
        private System.Windows.Forms.TabPage tabNotes;
        private System.Windows.Forms.TextBox txtNotes;
        private System.Windows.Forms.ToolStripMenuItem recentFilesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem recent1;
        private System.Windows.Forms.ToolStripMenuItem recent2;
        private System.Windows.Forms.ToolStripMenuItem recent3;
        private System.Windows.Forms.ToolStripMenuItem recent4;
        private System.Windows.Forms.ToolStripMenuItem recent5;
        private System.Windows.Forms.ToolStripMenuItem recent6;
        private System.Windows.Forms.ToolStripMenuItem recent7;
        private System.Windows.Forms.ToolStripMenuItem recent8;
        private System.Windows.Forms.ToolStripMenuItem recent9;
        private System.Windows.Forms.ToolStripMenuItem recent10;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveBinarySpritesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem savePCESpriteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveSprite2ColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveSprite4ColorToolStripMenuItem;
        private System.Windows.Forms.RadioButton rdoC64Sprite;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmap2ColorToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem saveRAWMSX1Raw16x16SpriteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem save16colorLinearSpriteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem save8colorLinearSpriteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem save16ColorRLESpriteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem save8ColorRLESpriteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem save4ColorRLESpriteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem save2ColorRLESpriteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem camputersLynxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapToolStripMenuItem17;
        private System.Windows.Forms.RadioButton rdoHalfWidthFourColor;
        private System.Windows.Forms.RadioButton rdoVic20MultiColor;
        private System.Windows.Forms.ToolStripMenuItem saveRaw8x8TileBitmapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sinclairQLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem raw8colorBitmapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveSpriteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem raw4colorBitmapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem x86ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem aRMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wonderSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapToolStripMenuItem18;
        private System.Windows.Forms.ToolStripMenuItem saveSpriteToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saveRawSpriteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRaw8x8TilesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRaw8x8TilesToolStripMenuItem1;
        private System.Windows.Forms.RadioButton RdoDisplayEGX;
        private System.Windows.Forms.ToolStripMenuItem eGX416ColorCPCToolStripMenuItem;
        private System.Windows.Forms.Button btnTileCopy;
        private System.Windows.Forms.TabPage tabTileCopy;
        private System.Windows.Forms.ToolStripMenuItem tilesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addTilesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clearTilesToolStripMenuItem;
        private System.Windows.Forms.TextBox txtFirstTile;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtNextTile;
        private System.Windows.Forms.Label lblNextTile;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cboTileFormat;
        private System.Windows.Forms.ToolStripMenuItem saveRawSpriteToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmap2bitPlanarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmap4bitLinearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmap2bitLinearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem msDosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapCGAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapEGAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapVGAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem riscOSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRaw4ColorBitmapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gBAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmap4bppToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paletteToClipboardToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paletteToClipboardToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem paletteToClipboardToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem paletteToClipboardToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem paletteToClipboardToolStripMenuItem4;
        private System.Windows.Forms.Button BtnClearAdd;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RadioButton rdoULAplus;
        private System.Windows.Forms.Panel pnlULAPal;
        private System.Windows.Forms.Button BtnUlaPalSwap;
        private System.Windows.Forms.ToolStripMenuItem specNEXTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveULAScreenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveNEXTPaletteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveULAScreenPaletteOnlyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveNEXT9BitPaletteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveLoResLayerRadasjimianRawBitmap128x96ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem x16ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem save8bppRawBitmapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem save4bppRawBitmalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem save8bppRawBitmapToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem save4bppRawBitmapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRaw8x8TilemapToolStripMenuItem;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPalette;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ToolStripMenuItem tMS9900ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tI99ToolStripMenuItem;
        private System.Windows.Forms.RadioButton rdoSprWide;
        private System.Windows.Forms.RadioButton rdoVGA;
        private System.Windows.Forms.ToolStripMenuItem loadSpriteToolStripMenuItem;
        private System.Windows.Forms.RadioButton rdoGuide16_32_64;
        private System.Windows.Forms.RadioButton rdoDisplay256;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtFixedFileSize;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.CheckBox chkHasDosHeader;
        private System.Windows.Forms.TextBox txtSpriteDataOffSet;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtNeoSprHeight;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtNeoSprSkip;
        private System.Windows.Forms.CheckBox chkSimpleSize;
        private System.Windows.Forms.ToolStripMenuItem palettesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem defauktToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem enterprise256ColorToolStripMenuItem;
        private System.Windows.Forms.RadioButton rdoDispEnt256;
        private System.Windows.Forms.ToolStripMenuItem simple4x4x4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem loadFromPALIrfanviewToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saveToPALirfanviewToolStripMenuItem1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.ToolStripMenuItem colorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem save4bpp16x16SpritesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem save8bpp16x16SpritesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paletteToClipboardRGBToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox txtHspriteH;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtHspriteW;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnFloodFill;
        private System.Windows.Forms.ComboBox cboCheckMode;
        private System.Windows.Forms.Label lblMaxSpritesByOffset;
        private System.Windows.Forms.ToolStripMenuItem save4bpp8x8TilesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem save8bpp8x8TilesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem save8bpp16x16TilesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem save4bpp8x8TilesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saveMSX2RawYJKBitmapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveMSX2RawYJKABitmapYAEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem interlaceOddFieldsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem interlaceEvenFieldsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importImageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fromFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fromFilewithPaletteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pDP11ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uKNCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapToolStripMenuItem19;
        private System.Windows.Forms.ToolStripMenuItem mSX1PaletteToolStripMenuItem;
        private System.Windows.Forms.RadioButton rdoMSX1Color;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmap3BitplanesToolStripMenuItem;
        private System.Windows.Forms.CheckBox chkTransparency;
        private System.Windows.Forms.ToolStripMenuItem fileProcessorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rLECompressPerByteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rLECompressAlternatingBytesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rLECompressFourBytesToolStripMenuItem;
        private System.Windows.Forms.Button btnHelp;
        private System.Windows.Forms.Button btnLearnAsm;
        private System.Windows.Forms.Timer tmrHideInfo;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button btnOnlineHelp;
        private System.Windows.Forms.Button btnYoutube;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ToolStripMenuItem mIPSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pSXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem save8x8Font16bppToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem n64ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem save8x8Font16bppToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem nDSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapToolStripMenuItem20;
        private System.Windows.Forms.RadioButton rdoRGBA;
        private System.Windows.Forms.ToolStripMenuItem greyScalePaletteToolStripMenuItem;
        private System.Windows.Forms.RadioButton rdoChannel;
        private System.Windows.Forms.Label lblAlpha;
        private System.Windows.Forms.TrackBar trkAlpha;
        private System.Windows.Forms.Label lblAlpha2;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.RadioButton rdoBnk32;
        private System.Windows.Forms.RadioButton rdoBnk8;
        private System.Windows.Forms.RadioButton rdoBnk16;
        private System.Windows.Forms.RadioButton rdoBnk4;
        private System.Windows.Forms.ToolStripMenuItem saveRaw256ColorBitmapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRaw256ColorBitmap4bppToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRaw256ColorBitmap8bppToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sMSPaletteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gGPaletteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paletteToClipboardToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem fM7ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapToolStripMenuItem21;
        private System.Windows.Forms.ToolStripMenuItem mSX2PaletteToClipboardToolStripMenuItem;
        private System.Windows.Forms.Button btnVector;
        private System.Windows.Forms.TabPage tabVector;
        private System.Windows.Forms.TextBox txtVectors;
        private System.Windows.Forms.Button btnVectorToClip;
        private System.Windows.Forms.Button btnVectorClear;
        private System.Windows.Forms.ComboBox CboVectorType;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ToolStripMenuItem save8bpp8x8TilesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem paletteToClipboardToolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem paletteToClipboardToolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem paletteToClipboardToolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem saveRaw8x82colorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paletteToClipboardToolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem raw8Color8x8BitmapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sQLCLX8ColorPaletteToolStripMenuItem;
        private System.Windows.Forms.RadioButton rdo8Color;
        private System.Windows.Forms.ToolStripMenuItem paletteToClipboardToolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem saveRaw8x8BitmapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paletteToClipboardToolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem copperlistPaletteToClipboardToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paletteToClipboardToolStripMenuItem12;
        private System.Windows.Forms.Button btnZ80Vec;
        private System.Windows.Forms.ToolStripMenuItem spritesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem spriteSpace8x816x16ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveTi8416bitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveTi83BitmapBWToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paletteToClipboard15bitBGRToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveTi84Bitmap4bppToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveSprite4ColorToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem dragonCOCOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem palette0GToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem palette1WCMOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dragonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRaw4ColorBitmapToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem savToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tRS80CoCo3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveCoCo46ColorBitmapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem foenixC256ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem savePaletteToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem aToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem paletteToClipboardToolStripMenuItem13;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem saveRawSuperHiResBitmapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRaw8x8Tiles4ColorZigTileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmap2PlaneToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRaw8x8Tiles2PlaneToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRaw8x8Tiles3PlaneToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveDoubleHeightBitmapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmap2bpp4ColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem save4bppSpriteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem save8bppSpriteToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.CheckBox chkSaveMultiRaw;
        private System.Windows.Forms.Button btnExportInfo;
        private System.Windows.Forms.ToolStripMenuItem generatePixelMapToolStripMenuItem;
        private System.Windows.Forms.ComboBox cboDeres;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtSaveTileCount;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ToolStripMenuItem deresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem halveYToolStripMenuItem;
        private System.Windows.Forms.Button btnMatchAll;
        private System.Windows.Forms.ToolStripMenuItem paletteToClipboardToolStripMenuItem14;
        private System.Windows.Forms.ToolStripMenuItem save4bToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem save4bpp8x8TilesToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem paletteToClipboardToolStripMenuItem15;
        private System.Windows.Forms.ToolStripMenuItem saveRaw8x4Tiles4ColorHalfHeightToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem save8bpp8x8TilesToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem save8bpp8x8TilesSpriteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem save2bpp8x8TilesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem save2bppRawBitmapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem save2bpp8x8TilesHalfHeightToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem insertBlankSpriteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addMultipleToolStripMenuItem;
        private System.Windows.Forms.Button btnExportTilelist;
        private System.Windows.Forms.ToolStripMenuItem deresAllMultipleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveCDSpriteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveHalfHeightRawBitmap8x4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pETToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapToolStripMenuItem22;
    }
}

