﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace AkuSpriteEditor
{
    public partial class Form1 : Form
    {
        public bool firsthelp = true;
        public bool helpon = false;
        public Bitmap bmpZoom;
        public Bitmap bmpTileCopySource;
        public Bitmap bmpPalette;
        public byte[, , ,] spritepixel;
        public byte[, , ,] SpeccyPaletteF;   //foreground
        public byte[, , ,] SpeccyPaletteB;   //Background
        public byte[, , ,] SpeccyPaletteL;   //Lightness
        AkuSpriteEditor.CompCPC CpcSpriteCompiler;
        AkuSpriteEditor.CompZX ZxSpriteCompiler;
        public byte[, ,] Bak_spritepixel;
        public byte[, ,] Bak_SpeccyPaletteF;   //foreground
        public byte[, ,] Bak_SpeccyPaletteB;   //Background
        public byte[, ,] Bak_SpeccyPaletteL;   //Lightness
        public byte[,] TileCopyNum;   //Lightness
        int NextBackup = -1;
        int MinBackup = 0;
        int CurrentBackup = -1;
        public int LastVectorX = 128;
        public int LastVectorY = 128;
        public int VectorCount = 0;
        string VectorString = "";
        public Label[] ColorSelector;
        public Label[,] SpeccySelector;
        public Label[] C64Selector;
        public Label SpeccySample;
        public PictureBoxWithInterpolationMode picTileCopySource;
        public PictureBoxWithInterpolationMode PicZoom;
        public PictureBoxWithInterpolationMode picPalette;
        public byte colorLeft = 15;
        public byte colorRight = 0;
        public byte SpeccyColorFore = 7;
        public byte SpeccyColorBack = 0;
        public byte SpeccyColorBright = 0;
        public byte C64Color1 = 0;
        public byte C64Color2 = 0;
        public byte C64Color3 = 0;
        public byte AppleColor = 0;
        public Label AppleSelector;
        public int CurrentSprite = 0;
        public int CurrentBank = 0;
        public int LastBank = 0;
        public Int16[] Spr_Wid;
        public Int16[] Spr_Hei;
        public Int16[] Spr_MinX;
        public Int16[] Spr_MinY;
        public Int16[] Spr_Xoff;
        public Int16[] Spr_Yoff;
        public int BankCount = 4;
        public int BankSpriteCount = 64;
        public int UndoBuffers = 10;
        public int[] Spr_Mempos;
        public byte[] Spr_MemposReset;
        public byte[] Spr_FixedSize;
        public int SpriteCount;
        public bool RespondToDrag = false;
        //public int LastSetPixelX, LastSetPixelY; // Used for checking mouse movement
        public Color[] Speccypalettedark = { Color.Black, Color.DarkBlue, Color.DarkRed, Color.DarkMagenta, Color.Green, Color.DarkCyan, Color.YellowGreen, Color.DarkGray, Color.DarkGray, Color.LightGray };
        public Color[] Speccypalette = { Color.Black, Color.Blue, Color.Red, Color.Magenta, Color.Lime, Color.Cyan, Color.Yellow, Color.White, Color.DarkGray, Color.LightGray };
        public Color[] QLpalette = { Color.Black, Color.Blue, Color.Red, Color.Magenta, Color.Lime, Color.Cyan, Color.Yellow, Color.White, Color.White, Color.White, Color.White, Color.White, Color.White, Color.White, Color.White, Color.White };
        public byte[] PetBlocks = { 0x60, 0x7E, 0x7C, 0xE2, 0x7B, 0x61, 0xFF, 0xEC, 0x6C, 0x7F, 0xE1, 0xFB, 0x62, 0xFC, 0xFE, 0xE0 };
        public Color[] C64palette = { Color.Black, Color.White,
                                           Color.FromArgb(136,0,0),Color.FromArgb(170,255,255),
                                           Color.FromArgb(204,68,204),Color.FromArgb(0,204,85),
                                           Color.FromArgb(0,0,170),Color.FromArgb(238,238,119),

                                           Color.FromArgb(221,136,85),Color.FromArgb(102,68,0),
                                           Color.FromArgb(255,119,119),Color.FromArgb(51,51,51),
                                           Color.FromArgb(119,119,119),Color.FromArgb(170,255,102),
                                           Color.FromArgb(0,136,255),Color.FromArgb(187,187,187),
                                           };

        public Color[] NESpalette = { 
                                           Color.FromArgb(173,173,173),Color.FromArgb(21,95,217),
                                           Color.FromArgb(66,64,255),Color.FromArgb(117,39,254),
                                           Color.FromArgb(160,26,204),Color.FromArgb(183,30,123),
                                           Color.FromArgb(181,49,32),Color.FromArgb(153,78,0),

                                           Color.FromArgb(107,109,0),Color.FromArgb(56,135,0),
                                           Color.FromArgb(13,147,0),Color.FromArgb(0,143,50),
                                           Color.FromArgb(0,124,141),Color.FromArgb(0,0,0),
                                           Color.FromArgb(0,0,0),Color.FromArgb(0,0,0),
                                      
                                           };
        public Color[] MSXpalette = { 
                                           Color.FromArgb(0,0,0),Color.FromArgb(0,0,0),
                                           Color.FromArgb(33,200,66),Color.FromArgb(94,220,120),
                                           Color.FromArgb(84,85,237),Color.FromArgb(124,118,252),
                                           Color.FromArgb(212,82,77),Color.FromArgb(66,235,245),

                                           Color.FromArgb(252,85,84),Color.FromArgb(255,121,120),
                                           Color.FromArgb(212,193,84),Color.FromArgb(230,206,128),
                                           Color.FromArgb(33,176,59),Color.FromArgb(201,91,186),
                                           Color.FromArgb(204,204,204),Color.FromArgb(255,255,255),
                                      
                                           };
        public Color[] DragonPal0 = { Color.FromArgb(0, 255, 0), Color.FromArgb(255, 255, 0), Color.FromArgb(0, 0, 255), Color.FromArgb(64, 0, 24), Color.FromArgb(64, 0, 24), Color.FromArgb(64, 0, 24), Color.FromArgb(64, 0, 24), Color.FromArgb(64, 0, 24), Color.FromArgb(64, 0, 24), Color.FromArgb(64, 0, 24), Color.FromArgb(64, 0, 24), Color.FromArgb(64, 0, 24), Color.FromArgb(64, 0, 24), Color.FromArgb(64, 0, 24), Color.FromArgb(64, 0, 24), Color.FromArgb(64, 0, 24) };
        public Color[] DragonPal1 = { Color.FromArgb(255, 255, 255), Color.FromArgb(0, 255, 192), Color.FromArgb(255, 0, 255), Color.FromArgb(255, 128, 0), Color.FromArgb(255, 128, 0), Color.FromArgb(255, 128, 0), Color.FromArgb(255, 128, 0), Color.FromArgb(255, 128, 0), Color.FromArgb(255, 128, 0), Color.FromArgb(255, 128, 0), Color.FromArgb(255, 128, 0), Color.FromArgb(255, 128, 0), Color.FromArgb(255, 128, 0), Color.FromArgb(255, 128, 0), Color.FromArgb(255, 128, 0), Color.FromArgb(255, 128, 0) };
        public int backuptimer = 0;
        public int maxSpriteSizeX = 256;
        public int maxSpriteSizeY = 256;
        public string lastfilename = "";
        public string CurrentTool = "";
        public void InitMaxSpriteSize()
        {
            spritepixel = null;
            SpeccyPaletteF = null;
            SpeccyPaletteB = null;
            SpeccyPaletteL = null;

            Bak_spritepixel = null;
            Bak_SpeccyPaletteF = null;
            Bak_SpeccyPaletteB = null;
            Bak_SpeccyPaletteL = null;
            bmpZoom = null;

            bmpZoom = new Bitmap(maxSpriteSizeX + 1, maxSpriteSizeY + 1);

            bmpTileCopySource = new Bitmap(8, 8);
            spritepixel = new byte[BankCount, 64, maxSpriteSizeX, maxSpriteSizeY];
            SpeccyPaletteF = new byte[BankCount, 64, maxSpriteSizeX / 7, maxSpriteSizeY / 8];
            SpeccyPaletteB = new byte[BankCount, 64, maxSpriteSizeX / 7, maxSpriteSizeY / 8];
            SpeccyPaletteL = new byte[BankCount, 64, maxSpriteSizeX / 7, maxSpriteSizeY / 8];
            ClearSprites();
            Bak_spritepixel = new byte[UndoBuffers, maxSpriteSizeX, maxSpriteSizeY];
            Bak_SpeccyPaletteF = new byte[UndoBuffers, maxSpriteSizeX / 7, maxSpriteSizeY / 8];
            Bak_SpeccyPaletteB = new byte[UndoBuffers, maxSpriteSizeX / 7, maxSpriteSizeY / 8];
            Bak_SpeccyPaletteL = new byte[UndoBuffers, maxSpriteSizeX / 7, maxSpriteSizeY / 8];

        }
        /************************************************************************************************************************************************/

        public Form1()
        {
            InitializeComponent();
            InitMaxSpriteSize();

            CboVectorType.Text = "Packet";

            Spr_Wid = new Int16[256];
            Spr_Hei = new Int16[256];
            Spr_MinX = new Int16[256];
            Spr_MinY = new Int16[256];
            Spr_MemposReset = new byte[256];
            Spr_FixedSize = new byte[256];
            Spr_Mempos = new int[256];
            Spr_Xoff = new Int16[256];
            Spr_Yoff = new Int16[256];
            ColorSelector = new Label[19];
            SpeccySelector = new Label[11, 2];
            C64Selector = new Label[19];

            TileCopyNum = new byte[8, 8];
            PicZoom = new PictureBoxWithInterpolationMode();
            PicZoom.Padding = new Padding(0, 0, 0, 0);
            PicZoom.Top = 0;
            PicZoom.Left = 0;
            PicZoom.Anchor = AnchorStyles.Top | AnchorStyles.Left;


            picTileCopySource = new PictureBoxWithInterpolationMode();
            picTileCopySource.Width = 80;
            picTileCopySource.Height = 80;
            picTileCopySource.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.NearestNeighbor;
            picTileCopySource.SizeMode = PictureBoxSizeMode.Zoom;


            tabTileCopy.Controls.Add(picTileCopySource);

            PicZoom.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.NearestNeighbor;
            PicZoom.MouseMove += new MouseEventHandler(PicZoom_Drag);
            PicZoom.MouseDown += new MouseEventHandler(PicZoom_Down);
            PicZoom.MouseUp += new MouseEventHandler(PicZoom_Up);
            this.MouseWheel += new MouseEventHandler(PicZoom_Wheel);


            panel1.Controls.Add(PicZoom);
            PicZoom.Image = bmpZoom;
            picPreview.Image = bmpZoom;
            PicZoom.SizeMode = PictureBoxSizeMode.Zoom;

            bmpPalette = new Bitmap(17, 17);
            tabControl2.SelectedIndex = 2;

            panel1.Controls.Add(PicZoom);
            picPalette = new PictureBoxWithInterpolationMode();
            picPalette.Image = bmpPalette;
            picPalette.SizeMode = PictureBoxSizeMode.StretchImage;
            picPalette.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.NearestNeighbor;
            picPalette.Width = 220;
            picPalette.Height = 220;
            picPalette.Left = 10;
            picPalette.Top = 10;
            tabPalette.Controls.Add(picPalette);
            picPalette.MouseDown += new MouseEventHandler(picPalette_MouseDown);
            for (int i = 0; i <= 63; i++)
            {
                lstSprites.Items.Add(VbX.Right("00" + i.ToString(), 2) + " ");
            }
            lstSprites.SelectedIndex = 0;
            for (int i = 0; i < 19; i++)
            {
                ColorSelector[i] = new Label();
                ColorSelector[i].BorderStyle = BorderStyle.FixedSingle;
                if (i < 16)
                {
                    Color c = DP.DefPalette[i];
                    setpalette(i, c);
                }
                ColorSelector[i].Name = "Colorselector_" + i.ToString();
                if (i == 16) setpalette(i, Color.FromArgb(255, 255, 128, 255));
                if (i == 17) ColorSelector[i].BackColor = Color.FromArgb(255, 255, 255, 255);
                if (i == 18) ColorSelector[i].BackColor = Color.FromArgb(255, 0, 0, 0);
                if (i < 16) ColorSelector[i].Text = VbX.Hex(i);
                ColorSelector[i].Width = 32;
                ColorSelector[i].Height = 40;
                ColorSelector[i].Top = 4 + menuStrip1.Height;
                ColorSelector[i].Left = i * 32;
                if (i >= 17) ColorSelector[i].Left += 12;
                ColorSelector[i].MouseDown += new MouseEventHandler(ColorSelector_MouseDown);
                this.Controls.Add(ColorSelector[i]);
            }
            for (int i = 0; i <= 10; i++)
            {

                Label sp = new Label();
                sp.BorderStyle = BorderStyle.FixedSingle;

                sp.Name = "SpeccyBack_" + i.ToString();

                if (i == 8) { sp.Name = "SpeccyDark"; sp.Text = "0"; }
                if (i == 9) { sp.Name = "SpeccyLight"; sp.Text = "64"; }
                if (i < 10)
                {
                    sp.BackColor = Speccypalette[i];
                }



                sp.Width = 32;
                sp.Height = 24;
                sp.Top = 0;

                if (i >= 8)
                {
                    sp.Top += 12;
                }
                else
                {
                    sp.Text = VbX.CStr(i * 8);
                }
                sp.Left = i * 32;// +ColorSelector[18].Left;
                //sp.Left += 32 + 16;
                sp.MouseDown += new MouseEventHandler(SpeccySelector_MouseDown);
                pnlZXPalette.Controls.Add(sp);
                SpeccySelector[i, 0] = sp;
                if (i < 8)
                {
                    sp = new Label();
                    sp.BorderStyle = BorderStyle.FixedSingle;

                    sp.Text = VbX.CStr(i);
                    sp.BackColor = Speccypalette[i];

                    sp.Name = "SpeccyFore_" + i.ToString();

                    sp.Width = 32;
                    sp.Height = 24;
                    sp.Top = 24;
                    sp.Left = i * 32;// +ColorSelector[18].Left;
                    // sp.Left += 32 + 16;
                    sp.MouseDown += new MouseEventHandler(SpeccySelector_MouseDown);
                    pnlZXPalette.Controls.Add(sp);
                    SpeccySelector[i, 1] = sp;
                }
            }
            for (int i = 0; i <= 10; i++)
            {

                Label sp = new Label();
                sp.BorderStyle = BorderStyle.FixedSingle;

                sp.Name = "C64Back_" + (i + 8).ToString();

                if (i == 8) { sp.Name = "C64C1"; sp.Text = "C1"; C64Color1 = 1; sp.BackColor = C64palette[1]; }
                if (i == 9) { sp.Name = "C64C2"; sp.Text = "C2"; C64Color2 = 2; sp.BackColor = C64palette[2]; }
                if (i == 10) { sp.Name = "C64C3"; sp.Text = "C3"; C64Color1 = 3; sp.BackColor = C64palette[3]; }
                if (i < 8)
                {
                    sp.BackColor = C64palette[i + 8];
                }

                sp.Width = 32;
                sp.Height = 24;
                sp.Top = 24;

                if (i >= 8)
                {
                    sp.Top -= 12;
                }
                else
                {
                    sp.Text = VbX.CStr(i);
                }
                sp.Left = i * 32;// +ColorSelector[18].Left;
                //sp.Left += 32 + 16;

                //pnlC64pal.Controls.Add(sp);
                // SpeccySelector[i, 0] = sp;

                sp.MouseDown += new MouseEventHandler(C64Selector_MouseDown);
                pnlC64pal.Controls.Add(sp);
                C64Selector[i + 8] = sp;
                if (i < 8)
                {
                    sp = new Label();
                    sp.BorderStyle = BorderStyle.FixedSingle;

                    sp.Text = VbX.CStr(i + 8);
                    sp.BackColor = C64palette[i];

                    sp.Name = "C64Fore_" + (i).ToString();

                    sp.Width = 32;
                    sp.Height = 24;
                    sp.Top = 0;
                    sp.Left = i * 32;// +ColorSelector[18].Left;
                    // sp.Left += 32 + 16;
                    sp.MouseDown += new MouseEventHandler(C64Selector_MouseDown);
                    pnlC64pal.Controls.Add(sp);
                    C64Selector[i] = sp;
                }

            }

            for (int i = 0; i <= 2; i++)
            {

                Label sp = new Label();
                sp.BorderStyle = BorderStyle.FixedSingle;

                sp.Name = "APLBack_" + i.ToString();
                sp.Font = bigfont.Font;
                if (i == 0 || i == 2)
                {
                    sp.BackColor = Color.FromArgb(255, 0, 255);
                    sp.ForeColor = Color.FromArgb(0, 255, 0);


                }
                if (i == 1)
                {
                    sp.BackColor = Color.FromArgb(0, 175, 255);
                    sp.ForeColor = Color.FromArgb(255, 80, 0);
                }


                sp.Width = 32;
                sp.Height = 24;
                sp.Top = 12;
                sp.Left = i * 32;
                if (i < 2)
                {
                    sp.Text = VbX.CStr(i);
                }
                else { sp.Text = "S"; sp.Left += 16; AppleSelector = sp; }
                sp.Left = i * 32;// +ColorSelector[18].Left;
                //sp.Left += 32 + 16;
                sp.MouseDown += new MouseEventHandler(AppleSelector_MouseDown);
                pnlApplePal.Controls.Add(sp);

                // SpeccySelector[i, 0] = sp;


            }
            for (int i = 0; i <= 7; i++)
            {

                Label sp = new Label();
                sp.BorderStyle = BorderStyle.FixedSingle;

                sp.Name = "NESBack_" + i.ToString();

                if (i == 8) { sp.Name = "NESDark"; sp.Text = "0"; }
                if (i == 9) { sp.Name = "NESLight"; sp.Text = "64"; }
                if (i < 10)
                {
                    sp.BackColor = NESpalette[i];
                }



                sp.Width = 32;
                sp.Height = 24;
                sp.Top = 0;

                if (i >= 8)
                {
                    sp.Top += 12;
                }
                else
                {
                    sp.Text = VbX.CStr(i);
                }
                sp.Left = i * 32;// +ColorSelector[18].Left;
                //sp.Left += 32 + 16;
                sp.MouseDown += new MouseEventHandler(SpeccySelector_MouseDown);
                pnlNESpal.Controls.Add(sp);
                // SpeccySelector[i, 0] = sp;
                if (i < 8)
                {
                    sp = new Label();
                    sp.BorderStyle = BorderStyle.FixedSingle;

                    sp.Text = VbX.CStr(i + 8);
                    sp.BackColor = NESpalette[i + 8];

                    sp.Name = "NESFore_" + i.ToString();

                    sp.Width = 32;
                    sp.Height = 24;
                    sp.Top = 24;
                    sp.Left = i * 32;// +ColorSelector[18].Left;
                    // sp.Left += 32 + 16;
                    sp.MouseDown += new MouseEventHandler(SpeccySelector_MouseDown);
                    pnlNESpal.Controls.Add(sp);
                    // SpeccySelector[i, 1] = sp;
                }
            }
            for (int i = 0; i <= 7; i++)
            {

                Label sp = new Label();
                sp.BorderStyle = BorderStyle.FixedSingle;

                sp.Name = "MSXBack_" + i.ToString();

                if (i == 8) { sp.Name = "MSXDark"; sp.Text = "0"; }
                if (i == 9) { sp.Name = "MSXLight"; sp.Text = "64"; }
                if (i < 10)
                {
                    sp.BackColor = MSXpalette[i];
                }



                sp.Width = 32;
                sp.Height = 24;
                sp.Top = 0;

                if (i >= 8)
                {
                    sp.Top += 12;
                }
                else
                {
                    sp.Text = VbX.CStr(i);
                }
                sp.Left = i * 32;// +ColorSelector[18].Left;
                //sp.Left += 32 + 16;
                sp.MouseDown += new MouseEventHandler(SpeccySelector_MouseDown);
                pnlMSXpal.Controls.Add(sp);
                // SpeccySelector[i, 0] = sp;
                if (i < 8)
                {
                    sp = new Label();
                    sp.BorderStyle = BorderStyle.FixedSingle;

                    sp.Text = VbX.CStr(i + 8);
                    sp.BackColor = MSXpalette[i + 8];

                    sp.Name = "MSXFore_" + i.ToString();

                    sp.Width = 32;
                    sp.Height = 24;
                    sp.Top = 24;
                    sp.Left = i * 32;// +ColorSelector[18].Left;
                    // sp.Left += 32 + 16;
                    sp.MouseDown += new MouseEventHandler(SpeccySelector_MouseDown);
                    pnlMSXpal.Controls.Add(sp);
                    // SpeccySelector[i, 1] = sp;
                }
            }
            pnlMSXpal.Location = pnlZXPalette.Location;
            pnlNESpal.Location = pnlZXPalette.Location;
            pnlC64pal.Location = pnlZXPalette.Location;
            pnlApplePal.Location = pnlZXPalette.Location;
            pnlULAPal.Location = pnlZXPalette.Location;
            SpeccySampleUpdate();

            btnToolPixelPaint_Click(null, null);
            btnRefresh_Click(null, null);
            trkzoom.Value = 4;
            doscale(trkzoom.Value);



            string recentfile = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase).Replace("file:\\", "") + "\\AkuSprite.recent";
            if (VbX.exists(recentfile))
            {
                System.IO.StreamReader sr = new System.IO.StreamReader(recentfile);
                recent1.Text = sr.ReadLine();
                recent2.Text = sr.ReadLine();
                recent3.Text = sr.ReadLine();
                recent4.Text = sr.ReadLine();
                recent5.Text = sr.ReadLine();
                recent6.Text = sr.ReadLine();
                recent7.Text = sr.ReadLine();
                recent8.Text = sr.ReadLine();
                recent9.Text = sr.ReadLine();
                recent10.Text = sr.ReadLine();
                sr.Close();
            }
            simple4x4x4ToolStripMenuItem_Click(null, null);
        }

        /************************************************************************************************************************************************/

        private void doscale(int scale)
        {
            //PicZoom.zoom = scale;
            PicZoom.Width = maxSpriteSizeX * scale;
            PicZoom.Height = maxSpriteSizeY * scale;
        }
        /************************************************************************************************************************************************/
        private void ResetBackupTimer()
        {
            backuptimer = 0;
            tmrBackup.Enabled = true;
            btnUndo.Text = "Undo?";

        }
        /************************************************************************************************************************************************/
        private void RepaintArea(int x, int y)
        {

            int xx = x / 8;
            int yy = y / 8;
            xx = xx * 8;
            yy = yy * 8;
            for (int ax = xx; ax < xx + 8; ax++)
            {
                for (int ay = yy; ay < yy + 8; ay++)
                {
                    RepaintPixel(ax, ay);
                }
            }


        }
        /************************************************************************************************************************************************/
        private Color getpalette(int pen)
        {
            if (pen <= 16)
            {
                return ColorSelector[pen].BackColor;
            }
            int x = pen % 16;
            int y = pen / 16;
            return bmpPalette.GetPixel(x + 1, y + 1);


        }
        private void setpalette(int pen, Color c)
        {
            int x = pen % 16;
            int y = pen / 16;
            bmpPalette.SetPixel(x + 1, y + 1, c);
            picPalette.Refresh();
            if (pen <= 16)
            {
                ColorSelector[pen].BackColor = c;
            }
        }
        private int GetDisplayPaletteFB(ref int ColorF, ref int ColorB, int cb, int cs, int x, int y)
        {
            int x2 = x / 8; x2 = x2 * 8;


            ColorB = spritepixel[cb, cs, x2, y];
            ColorF = -1;
            for (int xx = 1; xx < 8; xx++)
            {
                int cc = spritepixel[cb, cs, x2 + xx, y];
                if (cc != ColorB)
                {
                    if (cc < ColorB)
                    {
                        ColorF = ColorB;
                        ColorB = cc;

                    }
                    if (cc > ColorF)
                    {
                        ColorF = cc;
                    }

                    if (ColorF < ColorB)
                    {
                        int tmp = ColorF;
                        ColorF = ColorB;
                        ColorB = tmp;

                    }
                }

            }
            if (ColorF == -1) ColorF = 15 - ColorB;

            if (ColorF < ColorB)
            {
                int tmp = ColorF;
                ColorF = ColorB;
                ColorB = tmp;

            }

            return 0;



        }
        private byte GetDisplayNum(int cb, int cs, int x, int y)
        {
            byte pen = spritepixel[cb, cs, x, y];

            if (chkTransparency.Checked)
            {
                if (rdoDisplayCPC.Checked)
                {
                    if (pen == 16) pen = 3; else pen = 0;
                }
                else
                    if (pen == 16) pen = 15; else pen = 0;
            }

            if (rdoMSX1Color.Checked)
            { //MSX test
                int ColorB = -1;
                int ColorF = -1;
                GetDisplayPaletteFB(ref ColorF, ref ColorB, cb, cs, x, y);
                if (pen == ColorF) return (byte)ColorF; else return (byte)ColorB;

            }

            if (rdoDisplayMSX.Checked)
            {
                pen = (byte)(pen % 16);

            }
            if (rdoSpecDither.Checked)
            {

                Color c = getpalette(pen);
                int r = c.R;
                int g = c.G;
                int b = c.B;



                g = (r + g + b + g + g);
                g = g / 5;
                if (pen == 0) g = 0;
                if (g < 4) return 0;

                if (g > 256 - 80) return 4;
                if (g < 48) return checkerize(x, y, 0, 4, 2);
                if (g > 256 - 160) return checkerize(x, y, 4, 0, 2);
                return checkerize(x, y, 4, 0, 1);
            }
            if (rdo8Color.Checked)
            {

                pen = (byte)(pen % 8);
            }
            if (rdoCPCdither.Checked)
            {
                Color c = getpalette(pen);
                int r = c.R;
                int g = c.G;
                int b = c.B;



                g = (r + g + b + g + g);



                if (cbo4colorDither.Text == "Alternate")
                {
                    g = (g + 100) / 5;

                    if (pen == 0) g = 0;
                    if (g < 32) return 0;
                    if (g > 150) return 3;
                    g = g / 32;

                }
                else
                {

                    g = g / 5;

                    if (pen == 0) g = 0;
                    if (g < 4) return 0;
                    if (g > 248) return 3;
                    g = g / 32;
                }




                byte col1 = 0;
                byte col2 = 0;

                if (g / 3 == 0) { col1 = 0; col2 = 1; }
                if (g / 3 == 1) { col1 = 1; col2 = 2; }
                if (g / 3 == 2) { col1 = 2; col2 = 3; }

                if (g % 3 == 0) { return checkerize(x, y, col1, col2, 2); }
                if (g % 3 == 1) { return checkerize(x, y, col1, col2, 1); }
                if (g % 3 == 2) { return checkerize(x, y, col2, col1, 2); }

            }

            if (RdoTIquarter.Checked)
            {
                x = x * 2;
                y = y * 2;
                if (x > 255) return 0;
                if (y > 255) return 0;
            }
            if (rdoVic20MultiColor.Checked)
            {
                x = x / 2;
                x = x * 2;

                int pena = spritepixel[cb, cs, x, y];
                int penb = spritepixel[cb, cs, x + 1, y];
                if (pena > 0) pena = 2;
                if (penb > 0) penb = 1;
                pen = (byte)(pena + penb);

            }
            if (rdoDisplayCPC0.Checked || (RdoDisplayEGX.Checked && y % 2 == 1) || rdoC64_4Color.Checked || rdoAppleColor.Checked || rdoHalfWidthFourColor.Checked)
            {
                x = x / 2;
                x = x * 2;

                pen = spritepixel[cb, cs, x, y];
                byte penb = spritepixel[cb, cs, x + 1, y];


                if (pen == 0) pen = penb;
            }
            if (rdoDispEnt256.Checked)
            {
                x = x / 4;
                x = x * 4;

                pen = spritepixel[cb, cs, x, y];
                byte penb = spritepixel[cb, cs, x + 3, y];


                if (pen == 0) pen = penb;
            }
            if ((rdoCPCpairs.Checked || rdoHalfWidthFourColor.Checked) && pen < 16)
            {
                int p = pen;
                if (p > 3)
                {
                    p = (p - 4) % 2 + 1;
                }
                pen = ((byte)p);
            }
            if ((rdoDisplayCPC.Checked || (RdoDisplayEGX.Checked && y % 2 == 0)) && pen < 16)
            {
                int p = pen;
                if (p > 3) p = p % 3 + 1;
                pen = ((byte)p);
            }
            if ((rdoDisplaySpeccy.Checked || rdoULAplus.Checked || RdoTIquarter.Checked) && pen > 0 && pen < 16)
            {

                pen = 1;
            }
            return pen;

        }
        /************************************************************************************************************************************************/
        private Color GetDisplayRGB(int cb, int cs, int x, int y)   // Get a color from the screen (appying viewmodes)
        {


            //if (cb < 0 || cb > 16) return Color.Black;

            byte pen = GetDisplayNum(cb, cs, x, y);         //get pixel colornum


            Color mc = getpalette(pen);                     //Get palette from color 

            int r = mc.R;
            int g = mc.G;
            int b = mc.B;
            int a = 255;
            if (rdoChannel.Checked)
            {
                r = spritepixel[cb + 0, cs, x, y];
                g = spritepixel[cb + 0, cs, x, y];
                b = spritepixel[cb + 0, cs, x, y];
            }
            if (rdoRGBA.Checked)
            {

                r = spritepixel[cb + 0, cs, x, y];
                g = spritepixel[cb + 1, cs, x, y];
                b = spritepixel[cb + 2, cs, x, y];
                a = spritepixel[cb + 3, cs, x, y];
                //VbX.MsgBox(a.ToString());
            }
            /*
            if (rdoSpecDither.Checked)                      // Spectrum 2 color dither
            {
                if (pen == 0) { return Color.FromArgb(0, 0, 0); }
                return Color.FromArgb(255, 255, 255);
            }

            if (rdoCPCdither.Checked)
            {
                if (pen == 0) { return Color.FromArgb(0, 0, 0); }
                if (pen == 1) { return Color.FromArgb(96, 0, 96); }
                if (pen == 2) { return Color.FromArgb(0, 255, 255); }
                if (pen == 3) { return Color.FromArgb(255, 255, 255); }


            }
             */
            if (rdoAppleColor.Checked)
            {
                pen = (byte)(pen % 4);

                if (pen == 0 || x / 7 > 32) { return Color.Black; }
                if (SpeccyPaletteF[CurrentBank, CurrentSprite, x / 7, y / 8] == 0)
                {
                    if (pen == 1) { return Color.FromArgb(255, 0, 255); }
                    if (pen == 2) { return Color.FromArgb(0, 255, 0); }
                }
                else
                {
                    if (pen == 1) { return Color.FromArgb(0, 175, 255); }
                    if (pen == 2) { return Color.FromArgb(255, 80, 0); }
                }
                if (pen >= 3) { return Color.FromArgb(255, 255, 255); }

            }

            if (rdoC64_4Color.Checked)
            {
                pen = (byte)(pen % 4);
                if (pen == 0) { return ColorSelector[0].BackColor; }
                if (pen == 1) { return C64palette[SpeccyPaletteF[CurrentBank, CurrentSprite, x / 8, y / 8]]; }
                if (pen == 2) { return C64palette[SpeccyPaletteB[CurrentBank, CurrentSprite, x / 8, y / 8]]; }
                if (pen == 3) { return C64palette[SpeccyPaletteL[CurrentBank, CurrentSprite, x / 8, y / 8]]; }

            }

            if (rdoULAplus.Checked)
            {
                if (ChkBackgroundTestDots.Checked && (x % 4) == 0 && (y % 4) == 0)
                {
                    pen = 1;
                    Color c = getpalette(pen);
                    r = c.R;
                    g = c.G;
                    b = c.B;
                }

                int specb = SpeccyPaletteB[CurrentBank, CurrentSprite, x / 8, y / 8];
                int specf = SpeccyPaletteF[CurrentBank, CurrentSprite, x / 8, y / 8];

                if (pen == 0)
                {
                    r = ColorSelector[specb].BackColor.R;
                    g = ColorSelector[specb].BackColor.G;
                    b = ColorSelector[specb].BackColor.B;
                }
                else
                {
                    r = ColorSelector[specf].BackColor.R;
                    g = ColorSelector[specf].BackColor.G;
                    b = ColorSelector[specf].BackColor.B;
                }

            }

            if ((rdoDisplaySpeccy.Checked || rdoSpecDither.Checked || RdoTIquarter.Checked) && pen < 16) // apply the spectrum effect!
            {
                if (ChkBackgroundTestDots.Checked && (x % 4) == 0 && (y % 4) == 0)
                {
                    pen = 1;
                }

                int specb = SpeccyPaletteB[CurrentBank, CurrentSprite, x / 8, y / 8];
                int specf = SpeccyPaletteF[CurrentBank, CurrentSprite, x / 8, y / 8];
                if (specb > 7) specb = 7;
                if (specf > 7) specf = 7;
                if (SpeccyPaletteL[CurrentBank, CurrentSprite, x / 8, y / 8] == 0)
                {
                    if (pen == 0)
                    {
                        r = Speccypalettedark[specb].R;
                        g = Speccypalettedark[specb].G;
                        b = Speccypalettedark[specb].B;
                    }
                    else
                    {
                        r = Speccypalettedark[specf].R;
                        g = Speccypalettedark[specf].G;
                        b = Speccypalettedark[specf].B;
                    }
                }
                else
                {
                    if (pen == 0)
                    {
                        r = Speccypalette[specb].R;
                        g = Speccypalette[specb].G;
                        b = Speccypalette[specb].B;
                    }
                    else
                    {
                        r = Speccypalette[specf].R;
                        g = Speccypalette[specf].G;
                        b = Speccypalette[specf].B;
                    }
                }

            } // End of spectrum palette tweaks

            return Color.FromArgb(a, r, g, b);
        }
        /************************************************************************************************************************************************/
        private void RepaintPixel(int x, int y)
        {

            int gridcol1 = 56 / 2;
            int gridcol2 = 64 / 2;
            int gridcol3 = 80 / 2;
            if (chkStrongGrid.Checked)
            {
                gridcol1 = 56;
                gridcol2 = 64;
                gridcol3 = 80;

            }

            Color mycolor = GetDisplayRGB(CurrentBank, CurrentSprite, x, y);

            int r = mycolor.R;
            int g = mycolor.G;
            int b = mycolor.B;
            //float a = 0.5F;
            float a = ((float)mycolor.A) / 255;

            if (rdoFrameNext.Checked && (CurrentBank + 1 < BankCount))
            {

                Color mycolor2 = GetDisplayRGB(CurrentBank + 1, CurrentSprite, x, y);
                r = (int)(((float)r) * .7 + mycolor2.R * .3);
                g = (int)(((float)g) * .7 + mycolor2.G * .3);
                b = (int)(((float)b) * .7 + mycolor2.B * .3);
            }


            if (rdoFrameLast.Checked && (CurrentBank - 1 >= 0))
            {
                Color mycolor2 = GetDisplayRGB(CurrentBank - 1, CurrentSprite, x, y);
                r = (int)(((float)r) * .7 + mycolor2.R * .3);
                g = (int)(((float)g) * .7 + mycolor2.G * .3);
                b = (int)(((float)b) * .7 + mycolor2.B * .3);
            }



            int rx = 0;
            int gx = 0;
            int bx = 0;




            if (!rdoGuideNone.Checked)
            {
                if (rdoC64Sprite.Checked)
                {
                    if (((x / 8) % 2) == 0) rx = gridcol2;
                    if (((y / 7) % 2) == 0)
                    {
                        if (rx == gridcol2) rx = 0; else rx = gridcol2;
                    }
                }
                if (rdoGuide4_8_32.Checked || rdoGuide4_8_24.Checked)
                {
                    if (((x / 8) % 2) == 0) rx = gridcol2;
                    if (((y / 8) % 2) == 0)
                    {
                        if (rx == gridcol2) rx = 0; else rx = gridcol2;
                    }
                }

                if (rdoGuide16_32_64.Checked)
                {
                    if (((x / 16) % 2) == 0) rx = gridcol2;
                    if (((y / 16) % 2) == 0)
                    {
                        if (rx == gridcol2) rx = 0; else rx = gridcol2;
                    }
                }
                if (rdoGuide7_14_28.Checked)
                {

                    if (((x / 7) % 2) == 0) rx = gridcol2;
                    if (((y / 7) % 2) == 0)
                    {
                        if (rx == gridcol2) rx = 0; else rx = gridcol2;
                    }

                    if (((x / 28) % 2) == 0) gx = gridcol1;
                    if (((y / 28) % 2) == 0)
                    {
                        if (gx == 0) gx = gridcol1; else gx = 0;
                    }
                    if (((x / 7) % 2) == 0) bx = gridcol3;
                }
                if (rdoC64Sprite.Checked)
                {
                    if (((x / 24) % 2) == 0) gx = gridcol1;
                    if (((y / 21) % 2) == 0)
                    {
                        if (gx == 0) gx = gridcol1; else gx = 0;
                    }
                    if (((x / 4) % 2) == 0) bx = gridcol3;
                }
                if (rdoGuide4_8_24.Checked)
                {
                    if (((x / 24) % 2) == 0) gx = gridcol1;
                    if (((y / 24) % 2) == 0)
                    {
                        if (gx == 0) gx = gridcol1; else gx = 0;
                    }
                    if (((x / 4) % 2) == 0) bx = gridcol3;
                }

                if (rdoGuide4_8_32.Checked)
                {
                    if (((x / 32) % 2) == 0) gx = gridcol1;
                    if (((y / 32) % 2) == 0)
                    {
                        if (gx == 0) gx = gridcol1; else gx = 0;
                    }
                    if (((x / 4) % 2) == 0) bx = gridcol3;
                }

                if (rdoGuide16_32_64.Checked)
                {
                    if (((x / 64) % 2) == 0) gx = gridcol1;
                    if (((y / 64) % 2) == 0)
                    {
                        if (gx == 0) gx = gridcol1; else gx = 0;
                    }
                    if (((x / 8) % 2) == 0) bx = gridcol3;
                }

            }



            r = (int)(((double)r) * a) + rx;
            g = (int)(((double)g) * a) + gx;
            b = (int)(((double)b) * a) + bx;



            if (r > 255) r = 255;
            if (g > 255) g = 255;
            if (b > 255) b = 255;

            bmpZoom.SetPixel(x + 1, y + 1, Color.FromArgb(255, r, g, b));
        }

        /************************************************************************************************************************************************/

        private byte checkerize(int x, int y, byte col1, byte col2, int pattern)      // create 'checkerboard' dithered paterns from forecolor/backcolor
        {
            int c = 1;
            if (pattern == 1)
            {
                if (x % 2 == 1) c = 1 - c;
                if (y % 2 == 1) c = 1 - c;
            }
            if (pattern == 2)
            {
                if (((x % 2 == y % 4 && y % 2 == 1) || (y % 2 == x % 4 && x % 2 == 1)) && x % 4 != y % 4) c = 1 - c;
            }
            if (pattern == 3)
            {
                if (x % 2 == 1) c = 1 - c;
                if (y % 2 == 1) c = 1 - c;
                c = 1 - c;
            }
            if (c == 1) return col1; else return col2;

        }
        /************************************************************************************************************************************************/
        private void PicZoom_Up(object sender, EventArgs e)
        {
            RespondToDrag = false;
        }
        private void PicZoom_Down(object sender, EventArgs e)
        {
            RespondToDrag = true;
            PicZoom_Drag(sender, e);
        }
        /************************************************************************************************************************************************/
        private void PicZoom_Wheel(object sender, System.Windows.Forms.MouseEventArgs e)        // handle scrollweel
        {

            int numberOfTextLinesToMove = e.Delta * SystemInformation.MouseWheelScrollLines / 120;
            int numberOfPixelsToMove = numberOfTextLinesToMove;
            // VbX.MsgBox("wheel" + numberOfPixelsToMove.ToString());
            // VbX.MsgBox(SystemInformation.MouseWheelScrollLines.ToString());


            if (ModifierKeys == Keys.Alt)       // Alt=Change Bank
            {
                if (numberOfPixelsToMove > 0)
                {
                    btnNextBank_Click(null, null);
                }
                if (numberOfPixelsToMove < 0)
                {
                    btnLastBank_Click(null, null);
                }


            }
            else if (ModifierKeys == Keys.Control)  //CTRL= Change Sprite
            {
                if (numberOfPixelsToMove > 0)
                {
                    btnNextSprite_Click(null, null);
                }
                if (numberOfPixelsToMove < 0)
                {
                    btnLastSprite_Click(null, null);
                }


            }
            else
            {
                if (numberOfPixelsToMove > 0)      // Regular=Zoom
                {
                    if (trkzoom.Value < trkzoom.Maximum) trkzoom.Value++;
                    trkzoom_Scroll(null, null);
                }
                if (numberOfPixelsToMove < 0)
                {
                    if (trkzoom.Value > trkzoom.Minimum) trkzoom.Value--;
                    trkzoom_Scroll(null, null);
                }
            }
        }

        /************************************************************************************************************************************************/
        private void PicZoom_Drag(object sender, EventArgs e)   // handle mouse click/drag on bitmap window
        {
            tabControl1.SelectedTab = tabControl1.TabPages[0];
            tabControl1.Focus();

            if (RespondToDrag == false) return;
            int chkr = 0;
            if (cboCheckMode.Text == "1/3") chkr = 1;
            if (cboCheckMode.Text == "2/3") chkr = 2;
            if (cboCheckMode.Text == "3/3") chkr = 3;

            var mouseEventArgs = e as MouseEventArgs;
            if (mouseEventArgs != null)
            {


                float scale = trkzoom.Value;
                float halfscale = scale / 2;
                float fx = (mouseEventArgs.X - halfscale) * maxSpriteSizeX;
                float fy = (mouseEventArgs.Y - halfscale) * maxSpriteSizeY;
                fx = fx / ((maxSpriteSizeX - 1) * scale);
                fy = fy / ((maxSpriteSizeY - 1) * scale);

                int x = (int)fx;//((mouseEventArgs.X - halfscale)) / scale;
                int y = (int)fy;//((mouseEventArgs.Y - halfscale)) / scale;


                //  VbX.MsgBox(mouseEventArgs.X.ToString());
                if (x > (maxSpriteSizeX - 1)) x = (maxSpriteSizeX - 1);
                if (y > (maxSpriteSizeY - 1)) y = (maxSpriteSizeY - 1);


                //x=x-1;
                //y=y-1;
                if (x < 0 || y < 0 || x > (maxSpriteSizeX - 1) || y > (maxSpriteSizeY - 1)) return;




                //// Tile Copy
                if (CurrentTool == "tilecopy")
                {
                    TileCopy(x, y, mouseEventArgs, false);
                    return;
                };

                if (mouseEventArgs.Button == MouseButtons.Middle || mouseEventArgs.Button == MouseButtons.XButton1)
                {
                    colorLeft = spritepixel[CurrentBank, CurrentSprite, x, y];
                    //ColorSelector[17].BackColor = getpalette(colorLeft);
                    if (rdoRGBA.Checked)
                    {
                        ColorSelector[17].BackColor = GetDisplayRGB(CurrentBank, CurrentSprite, x, y);
                    }
                    else
                    {
                        ColorSelector[17].BackColor = getpalette(colorLeft);
                    }
                    return;
                }
                if (mouseEventArgs.Button == MouseButtons.XButton2)
                {
                    colorRight = spritepixel[CurrentBank, CurrentSprite, x, y];
                    if (rdoRGBA.Checked)
                    {
                        ColorSelector[18].BackColor = GetDisplayRGB(CurrentBank, CurrentSprite, x, y);
                    }
                    else
                    {
                        ColorSelector[18].BackColor = getpalette(colorRight);
                    }
                    return;
                }

                //if (LastSetPixelX == x && LastSetPixelY == y)
                //{                    return;                }
                // Floodfill

                if (CurrentTool == "vector")
                {

                    x = x / 2;
                    y = y / 2;
                    x = x * 2;
                    y = y * 2;
                    int VectorXoff = x - LastVectorX;
                    int VectorYoff = LastVectorY - y;
                    Graphics g = Graphics.FromImage(bmpZoom);

                    if (VectorXoff / 2 == 0 && VectorYoff / 2 == 0) return;
                    if (CboVectorType.Text.ToLower() == "duffy")
                    {

                        g.DrawLine(Pens.PapayaWhip, LastVectorX, LastVectorY, x, y);
                        txtVectors.Text += "    dc.b $" + VbX.Dec2Hex8bit(VectorYoff / 2) + ",$" + VbX.Dec2Hex8bit(VectorXoff / 2) + VbX.nl();
                        VectorString += "1," + x.ToString() + "," + y.ToString() + VbX.nl();
                    }

                    if (CboVectorType.Text.ToLower() == "packet")
                    {
                        if (mouseEventArgs.Button == MouseButtons.Left)
                        {

                            g.DrawLine(Pens.PapayaWhip, LastVectorX, LastVectorY, x, y);
                            txtVectors.Text += "    dc.b $FF,$" + VbX.Dec2Hex8bit(VectorYoff / 2) + ",$" + VbX.Dec2Hex8bit(VectorXoff / 2) + VbX.nl();
                            VectorString += "1," + x.ToString() + "," + y.ToString() + VbX.nl();
                        }
                        if (mouseEventArgs.Button == MouseButtons.Right)
                        {
                            txtVectors.Text += "    dc.b $00,$" + VbX.Dec2Hex8bit(VectorYoff / 2) + ",$" + VbX.Dec2Hex8bit(VectorXoff / 2) + VbX.nl();
                            VectorString += "0," + x.ToString() + "," + y.ToString() + VbX.nl();
                        }
                    }
                    if (CboVectorType.Text.ToLower() == "cpacket")
                    {
                        x = x / 4;
                        y = y / 4;
                        x = x * 4;
                        y = y * 4;
                        VectorXoff = x - LastVectorX;
                        VectorYoff = LastVectorY - y;
                        if (VectorXoff / 4 == 0 && VectorYoff / 4 == 0) return;
                        if (mouseEventArgs.Button == MouseButtons.Left)
                        {

                            g.DrawLine(Pens.PapayaWhip, LastVectorX, LastVectorY, x, y);
                            txtVectors.Text += "    dc.b %0" + VbX.Right(VbX.Dec2Bin8Bit(VectorYoff / 4), 7) + ",%1" + VbX.Right(VbX.Dec2Bin8Bit(VectorXoff / 4), 7) + VbX.nl();
                            VectorString += "1," + x.ToString() + "," + y.ToString() + VbX.nl();
                        }
                        if (mouseEventArgs.Button == MouseButtons.Right)
                        {
                            txtVectors.Text += "    dc.b %0" + VbX.Right(VbX.Dec2Bin8Bit(VectorYoff / 4), 7) + ",%0" + VbX.Right(VbX.Dec2Bin8Bit(VectorXoff / 4), 7) + VbX.nl();
                            VectorString += "0," + x.ToString() + "," + y.ToString() + VbX.nl();
                        }
                    }
                    LastVectorX = x;
                    LastVectorY = y;
                    VectorCount++;
                    if (VectorCount == 127 && CboVectorType.Text.ToLower() == "packet")
                    {
                        txtVectors.Text += "    dc.b $01" + VbX.nl();
                        VectorCount = 0;
                    }
                    PicZoom.Image = bmpZoom;
                    picPreview.Image = bmpZoom;
                    return;
                }

                if (CurrentTool == "floodfill")
                {
                    if (chkr == 0)
                    {
                        if (mouseEventArgs.Button == MouseButtons.Left)
                        {
                            FloodFillPixel(x, y, spritepixel[CurrentBank, CurrentSprite, x, y], colorLeft, colorRight, 0);
                        }
                        if (mouseEventArgs.Button == MouseButtons.Right)
                        {
                            FloodFillPixel(x, y, spritepixel[CurrentBank, CurrentSprite, x, y], colorRight, colorLeft, 0);
                        }
                    }
                    else
                    {
                        // Check is iffy on fill - so we solid fill with 255 first
                        FloodFillPixel(x, y, spritepixel[CurrentBank, CurrentSprite, x, y], 255, 255, 0);

                        if (mouseEventArgs.Button == MouseButtons.Left)
                        {
                            FloodFillPixel(x, y, spritepixel[CurrentBank, CurrentSprite, x, y], colorLeft, colorRight, chkr);
                        }
                        if (mouseEventArgs.Button == MouseButtons.Right)
                        {
                            FloodFillPixel(x, y, spritepixel[CurrentBank, CurrentSprite, x, y], colorRight, colorLeft, chkr);
                        }
                    }

                    btnRefresh_Click(sender, e);
                }


                ///////// Do color swap
                if (CurrentTool == "colorswap")
                {
                    ColorSwap(x, y, mouseEventArgs);
                    return;

                }    ///////// Do color swap



                if (mouseEventArgs.Button == MouseButtons.Left)
                {

                    float rx = (mouseEventArgs.X - halfscale) * maxSpriteSizeX;
                    float ry = (mouseEventArgs.Y - halfscale) * maxSpriteSizeY;
                    rx = rx / ((maxSpriteSizeX - 1) * scale) - x;
                    ry = ry / ((maxSpriteSizeY - 1) * scale) - y;
                    if ((ry < .20 || ry > .80 || rx < .20 || rx > .80) && scale >= 3)
                    {   // didn't hit center
                        //  VbX.MsgBox(rx.ToString() + " " + ry.ToString());
                        return;
                    }

                    if (rdoRGBA.Checked)
                    {
                        Color cc = ColorSelector[17].BackColor;
                        spritepixel[CurrentBank + 0, CurrentSprite, x, y] = cc.R;
                        spritepixel[CurrentBank + 1, CurrentSprite, x, y] = cc.G;
                        spritepixel[CurrentBank + 2, CurrentSprite, x, y] = cc.B;
                        spritepixel[CurrentBank + 3, CurrentSprite, x, y] = (Byte)trkAlpha.Value;
                    }
                    else
                    {

                        ResetBackupTimer();
                        if (CurrentTool != "zxpaint" || cboZxPaintMode.Text != "Colors")
                        {
                            spritepixel[CurrentBank, CurrentSprite, x, y] = checkerize(x, y, colorLeft, colorRight, chkr);
                        }


                        if (CurrentTool != "zxpaint" || cboZxPaintMode.Text != "PixelMap")
                        {
                            if (pnlZXPalette.Visible)
                            {

                                SpeccyPaletteF[CurrentBank, CurrentSprite, x / 8, y / 8] = SpeccyColorFore;
                                SpeccyPaletteB[CurrentBank, CurrentSprite, x / 8, y / 8] = SpeccyColorBack;
                                SpeccyPaletteL[CurrentBank, CurrentSprite, x / 8, y / 8] = SpeccyColorBright;
                            }
                            if (pnlC64pal.Visible)
                            {
                                SpeccyPaletteF[CurrentBank, CurrentSprite, x / 8, y / 8] = C64Color1;
                                SpeccyPaletteB[CurrentBank, CurrentSprite, x / 8, y / 8] = C64Color2;
                                SpeccyPaletteL[CurrentBank, CurrentSprite, x / 8, y / 8] = C64Color3;
                            }
                            if (pnlApplePal.Visible)
                            {
                                SpeccyPaletteF[CurrentBank, CurrentSprite, x / 7, y / 8] = AppleColor;

                            }
                            if (pnlULAPal.Visible)
                            {

                                SpeccyPaletteF[CurrentBank, CurrentSprite, x / 8, y / 8] = colorLeft;
                                SpeccyPaletteB[CurrentBank, CurrentSprite, x / 8, y / 8] = colorRight;
                            }
                        }
                    }
                    //LastSetPixelX = x;
                    //LastSetPixelY = y;
                    RepaintArea(x, y);

                    //bmpZoom.SetPixel(x,y,Color.FromArgb(255, 255, 255, 0));
                    PicZoom.Image = bmpZoom;
                    picPreview.Image = bmpZoom;
                }
                if (mouseEventArgs.Button == MouseButtons.Right)
                {
                    ResetBackupTimer();
                    spritepixel[CurrentBank, CurrentSprite, x, y] = checkerize(x, y, colorRight, colorLeft, chkr); ;
                    RepaintArea(x, y);

                    //   bmpZoom.SetPixel(x, y, Color.FromArgb(255, 0, 0, 0));
                    PicZoom.Image = bmpZoom;
                    picPreview.Image = bmpZoom;
                }


            }
        }
        /************************************************************************************************************************************************/
        private void TileCopy(int x, int y, MouseEventArgs mouseEventArgs, bool norefresh)  // copy 8x8 square to somewhere else
        {
            int tm = 0;
            if (mouseEventArgs.Button == MouseButtons.Middle)
            {
                if (cboDeres.Text.Left(5) == "Match")
                {
                    switch (cboDeres.Text)
                    {
                        case "MatchNearest":
                            tm = FindTileMatch(0, x, y, false);
                            break;
                        case "Match98":
                            tm = FindTileMatch(63, x, y, true);
                            break;
                        case "Match97":
                            tm = FindTileMatch(62, x, y, true);
                            break;
                        case "Match96":
                            tm = FindTileMatch(61, x, y, true);
                            break;
                        case "Match95":
                            tm = FindTileMatch(60, x, y, true);
                            break;
                        case "Match90":
                            tm = FindTileMatch(56, x, y, true);
                            break;
                        case "Match80":
                            tm = FindTileMatch(50, x, y, true);
                            break;
                        case "Match70":
                            tm = FindTileMatch(45, x, y, true);
                            break;
                        case "Match65":
                            tm = FindTileMatch(40, x, y, true);
                            break;
                        case "Match50":
                            tm = FindTileMatch(32, x, y, true);
                            break;

                    }



                }
            }

            int sx = 0;
            int sy = 0;
            sx = x / 8; sx *= 8;
            sy = y / 8; sy *= 8;



            for (int xx = 0; xx < 8; xx++)
            {
                for (int yy = 0; yy < 8; yy++)
                {
                    if (mouseEventArgs.Button == MouseButtons.Right)
                    {
                        bmpTileCopySource.SetPixel(xx, yy, GetDisplayRGB(CurrentBank, CurrentSprite, sx + xx, sy + yy));
                        TileCopyNum[xx, yy] = GetDisplayNum(CurrentBank, CurrentSprite, sx + xx, sy + yy);
                        picTileCopySource.Image = bmpTileCopySource;
                    }
                    if (mouseEventArgs.Button == MouseButtons.Left)
                    {

                        spritepixel[CurrentBank, CurrentSprite, sx + xx, sy + yy] = TileCopyNum[xx, yy];

                    }
                    if (mouseEventArgs.Button == MouseButtons.Middle)
                    {
                        if (cboDeres.Text == "1/2")
                        {
                            int xB = xx / 2;
                            int yB = yy / 2;
                            xB = xB * 2;
                            yB = yB * 2;
                            spritepixel[CurrentBank, CurrentSprite, sx + xx, sy + yy] = spritepixel[CurrentBank, CurrentSprite, sx + xB, sy + yB];
                        }
                        if (cboDeres.Text == "1/4")
                        {
                            int xB = xx / 4;
                            int yB = yy / 4;
                            xB = xB * 4;
                            yB = yB * 4;
                            spritepixel[CurrentBank, CurrentSprite, sx + xx, sy + yy] = spritepixel[CurrentBank, CurrentSprite, sx + xB, sy + yB];
                        }
                        if (cboDeres.Text.Left(5) == "Match" && tm > -1)
                        {
                            int tx = tm % 32;
                            int ty = tm / 32;
                            tx = tx * 8; ty = ty * 8;
                            spritepixel[CurrentBank, CurrentSprite, sx + xx, sy + yy] = spritepixel[CurrentBank, 0, tx + xx, ty + yy];
                        }

                    }
                }
            }
            if (!norefresh)
            {
                if (mouseEventArgs.Button == MouseButtons.Left || mouseEventArgs.Button == MouseButtons.Middle)
                {
                    btnRefresh_Click(null, null);
                    ForceBackup();

                }
            }
        }


        private void btnMatchAll_Click(object sender, EventArgs e)
        {

            for (int x = 0; x < Spr_Wid[CurrentSprite]; x += 8)
            {
                for (int y = 0; y < Spr_Hei[CurrentSprite]; y += 8)
                {
                    TileCopy(x, y, new MouseEventArgs(MouseButtons.Middle, 0, 0, 0, 0), false);
                }
            }
            btnRefresh_Click(null, null);

        }


        private int FindTileMatch(int tolerance, int x, int y, bool TakeFirst)
        {
            int result = -1;

            int bestMatch = 0;

            int sx = 0;
            int sy = 0;
            sx = x / 8; sx *= 8;
            sy = y / 8; sy *= 8;

            for (int tile = 0; tile < VbX.CInt(txtNextTile.Text); tile++)
            {
                int pixelmatch = 0;
                int tx = tile % 32;
                int ty = tile / 32;
                tx = tx * 8; ty = ty * 8;

                for (int xx = 0; xx < 8; xx++)
                {
                    for (int yy = 0; yy < 8; yy++)
                    {
                        if (spritepixel[CurrentBank, CurrentSprite, sx + xx, sy + yy] == spritepixel[CurrentBank, 0, tx + xx, ty + yy]) pixelmatch++;
                    }
                }
                if (pixelmatch > bestMatch && pixelmatch >= tolerance) { result = tile; bestMatch = pixelmatch; if (TakeFirst) return result; }
            }

            return result;
        }


        /************************************************************************************************************************************************/
        private void ColorSwap(int x, int y, MouseEventArgs mouseEventArgs)
        {     // Swap two colors


            int minsprite = CurrentSprite;
            int maxsprite = CurrentSprite;
            int sx = 0; int sy = 0; int dx = maxSpriteSizeX; int dy = maxSpriteSizeY;
            if (cboColorConvertMode.Text == "AllSprites")
            { minsprite = 0; maxsprite = 63; }
            if (cboColorConvertMode.Text == "Block")
            {
                sx = x / 8; sx *= 8;
                sy = y / 8; sy *= 8;
                dx = sx + 8;
                dy = sy + 8;
            }
            if (cboColorConvertMode.Text == "8x1")
            {
                sx = x / 8; sx *= 8;
                sy = y;
                dx = sx + 8;
                dy = y + 1;
            }

            int fromcol = spritepixel[CurrentBank, CurrentSprite, x, y];
            int colmode = -1;


            if (mouseEventArgs.Button == MouseButtons.Left) colmode = 1;
            if (mouseEventArgs.Button == MouseButtons.Right) colmode = 2;
            if (colmode < 0) return;

            int chkr = 0;
            if (cboFillCheck.Text == "1/3") chkr = 1;
            if (cboFillCheck.Text == "2/3") chkr = 2;
            if (cboFillCheck.Text == "3/3") chkr = 3;

            // To avoid problems with swaping colors to check patterns, we first swap to temp color 255, then swap that to the destination colors
            DoColorSwap(minsprite, maxsprite, sx, sy, dx, dy, fromcol, colmode, 255, 255, 0);
            DoColorSwap(minsprite, maxsprite, sx, sy, dx, dy, 255, colmode, colorLeft, colorRight, chkr);

            btnRefresh_Click(null, null);
            ForceBackup();

        }
        /************************************************************************************************************************************************/
        private void FloodFillPixel(int xx, int yy, int changecolor, byte color1, byte color2, int check)
        {
            ForceBackup();
            int chkr = 0;
            if (cboCheckMode.Text == "1/3") chkr = 1;
            if (cboCheckMode.Text == "2/3") chkr = 2;
            if (cboCheckMode.Text == "3/3") chkr = 3;
            if (chkr == 0 && changecolor == color1) return;
            if (chkr > 0 && changecolor == color2) return;

            System.Collections.Stack myStack = new System.Collections.Stack();

            myStack.Push(xx);
            myStack.Push(yy);

            while (myStack.Count > 0)
            {
                yy = (int)myStack.Pop();    // Push current pixel on stack
                xx = (int)myStack.Pop();


                if (spritepixel[CurrentBank, CurrentSprite, xx, yy] == changecolor)
                {

                    spritepixel[CurrentBank, CurrentSprite, xx, yy] = checkerize(xx, yy, color1, color2, check);    // Set pixel

                    if (yy > 0)
                    {
                        if (spritepixel[CurrentBank, CurrentSprite, xx, yy - 1] == changecolor)      // see if pixel needs setting
                        {
                            myStack.Push(xx);            // push pixel onto stack
                            myStack.Push(yy - 1);

                        }
                    }

                    if (xx < maxSpriteSizeX - 1)
                    {
                        if (spritepixel[CurrentBank, CurrentSprite, xx + 1, yy] == changecolor)      // see if pixel needs setting
                        {
                            myStack.Push(xx + 1);        // push pixel onto stack
                            myStack.Push(yy);
                        }
                    }

                    if (xx > 0)
                    {
                        if (spritepixel[CurrentBank, CurrentSprite, xx - 1, yy] == changecolor)      // see if pixel needs setting
                        {
                            myStack.Push(xx - 1);        // push pixel onto stack
                            myStack.Push(yy);
                        }
                    }

                    if (yy < maxSpriteSizeY - 1)
                    {
                        if (spritepixel[CurrentBank, CurrentSprite, xx, yy + 1] == changecolor)      // see if pixel needs setting
                        {
                            myStack.Push(xx);        // push pixel onto stack
                            myStack.Push(yy + 1);
                        }
                    }
                }
            }
        }
        /************************************************************************************************************************************************/
        private void DoColorSwap(int minsprite, int maxsprite, int sx, int sy, int dx, int dy, int fromcol, int colmode, byte colLeft, byte colRight, int chkr)
        {

            for (int cs = minsprite; cs <= maxsprite; cs++)
            {
                for (int x = sx; x < dx; x++)
                {
                    for (int y = sy; y < dy; y++)
                    {
                        if (spritepixel[CurrentBank, cs, x, y] == fromcol)
                        {
                            if (colmode == 1)
                                spritepixel[CurrentBank, cs, x, y] = checkerize(x, y, colLeft, colRight, chkr);
                            else
                                spritepixel[CurrentBank, cs, x, y] = checkerize(x, y, colRight, colLeft, chkr);
                        }
                    }
                }
            }
        }
        /************************************************************************************************************************************************/

        private void picPalette_MouseDown(object sender, EventArgs e)
        {
            var mouseEventArgs = e as MouseEventArgs;
            int x = (mouseEventArgs.X + 6) / (220 / 16) - 1;
            int y = (mouseEventArgs.Y + 6) / (220 / 16) - 1;

            if (x < 0) return;
            if (y < 0) return;
            int cnum = (y) * 16 + (x);



            if (VbX.Right(btnSetPal.Text, 1) == "?")
            { //redefine this color
                ColorDialog colorDlg = new ColorDialog();

                colorDlg.FullOpen = true;
                colorDlg.Color = getpalette(cnum);
                if (colorDlg.ShowDialog() == DialogResult.OK)
                {
                    setpalette(cnum, colorDlg.Color);
                }
                btnRefresh_Click(sender, e);
                return;
            }
            if (VbX.Right(btnSetPal.Text, 1) == "#")
            { //redefine this color

                string NewCol = VbX.InputBox("Select a color from -GRB", "Enter a color def in -GRB format (0-F)", "0");

                if (NewCol.Length == 4)
                {

                    setpalette(cnum, Color.FromArgb(VbX.HexToInt(NewCol.Substring(2, 1)) * 16, VbX.HexToInt(NewCol.Substring(1, 1)) * 16, VbX.HexToInt(NewCol.Substring(3, 1)) * 16));
                }
                btnRefresh_Click(sender, e);
                return;
            }
            if (mouseEventArgs.Button == MouseButtons.Left)
            {
                ColorSelector[17].BackColor = getpalette(cnum);
                colorLeft = (byte)cnum;
            }
            if (mouseEventArgs.Button == MouseButtons.Right)
            {
                ColorSelector[17].BackColor = getpalette(cnum);
                colorLeft = (byte)cnum;
            }

            //VbX.MsgBox(cnum.ToString());

        }
        /************************************************************************************************************************************************/
        private void AppleSelector_MouseDown(object sender, EventArgs e)
        {
            var mouseEventArgs = e as MouseEventArgs;
            byte i = (byte)VbX.CInt(ss.GetItem(((Label)sender).Name, "_", 1));

            if (i < 2)
            {
                AppleColor = i;
                AppleSelector.BackColor = ((Label)sender).BackColor;
                AppleSelector.ForeColor = ((Label)sender).ForeColor;
            }

        }
        /************************************************************************************************************************************************/

        private void SpeccySelector_MouseDown(object sender, EventArgs e)
        {
            var mouseEventArgs = e as MouseEventArgs;
            byte i = (byte)VbX.CInt(ss.GetItem(((Label)sender).Name, "_", 1));
            String cmd = ss.GetItem(((Label)sender).Name, "_", 0);

            if (i == 10)
            {
                i = SpeccyColorBack;
                SpeccyColorBack = SpeccyColorFore;
                SpeccyColorFore = i;
                SpeccySampleUpdate();
                return;
            }


            switch (cmd)
            {
                case "SpeccyBack":
                    SpeccyColorBack = i;
                    break;
                case "SpeccyFore":
                    SpeccyColorFore = i;
                    break;
                case "SpeccyDark":
                    SpeccyColorBright = 0;
                    break;
                case "SpeccyLight":
                    SpeccyColorBright = 1;
                    break;

            }

            SpeccySampleUpdate();

        }

        /************************************************************************************************************************************************/

        private void C64Selector_MouseDown(object sender, EventArgs e)
        {
            var mouseEventArgs = e as MouseEventArgs;
            byte i = (byte)VbX.CInt(ss.GetItem(((Label)sender).Name, "_", 1));
            String cmd = ss.GetItem(((Label)sender).Name, "_", 0);



            if (mouseEventArgs.Button == MouseButtons.Left)
            {
                C64Selector[16].BackColor = C64Selector[i].BackColor;
                C64Color1 = i;
            }
            if (mouseEventArgs.Button == MouseButtons.Middle)
            {
                C64Selector[17].BackColor = C64Selector[i].BackColor;
                C64Color2 = i;
            }
            if (mouseEventArgs.Button == MouseButtons.Right)
            {
                C64Selector[18].BackColor = C64Selector[i].BackColor;
                C64Color3 = i;
            }


        }

        /************************************************************************************************************************************************/

        private void SpeccySampleUpdate()
        {
            Label sample = SpeccySelector[10, 0];
            if (SpeccyColorBright == 0)
            {
                sample.BackColor = Speccypalettedark[SpeccyColorBack];
                sample.ForeColor = Speccypalettedark[SpeccyColorFore];
            }
            if (SpeccyColorBright == 1)
            {
                sample.BackColor = Speccypalette[SpeccyColorBack];
                sample.ForeColor = Speccypalette[SpeccyColorFore];
            }

            sample.Text = "ABC";
            sample.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        }

        /************************************************************************************************************************************************/

        private void ColorSelector_MouseDown(object sender, EventArgs e)
        {
            byte i = (byte)VbX.CInt(ss.GetItem(((Label)sender).Name, "_", 1));
            if (VbX.Right(btnSetPal.Text, 1) == "?")
            { //redefine this color
                ColorDialog colorDlg = new ColorDialog();

                colorDlg.FullOpen = true;
                colorDlg.Color = ColorSelector[i].BackColor;
                if (colorDlg.ShowDialog() == DialogResult.OK)
                {
                    Color nc = colorDlg.Color;
                    int c = i;
                    if (c == 17) { c = colorLeft; ColorSelector[17].BackColor = nc; }
                    if (c == 18) { c = colorRight; ColorSelector[18].BackColor = nc; }
                    setpalette(c, colorDlg.Color);
                }
                btnRefresh_Click(sender, e);
                return;
            }
            if (VbX.Right(btnSetPal.Text, 1) == "#")
            { //redefine this color

                string NewCol = VbX.InputBox("Select a color from -GRB", "Enter a color def in -GRB format (0-F)", "0");

                if (NewCol.Length == 4)
                {
                    Color nc = Color.FromArgb(VbX.HexToInt(NewCol.Substring(2, 1)) * 16, VbX.HexToInt(NewCol.Substring(1, 1)) * 16, VbX.HexToInt(NewCol.Substring(3, 1)) * 16);
                    int c = i;
                    if (c == 17) { c = colorLeft; ColorSelector[17].BackColor = nc; }
                    if (c == 18) { c = colorRight; ColorSelector[18].BackColor = nc; }
                    setpalette(c, nc);
                }
                btnRefresh_Click(sender, e);
                return;
            }




            var mouseEventArgs = e as MouseEventArgs;

            if (mouseEventArgs.Button == MouseButtons.Right)
            {
                colorRight = i;
                ColorSelector[18].BackColor = ColorSelector[i].BackColor;
            }
            if (mouseEventArgs.Button == MouseButtons.Left)
            {
                colorLeft = i;
                ColorSelector[17].BackColor = ColorSelector[i].BackColor;
            }

        }
        /************************************************************************************************************************************************/

        private void trkzoom_Scroll(object sender, EventArgs e)
        {
            doscale(trkzoom.Value);
        }
        /************************************************************************************************************************************************/
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            lstSprites.SelectedIndex = CurrentSprite;
            SpriteStats(CurrentSprite);
            for (int x = 0; x < maxSpriteSizeX; x++)
                for (int y = 0; y < maxSpriteSizeY; y++)
                {
                    RepaintPixel(x, y);

                }
            PicZoom.Image = bmpZoom;
            picPreview.Image = bmpZoom;
            SpriteStats(CurrentSprite);
            lblSpriteInfo.Text = "(" + Spr_MinX[CurrentSprite].ToString() + "," + Spr_MinY[CurrentSprite].ToString() + ") - (" + Spr_Wid[CurrentSprite].ToString() + "," + Spr_Hei[CurrentSprite].ToString() + ")";
            int vpos = 0;
            for (int i = 0; i < CurrentSprite; i++)
            {
                vpos += Spr_Hei[i];
            }
            lblSpriteInfo.Text += "   Vpos:" + VbX.CStr(vpos);

            lblSpriteInfo.Text += VbX.Chr(13) + VbX.Chr(10) + "Sprites:" + SpriteCount.ToString();

            lblMaxSpritesByOffset.Text = VbX.CStr(VbX.Val(txtSpriteDataOffSet.Text) / 6);
            this.Text = "AkuSprite Editor -  Sprite:" + CurrentSprite.ToString() + "  Bank:" + CurrentBank.ToString() + " - File: [" + lastfilename + "]";

        }
        /************************************************************************************************************************************************/

        private void SpriteStats(int i)
        {

            if (Spr_FixedSize[i] > 0)
            {
                if ((i + 1) > SpriteCount) SpriteCount = i + 1;
                return;
            }
            Spr_Wid[i] = 0;
            Spr_Hei[i] = 0;
            Spr_MinX[i] = (Int16)maxSpriteSizeX;
            Spr_MinY[i] = (Int16)maxSpriteSizeY;
            for (int x = 0; x < maxSpriteSizeX; x++)
            {
                for (int y = 0; y < maxSpriteSizeY; y++)
                {
                    // RepaintPixel(x, y);
                    if (spritepixel[CurrentBank, i, x, y] != 0)
                    {
                        if (x >= Spr_Wid[i]) Spr_Wid[i] = (Int16)(x + 1);
                        if (y >= Spr_Hei[i]) Spr_Hei[i] = (Int16)(y + 1);
                        if (x < Spr_MinX[i]) Spr_MinX[i] = (Int16)x;
                        if (y < Spr_MinY[i]) Spr_MinY[i] = (Int16)y;
                        if ((i + 1) > SpriteCount) SpriteCount = i + 1;
                    }

                }
            }
            if (chkSimpleSize.Checked)
            {

                Spr_MinX[i] = (short)(Spr_MinX[i] / 8);
                Spr_MinY[i] = (short)(Spr_MinY[i] / 8);

                Spr_MinX[i] = (short)(Spr_MinX[i] * 8);
                Spr_MinY[i] = (short)(Spr_MinY[i] * 8);

                Spr_Wid[i] = (short)((Spr_Wid[i] + 7) / 8);
                Spr_Hei[i] = (short)((Spr_Hei[i] + 7) / 8);

                Spr_Wid[i] = (short)(Spr_Wid[i] * 8);
                Spr_Hei[i] = (short)(Spr_Hei[i] * 8);

            }

        }

        /************************************************************************************************************************************************/
        private void lstSprites_SelectedIndexChanged(object sender, EventArgs e)
        {
            //CurrentSprite = VbX.Val(ss.GetItem(lstSprites.Text, " ", 0));
            //if (this.Visible==true)            btnRefresh_Click(sender, e);
            //ForceBackup();
            ChangeCurrentSprite();
        }
        /************************************************************************************************************************************************/

        private void btnSetPal_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(toolTip1.GetToolTip((Control)sender)); }
            if (VbX.Right(btnSetPal.Text, 1) == "?")
            {
                btnSetPal.Text = "SetPal #";
                btnSetPal.BackColor = Color.LightGreen;
            }
            else if (VbX.Right(btnSetPal.Text, 1) == "#")
            {
                btnSetPal.Text = "SetPal  ";
                btnSetPal.BackColor = SystemColors.ButtonFace;
            }
            else
            {
                btnSetPal.Text = "SetPal ?";
                btnSetPal.BackColor = Color.LightBlue;
            }
        }
        /************************************************************************************************************************************************/
        private void rdoDisplayMSX_CheckedChanged(object sender, EventArgs e)
        {
            btnRefresh_Click(sender, e);
        }

        private void rdoDisplayCPC_CheckedChanged(object sender, EventArgs e)
        {
            btnRefresh_Click(sender, e);
        }

        private void rdoDisplaySpeccy_CheckedChanged(object sender, EventArgs e)
        {

            if (rdoDisplaySpeccy.Checked == true)
            {
                Palettepanelreset(sender);
                BtnAltPal.Text = "AltPal: ZX";
                pnlZXPalette.Visible = true;

            }
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void Togglebutton(Button b)
        {
            if (b.Text.Substring(0, 1) == "[")
            {
                b.Text = b.Text.Replace("[", "").Replace("]", "");
            }
            else
            {
                b.Text = "[" + b.Text + "]";
            }
        }
        /************************************************************************************************************************************************/
        private void ForceBackup()
        {
            backuptimer = 99999;
            tmrBackup.Enabled = true;
            btnUndo.Text = "Undo (F)";
        }
        /************************************************************************************************************************************************/
        private void tmrBackup_Tick(object sender, EventArgs e)
        {

            backuptimer += 100;
            if (backuptimer > 1000)
            {
                backuptimer = 0;

                btnUndo.Text = "Undo ";
                tmrBackup.Enabled = false;

                CurrentBackup = CurrentBackup + 1;
                if (CurrentBackup >= UndoBuffers)
                {
                    CurrentBackup = 0;
                    MinBackup = -1;
                }
                MakeBackup(CurrentBackup);

                NextBackup = CurrentBackup;
            }
        }
        /************************************************************************************************************************************************/
        private void MakeBackup(int i)
        {

            for (int x = 0; x < maxSpriteSizeX; x++)
            {
                for (int y = 0; y < maxSpriteSizeY; y++)
                {
                    Bak_spritepixel[i, x, y] = spritepixel[CurrentBank, CurrentSprite, x, y];
                }


            }
            for (int x = 0; x < maxSpriteSizeX / 32; x++)
            {
                for (int y = 0; y < maxSpriteSizeY / 32; y++)
                {
                    Bak_SpeccyPaletteF[i, x, y] = SpeccyPaletteF[CurrentBank, CurrentSprite, x, y];
                    Bak_SpeccyPaletteB[i, x, y] = SpeccyPaletteB[CurrentBank, CurrentSprite, x, y];
                    Bak_SpeccyPaletteL[i, x, y] = SpeccyPaletteL[CurrentBank, CurrentSprite, x, y];
                }
            }
        }
        /************************************************************************************************************************************************/
        private void btnUndo_Click(object sender, EventArgs e)
        {

            if (CurrentTool == "vector")
            {
                btnRefresh_Click(sender, e);
                LastVectorX = 128;
                LastVectorY = 128;
                int lines = ss.CountItems(VectorString, VbX.Chr(13));

                string NewString1 = "";
                string NewString2 = "";

                for (int i = 0; i < lines - 1; i++)
                {
                    String thisline = ss.GetItem(VectorString, VbX.Chr(13), i).Replace(VbX.Chr(10), ""); ;
                    String thisline2 = ss.GetItem(txtVectors.Text, VbX.Chr(13), i).Replace(VbX.Chr(10), ""); ;
                    NewString1 += thisline + VbX.nl();
                    NewString2 += thisline2 + VbX.nl();
                    Graphics g = Graphics.FromImage(bmpZoom);
                    int x = VbX.CInt(ss.GetItem(thisline, 1));
                    int y = VbX.CInt(ss.GetItem(thisline, 2));
                    if (VbX.CInt(ss.GetItem(thisline, 0)) == 1) g.DrawLine(Pens.PapayaWhip, LastVectorX, LastVectorY, x, y);
                    LastVectorX = x;
                    LastVectorY = y;
                }
                VectorString = NewString1;
                txtVectors.Text = NewString2;
                return;
            }


            if (MinBackup == CurrentBackup) return;
            int cb = CurrentBackup;
            CurrentBackup -= 1;
            if (CurrentBackup < 0) CurrentBackup = UndoBuffers - 1;
            if (CurrentBackup == NextBackup)
            {
                CurrentBackup = cb;
                return;
            }
            RestoreBackup(CurrentBackup);
        }
        /************************************************************************************************************************************************/

        private void RestoreBackup(int i)
        {

            for (int x = 0; x < maxSpriteSizeX; x++)
            {
                for (int y = 0; y < maxSpriteSizeY; y++)
                {
                    spritepixel[CurrentBank, CurrentSprite, x, y] = Bak_spritepixel[i, x, y];
                }

            }
            for (int x = 0; x < maxSpriteSizeX / 8; x++)
            {
                for (int y = 0; y < maxSpriteSizeY / 8; y++)
                {
                    SpeccyPaletteF[CurrentBank, CurrentSprite, x, y] = Bak_SpeccyPaletteF[i, x, y];
                    SpeccyPaletteB[CurrentBank, CurrentSprite, x, y] = Bak_SpeccyPaletteB[i, x, y];
                    SpeccyPaletteL[CurrentBank, CurrentSprite, x, y] = Bak_SpeccyPaletteL[i, x, y];
                }
            }
            btnRefresh_Click(null, null);
        }
        /************************************************************************************************************************************************/
        private void btnRedo_Click(object sender, EventArgs e)
        {
            if (CurrentBackup == NextBackup) return;
            CurrentBackup += 1;
            if (CurrentBackup > 9) CurrentBackup = 0;
            RestoreBackup(CurrentBackup);
        }
        /************************************************************************************************************************************************/
        private void btnLastSprite_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(toolTip1.GetToolTip((Control)sender)); }
            SaveSpriteDetails(-1);
            if (lstSprites.SelectedIndex == 0) return;
            lstSprites.SelectedIndex = lstSprites.SelectedIndex - 1;
            // CurrentSprite = VbX.Val(ss.GetItem(lstSprites.Text, " ", 0));
            //if (this.Visible == true) btnRefresh_Click(sender, e);
            //ResetBackup();
            //  ChangeCurrentSprite();
        }
        /************************************************************************************************************************************************/
        private void ResetBackup()
        {
            MinBackup = 0;
            NextBackup = -1;
            CurrentBackup = -1;
            ForceBackup();
        }
        /************************************************************************************************************************************************/
        private void btnNextSprite_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(toolTip1.GetToolTip((Control)sender)); }
            SaveSpriteDetails(-1);
            // if (lstSprites.SelectedIndex == 0) return;
            if (lstSprites.SelectedIndex == 63)
            {
                lstSprites.SelectedIndex = 63;
            }
            else lstSprites.SelectedIndex = lstSprites.SelectedIndex + 1;
            //  ChangeCurrentSprite();
        }
        /************************************************************************************************************************************************/
        private void ChangeCurrentSprite()
        {
            CurrentSprite = VbX.Val(ss.GetItem(lstSprites.Text, " ", 0));
            if (Spr_MemposReset[CurrentSprite] == 0) chkAligned.Checked = false; else chkAligned.Checked = true;
            if (Spr_FixedSize[CurrentSprite] == 0) chkFixedSize.Checked = false; else chkFixedSize.Checked = true;
            txtSpriteSettings.Text = Spr_Xoff[CurrentSprite].ToString();
            if (this.Visible == true) btnRefresh_Click(null, null);
            ResetBackup();
            if (CurrentBank > LastBank) LastBank = CurrentBank;


        }
        /************************************************************************************************************************************************/

        private void SaveSpriteDetails(int s)
        {

            if (s == -1) s = lstSprites.SelectedIndex;
            string spritedescr = s.ToString() + " ";
            spritedescr += Spr_Wid[s].ToString() + "x";
            spritedescr += Spr_Hei[s].ToString() + "   ";
            spritedescr += Spr_MinX[s].ToString() + "/";
            spritedescr += Spr_MinY[s].ToString();
            spritedescr += Spr_Hei[s].ToString() + "   ";
            spritedescr += Spr_Xoff[s].ToString() + "/";
            spritedescr += Spr_Yoff[s].ToString();
            lstSprites.Items[s] = spritedescr;


        }
        /************************************************************************************************************************************************/

        private void ClearSprites()
        {
            txtSpriteDataOffSet.Text = "&180";

            for (int b = 0; b < BankCount; b++)
            {
                for (int s = 0; s < BankSpriteCount; s++)
                {
                    for (int x = 0; x < (maxSpriteSizeX / 8); x++)
                    {
                        for (int y = 0; y < (maxSpriteSizeY / 8); y++)
                        {
                            SpeccyPaletteF[b, s, x, y] = 7;
                            SpeccyPaletteB[b, s, x, y] = 0;
                            SpeccyPaletteL[b, s, x, y] = 1;
                        }
                    }

                    for (int x = 0; x < maxSpriteSizeX; x++)
                    {
                        for (int y = 0; y < maxSpriteSizeY; y++)
                        {
                            spritepixel[b, s, x, y] = 0;

                        }
                    }
                }
            }
        }
        /************************************************************************************************************************************************/

        private void ClearSpritesCurrentBank()
        {
            int b = CurrentBank;
            for (int s = 0; s < BankSpriteCount; s++)
            {
                for (int x = 0; x < 32; x++)
                {
                    for (int y = 0; y < 32; y++)
                    {
                        SpeccyPaletteF[b, s, x, y] = 7;
                        SpeccyPaletteB[b, s, x, y] = 0;
                        SpeccyPaletteL[b, s, x, y] = 1;
                    }
                }

                for (int x = 0; x < 255; x++)
                {
                    for (int y = 0; y < 255; y++)
                    {
                        spritepixel[b, s, x, y] = 0;

                    }
                }
            }

        }


        /************************************************************************************************************************************************/


        private void loadSpectrumScreenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "Speccy Screen (*.scr)|*.scr";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;
            ClearSprites();
            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Open, System.IO.FileAccess.Read);

            System.IO.BinaryReader BR = new System.IO.BinaryReader(ST);
            byte b = 0;
            if (chkHasDosHeader.Checked)
            {
                for (int i = 0; i < 128; i++)
                {
                    //skip header
                    b = BR.ReadByte();
                }
            }
            int yy = 0;
            int x = 0;

            for (int by = 0; by < (256 * 192) / 8; by++)
            {
                int y1 = yy % 8 * 8;
                int y2 = (yy % 64) / 8;
                int y3 = (yy / 64) * 64;
                int y = y1 + y2 + y3;

                b = BR.ReadByte();
                int b1 = VbX.Bin2Dec(VbX.Dec2Bin8Bit(b).Substring(0, 1));
                int b2 = VbX.Bin2Dec(VbX.Dec2Bin8Bit(b).Substring(1, 1));
                int b3 = VbX.Bin2Dec(VbX.Dec2Bin8Bit(b).Substring(2, 1));
                int b4 = VbX.Bin2Dec(VbX.Dec2Bin8Bit(b).Substring(3, 1));
                int b5 = VbX.Bin2Dec(VbX.Dec2Bin8Bit(b).Substring(4, 1));
                int b6 = VbX.Bin2Dec(VbX.Dec2Bin8Bit(b).Substring(5, 1));
                int b7 = VbX.Bin2Dec(VbX.Dec2Bin8Bit(b).Substring(6, 1));
                int b8 = VbX.Bin2Dec(VbX.Dec2Bin8Bit(b).Substring(7, 1));
                spritepixel[CurrentBank, CurrentSprite, x + 0, y] = (byte)b1;
                spritepixel[CurrentBank, CurrentSprite, x + 1, y] = (byte)b2;
                spritepixel[CurrentBank, CurrentSprite, x + 2, y] = (byte)b3;
                spritepixel[CurrentBank, CurrentSprite, x + 3, y] = (byte)b4;
                spritepixel[CurrentBank, CurrentSprite, x + 4, y] = (byte)b5;
                spritepixel[CurrentBank, CurrentSprite, x + 5, y] = (byte)b6;
                spritepixel[CurrentBank, CurrentSprite, x + 6, y] = (byte)b7;
                spritepixel[CurrentBank, CurrentSprite, x + 7, y] = (byte)b8;
                x = x + 8;
                if (x == 256) { x = 0; yy++; }
            }
            for (int y2 = 0; y2 < 24; y2++)
            {
                for (int x2 = 0; x2 < 32; x2++)
                {
                    b = BR.ReadByte();
                    int b1 = VbX.Bin2Dec(VbX.Dec2Bin8Bit(b).Substring(1, 1));
                    int b2 = VbX.Bin2Dec(VbX.Dec2Bin8Bit(b).Substring(2, 3));
                    int b3 = VbX.Bin2Dec(VbX.Dec2Bin8Bit(b).Substring(5, 3));

                    SpeccyPaletteB[CurrentBank, CurrentSprite, x2, y2] = (byte)b2;
                    SpeccyPaletteF[CurrentBank, CurrentSprite, x2, y2] = (byte)b3;
                    SpeccyPaletteL[CurrentBank, CurrentSprite, x2, y2] = (byte)b1;

                }
            }

            BR.Close();
            VbX.MsgBox("Loaded");
            rdoDisplaySpeccy.Checked = true;
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void saveSpectrumBinaryToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "ZXS Binary Sprite (*.SPR)|*.SPR";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            SaveSpectrum(fd.FileName, true);
        }

        /************************************************************************************************************************************************/

        private void saveMSXASMPaletteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveASMPaletteToolStripMenuItem_Click(sender, e);

        }

        /************************************************************************************************************************************************/

        private void saveMSXBinaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "MSX Binary Sprite (*.SPR)|*.SPR";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            byte b = 0;
            int bytepos = 0;
            int thisspritebytepos = firstspritepos;

            for (int s = 0; s < SpriteCount; s++)
            {
                BW.Write((Byte)Spr_Hei[s]);
                BW.Write((Byte)((Spr_Wid[s] + 1) / 2));
                BW.Write((Byte)Spr_Yoff[s]);
                BW.Write((Byte)Spr_Xoff[s]);

                UInt16 mp = (UInt16)(thisspritebytepos);
                thisspritebytepos = thisspritebytepos + ((Spr_Hei[s] - Spr_MinY[s]) * ((Spr_Wid[s] + 1) / 2));
                BW.Write(mp);
                bytepos += 6;
            }
            while (bytepos < firstspritepos)
            {
                bytepos++;
                BW.Write((Byte)(0));
            }




            for (int spritenum = 0; spritenum < SpriteCount; spritenum++)
            {
                for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y++)
                {
                    for (int x = 0; x < Spr_Wid[spritenum]; x += 2)
                    {
                        int sp1 = spritepixel[CurrentBank, spritenum, x, y];
                        int sp2 = spritepixel[CurrentBank, spritenum, x + 1, y];



                        if (sp1 == 16) sp1 = 0;
                        if (sp2 == 16) sp2 = 0;


                        string tbyte = "";

                        tbyte += VbX.Dec2Bin8Bit(sp1).Substring(4, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp1).Substring(5, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);

                        tbyte += VbX.Dec2Bin8Bit(sp2).Substring(4, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp2).Substring(5, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);



                        //int b1 = VbX.Bin2Dec(VbX.Dec2Bin8Bit(b).Substring(0, 1) + VbX.Dec2Bin8Bit(b).Substring(4, 1));
                        //int b3 = VbX.Bin2Dec(VbX.Dec2Bin8Bit(b).Substring(1, 1) + VbX.Dec2Bin8Bit(b).Substring(5, 1));
                        //int b2 = VbX.Bin2Dec(VbX.Dec2Bin8Bit(b).Substring(2, 1) + VbX.Dec2Bin8Bit(b).Substring(6, 1));
                        //int b4 = VbX.Bin2Dec(VbX.Dec2Bin8Bit(b).Substring(3, 1) + VbX.Dec2Bin8Bit(b).Substring(7, 1));

                        BW.Write((Byte)VbX.Bin2Dec(tbyte));



                    }
                }


            }

            BW.Close();
            ST.Close();
            //VbX.MsgBox("Saved");
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }

        /************************************************************************************************************************************************/


        private void pasteZXToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string response = VbX.InputBox("Replace Sprite", "Replace Sprite", "yes/no");
            if (response != "*yes*") return;


            Bitmap clipbit = (Bitmap)Clipboard.GetImage();
            if (clipbit == null) return;
            for (int x = 0; x < maxSpriteSizeX; x += 8)
            {
                for (int y = 0; y < maxSpriteSizeY; y += 8)
                {
                    string[] ccol = new string[maxSpriteSizeX];
                    int[] cct = new int[maxSpriteSizeX];
                    int bestcolnum = 0;
                    string bestcol = "";
                    int bestcolnum2 = 0;
                    string bestcol2 = "";
                    for (int xx = x; xx < x + 8; xx++)
                    {
                        for (int yy = y; yy < y + 8; yy++)
                        {
                            Color c = Color.Black;

                            if (y < clipbit.Height && x < clipbit.Width)
                            {
                                c = clipbit.GetPixel(xx, yy);
                            }

                            int r = c.R / 16;
                            int g = c.G / 16;
                            int b = c.B / 16;
                            string thiscol = VbX.Hex(r) + VbX.Hex(g) + VbX.Hex(b);
                            for (int i = 0; i < maxSpriteSizeX; i++)
                            {
                                if (ccol[i] == thiscol)
                                {
                                    cct[i]++;
                                    if (cct[i] > bestcolnum)
                                    {
                                        bestcol = thiscol;
                                        bestcolnum = cct[i];
                                    }
                                    else if (cct[i] > bestcolnum2)
                                    {
                                        bestcol2 = thiscol;
                                        bestcolnum2 = cct[i];

                                    }
                                }
                                if (ccol[i] == "" || ccol[i] == null)
                                {
                                    cct[i]++;
                                    ccol[i] = thiscol;
                                    if (cct[i] > bestcolnum)
                                    {
                                        bestcol = thiscol;
                                        bestcolnum = cct[i];
                                    }

                                }
                                i = 1024;
                            }
                        }
                    }
                    // VbX.MsgBox(bestcol + "  " + bestcolnum);
                    byte c1 = 1;
                    byte c0 = 0;
                    if (((VbX.Val("&0" + bestcol) < VbX.Val("&0" + bestcol2))) || bestcol == "000")
                    {

                        c1 = 0;
                        c0 = 1;
                    }


                    SpeccyPaletteB[CurrentBank, CurrentSprite, x / 8, y / 8] = 0;
                    SpeccyPaletteF[CurrentBank, CurrentSprite, x / 8, y / 8] = 7;


                    for (int xx = x; xx < x + 8; xx++)
                    {
                        for (int yy = y; yy < y + 8; yy++)
                        {
                            Color c = Color.Black;

                            if (y < clipbit.Height && x < clipbit.Width)
                            {
                                c = clipbit.GetPixel(xx, yy);
                            }

                            int r = c.R / 16;
                            int g = c.G / 16;
                            int b = c.B / 16;
                            string thiscol = VbX.Hex(r) + VbX.Hex(g) + VbX.Hex(b);
                            if (bestcol == thiscol)
                            {
                                spritepixel[CurrentBank, CurrentSprite, xx, yy] = c1;
                            }
                            else
                            {
                                spritepixel[CurrentBank, CurrentSprite, xx, yy] = c0;
                            }

                        }

                    }

                }
            }
            rdoDisplaySpeccy.Checked = true;
            btnRefresh_Click(sender, e);
        }

        /************************************************************************************************************************************************/

        private void copyPreviewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Clipboard.SetImage(bmpZoom);
            Bitmap clipbit = new Bitmap(maxSpriteSizeX, maxSpriteSizeY);
            for (int x = 0; x < maxSpriteSizeX; x++)
            {
                for (int y = 0; y < maxSpriteSizeY; y++)
                {
                    clipbit.SetPixel(x, y, bmpZoom.GetPixel(x + 1, y + 1));
                }
            }

            Clipboard.SetImage(clipbit);
        }
        /************************************************************************************************************************************************/
        private void canvasSizeToolStripMenuItem_Click(object sender, EventArgs e)
        {

            string newxy = VbX.InputBox("New size? (X,Y)", "New size (X,Y)", VbX.CStr(Spr_Wid[CurrentSprite]) + "," + VbX.CStr(Spr_Hei[CurrentSprite]));
            int mx = (byte)VbX.CInt(ss.GetItem(newxy, ",", 0));
            int my = (byte)VbX.CInt(ss.GetItem(newxy, ",", 1));

            if (my == 0 || mx == 0) return;
            for (int y = my; y < maxSpriteSizeY; y++)
            {
                for (int x = 0; x < maxSpriteSizeX; x++)
                {
                    spritepixel[CurrentBank, CurrentSprite, x, y] = 0;
                }
            }


            for (int y = 0; y < maxSpriteSizeY; y++)
            {
                for (int x = mx; x < maxSpriteSizeX; x++)
                {
                    spritepixel[CurrentBank, CurrentSprite, x, y] = 0;
                }
            }
            btnRefresh_Click(sender, e);
        }

        /************************************************************************************************************************************************/

        private void loadCPCBinaryToolStripMenuItem_Click(object sender, EventArgs e)
        {

            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "Cpc Plus Binary Sprite (*.PLS)|*.PLS";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;
            ClearSprites();
            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Open, System.IO.FileAccess.Read);

            System.IO.BinaryReader BR = new System.IO.BinaryReader(ST);
            byte b = 0;
            if (chkHasDosHeader.Checked)
            {
                for (int i = 0; i < 128; i++)
                {
                    //skip header
                    b = BR.ReadByte();
                }
            }
            for (int s = 0; s < 16; s++)
            {
                for (int y = 0; y < 16; y++)
                {
                    for (int x = 0; x < 15; x += 2)
                    {
                        if (ST.Position < ST.Length)
                        {
                            b = BR.ReadByte();
                            int b2 = b / 16;
                            int b1 = b % 16;
                            spritepixel[CurrentBank, s, x, y] = (byte)b1;
                            spritepixel[CurrentBank, s, x + 1, y] = (byte)b2;
                        }
                    }
                }
            }

            BR.Close();
            ST.Close();
            VbX.MsgBox("Loaded");
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void loadCPCBinaryToolStripMenuItem1_Click(object sender, EventArgs e)
        {


            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "CPC Binary Sprite (*.*)|*.*";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;
            ClearSpritesCurrentBank();
            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Open, System.IO.FileAccess.Read);

            System.IO.BinaryReader BR = new System.IO.BinaryReader(ST);
            byte b = 0;
            int firstspritepos = 0;
            int fileoffset = 0;
            int spritenum = 0;
            if (chkHasDosHeader.Checked)
            {
                fileoffset = 128;
                for (int i = 0; i < 128; i++)
                {
                    //skip header
                    b = BR.ReadByte();
                }
            }

            while (firstspritepos == 0 || (firstspritepos) >= ((ST.Position - fileoffset) + 6))
            {
                b = BR.ReadByte();
                Spr_Hei[spritenum] = (byte)b;

                b = BR.ReadByte();
                Spr_Wid[spritenum] = (byte)(b * 4);


                b = BR.ReadByte();
                Spr_Yoff[spritenum] = (byte)b;
                b = BR.ReadByte();
                Spr_Xoff[spritenum] = (byte)b;


                b = BR.ReadByte();
                int Mempos = (int)b;
                b = BR.ReadByte();
                Mempos += ((int)b * 256);
                Spr_Mempos[spritenum] = Mempos;

                if (spritenum < 63) spritenum++;

                if (firstspritepos == 0) firstspritepos = Mempos;
            }

            while ((ST.Position - fileoffset) > ST.Position)
            {
                b = BR.ReadByte();
            }

            int spritecount = spritenum;

            while (Spr_Mempos[spritecount] > ST.Length - fileoffset)
            {
                spritecount--;
            }

            for (spritenum = 0; spritenum < spritecount; spritenum++)
            {
                //VbX.MsgBox((ST.Position - fileoffset).ToString() + " " + Spr_Mempos[spritenum].ToString());
                if ((ST.Position - fileoffset) == Spr_Mempos[spritenum])
                {
                    Spr_MemposReset[spritenum] = 0;
                }
                else
                {
                    Spr_MemposReset[spritenum] = 1;
                    while ((Spr_Mempos[spritenum]) > (ST.Position - fileoffset) && (ST.Length > ST.Position))
                    {
                        b = BR.ReadByte();
                    }


                }
                for (int y = Spr_Yoff[spritenum]; y < Spr_Hei[spritenum] + Spr_Yoff[spritenum]; y++)
                {
                    for (int x = 0; x < Spr_Wid[spritenum]; x += 4)
                    {
                        try
                        {
                            b = BR.ReadByte();
                        }
                        catch (Exception ee)
                        {
                            b = 0;
                        }

                        int b1 = VbX.Bin2Dec(VbX.Dec2Bin8Bit(b).Substring(4, 1) + VbX.Dec2Bin8Bit(b).Substring(0, 1));
                        int b2 = VbX.Bin2Dec(VbX.Dec2Bin8Bit(b).Substring(5, 1) + VbX.Dec2Bin8Bit(b).Substring(1, 1));
                        int b3 = VbX.Bin2Dec(VbX.Dec2Bin8Bit(b).Substring(6, 1) + VbX.Dec2Bin8Bit(b).Substring(2, 1));
                        int b4 = VbX.Bin2Dec(VbX.Dec2Bin8Bit(b).Substring(7, 1) + VbX.Dec2Bin8Bit(b).Substring(3, 1));

                        int transpcol = VbX.Bin2Dec(VbX.Right(VbX.Dec2Bin8Bit(Spr_Xoff[spritenum]), 3));

                        if ((transpcol == 5 && b1 == 0 && b2 == 1 && b3 == 2 && b4 == 3) || (transpcol == 4 && b1 == 3 && b2 == 2 && b3 == 1 && b4 == 0))
                        {
                            b1 = 16;
                            b2 = 16;
                            b3 = 16;
                            b4 = 16;
                        }


                        spritepixel[CurrentBank, spritenum, x, y] = (byte)b1;
                        spritepixel[CurrentBank, spritenum, x + 1, y] = (byte)b2;
                        spritepixel[CurrentBank, spritenum, x + 2, y] = (byte)b3;
                        spritepixel[CurrentBank, spritenum, x + 3, y] = (byte)b4;


                    }
                }

            }

            BR.Close();
            ST.Close();
            VbX.MsgBox("Loaded");

            txtSpriteDataOffSet.Text = "&" + VbX.Hex(firstspritepos);
            ForceBackup();
            btnRefresh_Click(sender, e);
        }

        /************************************************************************************************************************************************/

        private void saveCPCBinaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "CPC Binary Sprite (*.SPR)|*.SPR";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }
            //VbX.MsgBox(SpriteCount.ToString());
            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            byte b = 0;
            int bytepos = 0;
            int thisspritebytepos = firstspritepos;

            for (int s = 0; s < SpriteCount; s++)
            {
                BW.Write((Byte)(Spr_Hei[s] - Spr_MinY[s]));
                BW.Write((Byte)((Spr_Wid[s] + 3) / 4));
                BW.Write((Byte)Spr_MinY[s]); // BW.Write((Byte)Spr_Yoff[s]);
                BW.Write((Byte)Spr_Xoff[s]);

                if (Spr_MemposReset[s] != 0 && thisspritebytepos % 256 != 0)
                {
                    thisspritebytepos = thisspritebytepos / 256;
                    thisspritebytepos++;
                    thisspritebytepos = thisspritebytepos * 256;
                }

                UInt16 mp = (UInt16)(thisspritebytepos);
                thisspritebytepos = thisspritebytepos + ((Spr_Hei[s] - Spr_MinY[s]) * ((Spr_Wid[s] + 3) / 4));
                BW.Write(mp);
                bytepos += 6;
            }
            while (bytepos < firstspritepos)
            {
                bytepos++;
                BW.Write((Byte)(0));
            }


            for (int spritenum = 0; spritenum < SpriteCount; spritenum++)
            {
                if (Spr_MemposReset[spritenum] != 0)
                {
                    while (ST.Position % 256 != 0)
                    {
                        BW.Write((Byte)(0));
                        //   VbX.MsgBox(ST.Position.ToString());
                    }
                }
                if (rdoDisplayCPC0.Checked)
                {
                    CPC_SaveRAW_16Color(BW, spritenum, 1);
                }
                else
                {
                    CPC_SaveRAW_4Color(BW, spritenum, false, 1);
                }

            }

            BW.Close();
            ST.Close();
            //VbX.MsgBox("Saved");
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }

        /************************************************************************************************************************************************/

        private void saveRAWBitmapToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveCPCRawBmp_Click(sender, e);
        }
        private void SaveCPCRawBmp_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }

            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);



            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            int fs = CurrentSprite;
            int ls = CurrentSprite + 1;
            if (chkSaveMultiRaw.Checked)
            {
                fs = 0;
                ls = SpriteCount;

            }
            for (int cs = fs; cs < ls; cs++)
            {
                if (rdoDispEnt256.Checked)
                {
                    CPC_SaveRAW_256Color(BW, cs, 1);
                }
                else if (rdoDisplayCPC0.Checked)
                {
                    CPC_SaveRAW_16Color(BW, cs, 1);
                }
                else
                {
                    CPC_SaveRAW_4Color(BW, cs, false, 1);
                }
            }
            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }

        /************************************************************************************************************************************************/
        private void CPC_SaveRAW_EGX(System.IO.BinaryWriter BW, int spritenum, int Ystep)
        {
            for (int yy = 0; yy < Ystep; yy++)
            {

                for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += Ystep)
                {
                    if ((y + yy) % 2 == 1)
                    {
                        for (int x = 0; x < Spr_Wid[spritenum]; x += 4)
                        {

                            int sp1 = GetDisplayNum(CurrentBank, spritenum, x, y + yy);
                            int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + yy);


                            if (sp2 == 16 && sp1 == 16)
                            {
                                int transpcol = VbX.Bin2Dec(VbX.Right(VbX.Dec2Bin8Bit(Spr_Xoff[spritenum]), 3));
                                if (transpcol == 5)
                                {
                                    sp1 = 0;
                                    sp2 = 1;
                                }
                                if (transpcol == 4)
                                {
                                    sp1 = 3;
                                    sp2 = 2;
                                }
                            }
                            if (sp1 == 16) sp1 = 0;
                            if (sp2 == 16) sp2 = 0;


                            string tbyte = "";

                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(5, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(5, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(4, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(4, 1);


                            BW.Write((Byte)VbX.Bin2Dec(tbyte));
                        }
                    }
                    else
                    {

                        for (int rx = 0; rx < Spr_Wid[spritenum]; rx += 4)
                        {
                            int x = rx;


                            int sp1 = GetDisplayNum(CurrentBank, spritenum, x, y + yy);
                            int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 1, y + yy);
                            int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + yy);
                            int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 3, y + yy);


                            if (sp4 == 16 && sp3 == 16 && sp2 == 16 && sp1 == 16)
                            {
                                int transpcol = VbX.Bin2Dec(VbX.Right(VbX.Dec2Bin8Bit(Spr_Xoff[spritenum]), 3));
                                if (transpcol == 5)
                                {
                                    sp1 = 0;
                                    sp2 = 1;
                                    sp3 = 2;
                                    sp4 = 3;
                                }
                                if (transpcol == 4)
                                {
                                    sp1 = 3;
                                    sp2 = 2;
                                    sp3 = 1;
                                    sp4 = 0;
                                }
                            }
                            if (sp1 == 16) sp1 = 0;
                            if (sp2 == 16) sp2 = 0;
                            if (sp3 == 16) sp3 = 0;
                            if (sp4 == 16) sp4 = 0;


                            string tbyte = "";

                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp3).Substring(7, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp4).Substring(7, 1);

                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp3).Substring(6, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp4).Substring(6, 1);

                            BW.Write((Byte)VbX.Bin2Dec(tbyte));
                        }

                    }
                }

                if (Ystep == 8)
                {
                    for (int i = 0; i < 48; i++)
                    {
                        BW.Write((Byte)(0));
                    }
                }
            }

        }
        /************************************************************************************************************************************************/
        private void CPC_SaveRAW_16Color(System.IO.BinaryWriter BW, int spritenum, int Ystep)
        {
            for (int yy = 0; yy < Ystep; yy++)
            {

                for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += Ystep)
                {

                    for (int x = 0; x < Spr_Wid[spritenum]; x += 4)
                    {

                        int sp1 = spritepixel[CurrentBank, spritenum, x, y + yy];
                        int sp2 = spritepixel[CurrentBank, spritenum, x + 2, y + yy];


                        if (sp2 == 16 && sp1 == 16)
                        {
                            int transpcol = VbX.Bin2Dec(VbX.Right(VbX.Dec2Bin8Bit(Spr_Xoff[spritenum]), 3));
                            if (transpcol == 5)
                            {
                                sp1 = 0;
                                sp2 = 1;
                            }
                            if (transpcol == 4)
                            {
                                sp1 = 3;
                                sp2 = 2;
                            }
                        }
                        if (sp1 == 16) sp1 = 0;
                        if (sp2 == 16) sp2 = 0;


                        string tbyte = "";

                        tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp1).Substring(5, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp2).Substring(5, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp1).Substring(4, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp2).Substring(4, 1);




                        BW.Write((Byte)VbX.Bin2Dec(tbyte));
                    }
                }

                if (Ystep == 8)
                {
                    for (int i = 0; i < 48; i++)
                    {
                        BW.Write((Byte)(0));
                    }
                }
            }
        }
        /************************************************************************************************************************************************/
        private void CPC_SaveRAW_256Color(System.IO.BinaryWriter BW, int spritenum, int Ystep)
        {   // For enterprise
            for (int yy = 0; yy < Ystep; yy++)
            {

                for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += Ystep)
                {

                    for (int x = 0; x < Spr_Wid[spritenum]; x += 4)
                    {


                        int sp1 = GetDisplayNum(CurrentBank, spritenum, x, y + yy);


                        Color c = getpalette(sp1);
                        //; 	GRBGRBGR  	;g0 | r0 | b0 | g1 | r1 | b1 | g2 | r2 | - x0 = lsb 

                        string gg = VbX.Dec2Bin8Bit(c.G);
                        string rr = VbX.Dec2Bin8Bit(c.R);
                        string bb = VbX.Dec2Bin8Bit(c.B);
                        string tbyte = gg.Substring(2, 1) + rr.Substring(2, 1) + bb.Substring(1, 1) + gg.Substring(1, 1) + rr.Substring(1, 1) + bb.Substring(0, 1) + gg.Substring(0, 1) + rr.Substring(0, 1);

                        BW.Write((Byte)VbX.Bin2Dec(tbyte));
                    }
                }

                if (Ystep == 8)
                {
                    for (int i = 0; i < 48; i++)
                    {
                        BW.Write((Byte)(0));
                    }
                }
            }

        }
        /************************************************************************************************************************************************/

        private void CPC_SaveRAW_4Color(System.IO.BinaryWriter BW, int spritenum, bool ZigZag, int Ystep)
        {
            for (int yy = 0; yy < Ystep; yy++)
            {
                for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += Ystep)
                {
                    for (int rx = 0; rx < Spr_Wid[spritenum]; rx += 4)
                    {
                        int x = rx;
                        if (ZigZag && y % 2 == 1)
                        {
                            x = (Spr_Wid[spritenum] - x) - 4;
                        }


                        int sp1 = GetDisplayNum(CurrentBank, spritenum, x, y + yy);
                        int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 1, y + yy);
                        int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + yy);
                        int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 3, y + yy);


                        if (sp4 == 16 && sp3 == 16 && sp2 == 16 && sp1 == 16)
                        {
                            int transpcol = VbX.Bin2Dec(VbX.Right(VbX.Dec2Bin8Bit(Spr_Xoff[spritenum]), 3));
                            if (transpcol == 5)
                            {
                                sp1 = 0;
                                sp2 = 1;
                                sp3 = 2;
                                sp4 = 3;
                            }
                            if (transpcol == 4)
                            {
                                sp1 = 3;
                                sp2 = 2;
                                sp3 = 1;
                                sp4 = 0;
                            }
                        }
                        if (sp1 == 16) sp1 = 0;
                        if (sp2 == 16) sp2 = 0;
                        if (sp3 == 16) sp3 = 0;
                        if (sp4 == 16) sp4 = 0;


                        string tbyte = "";

                        tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp3).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp4).Substring(7, 1);

                        tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp3).Substring(6, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp4).Substring(6, 1);

                        BW.Write((Byte)VbX.Bin2Dec(tbyte));
                    }
                }
                if (Ystep == 8 && yy < 7
                    )
                {
                    for (int i = 0; i < 48; i++)
                    {
                        BW.Write((Byte)(0));
                    }
                }
            }

        }

        /************************************************************************************************************************************************/

        private void CPC_SaveRAW_16Color8x8(System.IO.BinaryWriter BW, int spritenum, bool ZigZag, int Ystep)
        {

            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += Ystep)
            {
                for (int rx = 0; rx < Spr_Wid[spritenum]; rx += 8)
                {
                    for (int yy = 0; yy < Ystep; yy++)
                    {
                        for (int rrx = 0; rrx < 8; rrx += 4)
                        {


                            int x = rx + rrx;
                            if (ZigZag && yy % 2 == 1)
                            {
                                x = rx + (8 - rrx);
                            }



                            int sp1 = spritepixel[CurrentBank, spritenum, x, y + yy];
                            int sp2 = spritepixel[CurrentBank, spritenum, x + 2, y + yy];


                            if (sp2 == 16 && sp1 == 16)
                            {
                                int transpcol = VbX.Bin2Dec(VbX.Right(VbX.Dec2Bin8Bit(Spr_Xoff[spritenum]), 3));
                                if (transpcol == 5)
                                {
                                    sp1 = 0;
                                    sp2 = 1;
                                }
                                if (transpcol == 4)
                                {
                                    sp1 = 3;
                                    sp2 = 2;
                                }
                            }
                            if (sp1 == 16) sp1 = 0;
                            if (sp2 == 16) sp2 = 0;


                            string tbyte = "";

                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(5, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(5, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(4, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(4, 1);




                            BW.Write((Byte)VbX.Bin2Dec(tbyte));
                        }
                    }

                }
            }
        }
        private void CPC_SaveRAW_4Color8x8(System.IO.BinaryWriter BW, int spritenum, bool ZigZag, int Ystep, int ymove)
        {

            int Tnum = 1;
            int Tcount = VbX.CInt(txtSaveTileCount.Text);
            if (Tcount == 0) Tcount = 60000;

            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += Ystep)
            {
                for (int rx = 0; rx < Spr_Wid[spritenum]; rx += 8)
                {
                    if (Tnum <= Tcount)
                    {
                        for (int yy = 0; yy < Ystep; yy += ymove)
                        {
                            for (int rrx = 0; rrx < 8; rrx += 4)
                            {


                                int x = rx + rrx;
                                if (ZigZag && yy % 2 == 1)
                                {
                                    x = rx + (8 - rrx);
                                }


                                int sp1 = GetDisplayNum(CurrentBank, spritenum, x, y + yy);
                                int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 1, y + yy);
                                int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + yy);
                                int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 3, y + yy);


                                if (sp4 == 16 && sp3 == 16 && sp2 == 16 && sp1 == 16)
                                {
                                    int transpcol = VbX.Bin2Dec(VbX.Right(VbX.Dec2Bin8Bit(Spr_Xoff[spritenum]), 3));
                                    if (transpcol == 5)
                                    {
                                        sp1 = 0;
                                        sp2 = 1;
                                        sp3 = 2;
                                        sp4 = 3;
                                    }
                                    if (transpcol == 4)
                                    {
                                        sp1 = 3;
                                        sp2 = 2;
                                        sp3 = 1;
                                        sp4 = 0;
                                    }
                                }
                                if (sp1 == 16) sp1 = 0;
                                if (sp2 == 16) sp2 = 0;
                                if (sp3 == 16) sp3 = 0;
                                if (sp4 == 16) sp4 = 0;


                                string tbyte = "";

                                tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp3).Substring(7, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp4).Substring(7, 1);

                                tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp3).Substring(6, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp4).Substring(6, 1);

                                BW.Write((Byte)VbX.Bin2Dec(tbyte));
                            }
                        }
                    }

                    Tnum++;
                }
            }
        }

        /************************************************************************************************************************************************/
        private void saveSpritesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Text Sprite Data (*.txt)|*.txt";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;
            dosave(fd.FileName);

        }
        /************************************************************************************************************************************************/
        private void dosave(String filename)
        {
            if (filename.Length == 0) return;

            if (System.IO.File.Exists(filename + ".old"))
            {
                System.IO.File.Delete(filename + ".old");

            }

            if (System.IO.File.Exists(filename))
            {
                System.IO.File.Copy(filename, filename + ".old");

            }


            lastfilename = filename;
            reSaveSpritesToolStripMenuItem.Enabled = true;

            string nl = VbX.Chr(13) + VbX.Chr(10);
            System.IO.StreamWriter SR = new System.IO.StreamWriter(filename, false, Encoding.ASCII);

            SR.Write("FileVersion,1" + nl);
            SR.Write("Sprites," + BankSpriteCount.ToString() + nl);

            SR.Write("SpriteSize," + maxSpriteSizeX.ToString() + "," + maxSpriteSizeY.ToString() + "," + BankCount.ToString() + "," + BankSpriteCount.ToString() + nl);

            for (int i = 0; i <= 255; i++)
            {
                SR.Write("Colorselector," + i.ToString());
                SR.Write("," + getpalette(i).R.ToString());
                SR.Write("," + getpalette(i).G.ToString());
                SR.Write("," + getpalette(i).B.ToString());
                SR.Write(nl);
            }

            int OldBank = CurrentBank;
            for (CurrentBank = 0; CurrentBank <= LastBank; CurrentBank++)
            {
                SpriteCount = 0;
                for (int s = 0; s < BankSpriteCount; s++)
                {

                    SpriteStats(s);         // update all our info on the sprites
                }

                //  VbX.MsgBox(CurrentBank.ToString() + " " + SpriteCount.ToString());
                if (SpriteCount > 0)
                {
                    SR.Write("spritebank," + CurrentBank.ToString() + nl);


                    SR.Write("SpriteStart" + nl);
                    for (int s = 0; s < SpriteCount; s++)
                    {

                        SR.Write("SpriteBitmapBlock," + s.ToString() + "," + Spr_Hei[s].ToString() + "," + Spr_Wid[s].ToString() + nl);
                        for (int y = 0; y < Spr_Hei[s]; y++)
                        {
                            for (int x = 0; x < Spr_Wid[s]; x++)
                            {
                                if (x > 0) SR.Write(",");
                                SR.Write(spritepixel[CurrentBank, s, x, y].ToString());
                            }
                            SR.Write(VbX.Chr(13) + VbX.Chr(10));
                        }
                        SR.Write("SpriteSpeccyBlock," + s.ToString() + "," + ((Spr_Hei[s] + 7) / 8).ToString() + "," + ((Spr_Wid[s] + 7) / 8).ToString() + nl);
                        for (int y = 0; y < (Spr_Hei[s] + 7) / 8; y++)
                        {
                            for (int x = 0; x < (Spr_Wid[s] + 7) / 8; x++)
                            {
                                if (x > 0) SR.Write(",");
                                SR.Write(SpeccyPaletteF[CurrentBank, s, x, y].ToString() + ",");
                                SR.Write(SpeccyPaletteB[CurrentBank, s, x, y].ToString() + ",");
                                SR.Write(SpeccyPaletteL[CurrentBank, s, x, y].ToString());
                            }
                            SR.Write(VbX.Chr(13) + VbX.Chr(10));
                        }
                        SR.Write("SpriteAttribs," + s.ToString() + "," + (Spr_Xoff[s]).ToString() + "," + Spr_FixedSize[s].ToString() + "," + Spr_MemposReset[s].ToString() + nl);
                    }
                }
            }
            CurrentBank = OldBank;
            //        public byte[,,] spritepixel;
            //public byte[, ,] SpeccyPaletteF;   //foreground
            //public byte[, ,] SpeccyPaletteB;   //Background
            //public byte[, ,] SpeccyPaletteL;   //Lightness
            SR.Write("HspriteSize," + txtHspriteW.Text + "," + txtHspriteH.Text + nl);

            SR.Write("SpriteDataOffSet," + txtSpriteDataOffSet.Text + nl);
            SR.Write("SpriteNotes,Start" + nl);
            SR.Write(txtNotes.Text + nl);
            SR.Write("SpriteNotes,End" + nl);


            SR.Write("eof" + nl);
            SR.Close();
            //VbX.MsgBox("Save Complete");
            tabControl1.SelectedTab = tabControl1.TabPages[0];

        }

        /************************************************************************************************************************************************/

        private void savePaletteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Text Palette Data (*.txt)|*.txt";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            string nl = VbX.Chr(13) + VbX.Chr(10);
            System.IO.StreamWriter SR = new System.IO.StreamWriter(fd.FileName, false, Encoding.ASCII);

            SR.Write("FileVersion,1" + nl);
            SR.Write("Sprites,0" + nl);

            for (int i = 0; i < 256; i++)
            {
                SR.Write("Colorselector," + i.ToString());
                SR.Write("," + getpalette(i).R.ToString());
                SR.Write("," + getpalette(i).G.ToString());
                SR.Write("," + getpalette(i).B.ToString());
                SR.Write(nl);
                SR.Write(nl);
                SR.Write(nl);
            }
            SR.Close();
        }

        /************************************************************************************************************************************************/

        private void DoLoadFile(string File, bool loadpixels, bool loadbackground, bool loadpalette, bool loadsettings)
        {

            if (loadpixels && loadbackground && loadpalette & loadsettings)
            {
                lastfilename = File;
                this.Text = "AkuSprite Editor [" + File + "]";
            }



            reSaveSpritesToolStripMenuItem.Enabled = true;

            int spriteresetdone = 0;

            System.IO.StreamReader SR = new System.IO.StreamReader(File);
            int s = 0;

            string lin2 = "";    // read dummy line
            lin2 = SR.ReadLine();       // read dummy line
            while (ss.GetItem(lin2, ",", 0).ToLower() != "eof" && !SR.EndOfStream)
            {

                string command = ss.GetItem(lin2, ",", 0).ToLower();
                int sprite = VbX.CInt(ss.GetItem(lin2, ",", 1).ToLower());
                if (command == "colorselector" && loadpalette)
                {
                    setpalette(sprite, Color.FromArgb(VbX.CInt(ss.GetItem(lin2, ",", 2).ToLower()), VbX.CInt(ss.GetItem(lin2, ",", 3).ToLower()), VbX.CInt(ss.GetItem(lin2, ",", 4).ToLower())));

                }


                if (lin2.ToLower().Trim() == "spritenotes,start")
                {
                    //VbX.MsgBox("notes");
                    lin2 = SR.ReadLine();
                    txtNotes.Text = "";
                    while (lin2.ToLower().Trim() != "spritenotes,end")
                    {
                        txtNotes.Text = txtNotes.Text + lin2 + VbX.Chr(13) + VbX.Chr(10);
                        lin2 = SR.ReadLine();
                    }




                }
                if (command == "spritebitmapblock" && loadpixels)
                {

                    if (spriteresetdone == 0)
                    {
                        ClearSprites();
                        CurrentSprite = 0;
                        spriteresetdone = 1;
                    }
                    int maxy = VbX.CInt(ss.GetItem(lin2, ",", 2).ToLower());
                    int maxx = VbX.CInt(ss.GetItem(lin2, ",", 3).ToLower());
                    Spr_Hei[sprite] = (Int16)maxy;
                    Spr_Wid[sprite] = (Int16)maxx;

                    for (int y = 0; y < maxy; y++)
                    {
                        string lin = SR.ReadLine();
                        for (int x = 0; x < maxSpriteSizeX; x++)
                        {
                            spritepixel[CurrentBank, sprite, x, y] = (byte)VbX.CInt(ss.GetItem(lin, ",", x));
                        }
                    }

                }
                if (command == "spriteattribs" && loadsettings)
                {
                    s = VbX.CInt(ss.GetItem(lin2, ",", 1).ToLower());
                    Spr_Xoff[s] = (Int16)VbX.CInt(ss.GetItem(lin2, ",", 2).ToLower());
                    Spr_FixedSize[s] = (byte)VbX.CInt(ss.GetItem(lin2, ",", 3).ToLower());
                    Spr_MemposReset[s] = (byte)VbX.CInt(ss.GetItem(lin2, ",", 4).ToLower());
                    if (Spr_FixedSize[s] != 0)
                    {
                        Spr_MinX[s] = 0;
                        Spr_MinY[s] = 0;
                    }

                }

                if (command == "hspritesize" && loadsettings)
                {
                    txtHspriteW.Text = ss.GetItem(lin2, ",", 1).ToLower();
                    txtHspriteH.Text = ss.GetItem(lin2, ",", 2).ToLower();
                }
                if (command == "spritedataoffset" && loadsettings)
                {
                    txtSpriteDataOffSet.Text = ss.GetItem(lin2, ",", 1).ToLower();
                }
                if (command == "spritebank")
                {
                    CurrentBank = VbX.CInt(ss.GetItem(lin2, ",", 1));
                    if (CurrentBank > LastBank) LastBank = CurrentBank;
                }
                if (command == "spritesize" && loadsettings)
                {
                    maxSpriteSizeX = VbX.CInt(ss.GetItem(lin2, ",", 1));
                    maxSpriteSizeY = VbX.CInt(ss.GetItem(lin2, ",", 2));
                    BankCount = VbX.CInt(ss.GetItem(lin2, ",", 3));
                    if (BankCount < 4) BankCount = 8;
                    BankSpriteCount = VbX.CInt(ss.GetItem(lin2, ",", 3));
                    if (BankCount < 32) BankSpriteCount = 64;

                    if (maxSpriteSizeY < 1) maxSpriteSizeY = maxSpriteSizeX;

                    if (maxSpriteSizeX == 512 && maxSpriteSizeY == 256)
                    {
                        picPreview.Height = 128;
                    }
                    else if (maxSpriteSizeY == 240) picPreview.Height = 192;
                    else picPreview.Height = 256;

                    InitMaxSpriteSize();
                }
                if (command == "spritespeccyblock" && loadbackground)
                {
                    int maxy = VbX.CInt(ss.GetItem(lin2, ",", 2).ToLower());
                    int maxx = VbX.CInt(ss.GetItem(lin2, ",", 3).ToLower());
                    sprite = VbX.CInt(ss.GetItem(lin2, ",", 1).ToLower());
                    for (int y = 0; y < maxy; y++)
                    {
                        string lin = SR.ReadLine();
                        for (int x = 0; x < 32; x++)
                        {

                            SpeccyPaletteF[CurrentBank, sprite, x, y] = (byte)VbX.CInt(ss.GetItem(lin, ",", x * 3 + 0));
                            SpeccyPaletteB[CurrentBank, sprite, x, y] = (byte)VbX.CInt(ss.GetItem(lin, ",", x * 3 + 1));
                            SpeccyPaletteL[CurrentBank, sprite, x, y] = (byte)VbX.CInt(ss.GetItem(lin, ",", x * 3 + 2));

                            //SR.Write(SpeccyPaletteF[CurrentBank,s, x, y].ToString() + ",");
                            //SR.Write(SpeccyPaletteB[CurrentBank,s, x, y].ToString() + ",");
                            //SR.Write(SpeccyPaletteL[CurrentBank,s, x, y].ToString());
                        }
                    }

                }
                lin2 = SR.ReadLine();       // read dummy line
            }
            tabControl1.SelectedTab = tabControl1.TabPages[0];
            // VbX.MsgBox("Load Complete");

            //        public byte[,,] spritepixel;
            //public byte[, ,] SpeccyPaletteF;   //foreground
            //public byte[, ,] SpeccyPaletteB;   //Background
            //public byte[, ,] SpeccyPaletteL;   //Lightness
            SR.Close();
            CurrentBank = 0;
            for (int i = 0; i < BankSpriteCount; i++)
            {

                SpriteStats(i);         // update all our info on the sprites
                SaveSpriteDetails(i);
            }
            ForceBackup();
            btnRefresh_Click(null, null);
            doscale(trkzoom.Value);
        }

        /************************************************************************************************************************************************/

        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DoLoad(true, true, true, true);
        }
        /************************************************************************************************************************************************/

        private void copyToClipboardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Bitmap clipbit = new Bitmap(maxSpriteSizeX, maxSpriteSizeY + 16);
            for (int x = 0; x < maxSpriteSizeX; x++)
            {
                for (int y = 0; y < maxSpriteSizeY; y++)
                {
                    Color mycolor = GetDisplayRGB(CurrentBank, CurrentSprite, x, y);
                    clipbit.SetPixel(x, y, mycolor);
                }
            }

            if (rdoDisplay256.Checked || rdoDispEnt256.Checked)
            {
                for (int col = 0; col < 256; col++)
                {
                    int cxp = (col % 64) * 4;
                    int cyp = (col / 64) * 4;



                    for (int cx = 0; cx < 4; cx++)
                    {
                        for (int cy = 0; cy < 4; cy++)
                        {
                            clipbit.SetPixel(cxp + cx, maxSpriteSizeY + cyp + cy, getpalette(col));
                        }
                    }
                }
            }
            else
            {


                for (int col = 0; col <= 16; col++)
                {
                    for (int cx = 0; cx < 15; cx++)
                    {
                        for (int cy = 0; cy < 16; cy++)
                        {
                            clipbit.SetPixel(col * 15 + cx, maxSpriteSizeY + cy, ColorSelector[col].BackColor);
                        }
                    }
                }
            }
            Clipboard.SetImage(clipbit);
        }

        /************************************************************************************************************************************************/

        private void pasteToClipToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Bitmap clipbit = (Bitmap)Clipboard.GetImage();
            if (clipbit == null) return;
            string response = VbX.InputBox("Replace Sprite", "Replace Sprite", "yes/no");
            if (response != "*yes*") return;
            LoadBitmapFile(clipbit);
        }

        /************************************************************************************************************************************************/

        private void DoLoad(bool loadpixels, bool loadbackground, bool loadpalette, bool loadsettings)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "Text Sprite Data (*.txt)|*.txt";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;
            string File = fd.FileName;
            DoLoadFile(File, loadpixels, loadbackground, loadpalette, loadsettings);
            recent10.Text = recent9.Text;
            recent9.Text = recent8.Text;
            recent8.Text = recent7.Text;
            recent7.Text = recent6.Text;
            recent6.Text = recent5.Text;
            recent5.Text = recent4.Text;
            recent4.Text = recent3.Text;
            recent3.Text = recent2.Text;
            recent2.Text = recent1.Text;
            recent1.Text = File;


        }

        /************************************************************************************************************************************************/

        private void fourColor2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int x = 0; x < maxSpriteSizeX; x++)
            {
                for (int y = 0; y < maxSpriteSizeY; y++)
                {

                    byte i = spritepixel[CurrentBank, CurrentSprite, x, y];
                    switch (i)
                    {
                        case 1:
                            i = checkerize(x, y, 3, 0, 1);
                            break;
                        case 2:
                            i = checkerize(x, y, 3, 0, 2);
                            break;
                    }

                    spritepixel[CurrentBank, CurrentSprite, x, y] = i;

                }
            }
        }

        /************************************************************************************************************************************************/

        private void invertZXToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            string response = VbX.InputBox("Replace Sprite", "Replace Sprite", "yes/no");
            if (response != "*yes*") return;


            Bitmap clipbit = (Bitmap)Clipboard.GetImage();
            if (clipbit == null) return;
            for (int x = 0; x < maxSpriteSizeX; x++)
            {
                for (int y = 0; y < maxSpriteSizeY; y++)
                {
                    Color c = Color.Black;

                    if (y < clipbit.Height && x < clipbit.Width)
                    {
                        c = clipbit.GetPixel(x, y);
                    }

                    for (int i = 0; i < 16; i++)
                    {
                        if (ColorSelector[i].BackColor.R == c.R && ColorSelector[i].BackColor.G == c.G && ColorSelector[i].BackColor.B == c.B)
                        {
                            spritepixel[CurrentBank, CurrentSprite, x, y] = (byte)i;
                        }
                    }
                }
            }
            btnRefresh_Click(sender, e);

        }
        /************************************************************************************************************************************************/
        private void chkStrongGrid_CheckedChanged(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(toolTip1.GetToolTip((Control)sender)); }
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void saveSpectrumScreenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveSpeccyScreen(false);
        }

        private void SaveSpeccyScreen(bool ulaplus)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "ZXS Binary Sprite (*.SCR)|*.SCR";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }



            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            byte b = 0;
            int bytepos = 0;
            int thisspritebytepos = firstspritepos;

            int spritenum = CurrentSprite;

            int yy = 0;
            int x = 0;


            for (int by = 0; by < (256 * 192) / 8; by++)
            {
                int y1 = yy % 8 * 8;
                int y2 = (yy % 64) / 8;
                int y3 = (yy / 64) * 64;
                int y = y1 + y2 + y3;

                int sp1 = spritepixel[CurrentBank, spritenum, x, y];
                int sp2 = spritepixel[CurrentBank, spritenum, x + 1, y];
                int sp3 = spritepixel[CurrentBank, spritenum, x + 2, y];
                int sp4 = spritepixel[CurrentBank, spritenum, x + 3, y];
                int sp5 = spritepixel[CurrentBank, spritenum, x + 4, y];
                int sp6 = spritepixel[CurrentBank, spritenum, x + 5, y];
                int sp7 = spritepixel[CurrentBank, spritenum, x + 6, y];
                int sp8 = spritepixel[CurrentBank, spritenum, x + 7, y];

                string tbyte = "";

                tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);
                tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);
                tbyte += VbX.Dec2Bin8Bit(sp3).Substring(7, 1);
                tbyte += VbX.Dec2Bin8Bit(sp4).Substring(7, 1);
                tbyte += VbX.Dec2Bin8Bit(sp5).Substring(7, 1);
                tbyte += VbX.Dec2Bin8Bit(sp6).Substring(7, 1);
                tbyte += VbX.Dec2Bin8Bit(sp7).Substring(7, 1);
                tbyte += VbX.Dec2Bin8Bit(sp8).Substring(7, 1);


                BW.Write((Byte)VbX.Bin2Dec(tbyte));
                x = x + 8;
                if (x == 256) { x = 0; yy++; }
            }
            for (int y = 0; y < (192 / 8); y++)
            {
                for (x = 0; x < (256 / 8); x++)
                {
                    if (ulaplus == false)
                    {
                        string tbyte = "0"; //flashing is bad -mkay!
                        tbyte += VbX.Dec2Bin8Bit(SpeccyPaletteL[CurrentBank, spritenum, x, y]).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(SpeccyPaletteB[CurrentBank, spritenum, x, y]).Substring(5, 3);
                        tbyte += VbX.Dec2Bin8Bit(SpeccyPaletteF[CurrentBank, spritenum, x, y]).Substring(5, 3);
                        BW.Write((Byte)VbX.Bin2Dec(tbyte));
                    }
                    else
                    {
                        string tbyte = "";
                        tbyte += VbX.Dec2Bin8Bit(SpeccyPaletteB[CurrentBank, spritenum, x, y]).Substring(4, 4);
                        tbyte += VbX.Dec2Bin8Bit(SpeccyPaletteF[CurrentBank, spritenum, x, y]).Substring(4, 4);
                        BW.Write((Byte)VbX.Bin2Dec(tbyte));
                    }

                }
            }


            BW.Close();
            ST.Close();
            //VbX.MsgBox("Saved");
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(null, null);

        }

        /************************************************************************************************************************************************/

        private void rLEASMToolStripMenuItem_Click(object sender, EventArgs e)
        {

            DoCPCRLE("cpc");
        }
        private void DoCPCRLE(string mode)
        {
            StringBuilder result = new StringBuilder();
            StringBuilder Header = new StringBuilder();

            for (int c = 0; c < SpriteCount; c++)
            {

                int w = Spr_Wid[c] / 4;
                string Filen = "Sprite" + VbX.CStr(c);

                Header.Append("     call Sprite0_Setup" + VbX.nl());
                Header.Append("     call RLE_Draw" + VbX.nl());
                Header.Append("     di" + VbX.nl());
                Header.Append("     halt" + VbX.nl());
                if (mode == "ent")
                {
                    Header.Append("     read \"\\SrcENT\\Akuyou_ENT_RLE.asm\"" + VbX.nl());

                }
                else
                {
                    Header.Append("     read \"\\SrcCPC\\Akuyou_CPC_RLE.asm\"" + VbX.nl());
                }
                Header.Append("     jp " + Filen + "_Setup" + VbX.nl());
                result.Append(Filen + "_Setup:" + VbX.nl());

                result.Append("     ld hl," + Filen + "_Start-1" + VbX.nl());
                result.Append("     ld de," + Filen + "_End-1" + VbX.nl());
                result.Append("     ld b,0   ;Y-Start" + VbX.nl());
                result.Append("     ld ixh," + VbX.CStr(w) + "	;Width" + VbX.nl());
                result.Append("     ld IXL," + VbX.CStr(40 - (w / 2)) + "+" + VbX.CStr(w) + "-1	;X-Righthandside" + VbX.nl());
                result.Append("     ret" + VbX.nl());


                AkuSpriteEditor.RLEBinaryCPC nr = new AkuSpriteEditor.RLEBinaryCPC();
                result.Append(Filen + "_Start:" + VbX.nl());
                nr.width = Spr_Wid[c];
                nr.height = Spr_Hei[c];
                nr.spritepixel = new short[maxSpriteSizeX, maxSpriteSizeY];
                for (int y = 0; y < nr.height; y++)
                {
                    for (int x = 0; x < nr.width; x++)
                    {
                        nr.spritepixel[x, y] = GetDisplayNum(CurrentBank, c, x, y);
                    }
                }
                nr.NewRLE();

                result.Append("     db ");
                for (int i = 0; i < nr.RleDataPos; i++)
                {
                    if (i > 0)
                    {
                        if (i % 16 == 0)
                        {
                            result.Append(VbX.nl() + "      db ");
                        }
                        else
                        {
                            result.Append(",");
                        }
                    }
                    result.Append("&" + VbX.Hex(nr.RleData[i]));
                }
                result.Append(VbX.nl() + Filen + "_End:" + VbX.nl() + VbX.nl());
            }
            Clipboard.SetText(Header.ToString() + VbX.nl() + VbX.nl() + result.ToString());
            VbX.MsgBox("Copied to Clipboard");

        }

        /************************************************************************************************************************************************/

        private void rLEASMCOLORToolStripMenuItem_Click(object sender, EventArgs e)
        {

            StringBuilder Header = new StringBuilder();

            StringBuilder result = new StringBuilder();
            for (int c = 0; c < SpriteCount; c++)
            {
                AkuSpriteEditor.RLEBinaryZX nr = new AkuSpriteEditor.RLEBinaryZX();

                int w = Spr_Wid[c] / 8;
                string Filen = "Sprite" + VbX.CStr(c);

                Header.Append("     ld de," + Filen + "_jumpblock" + VbX.nl());
                Header.Append("     call Rle_FromPointers" + VbX.nl());

                Header.Append("     halt" + VbX.nl());
                Header.Append("     read \"\\SrcZX\\Akuyou_Spectrum_RLE.asm\"" + VbX.nl());
                Header.Append("     jp " + Filen + "_Setup" + VbX.nl());
                Header.Append("callHL:" + VbX.nl());
                Header.Append("     push hl" + VbX.nl());
                Header.Append("     ret" + VbX.nl());

                Header.Append(Filen + "_jumpblock:	" + VbX.nl());



                Header.Append("     jp " + Filen + "_Setup" + VbX.nl());
                result.Append(Filen + "_Setup:" + VbX.nl());

                result.Append("     ld hl," + Filen + "_Start-1" + VbX.nl());
                result.Append("     ld de," + Filen + "_End-1" + VbX.nl());
                result.Append("     ld b,0*8   ;Y-Start" + VbX.nl());
                result.Append("     ld ixh," + VbX.CStr(w) + "	;Width" + VbX.nl());
                result.Append("     ld IXL," + VbX.CStr(16 - (w / 2)) + "+" + VbX.CStr(w - 1) + "	;X-Righthandside" + VbX.nl());
                result.Append("     ret" + VbX.nl());
                result.Append(Filen + "_Start:" + VbX.nl());






                nr.width = Spr_Wid[c];
                nr.height = Spr_Hei[c];
                nr.spritepixel = new short[maxSpriteSizeX, maxSpriteSizeY];
                for (int y = 0; y < nr.height; y++)
                {
                    for (int x = 0; x < nr.width; x++)
                    {
                        nr.spritepixel[x, y] = spritepixel[CurrentBank, c, x, y];
                    }
                }

                nr.NewRLE();
                // VbX.MsgBox(nr.RleDataPos.ToString());
                result.Append("     db ");
                for (int i = 0; i < nr.RleDataPos; i++)
                {
                    if (i > 0)
                    {
                        if (i % 16 == 0)
                        {
                            result.Append(VbX.nl() + "     db ");
                        }
                        else
                        {
                            result.Append(",");
                        }
                    }
                    result.Append("&" + VbX.Hex(nr.RleData[i]));
                }
                result.Append(VbX.nl() + Filen + "_End:" + VbX.nl() + VbX.nl());




                w = Spr_Wid[c] / 8;

                Header.Append("     jp " + Filen + "Color_Setup" + VbX.nl());
                result.Append(Filen + "Color_Setup:" + VbX.nl());

                result.Append("     ld hl," + Filen + "Color_Start-1" + VbX.nl());
                result.Append("     ld de," + Filen + "Color_End-1" + VbX.nl());
                result.Append("     ld b,0*8   ;Y-Start" + VbX.nl());
                result.Append("     ld ixh," + VbX.CStr(w) + "	;Width" + VbX.nl());
                result.Append("     ld IXL," + VbX.CStr(16 - (w / 2)) + "+" + VbX.CStr(w - 1) + "	;X-Righthandside" + VbX.nl());
                result.Append("     ret" + VbX.nl());
                nr = new AkuSpriteEditor.RLEBinaryZX();
                result.Append(Filen + "Color_Start:" + VbX.nl());
                nr.spritepixel = new short[4 * 8, 1024];
                int xx = 4 * 8 - 8;
                int yy = 0;
                for (int y = 0; y < (Spr_Hei[c] / 8); y++)
                {
                    for (int x = (Spr_Wid[c] / 8) - 1; x >= 0; x--)
                    {

                        string tbyte = "0"; //flashing is bad -mkay!
                        tbyte += VbX.Dec2Bin8Bit(SpeccyPaletteL[CurrentBank, c, x, y]).Substring(7, 1);

                        tbyte += VbX.Dec2Bin8Bit(SpeccyPaletteB[CurrentBank, c, x, y]).Substring(5, 3);
                        tbyte += VbX.Dec2Bin8Bit(SpeccyPaletteF[CurrentBank, c, x, y]).Substring(5, 3);

                        nr.spritepixel[xx + 7, yy] = (byte)VbX.Bin2Dec(tbyte.Substring(7, 1));
                        nr.spritepixel[xx + 6, yy] = (byte)VbX.Bin2Dec(tbyte.Substring(6, 1));
                        nr.spritepixel[xx + 5, yy] = (byte)VbX.Bin2Dec(tbyte.Substring(5, 1));
                        nr.spritepixel[xx + 4, yy] = (byte)VbX.Bin2Dec(tbyte.Substring(4, 1));

                        nr.spritepixel[xx + 3, yy] = (byte)VbX.Bin2Dec(tbyte.Substring(3, 1));
                        nr.spritepixel[xx + 2, yy] = (byte)VbX.Bin2Dec(tbyte.Substring(2, 1));
                        nr.spritepixel[xx + 1, yy] = (byte)VbX.Bin2Dec(tbyte.Substring(1, 1));
                        nr.spritepixel[xx + 0, yy] = (byte)VbX.Bin2Dec(tbyte.Substring(0, 1));
                        xx -= 8;
                        if (xx < 0) { yy++; xx = 4 * 8 - 8; }

                    }
                }

                nr.width = 4 * 8;
                nr.height = yy;
                nr.NewRLE();

                result.Append("     db ");
                for (int i = 0; i < nr.RleDataPos; i++)
                {
                    if (i > 0)
                    {
                        if (i % 16 == 0)
                        {
                            result.Append(VbX.nl() + "      db ");
                        }
                        else
                        {
                            result.Append(",");
                        }
                    }
                    result.Append("&" + VbX.Hex(nr.RleData[i]));
                }
                result.Append(VbX.nl() + Filen + "Color_End:" + VbX.nl() + VbX.nl());
            }
            Clipboard.SetText(Header.ToString() + VbX.nl() + VbX.nl() + result.ToString());
            VbX.MsgBox("Copied to Clipboard!");
        }

        /************************************************************************************************************************************************/

        private void saveMSXBitmapToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "MSX Bitmap Screen/Sprite (*.SCR)|*.SCR";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;





            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            int spritenum = CurrentSprite;



            BW.Write((Byte)(0));         // First byte = format: 0= no palette 1 = palette
            BW.Write((UInt16)(Spr_Wid[spritenum]));         // Width
            BW.Write((UInt16)(Spr_Hei[spritenum]));         // Height

            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y++)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 2)
                {
                    int sp1 = spritepixel[CurrentBank, spritenum, x, y];
                    int sp2 = spritepixel[CurrentBank, spritenum, x + 1, y];

                    if (sp1 == 16) sp1 = 0;
                    if (sp2 == 16) sp2 = 0;
                    string tbyte = "";
                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(4, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(5, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);

                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(4, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(5, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);

                    BW.Write((Byte)VbX.Bin2Dec(tbyte));
                }
            }

            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }

        /************************************************************************************************************************************************/

        private void saveMSXBitmapWithPaletteToolStripMenuItem1_Click(object sender, EventArgs e)
        {



            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "MSX Bitmap Screen/Sprite (*.SCR)|*.SCR";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;





            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            int spritenum = CurrentSprite;



            BW.Write((Byte)(1));         // First byte = format: 0= no palette 1 = palette
            BW.Write((UInt16)(Spr_Wid[spritenum]));         // Width
            BW.Write((UInt16)(Spr_Hei[spritenum]));         // Height





            for (int i = 0; i < 16; i++)
            {
                string tbyte = "";
                tbyte = "0" + VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.R).Substring(0, 3) + "0" + VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.B).Substring(0, 3);
                BW.Write((Byte)VbX.Bin2Dec(tbyte));
                tbyte = "00000" + VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.G).Substring(0, 3);
                BW.Write((Byte)VbX.Bin2Dec(tbyte));

            }




            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y++)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 2)
                {
                    int sp1 = spritepixel[CurrentBank, spritenum, x, y];
                    int sp2 = spritepixel[CurrentBank, spritenum, x + 1, y];

                    if (sp1 == 16) sp1 = 0;
                    if (sp2 == 16) sp2 = 0;
                    string tbyte = "";
                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(4, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(5, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);

                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(4, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(5, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);

                    BW.Write((Byte)VbX.Bin2Dec(tbyte));
                }
            }

            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }

        /************************************************************************************************************************************************/

        private void saveMSXBitmapSpritesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveMSXSprites(false);

        }

        private void SaveMSXSprites(bool rle)
        {
            {

                Bitmap clipbit = new Bitmap(256, 1024);
                UInt16[,] tilearray = new UInt16[256, 1024];



                for (int x = 0; x < 256; x++)
                {
                    for (int y = 0; y < 1024; y++)
                    {
                        tilearray[x, y] = 256;
                    }

                }
                int CurrentX = 0;
                int CurrentY = 0;
                int CurrentYHeight = 0;
                int TotalYHeight = 0;

                SaveFileDialog fd = new SaveFileDialog();
                fd.Filter = "MSX Binary Sprite (*.MAP)|*.MAP";
                DialogResult dr = fd.ShowDialog();
                if (dr != DialogResult.OK) return;


                int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
                for (int s = 0; s < BankSpriteCount; s++)
                {
                    SpriteStats(s);         // update all our info on the sprites
                }





                System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

                System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
                byte b = 0;
                int bytepos = 0;
                int thisspritebytepos = firstspritepos;

                for (int s = 0; s < SpriteCount; s++)
                {


                    int ThisActualHeight = Spr_Hei[s] - Spr_MinY[s];

                    BW.Write((Byte)(ThisActualHeight));
                    BW.Write((Byte)((Spr_Wid[s] + 1) / 2));
                    BW.Write((Byte)Spr_MinY[s]);
                    BW.Write((Byte)Spr_Xoff[s]);

                    bool OutputThisOne = true;
                    if (Spr_Wid[s] < 1 || ThisActualHeight < 1) OutputThisOne = false;

                    if (OutputThisOne)
                    {
                        for (int sy = 0; sy < 1024; sy++)
                        {
                            for (int sx = 0; sx < 256 - (Spr_Wid[s] - 1); sx += 2)
                            {
                                if (tilearray[sx, sy] == 256)
                                {
                                    bool valid = true;
                                    for (int zx = 0; zx < Spr_Wid[s]; zx++)
                                    {
                                        for (int zy = 0; zy < Spr_Hei[s]; zy++)
                                        {
                                            if (tilearray[sx + zx, sy + zy] < 256)
                                            {
                                                valid = false;
                                                zy = 1024; zx = 1024;
                                            }
                                        }
                                    }
                                    if (valid == true)
                                    {
                                        CurrentX = sx;
                                        CurrentY = sy;
                                        sy = 1024;
                                        sx = 1024;
                                    }
                                }
                            }
                        }

                        if (Spr_Hei[s] - Spr_MinY[s] > CurrentYHeight) CurrentYHeight = ThisActualHeight;
                        for (int y = Spr_MinY[s]; y < Spr_Hei[s]; y++)
                        {
                            int y2 = y - Spr_MinY[s];
                            for (int x = 0; x < Spr_Wid[s]; x++)
                            {
                                int c = spritepixel[CurrentBank, s, x, y];
                                if (c == 16) c = 0;

                                clipbit.SetPixel(x + CurrentX, y2 + CurrentY, ColorSelector[c].BackColor);
                                tilearray[x + CurrentX, y2 + CurrentY] = (UInt16)c;
                            }
                        }

                    }
                    UInt16 bw = 0;
                    bw = (UInt16)CurrentX;
                    BW.Write(bw);
                    bw = (UInt16)CurrentY;
                    BW.Write(bw);
                    b = (Byte)Spr_Wid[s];
                    BW.Write(b);
                    b = (Byte)(ThisActualHeight);
                    BW.Write(b);


                    CurrentX = CurrentX + Spr_Wid[s];
                    if (CurrentY + ThisActualHeight > TotalYHeight) TotalYHeight = CurrentY + ThisActualHeight;
                }


                BW.Close();
                ST.Close();



                if (rle == false)
                {
                    string fname2 = fd.FileName.Replace(".MAP", ".SCR");
                    ST = new System.IO.FileStream(fname2, System.IO.FileMode.Create, System.IO.FileAccess.Write);
                    BW = new System.IO.BinaryWriter(ST);

                    BW.Write((Byte)(0));         // First byte = format: 0= no palette 1 = palette
                    BW.Write((UInt16)(256));         // Width
                    BW.Write((UInt16)(TotalYHeight));         // Height

                    for (int y = 0; y <= TotalYHeight; y++)
                    {
                        for (int x = 0; x < 256; x += 2)
                        {
                            int sp1 = tilearray[x, y];
                            int sp2 = tilearray[x + 1, y];

                            if (sp1 >= 16) sp1 = 0;
                            if (sp2 >= 16) sp2 = 0;
                            string tbyte = "";
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(4, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(5, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);

                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(4, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(5, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);

                            BW.Write((Byte)VbX.Bin2Dec(tbyte));
                        }
                    }


                    BW.Close();
                    ST.Close();
                }
                else
                {
                    // rle
                    string fname2 = fd.FileName.Replace(".MAP", ".RLE");
                    ST = new System.IO.FileStream(fname2, System.IO.FileMode.Create, System.IO.FileAccess.Write);

                    BW = new System.IO.BinaryWriter(ST);
                    int spritenum = CurrentSprite;

                    BW.Write((Byte)(0));         // First byte = format: 0= no palette 1 = palette
                    BW.Write((UInt16)(256));         // Width
                    BW.Write((UInt16)(TotalYHeight));         // Height



                    AkuSpriteEditor.RLEBinaryMSX nr = new AkuSpriteEditor.RLEBinaryMSX();

                    nr.width = 256;
                    nr.height = TotalYHeight;
                    nr.spritepixel = new short[256, TotalYHeight];
                    for (int y = 0; y < nr.height; y++)
                    {
                        for (int x = 0; x < nr.width; x++)
                        {
                            nr.spritepixel[x, y] = (byte)tilearray[x, y];
                        }
                    }
                    nr.NewRLE();

                    for (int i = 0; i < nr.RleDataPos; i++)
                    {
                        BW.Write((Byte)(nr.RleData[i]));         // First byte = format: 0= no palette 1 = palette
                    }

                    BW.Close();
                    ST.Close();


                }
                //VbX.MsgBox("Saved");
                tabControl1.SelectedTab = tabControl1.TabPages[0];

                btnRefresh_Click(null, null);

                Clipboard.SetImage(clipbit);

            }

        }

        /************************************************************************************************************************************************/


        private void buildRLEASMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AkuSpriteEditor.RLEBinaryMSX nr = new AkuSpriteEditor.RLEBinaryMSX();

            nr.width = Spr_Wid[CurrentSprite];
            nr.height = Spr_Hei[CurrentSprite];
            nr.spritepixel = new short[256, 256];
            for (int y = 0; y < nr.height; y++)
            {
                for (int x = 0; x < nr.width; x++)
                {
                    nr.spritepixel[x, y] = spritepixel[CurrentBank, CurrentSprite, x, y];
                }
            }
            nr.NewRLE();
            VbX.MsgBox(nr.RleDataPos.ToString());
            StringBuilder result = new StringBuilder();
            result.Append("     db ");
            for (int i = 0; i < nr.RleDataPos; i++)
            {
                if (i > 0)
                {
                    if (i % 16 == 0)
                    {
                        result.Append(VbX.nl() + "      db ");
                    }
                    else
                    {
                        result.Append(",");
                    }
                }
                result.Append("&" + VbX.Hex(nr.RleData[i]));
            }


            string loader = "";
            loader = loader + "		ld hl,RleFile" + VbX.nl();
            loader = loader + "		ld de,RleFile_End" + VbX.nl();
            loader = loader + "		ld bc,RleFile_End-RleFile" + VbX.nl();
            loader = loader + "		ld ix,0" + VbX.nl();
            loader = loader + "		ld iy,0" + VbX.nl();
            loader = loader + "		call VDP_RLEProcessorFromMemory	" + VbX.nl();
            loader = loader + "		di" + VbX.nl();
            loader = loader + "		halt" + VbX.nl();
            loader = loader + "RleFile:	 " + VbX.nl();
            loader = loader + "		db 0;nopalette" + VbX.nl();
            loader = loader + "     dw " + nr.width.ToString() + "," + nr.height.ToString() + VbX.nl();
            loader = loader + result.ToString() + VbX.nl();
            loader = loader + "RleFile_End:" + VbX.nl();
            loader = loader + "		include \"Z:\\SrcMSX\\Akuyou_MSX_RLE.asm\"" + VbX.nl();
            loader = loader + "LoadDiscSectorSpecialMSX:;Dummy Label - should never run" + VbX.nl();
            loader = loader + "		halt	" + VbX.nl();

            Clipboard.SetText(loader);
            VbX.MsgBox("Copied to Clipboard");
        }

        /***********************************************************************************************************************************************/
        private void saveMSXRLEPaletteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "MSX RLE Screen/Sprite (*.RLE)|*.RLE";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;
            saveMSXRLE(fd.FileName, true);


        }
        /***********************************************************************************************************************************************/
        private void saveMSXRLEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "MSX RLE Screen/Sprite (*.RLE)|*.RLE";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;
            saveMSXRLE(fd.FileName, false);
        }
        /************************************************************************************************************************************************/
        private void saveMSXRLE(string Filename, bool withpalette)
        {

            System.IO.Stream ST = new System.IO.FileStream(Filename, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            int spritenum = CurrentSprite;
            if (!withpalette)
            {
                BW.Write((Byte)(0));         // First byte = format: 0= no palette 1 = palette
            }
            else
            {
                BW.Write((Byte)(1));         // First byte = format: 0= no palette 1 = palette
            }
            BW.Write((UInt16)(Spr_Wid[spritenum]));         // Width
            BW.Write((UInt16)(Spr_Hei[spritenum]));         // Height
            if (withpalette)
            {

                for (int i = 0; i < 16; i++)
                {
                    string tbyte = "";
                    tbyte = VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.R).Substring(0, 3) + "0" + VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.B).Substring(0, 3) + "0";
                    BW.Write((Byte)VbX.Bin2Dec(tbyte));
                    tbyte = "0000" + VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.G).Substring(0, 3) + "0";
                    BW.Write((Byte)VbX.Bin2Dec(tbyte));

                }
            }
            AkuSpriteEditor.RLEBinaryMSX nr = new AkuSpriteEditor.RLEBinaryMSX();

            nr.width = Spr_Wid[CurrentSprite];
            nr.height = Spr_Hei[CurrentSprite];
            nr.spritepixel = new short[256, 256];
            for (int y = 0; y < nr.height; y++)
            {
                for (int x = 0; x < nr.width; x++)
                {
                    nr.spritepixel[x, y] = spritepixel[CurrentBank, CurrentSprite, x, y];
                }
            }
            nr.NewRLE();
            VbX.MsgBox(nr.RleDataPos.ToString());

            for (int i = 0; i < nr.RleDataPos; i++)
            {
                BW.Write((Byte)(nr.RleData[i]));         // First byte = format: 0= no palette 1 = palette
            }

            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            string loader = "";
            loader = loader + "		ld hl,RleFile" + VbX.nl();
            loader = loader + "		ld de,RleFile_End" + VbX.nl();
            loader = loader + "		ld bc,RleFile_End-RleFile" + VbX.nl();
            loader = loader + "		ld ix,0" + VbX.nl();
            loader = loader + "		ld iy,0" + VbX.nl();
            loader = loader + "		call VDP_RLEProcessorFromMemory	" + VbX.nl();
            loader = loader + "		di" + VbX.nl();
            loader = loader + "		halt" + VbX.nl();
            loader = loader + "RleFile:	 " + VbX.nl();
            loader = loader + "		incbin \"\\ResALL\\MSXRle.rle\"" + VbX.nl();
            loader = loader + "RleFile_End:" + VbX.nl();
            loader = loader + "		include \"\\SrcMSX\\Akuyou_MSX_RLE.asm\"" + VbX.nl();
            loader = loader + "LoadDiscSectorSpecialMSX:;Dummy Label - should never run" + VbX.nl();
            loader = loader + "		halt	" + VbX.nl();
            Clipboard.SetText(loader);
            VbX.MsgBox("Saved, and sample loader in clipboard.");
            btnRefresh_Click(null, null);

        }
        /***********************************************************************************************************************************************/
        private void addOneToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (CpcSpriteCompiler != null)
            {
                // CpcSpriteCompiler.globals_LastFrame = null;
                CpcSpriteCompiler.clearPrevioushistory();
            }
            CpcSpriteConvaddOneDiffToolStripMenuItem_Click(sender, e);

        }

        private void addOneToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            if (ZxSpriteCompiler == null)
            {
                ZxSpriteCompiler = new AkuSpriteEditor.CompZX();
                ZxSpriteCompiler.Doreset();
            }
            ZxSpriteCompiler.txtFilename_Text = "ClipImage";
            Bitmap clipbit = new Bitmap(256, 192);
            for (int x = 0; x < 256; x++)
            {
                for (int y = 0; y < 192; y++)
                {
                    int a = spritepixel[CurrentBank, CurrentSprite, x, y];
                    if (a > 1) a = 1;
                    ZxSpriteCompiler.globals_PixelMap[x, y] = a;


                    clipbit.SetPixel(x, y, ColorSelector[spritepixel[CurrentBank, CurrentSprite, x, y]].BackColor);
                }
            }







            for (int y = 0; y < 192 / 8; y++)
            {
                for (int x = 0; x < 256 / 8; x++)
                {
                    string tbyte = "0"; //flashing is bad -mkay!
                    tbyte += VbX.Dec2Bin8Bit(SpeccyPaletteL[CurrentBank, CurrentSprite, x, y]).Substring(7, 1);

                    tbyte += VbX.Dec2Bin8Bit(SpeccyPaletteB[CurrentBank, CurrentSprite, x, y]).Substring(5, 3);
                    tbyte += VbX.Dec2Bin8Bit(SpeccyPaletteF[CurrentBank, CurrentSprite, x, y]).Substring(5, 3);

                    ZxSpriteCompiler.globals_Colormap[(y * 32) + x] = VbX.Bin2Dec(tbyte);

                }
            }
            ZxSpriteCompiler.globals_ColormapSize = 32 * 24;

            Clipboard.SetImage(clipbit);
            ZxSpriteCompiler.button1_Click(null, null);
            string s = ZxSpriteCompiler.textBox1_Text;
            Clipboard.SetText(s);
            VbX.MsgBox("Saved to clipboard!");
        }
        /************************************************************************************************************************************************/
        private void duplicateFromToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string dupefrom = VbX.InputBox("?", "Copy Ftom which sprite?", CurrentSprite.ToString());
            if (dupefrom.Length == 0) return;
            int df = VbX.CInt(dupefrom);

            Spr_Wid[CurrentSprite] = Spr_Wid[df];
            Spr_Hei[CurrentSprite] = Spr_Hei[df];
            for (int y = 0; y < 256; y++)
            {
                for (int x = 0; x < 256; x++)
                {
                    spritepixel[CurrentBank, CurrentSprite, x, y] = spritepixel[CurrentBank, df, x, y];
                }
            }
            for (int y = 0; y < 32; y++)
            {
                for (int x = 0; x < 32; x++)
                {
                    SpeccyPaletteF[CurrentBank, CurrentSprite, x, y] = SpeccyPaletteF[CurrentBank, df, x, y];
                    SpeccyPaletteB[CurrentBank, CurrentSprite, x, y] = SpeccyPaletteB[CurrentBank, df, x, y];
                    SpeccyPaletteL[CurrentBank, CurrentSprite, x, y] = SpeccyPaletteL[CurrentBank, df, x, y];
                }
            }

            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void flipXToolStripMenuItem_Click(object sender, EventArgs e)
        {
            byte[,] ptemp = new byte[256, 256];
            byte[,] ptempF = new byte[32, 32];
            byte[,] ptempB = new byte[32, 32];
            byte[,] ptempL = new byte[32, 32];

            for (int y = 0; y < 256; y++)
            {
                for (int x = 0; x < 256; x++)
                {
                    ptemp[x, y] = spritepixel[CurrentBank, CurrentSprite, x, y];
                }
            }
            for (int y = 0; y < 32; y++)
            {
                for (int x = 0; x < 32; x++)
                {
                    ptempF[x, y] = SpeccyPaletteF[CurrentBank, CurrentSprite, x, y];
                    ptempB[x, y] = SpeccyPaletteB[CurrentBank, CurrentSprite, x, y];
                    ptempL[x, y] = SpeccyPaletteL[CurrentBank, CurrentSprite, x, y];
                }
            }

            int w = Spr_Wid[CurrentSprite] - 1;
            for (int y = 0; y < 256; y++)
            {
                for (int x = 0; x <= w; x++)
                {
                    spritepixel[CurrentBank, CurrentSprite, x, y] = ptemp[w - x, y];
                }
            }
            w = (Spr_Wid[CurrentSprite] / 8) - 1;
            for (int y = 0; y < 32; y++)
            {
                for (int x = 0; x <= w; x++)
                {

                    SpeccyPaletteF[CurrentBank, CurrentSprite, x, y] = ptempF[w - x, y];
                    SpeccyPaletteB[CurrentBank, CurrentSprite, x, y] = ptempB[w - x, y];
                    SpeccyPaletteL[CurrentBank, CurrentSprite, x, y] = ptempL[w - x, y];
                }
            }

            btnRefresh_Click(sender, e);

        }
        /************************************************************************************************************************************************/
        private void flipYToolStripMenuItem_Click(object sender, EventArgs e)
        {
            byte[,] ptemp = new byte[256, 256];
            byte[,] ptempF = new byte[32, 32];
            byte[,] ptempB = new byte[32, 32];
            byte[,] ptempL = new byte[32, 32];

            for (int y = 0; y < 256; y++)
            {
                for (int x = 0; x < 256; x++)
                {
                    ptemp[x, y] = spritepixel[CurrentBank, CurrentSprite, x, y];
                }
            }
            for (int y = 0; y < 32; y++)
            {
                for (int x = 0; x < 32; x++)
                {
                    ptempF[x, y] = SpeccyPaletteF[CurrentBank, CurrentSprite, x, y];
                    ptempB[x, y] = SpeccyPaletteB[CurrentBank, CurrentSprite, x, y];
                    ptempL[x, y] = SpeccyPaletteL[CurrentBank, CurrentSprite, x, y];
                }
            }

            int h = Spr_Hei[CurrentSprite] - 1;
            for (int y = 0; y <= h; y++)
            {
                for (int x = 0; x < 256; x++)
                {
                    spritepixel[CurrentBank, CurrentSprite, x, y] = ptemp[x, h - y];
                }
            }
            h = (Spr_Hei[CurrentSprite] / 8) - 1;
            for (int y = 0; y < h; y++)
            {
                for (int x = 0; x < 32; x++)
                {

                    SpeccyPaletteF[CurrentBank, CurrentSprite, x, y] = ptempF[x, h - y];
                    SpeccyPaletteB[CurrentBank, CurrentSprite, x, y] = ptempB[x, h - y];
                    SpeccyPaletteL[CurrentBank, CurrentSprite, x, y] = ptempL[x, h - y];
                }
            }

            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void mSX16ColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rdoDisplayMSX.Checked = true;
        }
        /************************************************************************************************************************************************/
        private void cPC4ColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rdoDisplayCPC.Checked = true;

        }
        /************************************************************************************************************************************************/
        private void zX2ColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rdoDisplaySpeccy.Checked = true;
        }
        /************************************************************************************************************************************************/
        private void highVisToggleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            chkStrongGrid.Checked = !chkStrongGrid.Checked;
        }
        /************************************************************************************************************************************************/
        private void reSaveSpritesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dosave(lastfilename);
        }

        /************************************************************************************************************************************************/

        private void chkAligned_CheckedChanged(object sender, EventArgs e)
        {
            Spr_MemposReset[CurrentSprite] = 0;
            if (chkAligned.Checked) Spr_MemposReset[CurrentSprite] = 1;
        }
        /************************************************************************************************************************************************/
        private void txtSpriteSettings_TextChanged(object sender, EventArgs e)
        {
            Spr_Xoff[CurrentSprite] = (byte)VbX.CInt(txtSpriteSettings.Text);
        }
        /************************************************************************************************************************************************/
        private void btnLastBank_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(toolTip1.GetToolTip((Control)sender)); }
            if (rdoRGBA.Checked)
            {
                if (CurrentBank > 3) CurrentBank = CurrentBank - 4;
            }
            else
            {
                if (CurrentBank > 0) CurrentBank = CurrentBank - 1;
            }
            for (int s = 0; s < BankSpriteCount; s++)
            {

                SpriteStats(s);         // update all our info on the sprites
                SaveSpriteDetails(s);
            }
            ChangeCurrentSprite();
        }
        /************************************************************************************************************************************************/
        private void btnNextBank_Click(object sender, EventArgs e)
        {

            if (helpon) { ShowHelp(toolTip1.GetToolTip((Control)sender)); }
            if (rdoRGBA.Checked)
            {
                if (CurrentBank < (BankCount - 4)) CurrentBank = CurrentBank + 4;
            }
            else
            {
                if (CurrentBank < (BankCount - 1))
                {
                    //VbX.MsgBox(CurrentBank.ToString());
                    CurrentBank = CurrentBank + 1;
                    //VbX.MsgBox(CurrentBank.ToString());
                }

            }
            for (int s = 0; s < BankSpriteCount; s++)
            {

                SpriteStats(s);         // update all our info on the sprites
                SaveSpriteDetails(s);
            }

            ChangeCurrentSprite();
        }
        /************************************************************************************************************************************************/
        private void duplicateOffsetFromToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string dupefrom = VbX.InputBox("?", "Copy From which sprite?", CurrentSprite.ToString());
            string offset = VbX.InputBox("?", "X,Y offset", "0,0");
            if (dupefrom.Length == 0) return;
            int df = VbX.CInt(dupefrom);

            Spr_Wid[CurrentSprite] = Spr_Wid[df];
            Spr_Hei[CurrentSprite] = Spr_Hei[df];
            int xoff = VbX.CInt(ss.GetItem(offset, 0));
            int yoff = VbX.CInt(ss.GetItem(offset, 1));
            for (int y = 0; y < 256 - yoff; y++)
            {
                for (int x = 0; x < 256 - xoff; x++)
                {
                    spritepixel[CurrentBank, CurrentSprite, x + xoff, y + yoff] = spritepixel[CurrentBank, df, x, y];
                }
            }
            xoff = xoff / 8;
            yoff = yoff / 8;
            for (int y = 0; y < 32 - yoff; y++)
            {
                for (int x = 0; x < 32 - xoff; x++)
                {
                    SpeccyPaletteF[CurrentBank, CurrentSprite, x + xoff, y + yoff] = SpeccyPaletteF[CurrentBank, df, x, y];
                    SpeccyPaletteB[CurrentBank, CurrentSprite, x + xoff, y + yoff] = SpeccyPaletteB[CurrentBank, df, x, y];
                    SpeccyPaletteL[CurrentBank, CurrentSprite, x + xoff, y + yoff] = SpeccyPaletteL[CurrentBank, df, x, y];
                }
            }

            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void saveMSXRLESpritesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveMSXSprites(true);
        }
        /************************************************************************************************************************************************/

        private void rdoGuideNone_CheckedChanged(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); }
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void tabEditor_Click(object sender, EventArgs e)
        {

        }
        /************************************************************************************************************************************************/
        private void yInterlaceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int y = Spr_Hei[CurrentSprite] * 2; y > 0; y--)
            {
                for (int x = 0; x < Spr_Wid[CurrentSprite]; x++)
                {
                    if (y % 2 == 0)
                    {
                        spritepixel[CurrentBank, CurrentSprite, x, y] = 0;
                    }
                    else
                    {
                        spritepixel[CurrentBank, CurrentSprite, x, y] = spritepixel[CurrentBank, CurrentSprite, x, y / 2];
                    }

                }
            }
            Spr_Hei[CurrentSprite] *= 2;
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void label3_Click(object sender, EventArgs e)
        {

        }
        /************************************************************************************************************************************************/
        private void setAllAttribsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int newval = VbX.CInt(VbX.InputBox("Set all", "128=Pset,64=DoubleHeight", "-1"));
            if (newval < 0) return;
            txtSpriteSettings.Text = newval.ToString();
            for (int s = 0; s < 63; s++)
            {
                Spr_Xoff[s] = (byte)newval;
            }
        }
        /************************************************************************************************************************************************/
        private void saveSpectrumTilesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "ZXS Binary Tiles (*.TSP)|*.TSP";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            SaveSpectrum(fd.FileName, false);
        }
        /************************************************************************************************************************************************/
        private void SaveSpectrum(string filename, bool SaveColors)
        {

            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }






            System.IO.Stream ST = new System.IO.FileStream(filename, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            byte b = 0;
            int bytepos = 0;
            int thisspritebytepos = firstspritepos;

            for (int s = 0; s < SpriteCount; s++)
            {
                BW.Write((Byte)(Spr_Hei[s] - Spr_MinY[s]));
                BW.Write((Byte)((Spr_Wid[s] + 7) / 8));
                BW.Write((Byte)Spr_MinY[s]);
                BW.Write((Byte)Spr_Xoff[s]);

                if (Spr_MemposReset[s] != 0 && thisspritebytepos % 256 != 0)
                {
                    thisspritebytepos = thisspritebytepos / 256;
                    thisspritebytepos++;
                    thisspritebytepos = thisspritebytepos * 256;
                }


                UInt16 mp = (UInt16)(thisspritebytepos);
                int thisspritesize = ((Spr_Hei[s] - Spr_MinY[s]) * ((Spr_Wid[s] + 7) / 8));

                if (SaveColors == true)
                {
                    thisspritesize += ((Spr_Hei[s] + 7) / 8) * ((Spr_Wid[s] + 7) / 8);//- (((Spr_MinY[s]) + 7) / 8))
                }
                if (thisspritesize < 0)
                {
                    VbX.MsgBox("You have a negative sprite size");
                    thisspritesize = 0;
                }
                thisspritebytepos = thisspritebytepos + thisspritesize;
                BW.Write(mp);
                bytepos += 6;
            }
            while (bytepos < firstspritepos)
            {
                bytepos++;
                BW.Write((Byte)(0));
            }




            for (int spritenum = 0; spritenum < SpriteCount; spritenum++)
            {

                if (Spr_MemposReset[spritenum] != 0)
                {
                    while (ST.Position % 256 != 0)
                    {
                        BW.Write((Byte)(0));
                        //   VbX.MsgBox(ST.Position.ToString());
                    }
                }

                for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y++)
                {
                    for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
                    {
                        int sp1 = spritepixel[CurrentBank, spritenum, x, y];
                        int sp2 = spritepixel[CurrentBank, spritenum, x + 1, y];
                        int sp3 = spritepixel[CurrentBank, spritenum, x + 2, y];
                        int sp4 = spritepixel[CurrentBank, spritenum, x + 3, y];
                        int sp5 = spritepixel[CurrentBank, spritenum, x + 4, y];
                        int sp6 = spritepixel[CurrentBank, spritenum, x + 5, y];
                        int sp7 = spritepixel[CurrentBank, spritenum, x + 6, y];
                        int sp8 = spritepixel[CurrentBank, spritenum, x + 7, y];


                        if (sp4 == 16 && sp3 == 16 && sp2 == 16 && sp1 == 16 && sp5 == 16 && sp6 == 16 && sp7 == 16 && sp8 == 16)
                        {
                            int transpcol = VbX.Bin2Dec(VbX.Right(VbX.Dec2Bin8Bit(Spr_Xoff[spritenum]), 3));
                            if (transpcol == 5)
                            {
                                sp1 = 0;
                                sp2 = 1;
                                sp3 = 0;
                                sp4 = 1;
                                sp5 = 0;
                                sp6 = 1;
                                sp7 = 0;
                                sp8 = 1;
                            }
                            if (transpcol == 4)
                            {
                                sp1 = 1;
                                sp2 = 0;
                                sp3 = 1;
                                sp4 = 0;
                                sp5 = 1;
                                sp6 = 0;
                                sp7 = 1;
                                sp8 = 0;
                            }
                        }
                        if (sp1 == 16) sp1 = 0;
                        if (sp2 == 16) sp2 = 0;
                        if (sp3 == 16) sp3 = 0;
                        if (sp4 == 16) sp4 = 0;
                        if (sp5 == 16) sp5 = 0;
                        if (sp6 == 16) sp6 = 0;
                        if (sp7 == 16) sp7 = 0;
                        if (sp8 == 16) sp8 = 0;

                        if (sp1 > 1) sp1 = 1;
                        if (sp2 > 1) sp2 = 1;
                        if (sp3 > 1) sp3 = 1;
                        if (sp4 > 1) sp4 = 1;
                        if (sp5 > 1) sp5 = 1;
                        if (sp6 > 1) sp6 = 1;
                        if (sp7 > 1) sp7 = 1;
                        if (sp8 > 1) sp8 = 1;

                        string tbyte = "";

                        tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp3).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp4).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp5).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp6).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp7).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp8).Substring(7, 1);





                        BW.Write((Byte)VbX.Bin2Dec(tbyte));



                    }

                }

                if (SaveColors)
                {
                    for (int y = 0; y < ((Spr_Hei[spritenum] + 7) / 8); y++)//((Spr_MinY[spritenum] + 7) / 8)
                    {
                        for (int x = 0; x < ((Spr_Wid[spritenum] + 7) / 8); x++)
                        {
                            string tbyte = "0"; //flashing is bad -mkay!
                            tbyte += VbX.Dec2Bin8Bit(SpeccyPaletteL[CurrentBank, spritenum, x, y]).Substring(7, 1);
                            tbyte += VbX.Dec2Bin8Bit(SpeccyPaletteB[CurrentBank, spritenum, x, y]).Substring(5, 3);
                            tbyte += VbX.Dec2Bin8Bit(SpeccyPaletteF[CurrentBank, spritenum, x, y]).Substring(5, 3);
                            BW.Write((Byte)VbX.Bin2Dec(tbyte));

                        }
                    }
                }
            }

            BW.Close();
            ST.Close();
            //VbX.MsgBox("Saved");
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(null, null);

        }
        /************************************************************************************************************************************************/
        private void chkFixedSize_MouseUp(object sender, MouseEventArgs e)
        {
            Spr_FixedSize[CurrentSprite] = 0;
            if (chkFixedSize.Checked)
            {
                SpriteStats(CurrentSprite);
                Spr_FixedSize[CurrentSprite] = 1;
                Spr_MinX[CurrentSprite] = 0;
                Spr_MinY[CurrentSprite] = 0;


                string newxy = VbX.InputBox("New size? (X,Y)", "New size (X,Y)", VbX.CStr(Spr_Wid[CurrentSprite]) + "," + VbX.CStr(Spr_Hei[CurrentSprite]));
                Spr_Wid[CurrentSprite] = (Int16)VbX.CInt(ss.GetItem(newxy, ",", 0));
                Spr_Hei[CurrentSprite] = (Int16)VbX.CInt(ss.GetItem(newxy, ",", 1));

            }
        }
        /************************************************************************************************************************************************/
        private void pixelShiftUpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int pixmove = VbX.CInt(VbX.InputBox("Move Size", "Move Size", "4"));
            if (pixmove == 0) return;

            for (int y = 0; y <= Spr_Hei[CurrentSprite] - 1; y++)
            {
                for (int x = 0; x < 256; x++)
                {
                    byte a = 0;
                    if (y + pixmove < 256)
                    {
                        a = spritepixel[CurrentBank, CurrentSprite, x, y + pixmove];
                    }
                    spritepixel[CurrentBank, CurrentSprite, x, y] = a;
                }
            }

            for (int y = 0; y < Spr_Hei[CurrentSprite] / 8; y++)
            {
                for (int x = 0; x <= Spr_Wid[CurrentSprite] / 8; x++)
                {
                    byte f = 7;
                    byte b = 0;
                    byte l = 0;
                    if (y - pixmove / 8 >= 0)
                    {
                        f = SpeccyPaletteF[CurrentBank, CurrentSprite, x, y + pixmove / 8];
                        b = SpeccyPaletteB[CurrentBank, CurrentSprite, x, y + pixmove / 8];
                        l = SpeccyPaletteL[CurrentBank, CurrentSprite, x, y + pixmove / 8];
                    }
                    SpeccyPaletteF[CurrentBank, CurrentSprite, x, y] = f;
                    SpeccyPaletteB[CurrentBank, CurrentSprite, x, y] = b;
                    SpeccyPaletteL[CurrentBank, CurrentSprite, x, y] = l;
                }

            }
            btnRefresh_Click(null, null);
        }
        /************************************************************************************************************************************************/
        private void pixelShiftDownToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int pixmove = VbX.CInt(VbX.InputBox("Move Size", "Move Size", "4"));
            if (pixmove == 0) return;

            Spr_Hei[CurrentSprite] += (byte)pixmove;
            for (int y = Spr_Hei[CurrentSprite] - 1; y >= 0; y--)
            {
                for (int x = 0; x < Spr_Wid[CurrentSprite]; x++)
                {
                    byte a = 0;
                    if (y - pixmove >= 0)
                    {
                        a = spritepixel[CurrentBank, CurrentSprite, x, y - pixmove];
                    }
                    spritepixel[CurrentBank, CurrentSprite, x, y] = a;
                }
            }
            for (int y = Spr_Hei[CurrentSprite] / 8; y >= 0; y--)
            {
                for (int x = 0; x <= Spr_Wid[CurrentSprite] / 8; x++)
                {
                    byte f = 7;
                    byte b = 0;
                    byte l = 0;
                    if (y - pixmove / 8 >= 0)
                    {
                        f = SpeccyPaletteF[CurrentBank, CurrentSprite, x, y - pixmove / 8];
                        b = SpeccyPaletteB[CurrentBank, CurrentSprite, x, y - pixmove / 8];
                        l = SpeccyPaletteL[CurrentBank, CurrentSprite, x, y - pixmove / 8];
                    }
                    SpeccyPaletteF[CurrentBank, CurrentSprite, x, y] = f;
                    SpeccyPaletteB[CurrentBank, CurrentSprite, x, y] = b;
                    SpeccyPaletteL[CurrentBank, CurrentSprite, x, y] = l;
                }

            }
            btnRefresh_Click(null, null);
        }

        /************************************************************************************************************************************************/
        private void pixelShiftRightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int pixmove = VbX.CInt(VbX.InputBox("Move Size", "Move Size", "4"));
            if (pixmove == 0) return;

            Spr_Wid[CurrentSprite] += (byte)pixmove;
            for (int y = 0; y < Spr_Hei[CurrentSprite]; y++)
            {

                for (int x = Spr_Wid[CurrentSprite] - 1; x >= 0; x--)
                {
                    byte a = 0;
                    if (x - pixmove >= 0)
                    {
                        a = spritepixel[CurrentBank, CurrentSprite, x - pixmove, y];
                    }
                    spritepixel[CurrentBank, CurrentSprite, x, y] = a;
                }

            }
            for (int y = 0; y < Spr_Hei[CurrentSprite] / 8; y++)
            {

                for (int x = Spr_Wid[CurrentSprite] / 8; x >= 0; x--)
                {
                    byte f = 7;
                    byte b = 0;
                    byte l = 0;
                    if (x - pixmove / 8 >= 0)
                    {
                        f = SpeccyPaletteF[CurrentBank, CurrentSprite, x - pixmove / 8, y];
                        b = SpeccyPaletteB[CurrentBank, CurrentSprite, x - pixmove / 8, y];
                        l = SpeccyPaletteL[CurrentBank, CurrentSprite, x - pixmove / 8, y];
                    }
                    SpeccyPaletteF[CurrentBank, CurrentSprite, x, y] = f;
                    SpeccyPaletteB[CurrentBank, CurrentSprite, x, y] = b;
                    SpeccyPaletteL[CurrentBank, CurrentSprite, x, y] = l;
                }

            }

            btnRefresh_Click(null, null);
        }
        /************************************************************************************************************************************************/
        private void pxShiftToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int pixmove = VbX.CInt(VbX.InputBox("Move Size", "Move Size", "2"));
            if (pixmove == 0) return;


            for (int y = 0; y < 256; y++)
            {

                for (int x = 0; x <= Spr_Wid[CurrentSprite] - 1; x++)
                {
                    byte a = 0;
                    if (x + pixmove < 256)
                    {
                        a = spritepixel[CurrentBank, CurrentSprite, x + pixmove, y];
                    }
                    spritepixel[CurrentBank, CurrentSprite, x, y] = a;
                }

            }
            for (int y = 0; y < Spr_Hei[CurrentSprite] / 8; y++)
            {

                for (int x = 0; x <= Spr_Wid[CurrentSprite] / 8; x++)
                {
                    byte f = 7;
                    byte b = 0;
                    byte l = 0;
                    if (x - pixmove / 8 >= 0)
                    {
                        f = SpeccyPaletteF[CurrentBank, CurrentSprite, x + pixmove / 8, y];
                        b = SpeccyPaletteB[CurrentBank, CurrentSprite, x + pixmove / 8, y];
                        l = SpeccyPaletteL[CurrentBank, CurrentSprite, x + pixmove / 8, y];
                    }
                    SpeccyPaletteF[CurrentBank, CurrentSprite, x, y] = f;
                    SpeccyPaletteB[CurrentBank, CurrentSprite, x, y] = b;
                    SpeccyPaletteL[CurrentBank, CurrentSprite, x, y] = l;
                }

            }
            btnRefresh_Click(null, null);
        }
        /************************************************************************************************************************************************/
        private void blackBorderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int w = Spr_Wid[CurrentSprite] - 1;
            int h = Spr_Hei[CurrentSprite] - 1;
            for (int y = 0; y <= h; y++)
            {
                for (int x = 0; x <= w; x++)
                {
                    if (spritepixel[CurrentBank, CurrentSprite, x, y] > 1)
                    {
                        for (int xx = -1; xx <= 1; xx++)
                        {
                            for (int yy = -1; yy <= 1; yy++)
                            {
                                int px = x + xx;
                                int py = y + yy;
                                if (px >= 0 && py >= 0 && px <= w && py <= h)
                                {
                                    if (spritepixel[CurrentBank, CurrentSprite, px, py] == 0)
                                    {
                                        spritepixel[CurrentBank, CurrentSprite, px, py] = 1;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            btnRefresh_Click(null, null);
        }

        /************************************************************************************************************************************************/

        private void saveASMPaletteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            PaletteToClipboard("    defw &0", "");
        }
        private void PaletteToClipboard(string prefix, string suffix)
        {


            string nl = VbX.Chr(13) + VbX.Chr(10);
            StringBuilder SR = new StringBuilder();

            for (int i = 0; i < 16; i++)
            {
                SR.Append(prefix);
                SR.Append(VbX.Hex(ColorSelector[i].BackColor.G / 16));
                SR.Append(VbX.Hex(ColorSelector[i].BackColor.R / 16));
                SR.Append(VbX.Hex(ColorSelector[i].BackColor.B / 16));
                SR.Append(suffix);
                SR.Append(" ;" + VbX.CStr(i) + "  -GRB");
                SR.Append(nl);
            }

            // SR.Close();
            Clipboard.SetText(SR.ToString());
            VbX.MsgBox("Copied to Clipboard");
            tabControl1.SelectedTab = tabControl1.TabPages[0];
        }
        /************************************************************************************************************************************************/
        private void rdoFrameNext_CheckedChanged(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(toolTip1.GetToolTip((Control)sender)); return; }
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void rdoFrameLast_CheckedChanged(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(toolTip1.GetToolTip((Control)sender)); return; }
            btnRefresh_Click(sender, e);
        }

        /************************************************************************************************************************************************/
        private void overlayLastFrameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (rdoFrameLast.Checked) rdoFrameNone.Checked = true; else rdoFrameLast.Checked = true;
            btnRefresh_Click(sender, e);

        }
        /************************************************************************************************************************************************/
        private void overlayNextFrameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (rdoFrameNext.Checked) rdoFrameNone.Checked = true; else rdoFrameNext.Checked = true;
            btnRefresh_Click(sender, e);
        }

        /************************************************************************************************************************************************/
        private void tabControl1_KeyDown(object sender, KeyEventArgs e)
        {
            if (tabControl1.SelectedTab != tabEditor) return;

            if (e.KeyCode == Keys.Down && CurrentBank > 0) { btnLastBank_Click(null, null); e.SuppressKeyPress = true; return; }
            if (e.KeyCode == Keys.Up && CurrentBank < 15) { btnNextBank_Click(null, null); e.SuppressKeyPress = true; return; }
            if (e.KeyCode == Keys.Left && CurrentSprite > 0) { btnLastSprite_Click(null, null); e.SuppressKeyPress = true; return; }
            if (e.KeyCode == Keys.Right && CurrentSprite < 63) { btnNextSprite_Click(null, null); e.SuppressKeyPress = true; return; }
            if (e.Modifiers == (Keys.Shift | Keys.Control) && e.KeyCode == Keys.Z) { btnRedo_Click(null, null); return; }
            if (e.Modifiers == (Keys.Control) && e.KeyCode == Keys.Z) { btnUndo_Click(null, null); return; }
            if (e.KeyCode == Keys.F5) btnRefresh_Click(null, null);
            if (e.KeyCode == Keys.Add && trkzoom.Value < 32) { trkzoom.Value++; doscale(trkzoom.Value); }
            if (e.KeyCode == Keys.Subtract && trkzoom.Value > 0) { trkzoom.Value--; doscale(trkzoom.Value); }

            if (e.Modifiers == (Keys.Control) && e.KeyCode == Keys.C) { copyToClipboardToolStripMenuItem_Click(null, null); return; }
            if (e.Modifiers == (Keys.Shift | Keys.Control) && e.KeyCode == Keys.C) { copyPreviewToolStripMenuItem_Click(null, null); return; }
            if (e.Modifiers == (Keys.Control) && e.KeyCode == Keys.V) { pasteToClipToolStripMenuItem_Click(null, null); return; }

        }
        /************************************************************************************************************************************************/
        private void makeTilesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string newxy = VbX.InputBox("New size? (X,Y)", "New size (X,Y)", VbX.CStr(Spr_Wid[CurrentSprite]) + "," + VbX.CStr(Spr_Hei[CurrentSprite]));
            int mx = (byte)VbX.CInt(ss.GetItem(newxy, ",", 0));
            int my = (byte)VbX.CInt(ss.GetItem(newxy, ",", 1));

            for (int x = 0; x < mx; x++)
            {
                for (int y = 0; y < my; y++)
                {
                    int x2 = x % Spr_Wid[CurrentSprite];
                    int y2 = y % Spr_Hei[CurrentSprite];

                    spritepixel[CurrentBank, CurrentSprite, x, y] = spritepixel[CurrentBank, CurrentSprite, x2, y2];

                }
            }

            Spr_Wid[CurrentSprite] = (byte)mx;
            Spr_Hei[CurrentSprite] = (byte)my;
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void tileShiftXToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int pixmove = VbX.CInt(VbX.InputBox("Move Size", "Move Size", "4"));
            if (pixmove == 0) return;

            byte[,] Sbak = new byte[256, 256];

            for (int x = 0; x < 256; x++)
            {
                for (int y = 0; y < 256; y++)
                {
                    Sbak[x, y] = spritepixel[CurrentBank, CurrentSprite, x, y];
                }
            }

            for (int y = 0; y < 256; y++)
            {

                for (int x = Spr_Wid[CurrentSprite] - 1; x >= 0; x--)
                {

                    int x2 = x + pixmove;
                    if (x2 >= 256) x2 -= 256;

                    spritepixel[CurrentBank, CurrentSprite, x, y] = Sbak[x2, y];
                }

            }
            btnRefresh_Click(null, null);
        }
        /************************************************************************************************************************************************/
        private void blackBorderTightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int w = Spr_Wid[CurrentSprite] - 1;
            int h = Spr_Hei[CurrentSprite] - 1;
            for (int y = 0; y <= h; y++)
            {
                for (int x = 0; x <= w; x++)
                {
                    if (spritepixel[CurrentBank, CurrentSprite, x, y] > 1)
                    {
                        for (int xx = -1; xx <= 1; xx++)
                        {
                            for (int yy = 0; yy <= 0; yy++)
                            {
                                int px = x + xx;
                                int py = y + yy;
                                if (px >= 0 && py >= 0 && px <= w && py <= h)
                                {
                                    if (spritepixel[CurrentBank, CurrentSprite, px, py] == 0)
                                    {
                                        spritepixel[CurrentBank, CurrentSprite, px, py] = 1;
                                    }
                                }
                            }
                        }
                        for (int xx = 0; xx <= 0; xx++)
                        {
                            for (int yy = -1; yy <= 1; yy++)
                            {
                                int px = x + xx;
                                int py = y + yy;
                                if (px >= 0 && py >= 0 && px <= w && py <= h)
                                {
                                    if (spritepixel[CurrentBank, CurrentSprite, px, py] == 0)
                                    {
                                        spritepixel[CurrentBank, CurrentSprite, px, py] = 1;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            btnRefresh_Click(null, null);
        }
        /************************************************************************************************************************************************/
        private void PaletteTint_Click(object sender, EventArgs e)
        {
            string ncol = VbX.InputBox("New COLOR (R,G,B)", "New COLOR (R,G,B)", "255,255,255");
            string ntint = VbX.InputBox("New Tint (0-1)", "New Tint (0-1)", ".1");
            int rr = (byte)VbX.CInt(ss.GetItem(ncol, ",", 0));
            int gg = (byte)VbX.CInt(ss.GetItem(ncol, ",", 1));
            int bb = (byte)VbX.CInt(ss.GetItem(ncol, ",", 2));
            Double aa = Double.Parse(ntint);

            Double a2 = 1 - aa;
            for (int c = 0; c < 16; c++)
            {
                int r2 = (int)((ColorSelector[c].BackColor.R * a2) + (rr * aa));
                int g2 = (int)((ColorSelector[c].BackColor.G * a2) + (gg * aa));
                int b2 = (int)((ColorSelector[c].BackColor.B * a2) + (bb * aa));

                ColorSelector[c].BackColor = Color.FromArgb(255, r2, g2, b2);



            }

        }
        /************************************************************************************************************************************************/
        private void saveSpectrumFontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }

            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "ZXS 8x8 binary (*.Raw)|*.Raw";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            SaveRAW_Planar(BW, CurrentSprite, 1);
            //saveSpectrumFont(BW);
            BW.Close();


        }
        /************************************************************************************************************************************************/
        private void halfSizeFontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int spritenum = CurrentSprite;
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 1)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
                {

                    int sp1 = spritepixel[CurrentBank, spritenum, x, y] + spritepixel[CurrentBank, spritenum, x + 1, y];
                    int sp3 = spritepixel[CurrentBank, spritenum, x + 2, y] + spritepixel[CurrentBank, spritenum, x + 3, y];
                    int sp5 = spritepixel[CurrentBank, spritenum, x + 4, y] + spritepixel[CurrentBank, spritenum, x + 5, y];
                    int sp7 = spritepixel[CurrentBank, spritenum, x + 6, y] + spritepixel[CurrentBank, spritenum, x + 7, y];
                    if (sp1 > 1) sp1 = 1;
                    if (sp3 > 1) sp3 = 1;
                    if (sp5 > 1) sp5 = 1;
                    if (sp7 > 1) sp7 = 1;
                    spritepixel[CurrentBank, spritenum, x, y] = (byte)(sp1);
                    spritepixel[CurrentBank, spritenum, x + 1, y] = (byte)(sp3);
                    spritepixel[CurrentBank, spritenum, x + 2, y] = (byte)(sp5);
                    spritepixel[CurrentBank, spritenum, x + 3, y] = (byte)(sp7);
                    spritepixel[CurrentBank, spritenum, x + 4, y] = 0;
                    spritepixel[CurrentBank, spritenum, x + 5, y] = 0;
                    spritepixel[CurrentBank, spritenum, x + 6, y] = 0;
                    spritepixel[CurrentBank, spritenum, x + 7, y] = 0;


                }
            }

        }
        /************************************************************************************************************************************************/
        private void saveCPCBinaryToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }

            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "CPC Binary Sprite (*.PLS)|*.PLS";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }


            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);


            byte b = 0;

            for (int s = 0; s < 16; s++)
            {
                for (int y = 0; y < 16; y++)
                {
                    for (int x = 0; x < 15; x += 2)
                    {

                        int b2 = spritepixel[CurrentBank, s, x, y];
                        int b1 = spritepixel[CurrentBank, s, x + 1, y] * 16;
                        b = (byte)(b2 + b1);
                        BW.Write((Byte)b);

                    }
                }
            }

            BW.Close();
            ST.Close();
            VbX.MsgBox("Save");
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void rdospr512_CheckedChanged(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(toolTip1.GetToolTip((Control)sender)); }
            picPreview.Height = 256;
            if (rdospr512.Checked)
            {
                maxSpriteSizeX = 512;
                maxSpriteSizeY = 512;
                InitMaxSpriteSize();
            }
            doscale(trkzoom.Value);
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void rdospr256_CheckedChanged(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(toolTip1.GetToolTip((Control)sender)); }
            picPreview.Height = 256;
            if (rdospr256.Checked)
            {
                maxSpriteSizeX = 256;
                maxSpriteSizeY = 256;
                InitMaxSpriteSize();
            }
            doscale(trkzoom.Value);
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void saveRawBitmapToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }

            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Raw Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);


            int spritenum = CurrentSprite;
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 1)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
                {
                    int yy = 0;
                    int sp1 = GetDisplayNum(CurrentBank, spritenum, x, y + yy);
                    int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 1, y + yy);
                    int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + yy);
                    int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 3, y + yy);
                    int sp5 = GetDisplayNum(CurrentBank, spritenum, x + 4, y + yy);
                    int sp6 = GetDisplayNum(CurrentBank, spritenum, x + 5, y + yy);
                    int sp7 = GetDisplayNum(CurrentBank, spritenum, x + 6, y + yy);
                    int sp8 = GetDisplayNum(CurrentBank, spritenum, x + 7, y + yy);


                    if (sp4 == 16 && sp3 == 16 && sp2 == 16 && sp1 == 16 && sp5 == 16 && sp6 == 16 && sp7 == 16 && sp8 == 16)
                    {
                        int transpcol = VbX.Bin2Dec(VbX.Right(VbX.Dec2Bin8Bit(Spr_Xoff[spritenum]), 3));
                        if (transpcol == 5)
                        {
                            sp1 = 0;
                            sp2 = 1;
                            sp3 = 0;
                            sp4 = 1;
                            sp5 = 0;
                            sp6 = 1;
                            sp7 = 0;
                            sp8 = 1;
                        }
                        if (transpcol == 4)
                        {
                            sp1 = 1;
                            sp2 = 0;
                            sp3 = 1;
                            sp4 = 0;
                            sp5 = 1;
                            sp6 = 0;
                            sp7 = 1;
                            sp8 = 0;
                        }
                    }
                    if (sp1 == 16) sp1 = 0;
                    if (sp2 == 16) sp2 = 0;
                    if (sp3 == 16) sp3 = 0;
                    if (sp4 == 16) sp4 = 0;
                    if (sp5 == 16) sp5 = 0;
                    if (sp6 == 16) sp6 = 0;
                    if (sp7 == 16) sp7 = 0;
                    if (sp8 == 16) sp8 = 0;

                    if (sp1 > 1) sp1 = 1;
                    if (sp2 > 1) sp2 = 1;
                    if (sp3 > 1) sp3 = 1;
                    if (sp4 > 1) sp4 = 1;
                    if (sp5 > 1) sp5 = 1;
                    if (sp6 > 1) sp6 = 1;
                    if (sp7 > 1) sp7 = 1;
                    if (sp8 > 1) sp8 = 1;

                    string tbyte = "";

                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp3).Substring(7, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp4).Substring(7, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp5).Substring(7, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp6).Substring(7, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp7).Substring(7, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp8).Substring(7, 1);

                    BW.Write((Byte)VbX.Bin2Dec(tbyte));


                }

            }
            BW.Close();
        }

        /************************************************************************************************************************************************/

        private void MSX_SaveRAW_16Color(System.IO.BinaryWriter BW, int spritenum)
        {
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y++)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 2)
                {
                    int sp1 = spritepixel[CurrentBank, spritenum, x, y];
                    int sp2 = spritepixel[CurrentBank, spritenum, x + 1, y];


                    if (sp2 == 16 && sp1 == 16)
                    {
                        int transpcol = VbX.Bin2Dec(VbX.Right(VbX.Dec2Bin8Bit(Spr_Xoff[spritenum]), 3));
                        if (transpcol == 5)
                        {
                            sp1 = 0;
                            sp2 = 1;
                        }
                        if (transpcol == 4)
                        {
                            sp1 = 3;
                            sp2 = 2;
                        }
                    }
                    if (sp1 == 16) sp1 = 0;
                    if (sp2 == 16) sp2 = 0;


                    string tbyte = "";

                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(4, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(5, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);

                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(4, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(5, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);

                    BW.Write((Byte)VbX.Bin2Dec(tbyte));
                }
            }
        }
        /************************************************************************************************************************************************/
        private void MSX_SaveRAW_16ColorNibbleFlipped(System.IO.BinaryWriter BW, int spritenum)
        {
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y++)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 2)
                {
                    int sp2 = spritepixel[CurrentBank, spritenum, x, y];
                    int sp1 = spritepixel[CurrentBank, spritenum, x + 1, y];


                    if (sp2 == 16 && sp1 == 16)
                    {
                        int transpcol = VbX.Bin2Dec(VbX.Right(VbX.Dec2Bin8Bit(Spr_Xoff[spritenum]), 3));
                        if (transpcol == 5)
                        {
                            sp1 = 0;
                            sp2 = 1;
                        }
                        if (transpcol == 4)
                        {
                            sp1 = 3;
                            sp2 = 2;
                        }
                    }
                    if (sp1 == 16) sp1 = 0;
                    if (sp2 == 16) sp2 = 0;


                    string tbyte = "";

                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(4, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(5, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);

                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(4, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(5, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);




                    BW.Write((Byte)VbX.Bin2Dec(tbyte));
                }
            }


        }

        /************************************************************************************************************************************************/

        private void VGA_SaveRAW_256Color(System.IO.BinaryWriter BW, int spritenum)
        {
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y++)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 1)
                {
                    int sp1 = spritepixel[CurrentBank, spritenum, x, y];
                    string tbyte = "";
                    tbyte += VbX.Dec2Bin8Bit(sp1);
                    BW.Write((Byte)VbX.Bin2Dec(tbyte));
                }
            }


        }/************************************************************************************************************************************************/
        private void saveRAWBitmapToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }

            if (rdoDisplay256.Checked)
            {
                SaveGridSprites((int)Spr_Wid[CurrentSprite], (int)Spr_Hei[CurrentSprite], 10002, true);
                return;
            }

            if (rdoDisplayCPC.Checked)
            {
                SaveGridSprites((int)Spr_Wid[CurrentSprite], (int)Spr_Hei[CurrentSprite], 2, true);
                return;
            }
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            MSX_SaveRAW_16Color(BW, CurrentSprite);


            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void saveRawBitmapToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            // SAM uses same screen format as MSX
            saveRAWBitmapToolStripMenuItem3_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void saveRawBitmapToolStripMenuItem4_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            //Spectrum and TI-83 use the same bitmap format!
            saveRawBitmapToolStripMenuItem1_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void saveCPCZigTileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "CPC Binary Sprite (*.SPR)|*.SPR";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            int thisspritebytepos = firstspritepos;




            for (int spritenum = 0; spritenum < SpriteCount; spritenum++)
            {
                if (Spr_MemposReset[spritenum] != 0)
                {
                    while (ST.Position % 256 != 0)
                    {
                        BW.Write((Byte)(0));
                        //   VbX.MsgBox(ST.Position.ToString());
                    }
                }
                if (rdoDisplayCPC0.Checked)
                {
                    CPC_SaveRAW_16Color(BW, spritenum, 1);
                }
                else
                {
                    CPC_SaveRAW_4Color(BW, spritenum, true, 1);
                }

            }

            BW.Close();
            ST.Close();
            //VbX.MsgBox("Saved");
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void saveRawBitmapToolStripMenuItem5_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);
            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            int firsts = 0;
            int lasts = BankSpriteCount;
            if (!chkSaveMultiRaw.Checked) { firsts = CurrentSprite; lasts = CurrentSprite + 1; }

            for (int cn = firsts; cn < lasts; cn++)
            {
                if (rdoDisplayCPC.Checked)
                {
                    SaveRAW_Planar(BW, cn, 2);
                }
                else
                {
                    SaveRAW_Planar(BW, cn, 4);
                }
            }

            BW.Close();
            ST.Close();



            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        void SaveRAW_PlanarFM7Tile(System.IO.BinaryWriter BW, int spritenum, int planes)
        {
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 8)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
                {
                    for (int p = 7; p > 7 - planes; p--)
                    {
                        for (int y2 = 0; y2 < 8; y2++)
                        {

                            int sp0 = GetDisplayNum(CurrentBank, spritenum, x, y + y2);
                            int sp1 = GetDisplayNum(CurrentBank, spritenum, x + 1, y + y2);
                            int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + y2);
                            int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 3, y + y2);
                            int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 4, y + y2);
                            int sp5 = GetDisplayNum(CurrentBank, spritenum, x + 5, y + y2);
                            int sp6 = GetDisplayNum(CurrentBank, spritenum, x + 6, y + y2);
                            int sp7 = GetDisplayNum(CurrentBank, spritenum, x + 7, y + y2);


                            string tbyte = "";
                            tbyte += VbX.Dec2Bin8Bit(sp0).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp3).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp4).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp5).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp6).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp7).Substring(p, 1);
                            BW.Write((Byte)VbX.Bin2Dec(tbyte));
                        }

                    }//y2
                }//x
            }//y

        }
        void SaveRAW_Planar(System.IO.BinaryWriter BW, int spritenum, int planes)
        {
            SaveRAW_Planar(BW, spritenum, planes, 8, 8, 1);

        }
        void SaveRAW_Planar(System.IO.BinaryWriter BW, int spritenum, int planes, int Xwidth, int Yheight, int Yinc)
        {
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += Yheight)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
                {
                    for (int y2 = 0; y2 < Yheight; y2 += Yinc)
                    {

                        int sp0 = GetDisplayNum(CurrentBank, spritenum, x, y + y2);
                        int sp1 = GetDisplayNum(CurrentBank, spritenum, x + 1, y + y2);
                        int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + y2);
                        int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 3, y + y2);
                        int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 4, y + y2);
                        int sp5 = GetDisplayNum(CurrentBank, spritenum, x + 5, y + y2);
                        int sp6 = GetDisplayNum(CurrentBank, spritenum, x + 6, y + y2);
                        int sp7 = GetDisplayNum(CurrentBank, spritenum, x + 7, y + y2);

                        for (int p = 7; p > 7 - planes; p--)
                        {
                            string tbyte = "";
                            tbyte += VbX.Dec2Bin8Bit(sp0).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp3).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp4).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp5).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp6).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp7).Substring(p, 1);
                            BW.Write((Byte)VbX.Bin2Dec(tbyte));
                        }

                    }//y2
                }//x
            }//y

        }
        void SaveRAW_PlanarAp2(System.IO.BinaryWriter BW, int spritenum, int planes)
        {
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 8)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
                {
                    for (int y2 = 0; y2 < 8; y2++)
                    {

                        int sp7 = GetDisplayNum(CurrentBank, spritenum, x, y + y2);
                        int sp6 = GetDisplayNum(CurrentBank, spritenum, x + 1, y + y2);
                        int sp5 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + y2);
                        int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 3, y + y2);
                        int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 5, y + y2);
                        int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 6, y + y2);
                        int sp1 = GetDisplayNum(CurrentBank, spritenum, x + 7, y + y2);
                        int sp0 = 0; GetDisplayNum(CurrentBank, spritenum, x + 7, y + y2);

                        for (int p = 7; p > 7 - planes; p--)
                        {
                            string tbyte = "";
                            tbyte += VbX.Dec2Bin8Bit(sp0).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp3).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp4).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp5).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp6).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp7).Substring(p, 1);
                            BW.Write((Byte)VbX.Bin2Dec(tbyte));
                        }

                    }//y2
                }//x
            }//y

        }
        /************************************************************************************************************************************************/
        void SaveRAW_PlanarVert(System.IO.BinaryWriter BW, int spritenum, int planes)
        {

            for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
            {
                for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 8)
                {
                    for (int y2 = 0; y2 < 8; y2++)
                    {

                        int sp0 = GetDisplayNum(CurrentBank, spritenum, x, y + y2);
                        int sp1 = GetDisplayNum(CurrentBank, spritenum, x + 1, y + y2);
                        int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + y2);
                        int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 3, y + y2);
                        int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 4, y + y2);
                        int sp5 = GetDisplayNum(CurrentBank, spritenum, x + 5, y + y2);
                        int sp6 = GetDisplayNum(CurrentBank, spritenum, x + 6, y + y2);
                        int sp7 = GetDisplayNum(CurrentBank, spritenum, x + 7, y + y2);


                        for (int p = 7; p > 7 - planes; p--)
                        {
                            string tbyte = "";
                            tbyte += VbX.Dec2Bin8Bit(sp0).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp3).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp4).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp5).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp6).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp7).Substring(p, 1);
                            BW.Write((Byte)VbX.Bin2Dec(tbyte));
                        }

                    }//y2
                }//x
            }//y

        }

        /************************************************************************************************************************************************/
        void SaveRAW_PlanarPCE(System.IO.BinaryWriter BW, int spritenum, int planes)
        {
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 8)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
                {
                    for (int p2 = 2; p2 >= 0; p2 -= 2)
                    {
                        for (int y2 = 0; y2 < 8; y2++)
                        {

                            int sp0 = GetDisplayNum(CurrentBank, spritenum, x, y + y2);
                            int sp1 = GetDisplayNum(CurrentBank, spritenum, x + 1, y + y2);
                            int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + y2);
                            int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 3, y + y2);
                            int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 4, y + y2);
                            int sp5 = GetDisplayNum(CurrentBank, spritenum, x + 5, y + y2);
                            int sp6 = GetDisplayNum(CurrentBank, spritenum, x + 6, y + y2);
                            int sp7 = GetDisplayNum(CurrentBank, spritenum, x + 7, y + y2);


                            string tbyte = "";
                            int p = 5 + p2;

                            tbyte = "";
                            tbyte += VbX.Dec2Bin8Bit(sp0).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp3).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp4).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp5).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp6).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp7).Substring(p, 1);
                            BW.Write((Byte)VbX.Bin2Dec(tbyte));
                            p = 4 + p2;

                            tbyte = "";
                            tbyte += VbX.Dec2Bin8Bit(sp0).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp3).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp4).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp5).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp6).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp7).Substring(p, 1);
                            BW.Write((Byte)VbX.Bin2Dec(tbyte));


                        }//y2
                    }//p2
                }//x
            }//y

        }

        /************************************************************************************************************************************************/

        void SaveRAW_PlanarSNS(System.IO.BinaryWriter BW, int spritenum, int planes)
        {
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 8)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
                {
                    if (planes == 4)
                    {
                        for (int p2 = 2; p2 >= 0; p2 -= 2)

                        //   for (int p2 =0 ; p2 <= 2; p2 += 2)
                        {
                            for (int y2 = 0; y2 < 8; y2++)
                            {

                                int sp0 = GetDisplayNum(CurrentBank, spritenum, x, y + y2);
                                int sp1 = GetDisplayNum(CurrentBank, spritenum, x + 1, y + y2);
                                int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + y2);
                                int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 3, y + y2);
                                int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 4, y + y2);
                                int sp5 = GetDisplayNum(CurrentBank, spritenum, x + 5, y + y2);
                                int sp6 = GetDisplayNum(CurrentBank, spritenum, x + 6, y + y2);
                                int sp7 = GetDisplayNum(CurrentBank, spritenum, x + 7, y + y2);


                                string tbyte = "";
                                int p = 4 + p2;

                                tbyte = "";
                                tbyte += VbX.Dec2Bin8Bit(sp0).Substring(p, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp1).Substring(p, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp2).Substring(p, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp3).Substring(p, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp4).Substring(p, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp5).Substring(p, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp6).Substring(p, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp7).Substring(p, 1);
                                BW.Write((Byte)VbX.Bin2Dec(tbyte));
                                p = 5 + p2;

                                tbyte = "";
                                tbyte += VbX.Dec2Bin8Bit(sp0).Substring(p, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp1).Substring(p, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp2).Substring(p, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp3).Substring(p, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp4).Substring(p, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp5).Substring(p, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp6).Substring(p, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp7).Substring(p, 1);
                                BW.Write((Byte)VbX.Bin2Dec(tbyte));


                            }//y2
                        }//p2
                    }
                    else
                    {
                        for (int y2 = 0; y2 < 8; y2++)
                        {

                            int sp0 = GetDisplayNum(CurrentBank, spritenum, x, y + y2);
                            int sp1 = GetDisplayNum(CurrentBank, spritenum, x + 1, y + y2);
                            int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + y2);
                            int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 3, y + y2);
                            int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 4, y + y2);
                            int sp5 = GetDisplayNum(CurrentBank, spritenum, x + 5, y + y2);
                            int sp6 = GetDisplayNum(CurrentBank, spritenum, x + 6, y + y2);
                            int sp7 = GetDisplayNum(CurrentBank, spritenum, x + 7, y + y2);


                            string tbyte = "";
                            int p = 4 + 2;

                            tbyte = "";
                            tbyte += VbX.Dec2Bin8Bit(sp0).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp3).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp4).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp5).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp6).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp7).Substring(p, 1);
                            BW.Write((Byte)VbX.Bin2Dec(tbyte));
                            p = 5 + 2;

                            tbyte = "";
                            tbyte += VbX.Dec2Bin8Bit(sp0).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp3).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp4).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp5).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp6).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp7).Substring(p, 1);
                            BW.Write((Byte)VbX.Bin2Dec(tbyte));


                        }//y2

                    }
                }//x
            }//y

        }

        /************************************************************************************************************************************************/

        void SaveRAW_PlanarNES(System.IO.BinaryWriter BW, int spritenum, int planes)
        {
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 8)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
                {
                    for (int p2 = 0; p2 <= 1; p2 += 1)
                    {
                        for (int y2 = 0; y2 < 8; y2++)
                        {

                            int sp0 = GetDisplayNum(CurrentBank, spritenum, x, y + y2);
                            int sp1 = GetDisplayNum(CurrentBank, spritenum, x + 1, y + y2);
                            int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + y2);
                            int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 3, y + y2);
                            int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 4, y + y2);
                            int sp5 = GetDisplayNum(CurrentBank, spritenum, x + 5, y + y2);
                            int sp6 = GetDisplayNum(CurrentBank, spritenum, x + 6, y + y2);
                            int sp7 = GetDisplayNum(CurrentBank, spritenum, x + 7, y + y2);


                            string tbyte = "";
                            int p = 7 - p2;

                            tbyte = "";
                            tbyte += VbX.Dec2Bin8Bit(sp0).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp3).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp4).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp5).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp6).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp7).Substring(p, 1);
                            BW.Write((Byte)VbX.Bin2Dec(tbyte));
                        }//y2
                    }//p2
                }//x
            }//y

        }

        /************************************************************************************************************************************************/

        void SaveRAW_PlanarAMI(System.IO.BinaryWriter BW, int spritenum, int planes)
        {
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 1)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
                {
                    int y2 = 0;

                    int sp0 = GetDisplayNum(CurrentBank, spritenum, x, y + y2);
                    int sp1 = GetDisplayNum(CurrentBank, spritenum, x + 1, y + y2);
                    int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + y2);
                    int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 3, y + y2);
                    int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 4, y + y2);
                    int sp5 = GetDisplayNum(CurrentBank, spritenum, x + 5, y + y2);
                    int sp6 = GetDisplayNum(CurrentBank, spritenum, x + 6, y + y2);
                    int sp7 = GetDisplayNum(CurrentBank, spritenum, x + 7, y + y2);

                    for (int p = 7; p > 7 - planes; p--)
                    {
                        string tbyte = "";
                        tbyte += VbX.Dec2Bin8Bit(sp0).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp1).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp2).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp3).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp4).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp5).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp6).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp7).Substring(p, 1);
                        BW.Write((Byte)VbX.Bin2Dec(tbyte));
                    }

                }//x
            }//y

        }
        /************************************************************************************************************************************************/
        void SaveRAW_PlanarCLX(System.IO.BinaryWriter BW, int spritenum, int planes)
        {
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 1)
            {
                for (int p = 7; p > 7 - planes; p--)
                {
                    for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
                    {
                        int y2 = 0;

                        int sp0 = GetDisplayNum(CurrentBank, spritenum, x, y + y2);
                        int sp1 = GetDisplayNum(CurrentBank, spritenum, x + 1, y + y2);
                        int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + y2);
                        int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 3, y + y2);
                        int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 4, y + y2);
                        int sp5 = GetDisplayNum(CurrentBank, spritenum, x + 5, y + y2);
                        int sp6 = GetDisplayNum(CurrentBank, spritenum, x + 6, y + y2);
                        int sp7 = GetDisplayNum(CurrentBank, spritenum, x + 7, y + y2);

                        string tbyte = "";
                        tbyte += VbX.Dec2Bin8Bit(sp0).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp1).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp2).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp3).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp4).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp5).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp6).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp7).Substring(p, 1);
                        BW.Write((Byte)VbX.Bin2Dec(tbyte));
                    }//x

                }//p
            }//y

        }
        void SaveRAW_PlanarFM7(System.IO.BinaryWriter BW, int spritenum, int planes)
        {
            for (int p = 7; p > 7 - planes; p--)
            {
                for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 1)
                {

                    for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
                    {
                        int y2 = 0;

                        int sp0 = GetDisplayNum(CurrentBank, spritenum, x, y + y2);
                        int sp1 = GetDisplayNum(CurrentBank, spritenum, x + 1, y + y2);
                        int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + y2);
                        int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 3, y + y2);
                        int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 4, y + y2);
                        int sp5 = GetDisplayNum(CurrentBank, spritenum, x + 5, y + y2);
                        int sp6 = GetDisplayNum(CurrentBank, spritenum, x + 6, y + y2);
                        int sp7 = GetDisplayNum(CurrentBank, spritenum, x + 7, y + y2);

                        string tbyte = "";
                        tbyte += VbX.Dec2Bin8Bit(sp0).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp1).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp2).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp3).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp4).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp5).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp6).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp7).Substring(p, 1);
                        BW.Write((Byte)VbX.Bin2Dec(tbyte));
                    }//x

                }//p
            }//y

        }
        /************************************************************************************************************************************************/
        void SaveRAW_PlanarCLX8(System.IO.BinaryWriter BW, int spritenum, int planes)
        {
            for (int y2 = Spr_MinY[spritenum]; y2 < Spr_Hei[spritenum]; y2 += 8)
            {

                for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
                {
                    for (int p = 7; p > 7 - planes; p--)
                    {

                        for (int y = 0; y < 8; y += 1)
                        {
                            int sp0 = GetDisplayNum(CurrentBank, spritenum, x, y + y2);
                            int sp1 = GetDisplayNum(CurrentBank, spritenum, x + 1, y + y2);
                            int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + y2);
                            int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 3, y + y2);
                            int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 4, y + y2);
                            int sp5 = GetDisplayNum(CurrentBank, spritenum, x + 5, y + y2);
                            int sp6 = GetDisplayNum(CurrentBank, spritenum, x + 6, y + y2);
                            int sp7 = GetDisplayNum(CurrentBank, spritenum, x + 7, y + y2);

                            string tbyte = "";
                            tbyte += VbX.Dec2Bin8Bit(sp0).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp3).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp4).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp5).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp6).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp7).Substring(p, 1);
                            BW.Write((Byte)VbX.Bin2Dec(tbyte));
                        }//x

                    }//p
                }//y
            }
        }
        /************************************************************************************************************************************************/


        void SaveRAW_PlanarAST(System.IO.BinaryWriter BW, int spritenum, int planes)
        {
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 1)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 16)
                {
                    //  for (int y2 = 0; y2 < 8; y2++)
                    // {
                    int y2 = 0;

                    int sp0 = GetDisplayNum(CurrentBank, spritenum, x, y + y2);
                    int sp1 = GetDisplayNum(CurrentBank, spritenum, x + 1, y + y2);
                    int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + y2);
                    int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 3, y + y2);
                    int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 4, y + y2);
                    int sp5 = GetDisplayNum(CurrentBank, spritenum, x + 5, y + y2);
                    int sp6 = GetDisplayNum(CurrentBank, spritenum, x + 6, y + y2);
                    int sp7 = GetDisplayNum(CurrentBank, spritenum, x + 7, y + y2);

                    int sp8 = GetDisplayNum(CurrentBank, spritenum, x + 8, y + y2);
                    int sp9 = GetDisplayNum(CurrentBank, spritenum, x + 9, y + y2);
                    int spA = GetDisplayNum(CurrentBank, spritenum, x + 10, y + y2);
                    int spB = GetDisplayNum(CurrentBank, spritenum, x + 11, y + y2);
                    int spC = GetDisplayNum(CurrentBank, spritenum, x + 12, y + y2);
                    int spD = GetDisplayNum(CurrentBank, spritenum, x + 13, y + y2);
                    int spE = GetDisplayNum(CurrentBank, spritenum, x + 14, y + y2);
                    int spF = GetDisplayNum(CurrentBank, spritenum, x + 15, y + y2);


                    for (int p = 7; p > 7 - planes; p--)
                    {
                        string tbyte = "";
                        tbyte += VbX.Dec2Bin8Bit(sp0).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp1).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp2).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp3).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp4).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp5).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp6).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp7).Substring(p, 1);
                        BW.Write((Byte)VbX.Bin2Dec(tbyte));
                        tbyte = "";
                        tbyte += VbX.Dec2Bin8Bit(sp8).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp9).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(spA).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(spB).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(spC).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(spD).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(spE).Substring(p, 1);
                        tbyte += VbX.Dec2Bin8Bit(spF).Substring(p, 1);
                        BW.Write((Byte)VbX.Bin2Dec(tbyte));
                    }

                    //  }//y2
                }//x
            }//y

        }

        void SaveRAW_PlanarAST8x8(System.IO.BinaryWriter BW, int spritenum, int planes)
        {
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 8)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
                {
                    for (int yy = 0; yy < 8; yy++)
                    {

                        //  for (int y2 = 0; y2 < 8; y2++)
                        // {
                        int y2 = 0;

                        int sp0 = GetDisplayNum(CurrentBank, spritenum, x, yy + y + y2);
                        int sp1 = GetDisplayNum(CurrentBank, spritenum, x + 1, yy + y + y2);
                        int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 2, yy + y + y2);
                        int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 3, yy + y + y2);
                        int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 4, yy + y + y2);
                        int sp5 = GetDisplayNum(CurrentBank, spritenum, x + 5, yy + y + y2);
                        int sp6 = GetDisplayNum(CurrentBank, spritenum, x + 6, yy + y + y2);
                        int sp7 = GetDisplayNum(CurrentBank, spritenum, x + 7, yy + y + y2);


                        for (int p = 7; p > 7 - planes; p--)
                        {
                            string tbyte = "";
                            tbyte += VbX.Dec2Bin8Bit(sp0).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp3).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp4).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp5).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp6).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp7).Substring(p, 1);
                            BW.Write((Byte)VbX.Bin2Dec(tbyte));

                        }
                    }
                    //  }//y2
                }//x
            }//y

        }
        /************************************************************************************************************************************************/

        private void saveRawBitmapToolStripMenuItem6_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }

            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            SaveRAW_Planar(BW, CurrentSprite, 2);


            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }

        /************************************************************************************************************************************************/

        private void saveRLEToolStripMenuItem_Click(object sender, EventArgs e)
        {

            StringBuilder result = new StringBuilder();
            StringBuilder Header = new StringBuilder();

            for (int c = 0; c < SpriteCount; c++)
            {

                int w = Spr_Wid[c] / 2;
                string Filen = "Sprite" + VbX.CStr(c);


                Header.Append("     ScreenStartDrawing" + VbX.nl());
                Header.Append("     di" + VbX.nl());
                Header.Append("     call " + Filen + "_Setup" + VbX.nl());
                Header.Append("     call RLE_Draw" + VbX.nl());
                Header.Append("     ScreenStopDrawing" + VbX.nl());
                Header.Append("     di" + VbX.nl());
                Header.Append("     halt" + VbX.nl());
                Header.Append("     read \"\\SrcSAM\\SAM_V1_RLE.asm\"" + VbX.nl());


                result.Append(Filen + "_Setup:" + VbX.nl());

                result.Append("     ld hl," + Filen + "_Start-1" + VbX.nl());
                result.Append("     ld de," + Filen + "_End-1" + VbX.nl());
                result.Append("     ld b,0   ;Y-Start" + VbX.nl());
                result.Append("     ld ixh," + VbX.CStr(w) + "	;Width" + VbX.nl());
                result.Append("     ld IXL," + VbX.CStr(64 - (w / 2)) + "+" + VbX.CStr(w) + "-1	;X-Righthandside" + VbX.nl());
                result.Append("     ret" + VbX.nl());


                AkuSpriteEditor.RLEBinarySAM nr = new AkuSpriteEditor.RLEBinarySAM();
                result.Append(Filen + "_Start:" + VbX.nl());
                nr.width = Spr_Wid[c];
                nr.height = Spr_Hei[c];
                nr.spritepixel = new short[maxSpriteSizeX, maxSpriteSizeY];
                for (int y = 0; y < nr.height; y++)
                {
                    for (int x = 0; x < nr.width; x++)
                    {
                        nr.spritepixel[x, y] = spritepixel[CurrentBank, c, x, y];
                    }
                }
                nr.NewRLE();

                result.Append(" db ");
                for (int i = 0; i < nr.RleDataPos; i++)
                {
                    if (i > 0)
                    {
                        if (i % 16 == 0)
                        {
                            result.Append(VbX.nl() + "  db ");
                        }
                        else
                        {
                            result.Append(",");
                        }
                    }
                    result.Append("&" + VbX.Hex(nr.RleData[i]));
                }
                result.Append(VbX.nl() + Filen + "_End:" + VbX.nl() + VbX.nl());
            }
            Clipboard.SetText(Header.ToString() + VbX.nl() + VbX.nl() + result.ToString());
            VbX.MsgBox("Copied to Clipboard");
        }

        /************************************************************************************************************************************************/

        private void saveRAWMSX1BitmapToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SaveRAW_MSXBW(BW, s, 1);
            }

            BW.Close();
            ST.Close();

            ST = new System.IO.FileStream(fd.FileName + ".COL", System.IO.FileMode.Create, System.IO.FileAccess.Write);
            BW = new System.IO.BinaryWriter(ST);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SaveRAW_MSXColor(BW, s, 1);
            }
            BW.Close();
            ST.Close();



            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);

        }


        void SaveRAW_MSXBW(System.IO.BinaryWriter BW, int spritenum, int planes)
        {
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 8)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
                {
                    for (int y2 = 0; y2 < 8; y2++)
                    {
                        int ColorF = 0;
                        int ColorB = 0;
                        GetDisplayPaletteFB(ref ColorF, ref ColorB, CurrentBank, spritenum, x, y + y2);

                        //string tbyte = "";
                        // tbyte += VbX.Dec2Bin8Bit(ColorF).Substring(4, 4);
                        // tbyte += VbX.Dec2Bin8Bit(ColorB).Substring(4, 4);


                        int sp0 = GetDisplayNum(CurrentBank, spritenum, x, y + y2);
                        int sp1 = GetDisplayNum(CurrentBank, spritenum, x + 1, y + y2);
                        int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + y2);
                        int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 3, y + y2);
                        int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 4, y + y2);
                        int sp5 = GetDisplayNum(CurrentBank, spritenum, x + 5, y + y2);
                        int sp6 = GetDisplayNum(CurrentBank, spritenum, x + 6, y + y2);
                        int sp7 = GetDisplayNum(CurrentBank, spritenum, x + 7, y + y2);

                        if (sp0 == ColorB) sp0 = 0; else sp0 = 1;
                        if (sp1 == ColorB) sp1 = 0; else sp1 = 1;
                        if (sp2 == ColorB) sp2 = 0; else sp2 = 1;
                        if (sp3 == ColorB) sp3 = 0; else sp3 = 1;
                        if (sp4 == ColorB) sp4 = 0; else sp4 = 1;
                        if (sp5 == ColorB) sp5 = 0; else sp5 = 1;
                        if (sp6 == ColorB) sp6 = 0; else sp6 = 1;
                        if (sp7 == ColorB) sp7 = 0; else sp7 = 1;

                        for (int p = 7; p > 7 - planes; p--)
                        {
                            string tbyte = "";
                            tbyte += VbX.Dec2Bin8Bit(sp0).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp3).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp4).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp5).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp6).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp7).Substring(p, 1);
                            BW.Write((Byte)VbX.Bin2Dec(tbyte));
                        }

                    }//y2
                }//x
            }//y

        }
        void SaveRAW_MSXColor(System.IO.BinaryWriter BW, int spritenum, int planes)
        {
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 8)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
                {
                    for (int y2 = 0; y2 < 8; y2++)
                    {
                        int ColorF = 0;
                        int ColorB = 0;
                        GetDisplayPaletteFB(ref ColorF, ref ColorB, CurrentBank, spritenum, x, y + y2);

                        string tbyte = "";
                        tbyte += VbX.Dec2Bin8Bit(ColorF).Substring(4, 4);
                        tbyte += VbX.Dec2Bin8Bit(ColorB).Substring(4, 4);
                        BW.Write((Byte)VbX.Bin2Dec(tbyte));


                    }//y2
                }//x
            }//y

        }
        /************************************************************************************************************************************************/

        private void saveRawVdpTileBitmapToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (rdoDisplayMSX.Checked)
            {
                SaveTileMap(8, 8, 4, 1);
            }
            else
            {
                SaveTileMap(8, 8, 2, 1);
            }


        }
        private void SaveTileMap(int Xwid, int Yhei, int Bpp, int ymove)
        {

            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            int SprFirst = CurrentSprite;
            int SprLast = CurrentSprite + 1;

            if (chkSaveMultiRaw.Checked) { SprFirst = 0; SprLast = SpriteCount; }

            for (int spritenum = SprFirst; spritenum <= SprLast; spritenum++)
            {

                for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += Yhei)
                {
                    for (int x = 0; x < Spr_Wid[spritenum]; x += Xwid)
                    {

                        for (int y2 = 0; y2 < Yhei; y2 += ymove)
                        {
                            if (Bpp == 2)
                            {
                                for (int xx = 0; xx < Xwid; xx += 4)
                                {
                                    int sp1 = GetDisplayNum(CurrentBank, spritenum, xx + x, y + y2);
                                    int sp2 = GetDisplayNum(CurrentBank, spritenum, xx + x + 1, y + y2);
                                    int sp3 = GetDisplayNum(CurrentBank, spritenum, xx + x + 2, y + y2);
                                    int sp4 = GetDisplayNum(CurrentBank, spritenum, xx + x + 3, y + y2);

                                    if (sp1 == 16) sp1 = 0;
                                    if (sp2 == 16) sp2 = 0;
                                    if (sp3 == 16) sp3 = 0;
                                    if (sp4 == 16) sp4 = 0;

                                    string tbyte = "";
                                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);

                                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);

                                    tbyte += VbX.Dec2Bin8Bit(sp3).Substring(6, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp3).Substring(7, 1);

                                    tbyte += VbX.Dec2Bin8Bit(sp4).Substring(6, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp4).Substring(7, 1);

                                    BW.Write((Byte)VbX.Bin2Dec(tbyte));
                                }
                            }
                            if (Bpp == 4)
                            {
                                for (int xx = 0; xx < Xwid; xx += 2)
                                {
                                    int sp1 = GetDisplayNum(CurrentBank, spritenum, xx + x, y + y2);
                                    int sp2 = GetDisplayNum(CurrentBank, spritenum, xx + x + 1, y + y2);

                                    if (sp1 == 16) sp1 = 0;
                                    if (sp2 == 16) sp2 = 0;
                                    string tbyte = "";
                                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(4, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(5, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);

                                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(4, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(5, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);

                                    BW.Write((Byte)VbX.Bin2Dec(tbyte));
                                }
                            } // 4bpp
                            if (Bpp == 8)
                            {
                                for (int xx = 0; xx < Xwid; xx++)
                                {
                                    int sp1 = GetDisplayNum(CurrentBank, spritenum, xx + x, y + y2);
                                    BW.Write((Byte)sp1);
                                }
                            } // 8bpp
                        }//y2
                    }//x
                }//y
            }

            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(null, null);


        }
        /************************************************************************************************************************************************/

        private void rdoCPCdither_CheckedChanged(object sender, EventArgs e)
        {
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void rdoSpecDither_CheckedChanged(object sender, EventArgs e)
        {
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void saveCPCSCRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "CPC Binary Screen (*.SCR)|*.SCR";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            byte b = 0;
            int bytepos = 0;
            int thisspritebytepos = firstspritepos;


            int spritenum = CurrentSprite;
            // for (int spritenum = 0; spritenum < SpriteCount; spritenum++)
            {

                if (rdoDisplayCPC0.Checked)
                {
                    CPC_SaveRAW_16Color(BW, spritenum, 8);
                }
                else if (RdoDisplayEGX.Checked)
                {
                    VbX.MsgBox("EGX");
                    CPC_SaveRAW_EGX(BW, spritenum, 8);
                }
                else
                {
                    CPC_SaveRAW_4Color(BW, spritenum, false, 8);
                }

            }

            BW.Close();
            ST.Close();
            //VbX.MsgBox("Saved");
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/

        private void saveFIXFontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "FIX Font Bitmap (*.FIX)|*.FIX";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            int spritenum = CurrentSprite;
            for (int b = 0; b < BankCount; b++)
            {
                for (int s = 0; s < SpriteCount; s++)
                {
                    for (int y = Spr_MinY[s]; y < Spr_Hei[s]; y += 8)
                    {
                        for (int x = 0; x < Spr_Wid[s]; x += 8)
                        {

                            for (int cc = 0; cc < 8; cc += 2)
                            {
                                for (int y2 = 0; y2 < 8; y2++)
                                {
                                    int xx = 0;
                                    if (cc == 0) xx = 4;
                                    if (cc == 2) xx = 6;
                                    if (cc == 4) xx = 0;
                                    if (cc == 6) xx = 2;


                                    int sp1 = GetDisplayNum(b, s, xx + x + 1, y + y2);
                                    int sp2 = GetDisplayNum(b, s, xx + x, y + y2);

                                    if (sp1 == 16) sp1 = 0;
                                    if (sp2 == 16) sp2 = 0;
                                    string tbyte = "";
                                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(4, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(5, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);

                                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(4, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(5, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);

                                    BW.Write((Byte)VbX.Bin2Dec(tbyte));

                                }
                            }//y2
                        }//x
                    }//y
                }

            }

            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void CpcSpriteCompilerClear_Click(object sender, EventArgs e)
        {
            if (CpcSpriteCompiler == null)
            {
                CpcSpriteCompiler = new AkuSpriteEditor.CompCPC();

            }
            CpcSpriteCompiler.textBox1_Text = "";
            CpcSpriteCompiler.Doreset();
        }
        /************************************************************************************************************************************************/
        private void CpcSpriteConvaddOneDiffToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (CpcSpriteCompiler == null)
            {
                CpcSpriteCompiler = new AkuSpriteEditor.CompCPC();
                CpcSpriteCompiler.Doreset();
            }
            CpcSpriteCompiler.txtFilename_Text = "ClipImage" + CurrentSprite.ToString() + "_";
            Bitmap clipbit = new Bitmap(Spr_Wid[CurrentSprite], Spr_Hei[CurrentSprite]);
            for (int x = 0; x < Spr_Wid[CurrentSprite]; x++)
            {
                for (int y = 0; y < Spr_Hei[CurrentSprite]; y++)
                {
                    int a = spritepixel[CurrentBank, CurrentSprite, x, y];
                    if (a > 4) a = 4;
                    CpcSpriteCompiler.globals_PixelMap[x, y] = a;


                    clipbit.SetPixel(x, y, ColorSelector[spritepixel[CurrentBank, CurrentSprite, x, y]].BackColor);
                }
            }

            Clipboard.SetImage(clipbit);
            CpcSpriteCompiler.button1_Click(null, null);
            string s = CpcSpriteCompiler.textBox1_Text;
            Clipboard.SetText(s);
            VbX.MsgBox("Saved to clipboard!");
        }
        /************************************************************************************************************************************************/
        private void saveRawBitmapToolStripMenuItem7_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            SaveRAW_PlanarAST(BW, CurrentSprite, 4);


            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/


        private void saveRawBitmapToolStripMenuItem8_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }

            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            SaveRAW_PlanarAMI(BW, CurrentSprite, 4);


            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void saveRawBitmapToolStripMenuItem9_Click(object sender, EventArgs e)
        {

            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }

            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            MSX_SaveRAW_16Color(BW, CurrentSprite);

            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/

        private void ResetButtons()
        {


            tabSpriteTools.TabPages.Remove(tabPixelPaint);
            tabSpriteTools.TabPages.Remove(tabZXPaint);
            tabSpriteTools.TabPages.Remove(tabColorSwap);
            tabSpriteTools.TabPages.Remove(tabTileCopy);
            tabSpriteTools.TabPages.Remove(tabVector);

            btnTileCopy.BackColor = SystemColors.ButtonFace;
            btnToolPixelPaint.BackColor = SystemColors.ButtonFace;
            btnZXpaint2.BackColor = SystemColors.ButtonFace;
            btnColorSwap2.BackColor = SystemColors.ButtonFace;
            btnFloodFill.BackColor = SystemColors.ButtonFace;
            btnVector.BackColor = SystemColors.ButtonFace;
            CurrentTool = "";
        }
        /************************************************************************************************************************************************/
        private void btnToolPixelPaint_Click(object sender, EventArgs e)
        {

            ResetButtons();
            tabSpriteTools.TabPages.Add(tabPixelPaint);
            tabPixelPaint.Show();
            btnToolPixelPaint.BackColor = SystemColors.ButtonShadow;
            CurrentTool = "pixelpaint";
            tabSpriteTools.SelectedTab = tabPixelPaint;
        }
        /************************************************************************************************************************************************/
        private void cboCheckMode_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = (char)(0);
        }
        /************************************************************************************************************************************************/
        private void btnZXpaint2_Click(object sender, EventArgs e)
        {
            ResetButtons();
            tabSpriteTools.TabPages.Add(tabZXPaint);
            tabZXPaint.Show();
            btnZXpaint2.BackColor = SystemColors.ButtonShadow;
            CurrentTool = "zxpaint";
            tabSpriteTools.SelectedTab = tabZXPaint;
        }
        /************************************************************************************************************************************************/
        private void btnColorSwap_Click_1(object sender, EventArgs e)
        {
            ResetButtons();
            tabSpriteTools.TabPages.Add(tabColorSwap);
            tabZXPaint.Show();
            btnColorSwap2.BackColor = SystemColors.ButtonShadow;
            CurrentTool = "colorswap";
            tabSpriteTools.SelectedTab = tabColorSwap;
        }
        /************************************************************************************************************************************************/
        private void Palettepanelreset(object sender)
        {
            pnlC64pal.Visible = false;
            pnlZXPalette.Visible = false;
            pnlNESpal.Visible = false;
            pnlMSXpal.Visible = false;

            pnlApplePal.Visible = false;
            pnlULAPal.Visible = false;
        }
        private void BtnAltPal_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(toolTip1.GetToolTip((Control)sender)); }
            rdoDisplayMSX.Checked = true;
            Palettepanelreset(null);

            if (BtnAltPal.Text == "AltPal:  ")
            {
                rdoDisplaySpeccy.Checked = true;
                BtnAltPal.Text = "AltPal: ZX";
                pnlZXPalette.Visible = true;

            }
            else if (BtnAltPal.Text == "AltPal: ZX")
            {
                BtnAltPal.Text = "AltPal: C64";
                pnlC64pal.Visible = true;
                rdoC64_4Color.Checked = true;

            }

            else if (BtnAltPal.Text == "AltPal: C64")
            {
                BtnAltPal.Text = "AltPal: NES";
                pnlNESpal.Visible = true;

            }
            else if (BtnAltPal.Text == "AltPal: NES")
            {

                BtnAltPal.Text = "AltPal: MSX";
                pnlMSXpal.Visible = true;
            }
            else if (BtnAltPal.Text == "AltPal: MSX")
            {

                BtnAltPal.Text = "AltPal: APL";
                pnlApplePal.Visible = true;
                rdoAppleColor.Checked = true;
            }
            else if (BtnAltPal.Text == "AltPal: APL")
            {
                BtnAltPal.Text = "AltPal: ULA";
                pnlULAPal.Visible = true;
                rdoULAplus.Checked = true;
            }
            else
            {
                BtnAltPal.Text = "AltPal:  ";
            }
        }
        /************************************************************************************************************************************************/

        private void cPC16ColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rdoDisplayCPC0.Checked = true;
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void rdoDisplayCPC0_CheckedChanged(object sender, EventArgs e)
        {
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void colorpairsCPCENTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rdoCPCpairs.Checked = true;
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void colorditheredCPCENTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rdoCPCdither.Checked = true;
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void colorditheredToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rdoSpecDither.Checked = true;
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void cbo4colorDither_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void applyViewColorConversionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int yy = 0; yy < Spr_Hei[CurrentSprite]; yy++)
            {
                for (int xx = 0; xx < Spr_Wid[CurrentSprite]; xx++)
                {
                    spritepixel[CurrentBank, CurrentSprite, xx, yy] = GetDisplayNum(CurrentBank, CurrentSprite, xx, yy);
                }
            }
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void rLEASMToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            DoCPCRLE("ent");
        }
        /************************************************************************************************************************************************/
        private void saveRawBitmapToolStripMenuItem10_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            // Genesis uses MSXvdp Exporter
            saveRawVdpTileBitmapToolStripMenuItem_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void rdoGuide6_12_24_CheckedChanged(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); }
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void rdoGuide4_8_32_CheckedChanged(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); }
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void rdoGuide4_8_24_CheckedChanged(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); }
            btnRefresh_Click(sender, e);

        }
        /************************************************************************************************************************************************/
        private void loadPaletteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DoLoad(false, false, true, false);
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void loadPixelsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DoLoad(true, false, false, false);
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void importBackgroundToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DoLoad(false, true, false, false);
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/

        private void saveRawBitmap2ColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Raw Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);


            int spritenum = CurrentSprite;
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 1)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 7)
                {
                    int yy = 0;
                    int sp7 = GetDisplayNum(CurrentBank, spritenum, x, y + yy);
                    int sp6 = GetDisplayNum(CurrentBank, spritenum, x + 1, y + yy);
                    int sp5 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + yy);
                    int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 3, y + yy);
                    int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 4, y + yy);
                    int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 5, y + yy);
                    int sp1 = GetDisplayNum(CurrentBank, spritenum, x + 6, y + yy);
                    // int sp8 = GetDisplayNum(CurrentBank, spritenum, x + 7, y + yy);

                    if (sp1 > 1) sp1 = 1;
                    if (sp2 > 1) sp2 = 1;
                    if (sp3 > 1) sp3 = 1;
                    if (sp4 > 1) sp4 = 1;
                    if (sp5 > 1) sp5 = 1;
                    if (sp6 > 1) sp6 = 1;
                    if (sp7 > 1) sp7 = 1;
                    //if (sp8 > 1) sp8 = 1;

                    string tbyte = "";
                    tbyte += "0";
                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp3).Substring(7, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp4).Substring(7, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp5).Substring(7, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp6).Substring(7, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp7).Substring(7, 1);
                    // tbyte += VbX.Dec2Bin8Bit(sp8).Substring(7, 1);

                    BW.Write((Byte)VbX.Bin2Dec(tbyte));


                }

            }
            BW.Close();
        }

        /************************************************************************************************************************************************/

        private void saveRawBitmap4ColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Raw Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);


            int spritenum = CurrentSprite;
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 1)
            {

                for (int x = 0; x < Spr_Wid[spritenum]; x += 14)
                {
                    int yy = 0;
                    int sp1 = GetDisplayNum(CurrentBank, spritenum, x, y + yy);
                    int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + yy);
                    int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 4, y + yy);
                    int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 6, y + yy);
                    int sp5 = GetDisplayNum(CurrentBank, spritenum, x + 8, y + yy);
                    int sp6 = GetDisplayNum(CurrentBank, spritenum, x + 10, y + yy);
                    int sp7 = GetDisplayNum(CurrentBank, spritenum, x + 12, y + yy);



                    string tbyte = "";
                    int colorbit = SpeccyPaletteF[CurrentBank, CurrentSprite, x / 7, y / 8];
                    if (colorbit > 1) colorbit = 1;
                    tbyte += colorbit.ToString();
                    tbyte += VbX.Dec2Bin8Bit(sp4).Substring(7, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp3).Substring(6, 2);
                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 2);
                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 2);

                    BW.Write((Byte)VbX.Bin2Dec(tbyte));
                    colorbit = SpeccyPaletteF[CurrentBank, CurrentSprite, (x + 7) / 7, y / 8];
                    if (colorbit > 1) colorbit = 1;
                    tbyte = colorbit.ToString();
                    tbyte += VbX.Dec2Bin8Bit(sp7).Substring(6, 2);
                    tbyte += VbX.Dec2Bin8Bit(sp6).Substring(6, 2);
                    tbyte += VbX.Dec2Bin8Bit(sp5).Substring(6, 2);
                    tbyte += VbX.Dec2Bin8Bit(sp4).Substring(6, 1);



                    BW.Write((Byte)VbX.Bin2Dec(tbyte));
                }

            }
            BW.Close();
        }

        /************************************************************************************************************************************************/

        private void saveRawBitmap2ColorToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            saveRawBitmapToolStripMenuItem1_Click(sender, e);
        }
        /************************************************************************************************************************************************/

        private void saveRawBitmap4ColorToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Raw Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);


            int spritenum = CurrentSprite;
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 1)
            {

                for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
                {
                    int yy = 0;
                    int sp1 = GetDisplayNum(CurrentBank, spritenum, x, y + yy);
                    int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + yy);
                    int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 4, y + yy);
                    int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 6, y + yy);

                    string tbyte = "";
                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 2);
                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 2);
                    tbyte += VbX.Dec2Bin8Bit(sp3).Substring(6, 2);
                    tbyte += VbX.Dec2Bin8Bit(sp4).Substring(6, 2);

                    BW.Write((Byte)VbX.Bin2Dec(tbyte));
                }

            }
            BW.Close();
        }
        /************************************************************************************************************************************************/

        private void saveRawBitmapToolStripMenuItem11_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            saveRAWBitmapToolStripMenuItem3_Click(sender, e);   //Lynx uses same format as MSX

        }

        /************************************************************************************************************************************************/

        private void saveRawBitmapToolStripMenuItem12_Click(object sender, EventArgs e)         // BBC 4 Color
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Raw Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);


            int spritenum = CurrentSprite;
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 8)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 4)
                {
                    for (int yy = 0; yy < 8; yy += 1)
                    {
                        int sp1 = GetDisplayNum(CurrentBank, spritenum, x, y + yy);
                        int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 1, y + yy);
                        int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + yy);
                        int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 3, y + yy);


                        string tbyte = "";

                        tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp3).Substring(6, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp4).Substring(6, 1);

                        tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp3).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp4).Substring(7, 1);

                        BW.Write((Byte)VbX.Bin2Dec(tbyte));
                    }

                }

            }
            BW.Close();
        }

        /************************************************************************************************************************************************/

        private void saveRawBitmap4ColorToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            // C64 4 color
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Raw Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);


            int spritenum = CurrentSprite;
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 8)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
                {
                    for (int yy = 0; yy < 8; yy += 1)
                    {
                        int sp1 = GetDisplayNum(CurrentBank, spritenum, x, y + yy);
                        int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + yy);
                        int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 4, y + yy);
                        int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 6, y + yy);


                        string tbyte = "";

                        tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 2);
                        tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 2);
                        tbyte += VbX.Dec2Bin8Bit(sp3).Substring(6, 2);
                        tbyte += VbX.Dec2Bin8Bit(sp4).Substring(6, 2);

                        BW.Write((Byte)VbX.Bin2Dec(tbyte));
                    }

                }

            }
            BW.Close();
        }

        /************************************************************************************************************************************************/

        private void saveRawBitmapToolStripMenuItem13_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            // PC Engine Raw

            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            SaveRAW_PlanarPCE(BW, CurrentSprite, 4);


            BW.Close();
            ST.Close();

            btnRefresh_Click(sender, e);
        }

        /************************************************************************************************************************************************/

        private void saveRawBitmapToolStripMenuItem14_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            // Nes Raw Bitmap

            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            SaveRAW_PlanarNES(BW, CurrentSprite, 2);


            BW.Close();
            ST.Close();

            btnRefresh_Click(sender, e);
        }

        /************************************************************************************************************************************************/

        private void saveRawBitmapToolStripMenuItem15_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }

            // Snes Raw Bitmap
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            SaveRAW_PlanarSNS(BW, CurrentSprite, 4);


            BW.Close();
            ST.Close();

            btnRefresh_Click(sender, e);

        }

        /************************************************************************************************************************************************/

        private void saveRawBitmapToolStripMenuItem16_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            SaveRAW_Planar(BW, CurrentSprite, 1);
            //saveSpectrumFont(BW);
            BW.Close();
        }

        /************************************************************************************************************************************************/

        //private void saveSpectrumFont(System.IO.BinaryWriter BW)
        //{

        //    int spritenum = CurrentSprite;
        //    for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 8)
        //    {
        //        for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
        //        {
        //            for (int yy = 0; yy < 8; yy++)
        //            {
        //                int sp1 = GetDisplayNum(CurrentBank, spritenum, x + 0, y + yy);
        //                int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 1, y + yy);
        //                int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + yy);
        //                int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 3, y + yy);
        //                int sp5 = GetDisplayNum(CurrentBank, spritenum, x + 4, y + yy);
        //                int sp6 = GetDisplayNum(CurrentBank, spritenum, x + 5, y + yy);
        //                int sp7 = GetDisplayNum(CurrentBank, spritenum, x + 6, y + yy);
        //                int sp8 = GetDisplayNum(CurrentBank, spritenum, x + 7, y + yy);


        //                if (sp4 == 16 && sp3 == 16 && sp2 == 16 && sp1 == 16 && sp5 == 16 && sp6 == 16 && sp7 == 16 && sp8 == 16)
        //                {
        //                    int transpcol = VbX.Bin2Dec(VbX.Right(VbX.Dec2Bin8Bit(Spr_Xoff[spritenum]), 3));
        //                    if (transpcol == 5)
        //                    {
        //                        sp1 = 0; sp2 = 1;
        //                        sp3 = 0; sp4 = 1;
        //                        sp5 = 0; sp6 = 1;
        //                        sp7 = 0; sp8 = 1;
        //                    }
        //                    if (transpcol == 4)
        //                    {
        //                        sp1 = 1; sp2 = 0;
        //                        sp3 = 1; sp4 = 0;
        //                        sp5 = 1; sp6 = 0;
        //                        sp7 = 1; sp8 = 0;
        //                    }
        //                }
        //                if (sp1 == 16) sp1 = 0;
        //                if (sp2 == 16) sp2 = 0;
        //                if (sp3 == 16) sp3 = 0;
        //                if (sp4 == 16) sp4 = 0;
        //                if (sp5 == 16) sp5 = 0;
        //                if (sp6 == 16) sp6 = 0;
        //                if (sp7 == 16) sp7 = 0;
        //                if (sp8 == 16) sp8 = 0;

        //                if (sp1 > 1) sp1 = 1;
        //                if (sp2 > 1) sp2 = 1;
        //                if (sp3 > 1) sp3 = 1;
        //                if (sp4 > 1) sp4 = 1;
        //                if (sp5 > 1) sp5 = 1;
        //                if (sp6 > 1) sp6 = 1;
        //                if (sp7 > 1) sp7 = 1;
        //                if (sp8 > 1) sp8 = 1;

        //                string tbyte = "";

        //                tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);
        //                tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);
        //                tbyte += VbX.Dec2Bin8Bit(sp3).Substring(7, 1);
        //                tbyte += VbX.Dec2Bin8Bit(sp4).Substring(7, 1);
        //                tbyte += VbX.Dec2Bin8Bit(sp5).Substring(7, 1);
        //                tbyte += VbX.Dec2Bin8Bit(sp6).Substring(7, 1);
        //                tbyte += VbX.Dec2Bin8Bit(sp7).Substring(7, 1);
        //                tbyte += VbX.Dec2Bin8Bit(sp8).Substring(7, 1);





        //                BW.Write((Byte)VbX.Bin2Dec(tbyte));

        //            }

        //        }

        //    }
        //}

        /************************************************************************************************************************************************/

        private void saveBMPMapToolStripMenuItem_Click(object sender, EventArgs e)
        {
            {

                SaveFileDialog fd = new SaveFileDialog();
                fd.Filter = "BMP Map (*.PNG)|*.PNG";
                DialogResult dr = fd.ShowDialog();
                if (dr != DialogResult.OK) return;
                string filename = fd.FileName;


                if (VbX.InStr(VbX.LCase(filename), "bank") > 0)
                {
                    filename = VbX.Left(filename, VbX.Len(filename) - 10);
                }
                else if (VbX.InStr(VbX.LCase(filename), "map") > 0)
                {
                    filename = VbX.Left(filename, VbX.Len(filename) - 8);
                }
                else
                {
                    filename = VbX.Left(filename, VbX.Len(filename) - 4);
                }


                int tilemapwidth = 768;
                int spacing = 48;
                Bitmap colormap = new Bitmap(tilemapwidth, 1024);


                UInt16[,] tilearray = new UInt16[tilemapwidth, 1024];



                for (int x = 0; x < tilemapwidth; x++) //Checkerboard background
                {
                    for (int y = 0; y < 1024; y++)
                    {
                        tilearray[x, y] = 256;
                        if (VbX.CInt(x / 8) % 2 == VbX.CInt(y / 8) % 2)
                        {
                            colormap.SetPixel(x, y, Color.FromArgb(20, 20, 20));
                        }
                        else
                        {
                            colormap.SetPixel(x, y, Color.FromArgb(40, 40, 40));
                        }

                    }

                }
                int CurrentX = 0;
                int CurrentY = 0;

                int[] SprPosX = new int[256];
                int[] SprPosY = new int[256];

                int CurrentYHeight = 0;
                int TotalYHeight = 0;



                int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
                for (int s = 0; s < BankSpriteCount; s++)
                {
                    Spr_Wid[s] = 0;
                    Spr_Hei[s] = 0;
                    Spr_MinX[s] = (Int16)maxSpriteSizeX;
                    Spr_MinY[s] = (Int16)maxSpriteSizeY;
                    if (Spr_FixedSize[s] > 0)
                    {
                        if ((s + 1) > SpriteCount) SpriteCount = s + 1;

                    }


                    for (int cb = 0; cb < BankCount; cb++)
                    {

                        //SpriteStats(s);         // update all our info on the sprites



                        for (int x = 0; x < maxSpriteSizeX; x++)
                        {
                            for (int y = 0; y < maxSpriteSizeY; y++)
                            {
                                // RepaintPixel(x, y);
                                if (spritepixel[cb, s, x, y] != 0)
                                {
                                    if (x >= Spr_Wid[s]) Spr_Wid[s] = (Int16)(x + 1);
                                    if (y >= Spr_Hei[s]) Spr_Hei[s] = (Int16)(y + 1);
                                    if (x < Spr_MinX[s]) Spr_MinX[s] = (Int16)x;
                                    if (y < Spr_MinY[s]) Spr_MinY[s] = (Int16)y;
                                    if ((s + 1) > SpriteCount) SpriteCount = s + 1;
                                }
                            }
                        }
                    }
                }



                byte b = 0;
                int bytepos = 0;
                int thisspritebytepos = firstspritepos;

                for (int s = 0; s < SpriteCount; s++)
                {


                    int ThisActualHeight = Spr_Hei[s];


                    bool OutputThisOne = true;
                    if (Spr_Wid[s] < 1 || ThisActualHeight < 1) OutputThisOne = false;

                    if (OutputThisOne)
                    {
                        for (int sy = 0; sy < 1024; sy += spacing) //Find a position for the new sprite
                        {
                            for (int sx = 0; sx < tilemapwidth - (Spr_Wid[s] - 1); sx += spacing)
                            {
                                if (tilearray[sx, sy] == 256)
                                {
                                    bool valid = true;
                                    for (int zx = 0; zx < Spr_Wid[s]; zx++)
                                    {
                                        for (int zy = 0; zy < Spr_Hei[s]; zy++)
                                        {
                                            if (tilearray[sx + zx, sy + zy] < 256)
                                            {
                                                valid = false;
                                                zy = 1024; zx = 1024;
                                            }
                                        }
                                    }
                                    if (valid == true)
                                    {
                                        CurrentX = sx;
                                        CurrentY = sy;
                                        sy = 1024;
                                        sx = 1024;
                                    }
                                }
                            }
                        }

                        if (Spr_Hei[s] > CurrentYHeight) CurrentYHeight = ThisActualHeight;
                        int sr = (s + 1) % 4;
                        int sg = ((s + 1) / 4) % 4;
                        int sb = ((s + 1) / 16) % 4;
                        //VbX.MsgBox(sr.ToString() + " " + sg.ToString() + " " + sb.ToString() + " ");
                        sr = (sr * 84);
                        sg = (sg * 84);
                        sb = (sb * 84);
                        SprPosX[s] = CurrentX;
                        SprPosY[s] = CurrentY;

                        for (int y = 0; y < Spr_Hei[s]; y++)
                        {
                            int y2 = y - 0;
                            for (int x = 0; x < Spr_Wid[s]; x++)
                            {
                                int c = spritepixel[CurrentBank, s, x, y];
                                //if (c == 16) c = 0;

                                //clipbit.SetPixel(x + CurrentX, y2 + CurrentY, ColorSelector[c].BackColor);

                                colormap.SetPixel(x + CurrentX, y2 + CurrentY, Color.FromArgb(sr, sg, sb));
                                tilearray[x + CurrentX, y2 + CurrentY] = (UInt16)c;
                            }
                        }
                    }

                    CurrentX = CurrentX + Spr_Wid[s];
                    if (CurrentY + ThisActualHeight > TotalYHeight) TotalYHeight = CurrentY + ThisActualHeight;
                }


                for (int col = 0; col < 64; col++)
                {
                    int sr = (col + 1) % 4;
                    int sg = ((col + 1) / 4) % 4;
                    int sb = ((col + 1) / 16) % 4;
                    //VbX.MsgBox(sr.ToString() + " " + sg.ToString() + " " + sb.ToString() + " ");
                    sr = (sr * 84);
                    sg = (sg * 84);
                    sb = (sb * 84);
                    for (int cx = 0; cx < 10; cx++)
                    {
                        for (int cy = 0; cy < 12; cy++)
                        {
                            colormap.SetPixel(col * 10 + cx, 1012 + cy, Color.FromArgb(sr, sg, sb));
                        }
                    }
                }
                colormap.Save(filename + "_Map.png");


                for (int Bnum = 0; Bnum < BankCount; Bnum++)
                {
                    CurrentBank = Bnum;

                    for (int x = 0; x < tilemapwidth; x++) //Checkerboard background
                    {
                        for (int y = 0; y < 1024; y++)
                        {
                            tilearray[x, y] = 256;
                            if (VbX.CInt(x / 8) % 2 == VbX.CInt(y / 8) % 2)
                            {
                                colormap.SetPixel(x, y, Color.FromArgb(20, 20, 20));
                            }
                            else
                            {
                                colormap.SetPixel(x, y, Color.FromArgb(40, 40, 40));
                            }

                        }

                    }
                    for (int s = 0; s < SpriteCount; s++)
                    {


                        for (int y = 0; y < Spr_Hei[s]; y++)
                        {
                            int y2 = y - 0;
                            for (int x = 0; x < Spr_Wid[s]; x++)
                            {
                                int c = spritepixel[Bnum, s, x, y];
                                // if (c == 16) c = 0;

                                colormap.SetPixel(x + SprPosX[s], y2 + SprPosY[s], ColorSelector[c].BackColor);

                                // colormap.SetPixel(x + CurrentX, y2 + CurrentY, Color.FromArgb(sr, sg, sb));
                                //tilearray[x + CurrentX, y2 + CurrentY] = (UInt16)c;
                            }
                        }
                    }

                    for (int col = 0; col <= 16; col++)
                    {
                        for (int cx = 0; cx < 12; cx++)
                        {
                            for (int cy = 0; cy < 12; cy++)
                            {
                                colormap.SetPixel(col * 12 + cx, 1000 + cy, ColorSelector[col].BackColor);
                            }
                        }
                    }



                    colormap.Save(filename + "_Bank" + Bnum.ToString() + ".png");
                }

                CurrentBank = 0;
                //Clipboard.SetImage(colormap);

            }
        }

        /************************************************************************************************************************************************/

        private void loadBMPMaToolStripMenuItem_Click(object sender, EventArgs e)
        {

            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "BMP Map (*.png)|*.png";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;
            string filename = fd.FileName;
            if (VbX.InStr(VbX.LCase(filename), "bank") > 0)
            {
                filename = VbX.Left(filename, VbX.Len(filename) - 10);
            }
            else if (VbX.InStr(VbX.LCase(filename), "map") > 0)
            {
                filename = VbX.Left(filename, VbX.Len(filename) - 8);
            }
            else
            {
                filename = VbX.Left(filename, VbX.Len(filename) - 4);
            }




            Bitmap colormap = new Bitmap(filename + "_Map.png");
            int[] MinX = new int[256];
            int[] MinY = new int[256];

            int[] MaxX = new int[256];
            int[] MaxY = new int[256];
            for (int i = 0; i < BankSpriteCount; i++)
            {
                MaxX[i] = 0;
                MaxY[i] = 0;
                MinX[i] = 10000;
                MinY[i] = 10000;
            }

            for (int x = 0; x < colormap.Width; x++)
            {
                for (int y = 0; y < colormap.Height - 24; y++)
                {
                    Color c = colormap.GetPixel(x, y);
                    int sr = c.R / 84;
                    int sg = c.G / 84;
                    int sb = c.B / 84;
                    int spritenum = sb * 16 + sg * 4 + sr;
                    if (spritenum > 0)
                    {
                        spritenum--;
                        if (x > MaxX[spritenum]) MaxX[spritenum] = x;
                        if (y > MaxY[spritenum]) MaxY[spritenum] = y;

                        if (x < MinX[spritenum]) MinX[spritenum] = x;
                        if (y < MinY[spritenum]) MinY[spritenum] = y;

                    }

                }

            }
            for (int i = 0; i < BankSpriteCount; i++)
            {

                if (MinX[i] == 10000) { MinX[i] = 0; MaxX[i] = -1; };
                if (MinY[i] == 10000) { MinY[i] = 0; MaxY[i] = -1; };

            }
            colormap.Dispose();
            for (int b = 0; b < BankCount; b++)
            {
                colormap = new Bitmap(filename + "_Bank" + b.ToString() + ".png");
                if (b == 0)
                {
                    for (int i = 0; i < 16; i++)
                    {
                        ColorSelector[i].BackColor = colormap.GetPixel(i * 12, 1000);
                    }
                }
                for (int i = 0; i < BankSpriteCount; i++)
                {
                    if (b == 1)
                    {
                        if (MinX[i] > 0)
                        {
                            Spr_MinX[i] = 0;
                            Spr_MinY[i] = 0;
                            Spr_Wid[i] = (short)(MaxX[i] - MinX[i] + 1);
                            Spr_Hei[i] = (short)(MaxY[i] - MinY[i] + 1);
                            Spr_FixedSize[i] = 1;
                        }
                    }
                    for (int x = MinX[i]; x <= MaxX[i]; x++)
                    {
                        for (int y = MinY[i]; y <= MaxY[i]; y++)
                        {
                            Color c = colormap.GetPixel(x, y);
                            int cnum = 0;
                            for (int co = 0; co <= 16; co++)
                            {
                                if (c == ColorSelector[co].BackColor) cnum = co;
                            }
                            spritepixel[b, i, x - MinX[i], y - MinY[i]] = (byte)cnum;
                        }

                    }
                }
                colormap.Dispose();
            }
            for (int s = 0; s < BankSpriteCount; s++)
            {

                SpriteStats(s);         // update all our info on the sprites
                SaveSpriteDetails(s);
            }


            btnRefresh_Click(sender, e);
        }

        /************************************************************************************************************************************************/

        private void recent1_Click(object sender, EventArgs e)
        {
            if (((ToolStripMenuItem)sender).Text == "") return;
            string Response = VbX.InputBox("Reload Sprites?", "Reload Sprites?", "yes/no");
            if (Response != "*yes*") return;
            DoLoadFile(((ToolStripMenuItem)sender).Text, true, true, true, true);
        }

        private void recent2_Click(object sender, EventArgs e)
        { recent1_Click(sender, e); }

        private void recent3_Click(object sender, EventArgs e)
        { recent1_Click(sender, e); }

        private void recent4_Click(object sender, EventArgs e)
        { recent1_Click(sender, e); }

        private void recent5_Click(object sender, EventArgs e)
        { recent1_Click(sender, e); }

        private void recent6_Click(object sender, EventArgs e)
        { recent1_Click(sender, e); }

        private void recent7_Click(object sender, EventArgs e)
        { recent1_Click(sender, e); }

        private void recent8_Click(object sender, EventArgs e)
        { recent1_Click(sender, e); }

        private void recent9_Click(object sender, EventArgs e)
        { recent1_Click(sender, e); }

        private void recent10_Click(object sender, EventArgs e)
        { recent1_Click(sender, e); }

        /************************************************************************************************************************************************/
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            string Response = VbX.InputBox("Exit Akusprite?", "Exit Akusprite?", "yes/no");
            if (Response != "*yes*") { e.Cancel = true; return; }


            string recentfile = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase).Replace("file:\\", "") + "\\AkuSprite.recent";

            System.IO.StreamWriter sw = new System.IO.StreamWriter(recentfile);
            sw.WriteLine(recent1.Text);
            sw.WriteLine(recent2.Text);
            sw.WriteLine(recent3.Text);
            sw.WriteLine(recent4.Text);
            sw.WriteLine(recent5.Text);
            sw.WriteLine(recent6.Text);
            sw.WriteLine(recent7.Text);
            sw.WriteLine(recent8.Text);
            sw.WriteLine(recent9.Text);
            sw.WriteLine(recent10.Text);
            sw.Close();
        }
        /************************************************************************************************************************************************/
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        /************************************************************************************************************************************************/
        private void saveBinarySpritesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveMSXBinaryToolStripMenuItem_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void savePCESpriteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            int planes = 4;
            int spritenum = CurrentSprite;
            for (int y = 0; y < Spr_Hei[spritenum]; y += 16)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 16)
                {
                    for (int p = 7; p > 7 - planes; p--)
                    {

                        for (int y2 = 0; y2 < 16; y2++)
                        {
                            for (int x2 = 8; x2 >= 0; x2 -= 8)
                            {

                                int sp0 = GetDisplayNum(CurrentBank, spritenum, x + x2, y + y2);
                                int sp1 = GetDisplayNum(CurrentBank, spritenum, x + x2 + 1, y + y2);
                                int sp2 = GetDisplayNum(CurrentBank, spritenum, x + x2 + 2, y + y2);
                                int sp3 = GetDisplayNum(CurrentBank, spritenum, x + x2 + 3, y + y2);
                                int sp4 = GetDisplayNum(CurrentBank, spritenum, x + x2 + 4, y + y2);
                                int sp5 = GetDisplayNum(CurrentBank, spritenum, x + x2 + 5, y + y2);
                                int sp6 = GetDisplayNum(CurrentBank, spritenum, x + x2 + 6, y + y2);
                                int sp7 = GetDisplayNum(CurrentBank, spritenum, x + x2 + 7, y + y2);

                                string tbyte = "";
                                tbyte += VbX.Dec2Bin8Bit(sp0).Substring(p, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp1).Substring(p, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp2).Substring(p, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp3).Substring(p, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp4).Substring(p, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp5).Substring(p, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp6).Substring(p, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp7).Substring(p, 1);
                                BW.Write((Byte)VbX.Bin2Dec(tbyte));
                            }
                        }
                    }//x
                }//y
            }
            BW.Close();
        }
        /************************************************************************************************************************************************/
        private void saveSprite2ColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }

            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "C64 Sprite (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);



            for (int spritenum = 0; spritenum < SpriteCount; spritenum++)
            {
                for (int y = 0; y < 21; y += 1)
                {
                    for (int x = 0; x < 24; x += 8)
                    {
                        int yy = 0;
                        int sp1 = GetDisplayNum(CurrentBank, spritenum, x, y + yy);
                        int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 1, y + yy);
                        int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + yy);
                        int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 3, y + yy);
                        int sp5 = GetDisplayNum(CurrentBank, spritenum, x + 4, y + yy);
                        int sp6 = GetDisplayNum(CurrentBank, spritenum, x + 5, y + yy);
                        int sp7 = GetDisplayNum(CurrentBank, spritenum, x + 6, y + yy);
                        int sp8 = GetDisplayNum(CurrentBank, spritenum, x + 7, y + yy);


                        if (sp4 == 16 && sp3 == 16 && sp2 == 16 && sp1 == 16 && sp5 == 16 && sp6 == 16 && sp7 == 16 && sp8 == 16)
                        {
                            int transpcol = VbX.Bin2Dec(VbX.Right(VbX.Dec2Bin8Bit(Spr_Xoff[spritenum]), 3));
                            if (transpcol == 5)
                            {
                                sp1 = 0; sp2 = 1;
                                sp3 = 0; sp4 = 1;
                                sp5 = 0; sp6 = 1;
                                sp7 = 0; sp8 = 1;
                            }
                            if (transpcol == 4)
                            {
                                sp1 = 1; sp2 = 0;
                                sp3 = 1; sp4 = 0;
                                sp5 = 1; sp6 = 0;
                                sp7 = 1; sp8 = 0;
                            }
                        }
                        if (sp1 == 16) sp1 = 0;
                        if (sp2 == 16) sp2 = 0;
                        if (sp3 == 16) sp3 = 0;
                        if (sp4 == 16) sp4 = 0;
                        if (sp5 == 16) sp5 = 0;
                        if (sp6 == 16) sp6 = 0;
                        if (sp7 == 16) sp7 = 0;
                        if (sp8 == 16) sp8 = 0;

                        if (sp1 > 1) sp1 = 1;
                        if (sp2 > 1) sp2 = 1;
                        if (sp3 > 1) sp3 = 1;
                        if (sp4 > 1) sp4 = 1;
                        if (sp5 > 1) sp5 = 1;
                        if (sp6 > 1) sp6 = 1;
                        if (sp7 > 1) sp7 = 1;
                        if (sp8 > 1) sp8 = 1;

                        string tbyte = "";

                        tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp3).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp4).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp5).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp6).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp7).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp8).Substring(7, 1);

                        BW.Write((Byte)VbX.Bin2Dec(tbyte));
                    }

                }
            }
            BW.Write((Byte)(0)); // spacer (each sprite must be 64 bytes
            BW.Close();
        }
        /************************************************************************************************************************************************/
        private void saveSprite4ColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            DoC64Sprite(2, 8, 24);
        }
        private void DoC64Sprite(int scale, int step, int spritewidth)
        {


            // C64 4 color
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "C64 4-color sprite (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);


            for (int spritenum = 0; spritenum < SpriteCount; spritenum++)
            {
                for (int y = 0; y < 21; y += 1)
                {
                    for (int x = 0; x < spritewidth; x += step)
                    {
                        int yy = 0;
                        {
                            int sp1 = GetDisplayNum(CurrentBank, spritenum, x, y + yy);
                            int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 1 * scale, y + yy);
                            int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 2 * scale, y + yy);
                            int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 3 * scale, y + yy);


                            string tbyte = "";

                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 2);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 2);
                            tbyte += VbX.Dec2Bin8Bit(sp3).Substring(6, 2);
                            tbyte += VbX.Dec2Bin8Bit(sp4).Substring(6, 2);

                            BW.Write((Byte)VbX.Bin2Dec(tbyte));
                        }

                    }

                }
                BW.Write((Byte)(0)); // spacer (each sprite must be 64 bytes
            }
            BW.Close();

        }
        /************************************************************************************************************************************************/
        private void saveRawBitmap2ColorToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            // C64 4 color
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Raw Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);


            int spritenum = CurrentSprite;
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 8)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
                {
                    for (int yy = 0; yy < 8; yy += 1)
                    {
                        int sp1 = GetDisplayNum(CurrentBank, spritenum, x, y + yy);
                        int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 1, y + yy);
                        int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + yy);
                        int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 3, y + yy);
                        int sp5 = GetDisplayNum(CurrentBank, spritenum, x + 4, y + yy);
                        int sp6 = GetDisplayNum(CurrentBank, spritenum, x + 5, y + yy);
                        int sp7 = GetDisplayNum(CurrentBank, spritenum, x + 6, y + yy);
                        int sp8 = GetDisplayNum(CurrentBank, spritenum, x + 7, y + yy);

                        string tbyte = "";

                        tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp3).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp4).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp5).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp6).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp7).Substring(7, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp8).Substring(7, 1);

                        BW.Write((Byte)VbX.Bin2Dec(tbyte));
                    }

                }

            }
            BW.Close();
        }
        /************************************************************************************************************************************************/
        private void saveRAWMSX1Raw16x16SpriteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);


            int spritenum = 0;
            int planes = 1;
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 16)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
                {
                    for (int y2 = 0; y2 < 16; y2++)
                    {

                        int sp0 = GetDisplayNum(CurrentBank, spritenum, x, y + y2);
                        int sp1 = GetDisplayNum(CurrentBank, spritenum, x + 1, y + y2);
                        int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + y2);
                        int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 3, y + y2);
                        int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 4, y + y2);
                        int sp5 = GetDisplayNum(CurrentBank, spritenum, x + 5, y + y2);
                        int sp6 = GetDisplayNum(CurrentBank, spritenum, x + 6, y + y2);
                        int sp7 = GetDisplayNum(CurrentBank, spritenum, x + 7, y + y2);

                        for (int p = 7; p > 7 - planes; p--)
                        {
                            string tbyte = "";
                            tbyte += VbX.Dec2Bin8Bit(sp0).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp3).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp4).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp5).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp6).Substring(p, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp7).Substring(p, 1);
                            BW.Write((Byte)VbX.Bin2Dec(tbyte));
                        }

                    }//y2
                }//x
            }//y


            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void CreateRawLynxBitmap(System.IO.BinaryWriter BW, int CurrentSprite, int bitdepth, bool RLE)
        {
            int spritenum = CurrentSprite;
            string tbyte = "";
            for (int y = 0; y < Spr_Hei[spritenum]; y++)
            {
                tbyte = "";
                for (int x = 0; x < Spr_Wid[spritenum]; x += 2)
                {
                    int sp1 = spritepixel[CurrentBank, spritenum, x, y];
                    int sp2 = spritepixel[CurrentBank, spritenum, x + 1, y];


                    if (sp2 == 16 && sp1 == 16)
                    {
                        int transpcol = VbX.Bin2Dec(VbX.Right(VbX.Dec2Bin8Bit(Spr_Xoff[spritenum]), 3));
                        if (transpcol == 5)
                        {
                            sp1 = 0;
                            sp2 = 1;
                        }
                        if (transpcol == 4)
                        {
                            sp1 = 3;
                            sp2 = 2;
                        }
                    }
                    if (sp1 == 16) sp1 = 0;
                    if (sp2 == 16) sp2 = 0;




                    if (bitdepth >= 4) tbyte += VbX.Dec2Bin8Bit(sp1).Substring(4, 1);
                    if (bitdepth >= 3) tbyte += VbX.Dec2Bin8Bit(sp1).Substring(5, 1);
                    if (bitdepth >= 2) tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);

                    if (bitdepth >= 4) tbyte += VbX.Dec2Bin8Bit(sp2).Substring(4, 1);
                    if (bitdepth >= 3) tbyte += VbX.Dec2Bin8Bit(sp2).Substring(5, 1);
                    if (bitdepth >= 2) tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);




                }
                // VbX.MsgBox(tbyte);      // Show uncompressed bit data
                if (RLE)
                {
                    string tbyte2 = tbyte;
                    tbyte = "";
                    string lastchunk = "";
                    string LinearChunk = "";
                    int LinearCount = 0;
                    int RleCount = 0;
                    for (int b = 0; b < tbyte2.Length; b += bitdepth)
                    {
                        string chunk = tbyte2.Substring(b, bitdepth);



                        if (lastchunk == "")
                        {


                        }
                        else
                        {
                            if (RleCount == 15 || ((b == tbyte2.Length - bitdepth && lastchunk == chunk) || (lastchunk != chunk && RleCount > 0)))
                            {
                                if (LinearCount > 0)
                                {

                                    tbyte += "1";
                                    tbyte += VbX.Dec2Bin8Bit((LinearChunk.Length / bitdepth) - 1).Substring(4, 4) + LinearChunk;
                                    // VbX.MsgBox(LinearChunk);
                                    LinearChunk = "";
                                    LinearCount = 0;
                                }

                                if (b == tbyte2.Length - bitdepth && RleCount <= 14 && lastchunk == chunk)
                                {
                                    RleCount++;
                                    chunk = "";
                                }

                                tbyte += "0";
                                tbyte += VbX.Dec2Bin8Bit(RleCount).Substring(4, 4) + lastchunk;
                                // VbX.MsgBox(VbX.Dec2Bin8Bit(RleCount).Substring(4, 4) + lastchunk);
                                RleCount = 0;
                                lastchunk = "";
                            }
                            else if (lastchunk != chunk && RleCount == 0)
                            {

                                LinearChunk += lastchunk;
                                LinearCount++;
                                if (LinearCount > 15)
                                {
                                    tbyte += "1";
                                    tbyte += "1111" + LinearChunk.Substring(0, 16 * bitdepth);
                                    LinearChunk = "";
                                    lastchunk = "";
                                    LinearCount = 0;
                                }
                                // VbX.MsgBox("Linear:" + LinearChunk + "," + LinearCount.ToString());

                            }
                            else// rle match
                            {
                                if (LinearCount > 0)
                                {

                                    tbyte += "1";
                                    tbyte += VbX.Dec2Bin8Bit((LinearChunk.Length / bitdepth) - 1).Substring(4, 4) + LinearChunk;
                                    // VbX.MsgBox(LinearChunk);
                                    LinearChunk = "";
                                    LinearCount = 0;
                                }
                                RleCount++;
                            }
                        }


                        lastchunk = chunk;
                    }
                    if (lastchunk != "")
                    {
                        LinearChunk += lastchunk;
                        LinearCount++;
                        tbyte += "1";
                        tbyte += VbX.Dec2Bin8Bit((LinearChunk.Length / bitdepth) - 1).Substring(4, 4) + LinearChunk;
                        LinearChunk = "";
                        LinearCount = 0;
                    }

                }

                if (tbyte.Length % 8 > 0)
                {
                    while (tbyte.Length % 8 > 0)
                    {
                        tbyte += "0";
                    }
                }
                else
                {
                    tbyte += "00000000";
                }
                // VbX.MsgBox(tbyte);      // show compressed data

                BW.Write((Byte)((tbyte.Length / 8) + 1));
                for (int c = 0; c < tbyte.Length; c += 8)
                {
                    string bchunk = tbyte.Substring(c, 8);
                    BW.Write((Byte)VbX.Bin2Dec(bchunk));
                }


                tbyte = "";
            }
            BW.Write((Byte)0);
        }
        /************************************************************************************************************************************************/
        private void save16colorLinearSpriteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Lynx Literalsprite (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            CreateRawLynxBitmap(BW, CurrentSprite, 4, false);
            BW.Close();
        }
        /************************************************************************************************************************************************/
        private void save8colorLinearSpriteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Lynx Literalsprite (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            CreateRawLynxBitmap(BW, CurrentSprite, 3, false);
            BW.Close();
        }
        /************************************************************************************************************************************************/
        private void sToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Lynx Literalsprite (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            CreateRawLynxBitmap(BW, CurrentSprite, 2, false);
            BW.Close();
        }
        /************************************************************************************************************************************************/
        private void sToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Lynx Literalsprite (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            CreateRawLynxBitmap(BW, CurrentSprite, 1, false);
            BW.Close();
        }
        /************************************************************************************************************************************************/
        private void save16ColorRLESpriteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Lynx Literalsprite (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            CreateRawLynxBitmap(BW, CurrentSprite, 4, true);
            BW.Close();
        }
        /************************************************************************************************************************************************/
        private void save8ColorRLESpriteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Lynx Literalsprite (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            CreateRawLynxBitmap(BW, CurrentSprite, 3, true);
            BW.Close();
        }
        /************************************************************************************************************************************************/
        private void save2ColorRLESpriteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Lynx Literalsprite (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            CreateRawLynxBitmap(BW, CurrentSprite, 1, true);
            BW.Close();
        }
        /************************************************************************************************************************************************/
        private void save4ColorRLESpriteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Lynx Literalsprite (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            CreateRawLynxBitmap(BW, CurrentSprite, 2, true);
            BW.Close();
        }
        /************************************************************************************************************************************************/
        private void saveRawBitmapToolStripMenuItem17_Click(object sender, EventArgs e)
        {

            // Camputers Lynx
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }

            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            SaveRAW_PlanarCLX(BW, CurrentSprite, 3);


            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void saveRaw8x8TileBitmapToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Camputers Lynx 8tile

            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            SaveRAW_PlanarCLX8(BW, CurrentSprite, 3);


            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void raw8colorBitmapToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            // Sinclair QL

            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            int spritenum = CurrentSprite;

            for (int y2 = Spr_MinY[spritenum]; y2 < Spr_Hei[spritenum]; y2 += 1)
            {

                for (int x = 0; x < Spr_Wid[spritenum]; x += 4)
                {

                    int y = 0;


                    int sp0 = GetDisplayNum(CurrentBank, spritenum, x, y + y2);
                    int sp1 = GetDisplayNum(CurrentBank, spritenum, x + 1, y + y2);
                    int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + y2);
                    int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 3, y + y2);




                    string tbyte = "";

                    tbyte += VbX.Dec2Bin8Bit(sp0).Substring(5, 1);
                    tbyte += "0";
                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(5, 1);
                    tbyte += "0";
                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(5, 1);
                    tbyte += "0";
                    tbyte += VbX.Dec2Bin8Bit(sp3).Substring(5, 1);
                    tbyte += "0";
                    BW.Write((Byte)VbX.Bin2Dec(tbyte));

                    tbyte = "";
                    tbyte += VbX.Dec2Bin8Bit(sp0).Substring(6, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp0).Substring(7, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp3).Substring(6, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp3).Substring(7, 1);
                    BW.Write((Byte)VbX.Bin2Dec(tbyte));


                }
            }



            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);

        }
        /************************************************************************************************************************************************/
        private void saveSpriteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            //Neo Geo Sprite
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "NeoGeo Sprite (*.c1)|*.c1";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            System.IO.Stream ST2 = new System.IO.FileStream(fd.FileName.Replace(".c1", ".c2"), System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW2 = new System.IO.BinaryWriter(ST2);
            SaveNeoGeo(BW, BW2);

            BW.Close();
            BW2.Close();
        }
        public void SaveNeoGeo(System.IO.BinaryWriter BW, System.IO.BinaryWriter BW2)
        {


            long bytecount = 0;
            int planes = 4;
            for (int bnk = 0; bnk < BankCount; bnk++)
            {
                for (int spritenum = 0; spritenum < SpriteCount; spritenum++)
                {

                    for (int x = 0; x < Spr_Wid[spritenum]; x += 16)
                    {

                        for (int y2 = 0; y2 < Spr_Hei[spritenum]; y2 += 16)
                        {
                            for (int x2 = 8; x2 >= 0; x2 -= 8)
                            {
                                for (int y = 0; y < 16; y += 1)
                                {
                                    for (int p = 7; p > 7 - planes; p--)
                                    {
                                        int sp0 = GetDisplayNum(bnk, spritenum, x + x2 + 7, y + y2);
                                        int sp1 = GetDisplayNum(bnk, spritenum, x + x2 + 6, y + y2);
                                        int sp2 = GetDisplayNum(bnk, spritenum, x + x2 + 5, y + y2);
                                        int sp3 = GetDisplayNum(bnk, spritenum, x + x2 + 4, y + y2);
                                        int sp4 = GetDisplayNum(bnk, spritenum, x + x2 + 3, y + y2);
                                        int sp5 = GetDisplayNum(bnk, spritenum, x + x2 + 2, y + y2);
                                        int sp6 = GetDisplayNum(bnk, spritenum, x + x2 + 1, y + y2);
                                        int sp7 = GetDisplayNum(bnk, spritenum, x + x2 + 0, y + y2);

                                        string tbyte = "";
                                        tbyte += VbX.Dec2Bin8Bit(sp0).Substring(p, 1);
                                        tbyte += VbX.Dec2Bin8Bit(sp1).Substring(p, 1);
                                        tbyte += VbX.Dec2Bin8Bit(sp2).Substring(p, 1);
                                        tbyte += VbX.Dec2Bin8Bit(sp3).Substring(p, 1);
                                        tbyte += VbX.Dec2Bin8Bit(sp4).Substring(p, 1);
                                        tbyte += VbX.Dec2Bin8Bit(sp5).Substring(p, 1);
                                        tbyte += VbX.Dec2Bin8Bit(sp6).Substring(p, 1);
                                        tbyte += VbX.Dec2Bin8Bit(sp7).Substring(p, 1);
                                        if (p >= 6)
                                        {
                                            bytecount++;
                                            BW.Write((Byte)VbX.Bin2Dec(tbyte));
                                        }
                                        else
                                        {
                                            BW2.Write((Byte)VbX.Bin2Dec(tbyte));
                                        }
                                    }
                                }//x
                            }//y

                        }//p
                    }

                }//s
            }   //bnk
            long targetcount = VbX.Val(txtFixedFileSize.Text);
            while (bytecount < targetcount)
            {
                bytecount++;
                BW2.Write((Byte)0);
                BW.Write((Byte)0);
            }

        }
        /************************************************************************************************************************************************/
        private void raw4colorBitmapToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            // 4 Color QL bitmap
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            SaveRAW_PlanarAMI(BW, CurrentSprite, 2);


            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void saveRawBitmapToolStripMenuItem18_Click(object sender, EventArgs e)
        {
            // Wonderswan uses SMS Exporter
            saveRawBitmapToolStripMenuItem5_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void saveSpriteToolStripMenuItem1_Click(object sender, EventArgs e)
        {            // X68000 Sprite

            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }


            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            int spritenum = CurrentSprite;

            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 16)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 16)
                {
                    for (int x2 = 0; x2 < Spr_Wid[spritenum]; x2 += 8)
                    {
                        for (int y3 = Spr_MinY[spritenum]; y3 < 16; y3 += 8)
                        {

                            for (int y2 = 0; y2 < 8; y2++)
                            {
                                for (int xx = 0; xx < 8; xx += 2)
                                {

                                    int sp1 = GetDisplayNum(CurrentBank, spritenum, x2 + xx + x, y + y2 + y3);
                                    int sp2 = GetDisplayNum(CurrentBank, spritenum, x2 + xx + x + 1, y + y2 + y3);

                                    if (sp1 == 16) sp1 = 0;
                                    if (sp2 == 16) sp2 = 0;
                                    string tbyte = "";
                                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(4, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(5, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);

                                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(4, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(5, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);

                                    BW.Write((Byte)VbX.Bin2Dec(tbyte));
                                }
                            }
                        }
                    }//y2
                }//x
            }//y


            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);

        }
        /************************************************************************************************************************************************/
        private void saveRawSpriteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }

            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);
            System.IO.Stream ST2 = new System.IO.FileStream(fd.FileName + ".2", System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            System.IO.BinaryWriter BW2 = new System.IO.BinaryWriter(ST2);

            int spritenum = CurrentSprite;
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y++)
            {
                for (int x = 0; x < 16; x += 16)
                {
                    int sp1 = spritepixel[CurrentBank, spritenum, x, y];
                    int sp2 = spritepixel[CurrentBank, spritenum, x + 1, y];
                    int sp3 = spritepixel[CurrentBank, spritenum, x + 2, y];
                    int sp4 = spritepixel[CurrentBank, spritenum, x + 3, y];
                    int sp5 = spritepixel[CurrentBank, spritenum, x + 4, y];
                    int sp6 = spritepixel[CurrentBank, spritenum, x + 5, y];
                    int sp7 = spritepixel[CurrentBank, spritenum, x + 6, y];
                    int sp8 = spritepixel[CurrentBank, spritenum, x + 7, y];
                    int sp9 = spritepixel[CurrentBank, spritenum, x + 8, y];
                    int sp10 = spritepixel[CurrentBank, spritenum, x + 9, y];
                    int sp11 = spritepixel[CurrentBank, spritenum, x + 10, y];
                    int sp12 = spritepixel[CurrentBank, spritenum, x + 11, y];
                    int sp13 = spritepixel[CurrentBank, spritenum, x + 12, y];
                    int sp14 = spritepixel[CurrentBank, spritenum, x + 13, y];
                    int sp15 = spritepixel[CurrentBank, spritenum, x + 14, y];
                    int sp16 = spritepixel[CurrentBank, spritenum, x + 15, y];


                    for (int p = 0; p >= -1; p -= 1)
                    {


                        string tbyte = "";
                        string tbyte2 = "";

                        tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7 + p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7 + p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp3).Substring(7 + p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp4).Substring(7 + p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp5).Substring(7 + p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp6).Substring(7 + p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp7).Substring(7 + p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp8).Substring(7 + p, 1);

                        BW.Write((Byte)VbX.Bin2Dec(tbyte));
                        tbyte = "";


                        tbyte += VbX.Dec2Bin8Bit(sp9).Substring(7 + p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp10).Substring(7 + p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp11).Substring(7 + p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp12).Substring(7 + p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp13).Substring(7 + p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp14).Substring(7 + p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp15).Substring(7 + p, 1);
                        tbyte += VbX.Dec2Bin8Bit(sp16).Substring(7 + p, 1);

                        BW.Write((Byte)VbX.Bin2Dec(tbyte));
                        tbyte = "";

                        tbyte2 += VbX.Dec2Bin8Bit(sp1).Substring(5 + p, 1);
                        tbyte2 += VbX.Dec2Bin8Bit(sp2).Substring(5 + p, 1);
                        tbyte2 += VbX.Dec2Bin8Bit(sp3).Substring(5 + p, 1);
                        tbyte2 += VbX.Dec2Bin8Bit(sp4).Substring(5 + p, 1);
                        tbyte2 += VbX.Dec2Bin8Bit(sp5).Substring(5 + p, 1);
                        tbyte2 += VbX.Dec2Bin8Bit(sp6).Substring(5 + p, 1);
                        tbyte2 += VbX.Dec2Bin8Bit(sp7).Substring(5 + p, 1);
                        tbyte2 += VbX.Dec2Bin8Bit(sp8).Substring(5 + p, 1);

                        BW2.Write((Byte)VbX.Bin2Dec(tbyte2));
                        tbyte2 = "";


                        tbyte2 += VbX.Dec2Bin8Bit(sp9).Substring(5 + p, 1);
                        tbyte2 += VbX.Dec2Bin8Bit(sp10).Substring(5 + p, 1);
                        tbyte2 += VbX.Dec2Bin8Bit(sp11).Substring(5 + p, 1);
                        tbyte2 += VbX.Dec2Bin8Bit(sp12).Substring(5 + p, 1);
                        tbyte2 += VbX.Dec2Bin8Bit(sp13).Substring(5 + p, 1);
                        tbyte2 += VbX.Dec2Bin8Bit(sp14).Substring(5 + p, 1);
                        tbyte2 += VbX.Dec2Bin8Bit(sp15).Substring(5 + p, 1);
                        tbyte2 += VbX.Dec2Bin8Bit(sp16).Substring(5 + p, 1);


                        BW2.Write((Byte)VbX.Bin2Dec(tbyte2));
                        tbyte2 = "";
                    }
                }
            }

            BW.Close();
            ST.Close();
            BW2.Close();
            ST2.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void saveRaw8x8TilesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            if (chkSaveMultiRaw.Checked)
            {
                for (int cs = 0; cs < SpriteCount; cs++)
                {
                    if (rdoDisplayCPC0.Checked)
                    {
                        CPC_SaveRAW_16Color8x8(BW, cs, false, 8);
                    }
                    else
                    {
                        CPC_SaveRAW_4Color8x8(BW, cs, false, 8, 1);
                    }
                }
            }
            else
            {

                if (rdoDisplayCPC0.Checked)
                {
                    CPC_SaveRAW_16Color8x8(BW, CurrentSprite, false, 8);
                }
                else
                {
                    CPC_SaveRAW_4Color8x8(BW, CurrentSprite, false, 8, 1);
                }
            }

            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);

        }
        /************************************************************************************************************************************************/
        private void saveRaw8x8TilesToolStripMenuItem1_Click(object sender, EventArgs e)
        {   // SAM 8x8 Tile Bitmap
            saveRawVdpTileBitmapToolStripMenuItem_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void eGX416ColorCPCToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RdoDisplayEGX.Checked = true;
        }
        /************************************************************************************************************************************************/
        private void btnTileCopy_Click(object sender, EventArgs e)
        {
            ResetButtons();
            tabSpriteTools.TabPages.Add(tabTileCopy);
            tabZXPaint.Show();
            btnTileCopy.BackColor = SystemColors.ButtonShadow;
            CurrentTool = "tilecopy";
            tabSpriteTools.SelectedTab = tabTileCopy;
        }
        /************************************************************************************************************************************************/
        private void addTilesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int spritenum = CurrentSprite;
            string TileMap = "";
            TileMap = AddTileMap(TileMap, spritenum);
            txtSaveTileCount.Text = txtNextTile.Text;
            chkSaveMultiRaw.Checked = false;
            VbX.MsgBox("TileCount:" + txtNextTile.Text);
            Clipboard.SetText(TileMap);
        }

        private String AddTileMap(String TileMap, int spritenum)
        {
            TileMap = TileMap + "Sprite_" + VbX.CStr(spritenum) + ":" + VbX.Chr(13) + VbX.Chr(10);
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 8)
            {

                TileMap = TileMap + "  db ";
                for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
                {
                    int found = -1;
                    for (int t = 0; t < VbX.CInt(txtNextTile.Text); t++)
                    {
                        int tileX = (t % 32) * 8;
                        int tileY = (t / 32) * 8;
                        bool match = true;
                        for (int tx = 0; tx < 8; tx++)
                        {
                            for (int ty = 0; ty < 8; ty++)
                            {
                                if (spritepixel[CurrentBank, spritenum, x + tx, y + ty] != spritepixel[CurrentBank, 0, tileX + tx, tileY + ty])
                                {
                                    match = false;
                                }
                            }
                        }
                        if (match == true) found = t;

                    }
                    if (found == -1)
                    {
                        found = VbX.CInt(txtNextTile.Text);
                        int tileX = (VbX.CInt(txtNextTile.Text) % 32) * 8;
                        int tileY = (VbX.CInt(txtNextTile.Text) / 32) * 8;
                        for (int tx = 0; tx < 8; tx++)
                        {
                            for (int ty = 0; ty < 8; ty++)
                            {
                                spritepixel[CurrentBank, 0, tileX + tx, tileY + ty] = spritepixel[CurrentBank, spritenum, x + tx, y + ty];

                            }
                        }
                        txtNextTile.Text = VbX.CStr(VbX.CInt(txtNextTile.Text) + 1);
                    }


                    found = found + VbX.CInt(txtFirstTile.Text);
                    if (cboTileFormat.Text.ToLower() == "nibble")
                    {
                        if (x > 0)
                        {
                            if ((x % 16) == 0) TileMap = TileMap + ",";
                        }
                        if ((x % 16) == 0) TileMap = TileMap + "&";


                        TileMap = TileMap + VbX.Hex(found);
                    }
                    else
                    {

                        if (x > 0) TileMap = TileMap + ",";

                        if (found >= 255)
                        {
                            found = found - 255;
                            TileMap = TileMap + "255,";
                        }

                        TileMap = TileMap + found;
                    }
                }
                TileMap = TileMap + VbX.Chr(13) + VbX.Chr(10);


            }
            TileMap = TileMap + VbX.Chr(13) + VbX.Chr(10);
            return TileMap;
        }

        /************************************************************************************************************************************************/
        private void clearTilesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int x = 0; x < 256; x++)
            {
                for (int y = 0; y < 256; y++)
                {
                    spritepixel[CurrentBank, 0, x, y] = 0;
                }
            }
            txtNextTile.Text = "0";
            addTilesToolStripMenuItem_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void saveRawSpriteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            // genesis sprite
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            int spritenum = CurrentSprite;
            for (int s = 0; s < SpriteCount; s++)
            {
                for (int x = 0; x < Spr_Wid[s]; x += 8)
                {
                    for (int y = Spr_MinY[s]; y < Spr_Hei[s]; y += 8)
                    {

                        for (int y2 = 0; y2 < 8; y2++)
                        {
                            for (int xx = 0; xx < 8; xx += 2)
                            {

                                int sp1 = GetDisplayNum(CurrentBank, s, xx + x, y + y2);
                                int sp2 = GetDisplayNum(CurrentBank, s, xx + x + 1, y + y2);

                                if (sp1 == 16) sp1 = 0;
                                if (sp2 == 16) sp2 = 0;
                                string tbyte = "";
                                tbyte += VbX.Dec2Bin8Bit(sp1).Substring(4, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp1).Substring(5, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);

                                tbyte += VbX.Dec2Bin8Bit(sp2).Substring(4, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp2).Substring(5, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);

                                BW.Write((Byte)VbX.Bin2Dec(tbyte));
                            }
                        }//y2
                    }//x
                }//y
            }

            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);

        }

        /************************************************************************************************************************************************/

        private void saveRawBitmap2bitPlanarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Wonderswan 2bpp
            saveRawBitmapToolStripMenuItem6_Click(sender, e);
        }

        private void saveRawBitmap4bitLinearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // WonderSwan 4bpp linear
            saveRawVdpTileBitmapToolStripMenuItem_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void saveRawBitmap2bitLinearToolStripMenuItem_Click(object sender, EventArgs e)
        {  // WonderSwan 2bpp linear
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            int spritenum = CurrentSprite;

            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 8)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
                {
                    for (int y2 = 0; y2 < 8; y2++)
                    {
                        for (int xx = 0; xx < 8; xx += 4)
                        {

                            int sp1 = GetDisplayNum(CurrentBank, spritenum, xx + x, y + y2);
                            int sp2 = GetDisplayNum(CurrentBank, spritenum, xx + x + 1, y + y2);
                            int sp3 = GetDisplayNum(CurrentBank, spritenum, xx + x + 2, y + y2);
                            int sp4 = GetDisplayNum(CurrentBank, spritenum, xx + x + 3, y + y2);

                            if (sp1 == 16) sp1 = 0;
                            if (sp2 == 16) sp2 = 0;
                            if (sp3 == 16) sp3 = 0;
                            if (sp4 == 16) sp4 = 0;
                            string tbyte = "";
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);

                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);

                            tbyte += VbX.Dec2Bin8Bit(sp3).Substring(6, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp3).Substring(7, 1);

                            tbyte += VbX.Dec2Bin8Bit(sp4).Substring(6, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp4).Substring(7, 1);
                            BW.Write((Byte)VbX.Bin2Dec(tbyte));
                        }
                    }//y2
                }//x
            }//y


            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);

        }
        /************************************************************************************************************************************************/
        private void saveRawBitmapCGAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Raw Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);


            int spritenum = CurrentSprite;
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 1)
            {

                for (int x = 0; x < Spr_Wid[spritenum]; x += 4)
                {
                    int yy = 0;
                    int sp1 = GetDisplayNum(CurrentBank, spritenum, x, y + yy);
                    int sp2 = GetDisplayNum(CurrentBank, spritenum, x + 1, y + yy);
                    int sp3 = GetDisplayNum(CurrentBank, spritenum, x + 2, y + yy);
                    int sp4 = GetDisplayNum(CurrentBank, spritenum, x + 3, y + yy);

                    string tbyte = "";
                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 2);
                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 2);
                    tbyte += VbX.Dec2Bin8Bit(sp3).Substring(6, 2);
                    tbyte += VbX.Dec2Bin8Bit(sp4).Substring(6, 2);

                    BW.Write((Byte)VbX.Bin2Dec(tbyte));
                }

            }
            BW.Close();
        }
        /************************************************************************************************************************************************/
        private void saveRawBitmapVGAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // DOS VGA
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            VGA_SaveRAW_256Color(BW, CurrentSprite);

            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);

        }
        /************************************************************************************************************************************************/
        private void saveRawBitmapEGAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // 4 bitplanes (Like Amiga)
            saveRawBitmapToolStripMenuItem8_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void saveRaw4ColorBitmapToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            MSX_SaveRAW_16ColorNibbleFlipped(BW, CurrentSprite);


            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void saveRawBitmap4bppToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // GBA Bitmap
            saveRawBitmapVGAToolStripMenuItem_Click(sender, e);
        }

        private void paletteToClipboardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PaletteToClipboard("    defw &0", "");
        }

        private void paletteToClipboardToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            PaletteToClipboard("    dw $0", "");
        }

        private void paletteToClipboardToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            PaletteToClipboard("    dc.w $0", "");
        }

        private void paletteToClipboardToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            PaletteToClipboard("    dw 0", "h");

        }

        private void paletteToClipboardToolStripMenuItem4_Click(object sender, EventArgs e)
        {
            PaletteToClipboard("    .word 0x0", "h");

        }

        private void BtnClearAdd_Click(object sender, EventArgs e)
        {
            clearTilesToolStripMenuItem_Click(sender, e);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            addTilesToolStripMenuItem_Click(sender, e);
        }

        private void BtnUlaPalSwap_Click(object sender, EventArgs e)
        {
            byte c = colorLeft;
            colorLeft = colorRight;
            colorRight = c;
            ColorSelector[17].BackColor = ColorSelector[colorLeft].BackColor;
            ColorSelector[18].BackColor = ColorSelector[colorRight].BackColor;

        }

        private void saveULAScreenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveSpeccyScreen(true);
        }
        /************************************************************************************************************************************************/
        private void saveNEXTPaletteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }

            string nl = VbX.Chr(13) + VbX.Chr(10);
            StringBuilder SR = new StringBuilder();
            SR.Append("       ;RRRGGGBB");
            SR.Append(nl);
            for (int i = 0; i < 16; i++)
            {
                SR.Append("    db %");
                SR.Append(VbX.Left(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.R), 3));
                SR.Append(VbX.Left(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.G), 3));
                SR.Append(VbX.Left(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.B), 2));
                SR.Append("");
                SR.Append(" ;" + VbX.CStr(i));
                SR.Append(nl);
            }

            // SR.Close();
            Clipboard.SetText(SR.ToString());
            VbX.MsgBox("Copied to Clipboard");
        }
        /************************************************************************************************************************************************/
        private void rdoULAplus_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoULAplus.Checked == true)
            {
                Palettepanelreset(sender);
                BtnAltPal.Text = "AltPal: ULA";
                pnlULAPal.Visible = true;

            }
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void saveULAScreenPaletteOnlyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "ZXS Binary Sprite (*.SCR)|*.SCR";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }



            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            byte b = 0;
            int bytepos = 0;
            int thisspritebytepos = firstspritepos;

            int spritenum = CurrentSprite;

            int yy = 0;
            int x = 0;


            for (int y = 0; y < (192 / 8); y++)
            {
                for (x = 0; x < (256 / 8); x++)
                {

                    string tbyte = "";
                    tbyte += VbX.Dec2Bin8Bit(SpeccyPaletteB[CurrentBank, spritenum, x, y]).Substring(4, 4);
                    tbyte += VbX.Dec2Bin8Bit(SpeccyPaletteF[CurrentBank, spritenum, x, y]).Substring(4, 4);
                    BW.Write((Byte)VbX.Bin2Dec(tbyte));


                }
            }


            BW.Close();
            ST.Close();
            //VbX.MsgBox("Saved");
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(null, null);
        }
        /************************************************************************************************************************************************/
        private void saveNEXT9BitPaletteToolStripMenuItem_Click(object sender, EventArgs e)
        {

            string nl = VbX.Chr(13) + VbX.Chr(10);
            StringBuilder SR = new StringBuilder();
            SR.Append("       ;RRRGGGBB  -------B");
            SR.Append(nl);
            for (int i = 0; i < 16; i++)
            {
                SR.Append("    db %");
                SR.Append(VbX.Left(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.R), 3));
                SR.Append(VbX.Left(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.G), 3));
                SR.Append(VbX.Left(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.B), 2));
                SR.Append(",%0000000");
                SR.Append(VbX.Right(VbX.Left(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.B), 3), 1));
                SR.Append(" ;" + VbX.CStr(i));
                SR.Append(nl);
            }

            // SR.Close();
            Clipboard.SetText(SR.ToString());
            VbX.MsgBox("Copied to Clipboard");
        }
        /************************************************************************************************************************************************/
        private void saveLoResLayerRadasjimianRawBitmap128x96ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveRawBitmapVGAToolStripMenuItem_Click(sender, e);
        }

        private void save8bppRawBitmapToolStripMenuItem_Click(object sender, EventArgs e)
        {   //Commander x16
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            saveRawBitmapVGAToolStripMenuItem_Click(sender, e);
        }

        private void save4bppRawBitmalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Commander x16 4bpp
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            saveRAWBitmapToolStripMenuItem3_Click(sender, e);
        }

        private void save8bppRawBitmapToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //NEXT
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            saveRawBitmapVGAToolStripMenuItem_Click(sender, e);
        }

        private void save4bppRawBitmapToolStripMenuItem_Click(object sender, EventArgs e)
        {   // Next 4bpp
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            saveRawBitmapToolStripMenuItem5_Click(sender, e);
        }

        private void saveRaw8x8TilemapToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Spectrum Tilemap
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            saveSpectrumFontToolStripMenuItem_Click(sender, e);
        }
        /************************************************************************************************************************************************/

        private void rdoSprWide_CheckedChanged(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(toolTip1.GetToolTip((Control)sender)); }
            if (rdoSprWide.Checked)
            {
                maxSpriteSizeX = 512;
                maxSpriteSizeY = 256;
                InitMaxSpriteSize();
            }
            picPreview.Height = 128;
            doscale(trkzoom.Value);
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void rdoVGA_CheckedChanged(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(toolTip1.GetToolTip((Control)sender)); }
            if (rdoVGA.Checked)
            {
                maxSpriteSizeX = 320;
                maxSpriteSizeY = 240;
                InitMaxSpriteSize();
            }
            picPreview.Height = 192; //            192;
            doscale(trkzoom.Value);
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void loadSpriteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); }

            OpenFileDialog fd = new OpenFileDialog();
            // fd.Filter = "NeoGeoSprite (*.C1;*-c1.BIN;*-c3.BIN;*-c5.BIN)|*.C1;*-c1.BIN;*-c3.BIN;*-c5.BIN";
            fd.Filter = "NeoGeoSprite (*.*)|*.*";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;
            ClearSprites();
            string filename2 = fd.FileName.Replace(".C1", ".C2").Replace(".c1", ".c2").Replace("-c1", "-c2").Replace("-c3", "-c4").Replace("-c5", "-c6").Replace("-c7", "-c8").Replace("_c1", "_c2").Replace("_c3", "_c4").Replace("_c5", "_c6");
            if (filename2 == fd.FileName)
            {
                VbX.MsgBox("Can't find 2nd file");
                return;
            }

            int yheight = VbX.CInt(txtNeoSprHeight.Text);//VbX.CInt(VbX.InputBox("Yheight? (sprites)","Yheight? (sprites)","16"))*16;
            long byteskip = VbX.CInt(txtNeoSprHeight.Text); //VbX.CInt(VbX.InputBox("Skip sprites?", "Skip sprites?", "0")) * 64;

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Open, System.IO.FileAccess.Read);
            System.IO.BinaryReader BR = new System.IO.BinaryReader(ST);
            System.IO.Stream ST2 = new System.IO.FileStream(filename2, System.IO.FileMode.Open, System.IO.FileAccess.Read);
            System.IO.BinaryReader BR2 = new System.IO.BinaryReader(ST2);
            int xpos = 0;
            int ypos = 0;
            int spos = 0;
            int bpos = 0;

            ST.Position = byteskip;
            ST2.Position = byteskip;

            while (ST.Position < ST.Length && bpos < 8)
            {
                for (int xx = 8; xx >= 0; xx -= 8)
                {
                    for (int yy = 0; yy < 16; yy++)
                    {
                        byte b0 = BR.ReadByte();
                        byte b1 = BR.ReadByte();
                        byte b2 = BR2.ReadByte();
                        byte b3 = BR2.ReadByte();

                        for (int p = 0; p <= 7; p++)
                        {

                            string p0 = VbX.Dec2Bin8Bit(b0).Substring(7 - p, 1);
                            string p1 = VbX.Dec2Bin8Bit(b1).Substring(7 - p, 1);
                            string p2 = VbX.Dec2Bin8Bit(b2).Substring(7 - p, 1);
                            string p3 = VbX.Dec2Bin8Bit(b3).Substring(7 - p, 1);

                            int colo = VbX.Bin2Dec(p3 + p2 + p1 + p0);
                            spritepixel[bpos, spos, xpos + xx + p, ypos + yy] = (byte)colo;
                        }

                    }
                }
                ypos += 16;
                if (ypos >= yheight) { xpos += 16; ypos = 0; }
                // xpos += 16;
                // if (xpos > 255) { ypos += 16; xpos = 0; }
                //                if (ypos > 255) { spos++; ypos = 0; xpos = 0; }
                if (xpos > 255) { spos++; ypos = 0; xpos = 0; }
                if (spos > 63) { bpos++; spos = 0; }

            }
            ST.Close();
            ST2.Close();
            btnRefresh_Click(sender, e);
        }
        /************************************************************************************************************************************************/
        private void defauktToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int i = 0; i <= 255; i++)
            {
                setpalette(i, DP.DefPalette[i]);
            }
        }
        /************************************************************************************************************************************************/
        private void enterprise256ColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //;g0 | r0 | b0 | g1 | r1 | b1 | g2 | r2 |
            //for (int i = 0; i <= 255; i++)
            //{
            //    string ii = VbX.Dec2Bin8Bit(i);
            //    int g = VbX.Bin2Dec(ii.Substring(6, 1) + ii.Substring(3, 1) + ii.Substring(0, 1) + ii.Substring(0, 1) + ii.Substring(0, 1) + "000");
            //    int r = VbX.Bin2Dec(ii.Substring(7, 1) + ii.Substring(4, 1) + ii.Substring(1, 1) + ii.Substring(1, 1) + ii.Substring(1, 1) + "000");
            //    int b = VbX.Bin2Dec(ii.Substring(5, 1) + ii.Substring(5, 1) + ii.Substring(2, 1) + ii.Substring(2, 1) + ii.Substring(2, 1) + "000"); ;
            //    setpalette(i,Color.FromArgb(r,g,b));
            //}
            for (int i = 0; i <= 255; i++)
            {
                string ii = VbX.Dec2Bin8Bit(i);
                int g = VbX.Bin2Dec(ii.Substring(2, 1) + ii.Substring(3, 1) + ii.Substring(4, 1)) * 36;
                int r = VbX.Bin2Dec(ii.Substring(5, 1) + ii.Substring(6, 1) + ii.Substring(7, 1)) * 36;
                int b = VbX.Bin2Dec(ii.Substring(0, 1) + ii.Substring(1, 1)) * 85;
                setpalette(i, Color.FromArgb(r, g, b));
            }
        }
        /************************************************************************************************************************************************/
        private void simple4x4x4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int i = 0; i <= 255; i++)
            {
                if (i < 16)
                {
                    setpalette(i, DP.DefPalette[i]);
                }
                if (i >= 16 && i < 48)
                {
                    int c = i - 16;
                    setpalette(i, Color.FromArgb(c * 8, c * 8, c * 8));
                }
                if (i >= 48 && i < 64)
                {
                    int c = i - 48;
                    if (c <= 15) setpalette(i, DP.Fleshtones[c]);
                    else
                        setpalette(i, Color.FromArgb(0, 0, 0));




                }
                if (i >= 64 && i < 128)
                {
                    string ii = VbX.Dec2Bin8Bit(i);

                    int r = VbX.Bin2Dec(ii.Substring(2, 1) + ii.Substring(3, 1)) * 28;
                    int g = VbX.Bin2Dec(ii.Substring(4, 1) + ii.Substring(5, 1)) * 18;
                    int b = VbX.Bin2Dec(ii.Substring(6, 1) + ii.Substring(7, 1)) * 28;
                    setpalette(i, Color.FromArgb(r, g, b));
                }
                if (i >= 128 && i < 192)
                {
                    string ii = VbX.Dec2Bin8Bit(i);
                    int r = VbX.Bin2Dec(ii.Substring(2, 1) + ii.Substring(3, 1)) * 56;
                    int g = VbX.Bin2Dec(ii.Substring(4, 1) + ii.Substring(5, 1)) * 40;
                    int b = VbX.Bin2Dec(ii.Substring(6, 1) + ii.Substring(7, 1)) * 56;
                    setpalette(i, Color.FromArgb(r, g, b));
                }
                if (i >= 192)
                {
                    string ii = VbX.Dec2Bin8Bit(i);
                    int r = VbX.Bin2Dec(ii.Substring(2, 1) + ii.Substring(3, 1)) * 85;
                    int g = VbX.Bin2Dec(ii.Substring(4, 1) + ii.Substring(5, 1)) * 85;
                    int b = VbX.Bin2Dec(ii.Substring(6, 1) + ii.Substring(7, 1)) * 85;
                    setpalette(i, Color.FromArgb(r, g, b));
                }
            }
        }
        /************************************************************************************************************************************************/
        private void loadFromPALIrfanviewToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "JASC-PAL (*.PAL)|*.PAL";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            System.IO.StreamReader SR = new System.IO.StreamReader(fd.FileName);
            SR.ReadLine();
            SR.ReadLine();
            int ccount = VbX.CInt(SR.ReadLine());
            for (int i = 0; i < ccount; i++)
            {
                string s2 = SR.ReadLine();
                Color c = Color.FromArgb(VbX.CInt(ss.GetItem(s2, " ", 0)), VbX.CInt(ss.GetItem(s2, " ", 1)), VbX.CInt(ss.GetItem(s2, " ", 2)));
                setpalette(i, c);
            }


            SR.Close();
        }
        /************************************************************************************************************************************************/
        private void saveToPALirfanviewToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "JASC-PAL (*.PAL)|*.PAL";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            System.IO.StreamWriter SR = new System.IO.StreamWriter(fd.FileName, false, Encoding.ASCII);
            SR.WriteLine("JASC-PAL");
            SR.WriteLine("0100");
            SR.WriteLine("256");
            for (int i = 0; i <= 255; i++)
            {
                Color c = getpalette(i);

                SR.WriteLine(c.R.ToString() + " " + c.G.ToString() + " " + c.B.ToString() + " ");
            }
            SR.Close();

        }
        /************************************************************************************************************************************************/
        private void colorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rdoDisplay256.Checked = true;
        }

        private void rdoDispEnt256_CheckedChanged(object sender, EventArgs e)
        {
            btnRefresh_Click(sender, e);
        }

        private void rdoDisplay256_CheckedChanged(object sender, EventArgs e)
        {
            btnRefresh_Click(sender, e);
        }

        private void save4bpp16x16SpritesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveGridSprites(VbX.CInt(txtHspriteW.Text), VbX.CInt(txtHspriteH.Text), 4, false);
        }
        /************************************************************************************************************************************************/
        public string SaveGridSprites(int Xsize, int Ysize, int BitDepth, bool OneSpriteOnly)
        {
            // Special Bitdepths:
            // 10001 = ENT 256 Color
            // 10002 = MSX 256 Color
            // 10003 = MSX2+ YJK
            // 100002 = 2 Bitplanes Byte concecutive (UKNC)

            int xmove = 1;
            if (BitDepth == 4) xmove = 2;
            if (BitDepth == 2) xmove = 4;
            if (BitDepth == 100002 || BitDepth == 100003) xmove = 8;

            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Bitmap Sprites (*.SPR;*.RAW)|*.SPR;*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return "";


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);


            int firstsprite = 0;
            int lastsprite = SpriteCount;
            if (OneSpriteOnly) { firstsprite = CurrentSprite; lastsprite = CurrentSprite; }


            for (int spritenum = 0; spritenum < SpriteCount; spritenum++)
            {
                Xsize = Spr_Wid[spritenum];
                Ysize = Spr_Hei[spritenum];
                for (int yy = Spr_MinY[spritenum]; yy < Spr_Hei[spritenum]; yy += Ysize)
                {
                    for (int xx = 0; xx < Spr_Wid[spritenum]; xx += Xsize)
                    {

                        for (int y = 0; y < Ysize; y++)
                        {
                            for (int x = 0; x < Xsize; x += xmove)
                            {
                                string tbyte = "";

                                if (BitDepth == 100002 || BitDepth == 100003)
                                {
                                    int sp8 = spritepixel[CurrentBank, spritenum, xx + x + 0, yy + y];
                                    int sp7 = spritepixel[CurrentBank, spritenum, xx + x + 1, yy + y];
                                    int sp6 = spritepixel[CurrentBank, spritenum, xx + x + 2, yy + y];
                                    int sp5 = spritepixel[CurrentBank, spritenum, xx + x + 3, yy + y];
                                    int sp4 = spritepixel[CurrentBank, spritenum, xx + x + 4, yy + y];
                                    int sp3 = spritepixel[CurrentBank, spritenum, xx + x + 5, yy + y];
                                    int sp2 = spritepixel[CurrentBank, spritenum, xx + x + 6, yy + y];
                                    int sp1 = spritepixel[CurrentBank, spritenum, xx + x + 7, yy + y];


                                    tbyte = "";

                                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp3).Substring(7, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp4).Substring(7, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp5).Substring(7, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp6).Substring(7, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp7).Substring(7, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp8).Substring(7, 1);
                                    BW.Write((Byte)VbX.Bin2Dec(tbyte));
                                    tbyte = "";

                                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp3).Substring(6, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp4).Substring(6, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp5).Substring(6, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp6).Substring(6, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp7).Substring(6, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp8).Substring(6, 1);


                                }

                                if (BitDepth == 100003)
                                {
                                    BW.Write((Byte)VbX.Bin2Dec(tbyte));
                                    int sp8 = spritepixel[CurrentBank, spritenum, xx + x + 0, yy + y];
                                    int sp7 = spritepixel[CurrentBank, spritenum, xx + x + 1, yy + y];
                                    int sp6 = spritepixel[CurrentBank, spritenum, xx + x + 2, yy + y];
                                    int sp5 = spritepixel[CurrentBank, spritenum, xx + x + 3, yy + y];
                                    int sp4 = spritepixel[CurrentBank, spritenum, xx + x + 4, yy + y];
                                    int sp3 = spritepixel[CurrentBank, spritenum, xx + x + 5, yy + y];
                                    int sp2 = spritepixel[CurrentBank, spritenum, xx + x + 6, yy + y];
                                    int sp1 = spritepixel[CurrentBank, spritenum, xx + x + 7, yy + y];

                                    tbyte = "";

                                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(5, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(5, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp3).Substring(5, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp4).Substring(5, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp5).Substring(5, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp6).Substring(5, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp7).Substring(5, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp8).Substring(5, 1);


                                }
                                if (BitDepth == 2)
                                {
                                    int sp1 = spritepixel[CurrentBank, spritenum, xx + x + 0, yy + y];
                                    int sp2 = spritepixel[CurrentBank, spritenum, xx + x + 1, yy + y];
                                    int sp3 = spritepixel[CurrentBank, spritenum, xx + x + 2, yy + y];
                                    int sp4 = spritepixel[CurrentBank, spritenum, xx + x + 3, yy + y];

                                    if (sp2 == 16 && sp1 == 16 && sp3 == 16 && sp4 == 16)
                                    {
                                        int transpcol = VbX.Bin2Dec(VbX.Right(VbX.Dec2Bin8Bit(Spr_Xoff[spritenum]), 3));
                                        if (transpcol == 5)
                                        {
                                            sp1 = 0;
                                            sp2 = 1;
                                            sp3 = 2;
                                            sp4 = 3;
                                        }
                                        if (transpcol == 4)
                                        {
                                            sp1 = 3;
                                            sp2 = 2;
                                            sp3 = 1;
                                            sp4 = 0;
                                        }
                                    }
                                    if (sp1 == 16) sp1 = 0;
                                    if (sp2 == 16) sp2 = 0;
                                    if (sp3 == 16) sp3 = 0;
                                    if (sp4 == 16) sp4 = 0;


                                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp3).Substring(6, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp3).Substring(7, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp4).Substring(6, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp4).Substring(7, 1);
                                }
                                if (BitDepth == 4)
                                {
                                    int sp1 = spritepixel[CurrentBank, spritenum, xx + x, yy + y];
                                    int sp2 = spritepixel[CurrentBank, spritenum, xx + x + 1, yy + y];

                                    if (sp2 == 16 && sp1 == 16)
                                    {
                                        int transpcol = VbX.Bin2Dec(VbX.Right(VbX.Dec2Bin8Bit(Spr_Xoff[spritenum]), 3));
                                        if (transpcol == 5)
                                        {
                                            sp1 = 0;
                                            sp2 = 1;
                                        }
                                        if (transpcol == 4)
                                        {
                                            sp1 = 3;
                                            sp2 = 2;
                                        }
                                    }
                                    if (sp1 == 16) sp1 = 0;
                                    if (sp2 == 16) sp2 = 0;

                                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(4, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(5, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);

                                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(4, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(5, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);
                                }
                                if (BitDepth == 8)
                                {

                                    int sp1 = spritepixel[CurrentBank, spritenum, x, y];

                                    tbyte += VbX.Dec2Bin8Bit(sp1);
                                }
                                if (BitDepth == 10001)
                                {  //ENT 256
                                    int sp1 = GetDisplayNum(CurrentBank, spritenum, x, y + yy);
                                    Color c = getpalette(sp1);
                                    //; 	GRBGRBGR  	;g0 | r0 | b0 | g1 | r1 | b1 | g2 | r2 | - x0 = lsb 
                                    string gg = VbX.Dec2Bin8Bit(c.G);
                                    string rr = VbX.Dec2Bin8Bit(c.R);
                                    string bb = VbX.Dec2Bin8Bit(c.B);
                                    tbyte = gg.Substring(2, 1) + rr.Substring(2, 1) + bb.Substring(1, 1) + gg.Substring(1, 1) + rr.Substring(1, 1) + bb.Substring(0, 1) + gg.Substring(0, 1) + rr.Substring(0, 1);
                                }
                                if (BitDepth == 10002) // MSX 256
                                {
                                    int sp1 = GetDisplayNum(CurrentBank, spritenum, x, y + yy);
                                    Color c = getpalette(sp1);
                                    //;  gggrrrbb
                                    string gg = VbX.Dec2Bin8Bit(c.G);
                                    string rr = VbX.Dec2Bin8Bit(c.R);
                                    string bb = VbX.Dec2Bin8Bit(c.B);
                                    tbyte = gg.Substring(0, 1) + gg.Substring(1, 1) + gg.Substring(2, 1) + rr.Substring(0, 1) + rr.Substring(1, 1) + rr.Substring(2, 1) + bb.Substring(0, 1) + bb.Substring(1, 1);
                                }
                                if (BitDepth == 10003 || BitDepth == 10004)      //MSX2 YJK
                                {

                                    int qx = x / 4;
                                    qx = qx * 4;
                                    // int s1 = GetDisplayNum(CurrentBank, spritenum, qx, y + yy);
                                    //int s2 = GetDisplayNum(CurrentBank, spritenum, qx+1, y + yy);
                                    //int s3 = GetDisplayNum(CurrentBank, spritenum, qx+2, y + yy);
                                    //int s4 = GetDisplayNum(CurrentBank, spritenum, qx+3, y + yy);

                                    Color c1 = GetDisplayRGB(CurrentBank, spritenum, qx, y + yy);
                                    Color c2 = GetDisplayRGB(CurrentBank, spritenum, qx + 1, y + yy);
                                    Color c3 = GetDisplayRGB(CurrentBank, spritenum, qx + 2, y + yy);
                                    Color c4 = GetDisplayRGB(CurrentBank, spritenum, qx + 3, y + yy);

                                    int r1 = (c1.R + c2.R + c3.R + c4.R) / 4;
                                    int g1 = (c1.G + c2.G + c3.G + c4.G) / 4;
                                    int b1 = (c1.B + c2.B + c3.B + c4.B) / 4;


                                    // int r1 = (c2.R + c3.R ) / 2;
                                    // int g1 = (c2.G + c3.G) / 2;
                                    // int b1 = (c2.B + c3.B) / 2;


                                    int Y = b1 / 2 + r1 / 4 + g1 / 8;
                                    int J = r1 - Y;
                                    int K = g1 - Y;

                                    Color c = GetDisplayRGB(CurrentBank, spritenum, x, y + yy);
                                    int Y2 = c.B / 2 + c.R / 4 + c.G / 8;

                                    //J = ((J + 159) * 255) / 352; //J=192 to -159 =351
                                    // K = ((K + 192) * 255) / 416; //K =224 to -192 =416

                                    J = (J * 128) / 192;
                                    K = (K * 128) / 224;

                                    string YY = VbX.Dec2Bin8Bit(Y2);
                                    string jj = VbX.Dec2Bin8Bit(J);
                                    string kk = VbX.Dec2Bin8Bit(K);



                                    if (BitDepth == 10003) { tbyte = YY.Substring(0, 5); }
                                    if (BitDepth == 10004) { tbyte = YY.Substring(0, 4) + "0"; }
                                    switch (x % 4)
                                    {
                                        case 0:
                                            tbyte = tbyte + kk.Substring(3, 3);
                                            break;
                                        case 1:
                                            tbyte = tbyte + kk.Substring(0, 3);
                                            break;
                                        case 2:
                                            tbyte = tbyte + jj.Substring(3, 3);
                                            break;
                                        case 3:
                                            tbyte = tbyte + jj.Substring(0, 3);
                                            break;
                                    }
                                }
                                BW.Write((Byte)VbX.Bin2Dec(tbyte));
                            }
                        }
                    }
                }

            }

            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(null, null);
            return fd.FileName;
        }
        private string Dec2Bin8BitN(int nn)
        {
            string response = "";
            if (nn < 0)
            {
                // response = "1";
                nn = Math.Abs(255 - nn) + 1;
            }
            //else response = "0";
            response = response + VbX.Dec2Bin8Bit(nn);
            return response;
        }
        /************************************************************************************************************************************************/
        private void save8bpp16x16SpritesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveGridSprites(VbX.CInt(txtHspriteW.Text), VbX.CInt(txtHspriteH.Text), 8, false);
        }
        /************************************************************************************************************************************************/
        private void paletteToClipboardRGBToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }

            string nl = VbX.Chr(13) + VbX.Chr(10);
            StringBuilder SR = new StringBuilder();

            for (int i = 0; i < 256; i++)
            {
                Color c = getpalette(i);
                SR.Append("    dw $0");
                SR.Append(VbX.Hex(c.R / 16));
                SR.Append(VbX.Hex(c.G / 16));
                SR.Append(VbX.Hex(c.B / 16));
                SR.Append("");
                SR.Append(" ;" + VbX.CStr(i) + "  -RGB");
                SR.Append(nl);
            }

            // SR.Close();
            Clipboard.SetText(SR.ToString());
            VbX.MsgBox("Copied to Clipboard");
            tabControl1.SelectedTab = tabControl1.TabPages[0];
        }

        private void btnFloodFill_Click(object sender, EventArgs e)
        {
            ResetButtons();
            CurrentTool = "floodfill";
            tabSpriteTools.TabPages.Add(tabPixelPaint);
            btnFloodFill.BackColor = SystemColors.ButtonShadow;
            tabSpriteTools.SelectedTab = tabPixelPaint;
        }

        private void save4bpp8x8TilesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveTileMap(8, 8, 4, 1);
        }

        private void saToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveTileMap(16, 16, 4, 1);
        }

        private void save8bpp8x8TilesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveTileMap(8, 8, 8, 1);
        }

        private void save8bpp16x16TilesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveTileMap(16, 16, 8, 1);
        }

        private void save4bpp8x8TilesToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveTileMap(8, 8, 4, 1);
        }

        private void saveMSX2RawYJKBitmapToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveGridSprites((int)Spr_Wid[CurrentSprite], (int)Spr_Hei[CurrentSprite], 10003, true);
        }

        private void saveMSX2RawYJKABitmapYAEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveGridSprites((int)Spr_Wid[CurrentSprite], (int)Spr_Hei[CurrentSprite], 10004, true);
        }

        private void interlaceOddFieldsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InterlaceGetFields(2, 1);
        }
        private void interlaceEvenFieldsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InterlaceGetFields(2, 0);
        }
        public void InterlaceGetFields(int Skip, int Start)
        {
            for (int y = 0; y <= Spr_Hei[CurrentSprite] - 1; y += 1)
            {
                for (int x = 0; x < 256; x++)
                {
                    byte a = 0;
                    if ((y * Skip) + Start < 256)
                    {
                        a = spritepixel[CurrentBank, CurrentSprite, x, (y * Skip) + Start];
                    }
                    spritepixel[CurrentBank, CurrentSprite, x, y] = a;
                }
            }
            btnRefresh_Click(null, null);
        }

        private void fromFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "Bitmap (*.png;*.gif;*.bmp)|*.png;*.gif;*.bmp";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;
            Bitmap b = new Bitmap(fd.FileName);
            //VbX.MsgBox(b.PixelFormat);
            LoadBitmapFile(b);
        }

        private void fromFilewithPaletteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "Bitmap (*.png;*.gif;*.bmp)|*.png;*.gif;*.bmp";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;
            Bitmap b = new Bitmap(fd.FileName);
            //VbX.MsgBox(b.Palette.Entries.Count().ToString());
            if (b.Palette.Entries.Count() > 256 || b.Palette.Entries.Count() == 0)
            {
                VbX.MsgBox("Can only load palette from 16/256 color images");
                return;
            }

            for (int c = 0; c < b.Palette.Entries.Count(); c++)
            {
                setpalette(c, b.Palette.Entries[c]);
            }

            LoadBitmapFile(b);
            //VbX.MsgBox(b.PixelFormat);
        }
        private void LoadBitmapFile(Bitmap b)
        {

            for (int x = 0; x < maxSpriteSizeX; x++)
            {
                for (int y = 0; y < maxSpriteSizeY; y++)
                {
                    Color c = Color.Black;
                    if (y < b.Height && x < b.Width)
                    {
                        c = b.GetPixel(x, y);
                    }
                    if (rdoRGBA.Checked)
                    {
                        spritepixel[CurrentBank, CurrentSprite, x, y] = c.R;
                        spritepixel[CurrentBank + 1, CurrentSprite, x, y] = c.G;
                        spritepixel[CurrentBank + 2, CurrentSprite, x, y] = c.B;
                        spritepixel[CurrentBank + 3, CurrentSprite, x, y] = c.A;
                    }
                    else
                    {
                        int currentpixel = FindColorPaletteMatch(c);
                        spritepixel[CurrentBank, CurrentSprite, x, y] = (byte)currentpixel;
                    }
                }
            }
            btnRefresh_Click(null, null);
        }
        private int FindColorPaletteMatch(Color c)
        {
            int currentpixel = 0;
            int bestpixel = 255 * 255 * 255;
            int maxcol = 15;

            if (rdoDisplay256.Checked || rdoDispEnt256.Checked) { maxcol = 255; }
            for (int i = 0; i <= maxcol; i++)
            {
                Color cc = getpalette(i);
                int thisdiff = Math.Abs(cc.R - c.R) + Math.Abs(cc.G - c.G) + Math.Abs(cc.B - c.B);

                if (thisdiff < bestpixel)
                {
                    bestpixel = thisdiff;
                    currentpixel = i;
                }
            }
            return currentpixel;
        }
        private void chkHasDosHeader_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void pDP11ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void saveRawBitmapToolStripMenuItem19_Click(object sender, EventArgs e)
        {
            string fn = SaveGridSprites((int)Spr_Wid[CurrentSprite], (int)Spr_Hei[CurrentSprite], 100002, true);

            if (fn == "") return;

            System.IO.StreamWriter sr = new System.IO.StreamWriter(fn + ".ASM");

            sr.Write(ClsBin2Asm.Bin2Asm(fn, "      .BYTE ", "", "oct8", "", ",", "        ;", (Spr_Wid[CurrentSprite] / 8) * 2));
            //^x000,^x000,^x004,^x004,^x080,^x080,^x000,^x000,^x040,^x000,^x001,^x001     ;  2
            sr.Close();
        }

        private void mSX1PaletteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 16; i++)
            {
                setpalette(i, MSXpalette[i]);
            }
        }

        private void saveRawBitmap3BitplanesToolStripMenuItem_Click(object sender, EventArgs e)
        {   // PDP11 3 bitplanes
            string fn = SaveGridSprites((int)Spr_Wid[CurrentSprite], (int)Spr_Hei[CurrentSprite], 100003, true);

            if (fn == "") return;

            System.IO.StreamWriter sr = new System.IO.StreamWriter(fn + ".ASM");

            sr.Write(ClsBin2Asm.Bin2Asm(fn, "      .BYTE ", "", "oct8", "", ",", "        ;", (Spr_Wid[CurrentSprite] / 8) * 3));
            //^x000,^x000,^x004,^x004,^x080,^x080,^x000,^x000,^x040,^x000,^x001,^x001     ;  2
            sr.Close();
        }

        private void chkTransparency_CheckedChanged(object sender, EventArgs e)
        {

            if (helpon) { ShowHelp(toolTip1.GetToolTip((Control)sender)); return; }
            btnRefresh_Click(sender, e);
        }

        private void rLECompressPerByteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "FileToCompress (*.*)|*.*";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            ClsRLEFile c = new ClsRLEFile();

            c.RLECompressFile(fd.FileName, fd.FileName + ".RLE", 0, 1);
        }

        private void rLECompressFourBytesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "FileToCompress (*.*)|*.*";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            ClsRLEFile c = new ClsRLEFile();

            c.RLECompressFile(fd.FileName, fd.FileName + ".RLE1", 0, 4);
            c.RLECompressFile(fd.FileName, fd.FileName + ".RLE2", 1, 4);
            c.RLECompressFile(fd.FileName, fd.FileName + ".RLE3", 2, 4);
            c.RLECompressFile(fd.FileName, fd.FileName + ".RLE4", 3, 4);
        }

        private void rLECompressAlternatingBytesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "FileToCompress (*.*)|*.*";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;

            ClsRLEFile c = new ClsRLEFile();

            c.RLECompressFile(fd.FileName, fd.FileName + ".RLE1", 0, 2);
            c.RLECompressFile(fd.FileName, fd.FileName + ".RLE2", 1, 2);
        }

        private void btnHelp_Click(object sender, EventArgs e)
        {
            if (helpon != true)
            {
                btnHelp.BackColor = Color.LightYellow;
                helpon = true;
                if (firsthelp)
                {
                    firsthelp = false;
                    VbX.MsgBox("Click on an option for help - Hint... look for [?] on menu items");
                }
            }
            else
            {
                btnHelp.BackColor = SystemColors.ButtonFace;
                helpon = false;
            }

        }
        private void ShowHelp(string helpstring)
        {
            btnHelp.BackColor = SystemColors.ButtonFace;
            helpon = false;

            if (helpstring.Contains("See: "))
            {
                helpstring = helpstring.Replace("See: ", "");
            }
            if (helpstring.Contains("http"))
            {
                System.Diagnostics.Process.Start(helpstring);

                // VbX.MsgBox(helpstring.Replace("See: ", ""));
                return;
            }
            if (helpstring.Length > 0)
            {
                VbX.MsgBox(helpstring);
                return;
            }
            VbX.MsgBox("Sorry, no help on this option yet :-(");
        }

        private void btnLearnAsm_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.assemblytutorial.com", "");
        }

        private void tmrHideInfo_Tick(object sender, EventArgs e)
        {
            tmrHideInfo.Enabled = false;
            tabControl2.SelectedIndex = 0;
            btnOnlineHelp.BackColor = SystemColors.ButtonFace;
            if (helpon != true)
            {
                btnHelp.BackColor = SystemColors.ButtonFace;
            }
        }


        private void rdoFrameNone_CheckedChanged(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(toolTip1.GetToolTip((Control)sender)); }
            btnRefresh_Click(sender, e);
        }

        private void ChkBackgroundTestDots_CheckedChanged(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(toolTip1.GetToolTip((Control)sender)); }
            btnRefresh_Click(sender, e);
        }

        private void btnOnlineHelp_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.chibiakumas.com/akusprite", "");
        }


        private void txtNeoSprHeight_MouseClick(object sender, MouseEventArgs e)
        {
            if (helpon) { ShowHelp(toolTip1.GetToolTip((Control)sender)); }
        }

        private void txtNeoSprSkip_MouseClick(object sender, MouseEventArgs e)
        {
            if (helpon) { ShowHelp(toolTip1.GetToolTip((Control)sender)); }
        }

        private void txtFixedFileSize_MouseClick(object sender, MouseEventArgs e)
        {
            if (helpon) { ShowHelp(toolTip1.GetToolTip((Control)sender)); }
        }

        private void rdoC64Sprite_CheckedChanged(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); }
            btnRefresh_Click(sender, e);
        }

        private void rdoGuide16_32_64_CheckedChanged(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); }
            btnRefresh_Click(sender, e);
        }

        private void tabSpriteTools_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void btnYoutube_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.youtube.com/channel/UC8t99gp5IN-FTf5rGVaRevw", "");
        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {

        }

        private void save8x8Font16bppToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //psx

            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "PSX Font (*.FNT)|*.FNT";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            int spritenum = CurrentSprite;

            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 8)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
                {
                    for (int yy = 0; yy < 8; yy++)
                    {
                        for (int xx = 0; xx < 8; xx++)
                        {
                            Color c = GetDisplayRGB(CurrentBank, spritenum, x + xx, y + yy);

                            string RR = VbX.Dec2Bin8Bit(c.R);
                            string GG = VbX.Dec2Bin8Bit(c.G);
                            string BB = VbX.Dec2Bin8Bit(c.B);
                            string tbyte = "1" + BB.Left(5) + GG.Left(5) + RR.Left(5);


                            BW.Write((UInt16)VbX.Bin2Dec(tbyte));
                        }
                    }
                }//x
            }//y
            //saveSpectrumFont(BW);
            BW.Close();


        }

        private void n64ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void save8x8Font16bppToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //n64

            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "N64 Font (*.FNT)|*.FNT";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            int spritenum = CurrentSprite;

            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 8)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
                {
                    for (int yy = 0; yy < 8; yy++)
                    {
                        for (int xx = 0; xx < 8; xx++)
                        {
                            Color c = GetDisplayRGB(CurrentBank, spritenum, x + xx, y + yy);

                            string RR = VbX.Dec2Bin8Bit(c.R);
                            string GG = VbX.Dec2Bin8Bit(c.G);
                            string BB = VbX.Dec2Bin8Bit(c.B);
                            string tbyte = RR.Left(5) + GG.Left(5) + BB.Left(5) + "1";

                            // Big endian - GRR
                            BW.Write((byte)VbX.Bin2Dec(tbyte.Left(8)));
                            BW.Write((byte)VbX.Bin2Dec(VbX.Right(tbyte, 8)));
                        }
                    }
                }//x
            }//y
            //saveSpectrumFont(BW);
            BW.Close();

        }

        private void saveRawBitmapToolStripMenuItem20_Click(object sender, EventArgs e)
        {
            //psx/nds

            SaveARGB16Bpp();
        }

        public void SaveARGB16Bpp()
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Raw Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            int spritenum = CurrentSprite;

            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 1)
            {

                for (int x = 0; x < Spr_Wid[spritenum]; x += 1)
                {
                    for (int yy = 0; yy < 1; yy++)
                    {
                        for (int xx = 0; xx < 1; xx++)
                        {
                            Color c = GetDisplayRGB(CurrentBank, spritenum, x + xx, y + yy);

                            string RR = VbX.Dec2Bin8Bit(c.R);
                            string GG = VbX.Dec2Bin8Bit(c.G);
                            string BB = VbX.Dec2Bin8Bit(c.B);
                            string tbyte = "1" + BB.Left(5) + GG.Left(5) + RR.Left(5);


                            BW.Write((UInt16)VbX.Bin2Dec(tbyte));
                        }
                    }
                }//x
            }//y
            //saveSpectrumFont(BW);
            BW.Close();
        }

        public void SaveBRG16Bpp()
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Raw Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            int spritenum = CurrentSprite;

            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += 1)
            {

                for (int x = 0; x < Spr_Wid[spritenum]; x += 1)
                {
                    for (int yy = 0; yy < 1; yy++)
                    {
                        for (int xx = 0; xx < 1; xx++)
                        {
                            Color c = GetDisplayRGB(CurrentBank, spritenum, x + xx, y + yy);
                            // BBBBBRRRRRGGGGG
                            string RR = VbX.Dec2Bin8Bit(c.R);
                            string GG = VbX.Dec2Bin8Bit(c.G);
                            string BB = VbX.Dec2Bin8Bit(c.B);
                            string tbyte = "0" + BB.Left(5) + RR.Left(5) + GG.Left(5);


                            BW.Write((UInt16)VbX.Bin2Dec(VbX.Right(tbyte, 8) + VbX.Left(tbyte, 8)));
                        }
                    }
                }//x
            }//y
            //saveSpectrumFont(BW);
            BW.Close();
        }
        private void greyScalePaletteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int i = 0; i <= 255; i++)
            {

                setpalette(i, Color.FromArgb(i, i, i));
            }
        }

        private void trkAlpha_Scroll(object sender, EventArgs e)
        {
            lblAlpha.Text = trkAlpha.Value.ToString();
        }

        private void rdoRGBA_CheckedChanged(object sender, EventArgs e)
        {
            LastBank = 7;
            ToggleTrueColor();
        }
        private void ToggleTrueColor()
        {
            if (rdoRGBA.Checked)
            {

            }
            else
            {

            }

            lblAlpha.Visible = rdoRGBA.Checked;
            lblAlpha2.Visible = rdoRGBA.Checked;
            trkAlpha.Visible = rdoRGBA.Checked;
            btnFloodFill.Enabled = !rdoRGBA.Checked;
            btnZXpaint2.Enabled = !rdoRGBA.Checked;
            btnTileCopy.Enabled = !rdoRGBA.Checked;

            btnColorSwap2.Enabled = !rdoRGBA.Checked;
            btnToolPixelPaint_Click(null, null);
        }

        private void rdoBnk4_CheckedChanged(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(toolTip1.GetToolTip((Control)sender)); }
            picPreview.Height = 256;
            if (rdoBnk4.Checked)
            {
                BankCount = 4;
                InitMaxSpriteSize();
            }
            doscale(trkzoom.Value);
            btnRefresh_Click(sender, e);
        }

        private void rdoBnk8_CheckedChanged(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(toolTip1.GetToolTip((Control)sender)); }
            picPreview.Height = 256;
            if (rdoBnk8.Checked)
            {
                BankCount = 8;
                InitMaxSpriteSize();
            }
            doscale(trkzoom.Value);
            btnRefresh_Click(sender, e);
        }

        private void rdoBnk16_CheckedChanged(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(toolTip1.GetToolTip((Control)sender)); }
            picPreview.Height = 256;
            if (rdoBnk16.Checked)
            {
                BankCount = 16;
                InitMaxSpriteSize();
            }
            doscale(trkzoom.Value);
            btnRefresh_Click(sender, e);
        }

        private void rdoBnk32_CheckedChanged(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(toolTip1.GetToolTip((Control)sender)); }
            picPreview.Height = 256;
            if (rdoBnk32.Checked)
            {
                BankCount = 32;
                InitMaxSpriteSize();
            }
            doscale(trkzoom.Value);
            btnRefresh_Click(sender, e);
        }

        private void saveRaw256ColorBitmapToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveRawBitmapVGAToolStripMenuItem_Click(sender, e);
        }

        private void saveRaw256ColorBitmap4bppToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveRawBitmapToolStripMenuItem20_Click(sender, e);
        }

        private void saveRaw256ColorBitmap8bppToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // NDS 256 color Bitmap
            saveRawBitmapVGAToolStripMenuItem_Click(sender, e);
        }

        private void sMSPaletteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string nl = VbX.Chr(13) + VbX.Chr(10);
            StringBuilder SR = new StringBuilder();

            for (int i = 0; i < 16; i++)
            {
                string prefix = "db %00";
                string suffix = ";";
                SR.Append(prefix);
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.B).Left(2));
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.G).Left(2));
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.R).Left(2));
                SR.Append(suffix);
                SR.Append(" ;" + VbX.CStr(i) + "  --BBGGRR");
                SR.Append(nl);
            }

            // SR.Close();
            Clipboard.SetText(SR.ToString());
            VbX.MsgBox("Copied to Clipboard");
            tabControl1.SelectedTab = tabControl1.TabPages[0];
        }

        private void gGPaletteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string nl = VbX.Chr(13) + VbX.Chr(10);
            StringBuilder SR = new StringBuilder();

            for (int i = 0; i < 16; i++)
            {
                string prefix = "dw &";
                string suffix = ";";
                SR.Append(prefix);
                SR.Append("0");
                SR.Append(VbX.Hex(ColorSelector[i].BackColor.B / 16));
                SR.Append(VbX.Hex(ColorSelector[i].BackColor.G / 16));
                SR.Append(VbX.Hex(ColorSelector[i].BackColor.R / 16));

                SR.Append(suffix);
                SR.Append(" ;" + VbX.CStr(i) + "  -BGR");
                SR.Append(nl);
            }

            // SR.Close();
            Clipboard.SetText(SR.ToString());
            VbX.MsgBox("Copied to Clipboard");
            tabControl1.SelectedTab = tabControl1.TabPages[0];
        }

        private void paletteToClipboardToolStripMenuItem5_Click(object sender, EventArgs e)
        {

            //SAM -BRGLBRG

            string nl = VbX.Chr(13) + VbX.Chr(10);
            StringBuilder SR = new StringBuilder();

            for (int i = 0; i < 16; i++)
            {
                string prefix = "db %0";
                string suffix = ";";
                SR.Append(prefix);
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.G).Substring(0, 1));
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.R).Substring(0, 1));
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.B).Substring(0, 1));
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.G).Substring(2, 1));   //Bright bit
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.G).Substring(1, 1));
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.R).Substring(1, 1));
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.B).Substring(1, 1));
                SR.Append(suffix);
                SR.Append(" ;" + VbX.CStr(i) + "  --GRBLGRB");
                SR.Append(nl);
            }

            // SR.Close();
            Clipboard.SetText(SR.ToString());
            VbX.MsgBox("Copied to Clipboard");
            tabControl1.SelectedTab = tabControl1.TabPages[0];
        }

        private void saveRawBitmapToolStripMenuItem21_Click(object sender, EventArgs e)
        {

            // Camputers Lynx
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }

            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            SaveRAW_PlanarFM7(BW, CurrentSprite, 3);


            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }

        private void mSX2PaletteToClipboardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string nl = VbX.Chr(13) + VbX.Chr(10);
            StringBuilder SR = new StringBuilder();

            for (int i = 0; i < 16; i++)
            {
                string prefix = "dw %00000";
                string suffix = ";";
                SR.Append(prefix);

                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.G).Left(3));
                SR.Append("0");
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.R).Left(3));
                SR.Append("0");
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.B).Left(3));

                SR.Append(suffix);
                SR.Append(" ;" + VbX.CStr(i) + "  %-----GGG-RRR-BBB");
                SR.Append(nl);
            }

            // SR.Close();
            Clipboard.SetText(SR.ToString());
            VbX.MsgBox("Copied to Clipboard");
            tabControl1.SelectedTab = tabControl1.TabPages[0];
        }

        private void btnVector_Click(object sender, EventArgs e)
        {
            ResetButtons();
            tabSpriteTools.TabPages.Add(tabVector);
            tabVector.Show();
            btnVector.BackColor = SystemColors.ButtonShadow;
            CurrentTool = "vector";
            tabSpriteTools.SelectedTab = tabVector;
        }

        private void btnVectorToClip_Click(object sender, EventArgs e)
        {
            if (CboVectorType.Text.ToLower() == "packet")
            {
                Clipboard.SetText(txtVectors.Text + "    Packet:" + VbX.nl() + "    dc.b $01");
            }
            if (CboVectorType.Text.ToLower() == "duffy")
            {

                Clipboard.SetText("    ;ldx #Duffy" + VbX.nl() +
                "    ;jsr $F3AD	;DuffAX" + VbX.nl() +
                "    Duffy:" + VbX.nl() + "    dc.b " + VectorCount + VbX.nl() + txtVectors.Text + ",$00,$00");

            }
        }

        private void btnVectorClear_Click(object sender, EventArgs e)
        {
            txtVectors.Text = "";
            LastVectorX = 128;
            LastVectorY = 128;
            VectorString = "";
            btnRefresh_Click(sender, e);
        }

        private void save8bpp8x8TilesToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveTileMap(8, 8, 8, 1);
        }

        private void paletteToClipboardToolStripMenuItem6_Click(object sender, EventArgs e)
        {
            palettetoclipboardsnes("    dw %");

        }
        private void palettetoclipboardsnes(string prefix)
        {
            string nl = VbX.Chr(13) + VbX.Chr(10);
            StringBuilder SR = new StringBuilder();

            for (int i = 0; i < 16; i++)
            {

                string suffix = ";";
                SR.Append(prefix);
                SR.Append("0");
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.B).Left(5));
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.G).Left(5));
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.R).Left(5));

                SR.Append(suffix);
                SR.Append(" ;" + VbX.CStr(i) + "  %-BBBBBGGGGGRRRRR");
                SR.Append(nl);
            }

            // SR.Close();
            Clipboard.SetText(SR.ToString());
            VbX.MsgBox("Copied to Clipboard");
        }
        private void paletteToClipboardToolStripMenuItem7_Click(object sender, EventArgs e)
        {
            string nl = VbX.Chr(13) + VbX.Chr(10);
            StringBuilder SR = new StringBuilder();

            for (int i = 0; i < 16; i++)
            {
                string prefix = "dw &";
                string suffix = ";";
                SR.Append(prefix);
                SR.Append("0");
                SR.Append(VbX.Hex(ColorSelector[i].BackColor.G / 16));
                SR.Append(VbX.Hex(ColorSelector[i].BackColor.B / 16));
                SR.Append(VbX.Hex(ColorSelector[i].BackColor.R / 16));

                SR.Append(suffix);
                SR.Append(" ;" + VbX.CStr(i) + "  -GBR");
                SR.Append(nl);
            }

            // SR.Close();
            Clipboard.SetText(SR.ToString());
            VbX.MsgBox("Copied to Clipboard");
        }

        private void paletteToClipboardToolStripMenuItem8_Click(object sender, EventArgs e)
        {
            string nl = VbX.Chr(13) + VbX.Chr(10);
            StringBuilder SR = new StringBuilder();

            for (int i = 0; i < 16; i++)
            {
                string prefix = "    dw %";
                string suffix = ";";
                SR.Append(prefix);
                SR.Append("0000000");
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.G).Left(3));
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.R).Left(3));
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.B).Left(3));
                SR.Append(suffix);
                SR.Append(" ;" + VbX.CStr(i) + "  %-------GGGRRRBBB");
                SR.Append(nl);
            }

            // SR.Close();
            Clipboard.SetText(SR.ToString());
            VbX.MsgBox("Copied to Clipboard");
        }

        private void saveRaw8x82colorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "AP2 8x8 binary (*.Raw)|*.Raw";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            SaveRAW_PlanarAp2(BW, CurrentSprite, 1);
            //saveSpectrumFont(BW);
            BW.Close();

        }

        private void paletteToClipboardToolStripMenuItem9_Click(object sender, EventArgs e)
        {
            string nl = VbX.Chr(13) + VbX.Chr(10);
            StringBuilder SR = new StringBuilder();

            for (int i = 0; i < 16; i++)
            {
                string prefix = "    dc.w %";
                string suffix = ";";
                SR.Append(prefix);

                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.G).Left(5));
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.R).Left(5));
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.B).Left(5));
                SR.Append("0");
                SR.Append(suffix);
                SR.Append(" ;" + VbX.CStr(i) + "  %GGGGGRRRRRBBBBB-");
                SR.Append(nl);
            }

            // SR.Close();
            Clipboard.SetText(SR.ToString());
            VbX.MsgBox("Copied to Clipboard");
        }

        private void raw8Color8x8BitmapToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            int spritenum = CurrentSprite;

            for (int y2 = Spr_MinY[spritenum]; y2 < Spr_Hei[spritenum]; y2 += 8)
            {

                for (int x = 0; x < Spr_Wid[spritenum]; x += 8)
                {
                    for (int yy = 0; yy < 8; yy++)
                    {
                        for (int xx = 0; xx < 8; xx += 4)
                        {

                            int y = 0;


                            int sp0 = GetDisplayNum(CurrentBank, spritenum, x + xx, y + yy + y2);
                            int sp1 = GetDisplayNum(CurrentBank, spritenum, x + xx + 1, y + yy + y2);
                            int sp2 = GetDisplayNum(CurrentBank, spritenum, x + xx + 2, y + yy + y2);
                            int sp3 = GetDisplayNum(CurrentBank, spritenum, x + xx + 3, y + yy + y2);

                            string tbyte = "";

                            tbyte += VbX.Dec2Bin8Bit(sp0).Substring(5, 1);
                            tbyte += "0";
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(5, 1);
                            tbyte += "0";
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(5, 1);
                            tbyte += "0";
                            tbyte += VbX.Dec2Bin8Bit(sp3).Substring(5, 1);
                            tbyte += "0";
                            BW.Write((Byte)VbX.Bin2Dec(tbyte));

                            tbyte = "";
                            tbyte += VbX.Dec2Bin8Bit(sp0).Substring(6, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp0).Substring(7, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp3).Substring(6, 1);
                            tbyte += VbX.Dec2Bin8Bit(sp3).Substring(7, 1);
                            BW.Write((Byte)VbX.Bin2Dec(tbyte));
                        }
                    }

                }
            }



            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }

        private void sQLCLX8ColorPaletteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 16; i++)
            {
                setpalette(i, QLpalette[i]);
            }
            btnRefresh_Click(sender, e);
        }

        private void paletteToClipboardToolStripMenuItem10_Click(object sender, EventArgs e)
        {
            string nl = VbX.Chr(13) + VbX.Chr(10);
            StringBuilder SR = new StringBuilder();

            for (int i = 0; i < 16; i++)
            {
                string prefix = "    dc.w %0000";
                string suffix = ";";
                SR.Append(prefix);

                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.B).Left(3));
                SR.Append("0");
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.G).Left(3));
                SR.Append("0");
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.R).Left(3));
                SR.Append("0");
                SR.Append(suffix);
                SR.Append(" ;" + VbX.CStr(i) + "  %----BBB-GGG-RRR-");
                SR.Append(nl);
            }

            // SR.Close();
            Clipboard.SetText(SR.ToString());
            VbX.MsgBox("Copied to Clipboard");
        }

        private void saveRaw8x8BitmapToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            SaveRAW_PlanarAST8x8(BW, CurrentSprite, 4);


            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }

        private void paletteToClipboardToolStripMenuItem11_Click(object sender, EventArgs e)
        {
            string nl = VbX.Chr(13) + VbX.Chr(10);
            StringBuilder SR = new StringBuilder();

            for (int i = 0; i < 16; i++)
            {
                string prefix = "    dc.w %00000";
                string suffix = ";";
                SR.Append(prefix);

                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.R).Left(3));
                SR.Append("0");
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.G).Left(3));
                SR.Append("0");
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.B).Left(3));

                SR.Append(suffix);
                SR.Append(" ;" + VbX.CStr(i) + "  %-----RRR-GGG-BBB");
                SR.Append(nl);
            }

            // SR.Close();
            Clipboard.SetText(SR.ToString());
            VbX.MsgBox("Copied to Clipboard");
        }

        private void copperlistPaletteToClipboardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string nl = VbX.Chr(13) + VbX.Chr(10);
            StringBuilder SR = new StringBuilder();

            for (int i = 0; i < 32; i++)
            {
                Color c = getpalette(i);
                SR.Append("    move.l #$" + VbX.Right("000" + VbX.Hex(384 + i * 2), 4) + "0");
                SR.Append(VbX.Hex(c.R / 16));
                SR.Append(VbX.Hex(c.G / 16));
                SR.Append(VbX.Hex(c.B / 16));
                SR.Append(",(a6)+");
                SR.Append(" ;" + VbX.CStr(i) + "  -RGB");
                SR.Append(nl);
            }

            // SR.Close();
            Clipboard.SetText(SR.ToString());
            VbX.MsgBox("Copied to Clipboard");
            tabControl1.SelectedTab = tabControl1.TabPages[0];
        }

        private void paletteToClipboardToolStripMenuItem12_Click(object sender, EventArgs e)
        {
            string nl = VbX.Chr(13) + VbX.Chr(10);
            StringBuilder SR = new StringBuilder();

            for (int i = 0; i < 16; i++)
            {
                string prefix = "    dc.w $";
                string suffix = ";";
                SR.Append(prefix);
                SR.Append("0");
                SR.Append(VbX.Hex(ColorSelector[i].BackColor.R / 16));
                SR.Append(VbX.Hex(ColorSelector[i].BackColor.G / 16));
                SR.Append(VbX.Hex(ColorSelector[i].BackColor.B / 16));

                SR.Append(suffix);
                SR.Append(" ;" + VbX.CStr(i) + "  -RGB");
                SR.Append(nl);
            }

            // SR.Close();
            Clipboard.SetText(SR.ToString());
            VbX.MsgBox("Copied to Clipboard");
            tabControl1.SelectedTab = tabControl1.TabPages[0];
        }

        private void CboVectorType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnZ80Vec_Click(object sender, EventArgs e)
        {
            String DestText = "";
            if (CboVectorType.Text.ToLower() == "cpacket")
            {


                int lines = ss.CountItems(VectorString, VbX.Chr(13));

                string NewString1 = "";
                string NewString2 = "";
                String thisline2 = "";
                for (int i = 0; i < lines - 1; i++)
                {
                    thisline2 = ss.GetItem(txtVectors.Text, VbX.Chr(13), i);
                    NewString2 += thisline2.Replace(VbX.Chr(10), "") + VbX.nl();

                }
                thisline2 = ss.GetItem(txtVectors.Text, VbX.Chr(13), lines - 1).Replace(VbX.Chr(10), "");
                NewString2 += VbX.Replace(thisline2, "dc.b %0", "dc.b %1");

                DestText = VbX.Replace(VbX.Replace("    CPacket:" + VbX.nl() + NewString2, "dc.b", "db"), "$", "&");
            }
            if (CboVectorType.Text.ToLower() == "packet")
            {
                DestText = VbX.Replace(VbX.Replace("    Packet:" + VbX.nl() + txtVectors.Text + "    dc.b $01", "dc.b", "db"), "$", "&");
            }
            if (CboVectorType.Text.ToLower() == "duffy")
            {

                DestText = "    ;ldx #Duffy" + VbX.nl() +
                "    ;jsr $F3AD	;DuffAX" + VbX.nl() +
                "    Duffy:" + VbX.nl() + "    dc.b " + VectorCount + VbX.nl() + txtVectors.Text + ",$00,$00";

            }

            DestText = VbX.Replace(VbX.Replace(DestText, "dc.b", "db"), "$", "&");
            Clipboard.SetText(DestText);
        }

        private void spriteSpace8x816x16ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            byte[,] copy = new byte[128, 128];

            for (int x = 0; x < 128; x++)
            {
                for (int y = 0; y < 128; y++)
                {
                    copy[x, y] = spritepixel[CurrentBank, CurrentSprite, x, y];
                }
            }
            for (int x = 0; x < 256; x++)
            {
                for (int y = 0; y < 256; y++)
                {
                    spritepixel[CurrentBank, CurrentSprite, x, y] = 0;
                }
            }


            for (int y = 0; y < 128; y += 8)
            {
                for (int x = 0; x < 128; x += 8)
                {
                    for (int yy = 0; yy < 8; yy++)
                    {
                        for (int xx = 0; xx < 8; xx++)
                        {
                            spritepixel[CurrentBank, CurrentSprite, x * 2 + xx, y * 2 + yy] = copy[x + xx, y + yy];
                        }
                    }
                }
            }
            btnRefresh_Click(sender, e);
        }

        private void saveTi8416bitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveBRG16Bpp();
        }

        private void saveTi83BitmapBWToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveRawBitmapToolStripMenuItem1_Click(sender, e);
        }

        private void paletteToClipboard15bitBGRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string nl = VbX.Chr(13) + VbX.Chr(10);
            StringBuilder SR = new StringBuilder();

            for (int i = 0; i < 16; i++)
            {
                string prefix = "    .dw %";
                string suffix = ";";
                SR.Append(prefix);
                SR.Append("0");
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.B).Left(5));
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.G).Left(5));
                SR.Append(VbX.Dec2Bin8Bit(ColorSelector[i].BackColor.R).Left(5));
                SR.Append(suffix);
                SR.Append(" ;" + VbX.CStr(i) + "  %-BBBBBGGGGGRRRRR");
                SR.Append(nl);
            }

            // SR.Close();
            Clipboard.SetText(SR.ToString());
            VbX.MsgBox("Copied to Clipboard");
        }

        private void saveTi84Bitmap4bppToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            int spritenum = CurrentSprite;
            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y++)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += 2)
                {
                    int sp1 = spritepixel[CurrentBank, spritenum, x, y];
                    int sp2 = spritepixel[CurrentBank, spritenum, x + 1, y];


                    if (sp2 == 16 && sp1 == 16)
                    {
                        int transpcol = VbX.Bin2Dec(VbX.Right(VbX.Dec2Bin8Bit(Spr_Xoff[spritenum]), 3));
                        if (transpcol == 5)
                        {
                            sp1 = 0;
                            sp2 = 1;
                        }
                        if (transpcol == 4)
                        {
                            sp1 = 3;
                            sp2 = 2;
                        }
                    }
                    if (sp1 == 16) sp1 = 0;
                    if (sp2 == 16) sp2 = 0;


                    string tbyte = "";
                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(4, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(5, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);

                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(4, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(5, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                    tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);


                    BW.Write((Byte)VbX.Bin2Dec(tbyte));
                }
            }
            BW.Close();
        }

        private void saveSprite4ColorToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            DoC64Sprite(1, 4, 12);
        }


        private void saveRawBitmapToolStripMenuItem1_Click_1(object sender, EventArgs e)
        {
            saveRAWMSX1BitmapToolStripMenuItem_Click(sender, e);
        }

        private void palette0GToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 16; i++)
            {
                setpalette(i, DragonPal0[i]);
            }
            btnRefresh_Click(sender, e);
        }

        private void palette1WCMOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 16; i++)
            {
                setpalette(i, DragonPal1[i]);
            }
            btnRefresh_Click(sender, e);
        }

        private void saveRaw4ColorBitmapToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            SaveGridSprites((int)Spr_Wid[CurrentSprite], (int)Spr_Hei[CurrentSprite], 2, true);
        }

        private void savToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveRawBitmapToolStripMenuItem1_Click(sender, e);
        }

        private void saveCoCo46ColorBitmapToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveRAWBitmapToolStripMenuItem3_Click(sender, e);
        }

        private void savePaletteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }

            string nl = VbX.Chr(13) + VbX.Chr(10);
            StringBuilder SR = new StringBuilder();

            for (int i = 0; i < 256; i++)
            {
                Color c = getpalette(i);
                SR.Append("    .byte ");
                SR.Append("$" + VbX.Right("00" + VbX.Hex(c.B), 2) + ",");
                SR.Append("$" + VbX.Right("00" + VbX.Hex(c.G), 2) + ",");
                SR.Append("$" + VbX.Right("00" + VbX.Hex(c.R), 2) + ",$FF");

                SR.Append("");
                SR.Append(" ;" + VbX.CStr(i) + "  BGRA");
                SR.Append(nl);
            }

            // SR.Close();
            Clipboard.SetText(SR.ToString());
            VbX.MsgBox("Copied to Clipboard");
            tabControl1.SelectedTab = tabControl1.TabPages[0];
        }

        private void paletteToClipboardToolStripMenuItem13_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }

            string nl = VbX.Chr(13) + VbX.Chr(10);
            StringBuilder SR = new StringBuilder();

            for (int i = 0; i < 16; i++)
            {
                Color c = getpalette(i);
                SR.Append("    .word $0");
                SR.Append(VbX.Hex(c.R / 16));
                SR.Append(VbX.Hex(c.G / 16));
                SR.Append(VbX.Hex(c.B / 16));
                SR.Append("");
                SR.Append(" ;" + VbX.CStr(i) + "  -RGB");
                SR.Append(nl);
            }

            // SR.Close();
            Clipboard.SetText(SR.ToString());
            VbX.MsgBox("Copied to Clipboard");
            tabControl1.SelectedTab = tabControl1.TabPages[0];
        }

        private void toolStripMenuItem10_Click(object sender, EventArgs e)
        {
            saveRawBitmapToolStripMenuItem15_Click(sender, e);
        }

        private void toolStripMenuItem11_Click(object sender, EventArgs e)
        {
            paletteToClipboardToolStripMenuItem6_Click(sender, e);
        }

        private void saveRawSuperHiResBitmapToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveRAWBitmapToolStripMenuItem3_Click(sender, e);
        }

        private void saveRaw8x8Tiles4ColorZigTileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            if (rdoDisplayCPC0.Checked)
            {
                // CPC_SaveRAW_16Color(BW, CurrentSprite, 1);
            }
            else
            {
                CPC_SaveRAW_4Color8x8(BW, CurrentSprite, true, 8, 1);
            }

            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }

        private void saveRawBitmap2PlaneToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }

            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            SaveRAW_PlanarFM7(BW, CurrentSprite, 2);


            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }

        private void saveRaw8x8Tiles2PlaneToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }

            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            SaveRAW_PlanarFM7Tile(BW, CurrentSprite, 2);


            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);

        }

        private void saveRaw8x8Tiles3PlaneToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }

            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            SaveRAW_PlanarFM7Tile(BW, CurrentSprite, 3);

            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }

        private void saveDoubleHeightBitmapToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Vic 20 8x16 chars
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            SaveRAW_Planar(BW, CurrentSprite, 1, 8, 16, 1);
            //saveSpectrumFont(BW);
            BW.Close();
        }

        private void saveRawBitmap2bpp4ColorToolStripMenuItem_Click(object sender, EventArgs e)
        {

            // Snes Raw Bitmap
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            SaveRAW_PlanarSNS(BW, CurrentSprite, 2);


            BW.Close();
            ST.Close();

            btnRefresh_Click(sender, e);

        }

        private void save4bppSpriteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveGridSprites(VbX.CInt(txtHspriteW.Text), VbX.CInt(txtHspriteH.Text), 4, false);
        }

        private void save8bppSpriteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveGridSprites(VbX.CInt(txtHspriteW.Text), VbX.CInt(txtHspriteH.Text), 8, false);
        }

        private void btnExportInfo_Click(object sender, EventArgs e)
        {
            int pixelcount = 0;
            String List = "";
            for (int s = 0; s < SpriteCount; s++)
            {

                List += VbX.Left("    dw &" + VbX.Dec2Hex16bit(pixelcount) + "/PixelsPerByte + SpriteBase" + VbX.Space(50), 50) + ";SpriteAddr " + s.ToString() + VbX.nl();
                pixelcount = pixelcount + (int)(Spr_Wid[s]) * (int)(Spr_Hei[s]);
                List += VbX.Left("     db " + Spr_Wid[s].ToString() + "," + (Spr_Hei[s] - Spr_MinY[s]).ToString() + VbX.Space(50), 50) + ";XY " + VbX.nl();

            }
            Clipboard.SetText(List);
            VbX.MsgBox("Copied to Clipboard");
        }

        private void generatePixelMapToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int bitmask = 0;
            for (int s = 0; s < 256; s++)
            {
                int Sx = s / 16; Sx = Sx * 16;
                int Sy = s % 16; Sy = Sy * 16;

                int Cnum = 0;
                for (int xx = 0; xx < 2; xx++)
                {
                    for (int yy = 0; yy < 4; yy++)
                    {

                        byte Color = 0;

                        Color = (byte)VbX.Bin2Dec(VbX.Dec2Bin8Bit(bitmask).Substring(Cnum, 1));
                        Cnum++;
                        for (int xxx = 0; xxx < 8; xxx += 1)
                        {
                            for (int yyy = 0; yyy < 4; yyy += 1)
                            {
                                spritepixel[CurrentBackup, CurrentSprite, Sx + xxx + xx * 8, Sy + yyy + yy * 4] = (byte)(Color);
                            }
                        }

                    }
                }
                bitmask++;
            }
            btnRefresh_Click(sender, e);



        }

        private void halveYToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int y = 0; y <= Spr_Hei[CurrentSprite] - 1; y += 2)
            {
                for (int x = 0; x < 256; x++)
                {

                    spritepixel[CurrentBank, CurrentSprite, x, y] = spritepixel[CurrentBank, CurrentSprite, x, y + 1];
                }
            }
            btnRefresh_Click(null, null);
        }

        private void paletteToClipboardToolStripMenuItem14_Click(object sender, EventArgs e)
        {
            //GBA Palette
            palettetoclipboardsnes("    .word 0b");
        }

        private void save4bToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int Yhei = 8;
            int Xwid = 8;

            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            int spritenum = CurrentSprite;

            for (int y = Spr_MinY[spritenum]; y < Spr_Hei[spritenum]; y += Yhei)
            {
                for (int x = 0; x < Spr_Wid[spritenum]; x += Xwid)
                {

                    for (int y2 = 0; y2 < Yhei; y2++)
                    {
                        for (int xb = 0; xb <= 4; xb += 4)
                        {
                            for (int xx = 0; xx <= 2; xx += 2)
                            {
                                int sp1 = GetDisplayNum(CurrentBank, spritenum, xb + xx + x, y + y2);
                                int sp2 = GetDisplayNum(CurrentBank, spritenum, xb + xx + x + 1, y + y2);

                                if (sp1 == 16) sp1 = 0;
                                if (sp2 == 16) sp2 = 0;
                                string tbyte = "";

                                tbyte += VbX.Dec2Bin8Bit(sp2).Substring(4, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp2).Substring(5, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp2).Substring(6, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp2).Substring(7, 1);

                                tbyte += VbX.Dec2Bin8Bit(sp1).Substring(4, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp1).Substring(5, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp1).Substring(6, 1);
                                tbyte += VbX.Dec2Bin8Bit(sp1).Substring(7, 1);


                                BW.Write((Byte)VbX.Bin2Dec(tbyte));
                            }
                        }

                    }//y2
                }//x
            }//y


            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(null, null);
        }

        private void save4bpp8x8TilesToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            save4bToolStripMenuItem_Click(sender, e);
        }

        private void paletteToClipboardToolStripMenuItem15_Click(object sender, EventArgs e)
        {
            //NDS Palette
            palettetoclipboardsnes("    .word 0b");
        }

        private void saveRaw8x4Tiles4ColorHalfHeightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            if (chkSaveMultiRaw.Checked)
            {
                for (int cs = 0; cs < SpriteCount; cs++)
                {
                    if (rdoDisplayCPC0.Checked)
                    {
                        CPC_SaveRAW_16Color8x8(BW, cs, false, 8);
                    }
                    else
                    {
                        CPC_SaveRAW_4Color8x8(BW, cs, false, 8, 2);
                    }
                }
            }
            else
            {

                if (rdoDisplayCPC0.Checked)
                {
                    CPC_SaveRAW_16Color8x8(BW, CurrentSprite, false, 8);
                }
                else
                {
                    CPC_SaveRAW_4Color8x8(BW, CurrentSprite, false, 8, 2);
                }
            }

            BW.Close();
            ST.Close();
            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }

        private void save8bpp8x8TilesToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            SaveGridSprites(VbX.CInt(txtHspriteW.Text), VbX.CInt(txtHspriteH.Text), 8, false);
        }

        private void save8bpp8x8TilesSpriteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveGridSprites(VbX.CInt(txtHspriteW.Text), VbX.CInt(txtHspriteH.Text), 8, false);
        }

        private void save2bpp8x8TilesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveTileMap(8, 8, 2, 1);
        }

        private void save2bppRawBitmapToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // SpecNext 2bpp

            SaveGridSprites(0, 0, 2, true);


        }

        private void save2bpp8x8TilesHalfHeightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveTileMap(8, 8, 2, 2);
        }

        private void insertBlankSpriteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int cs = SpriteCount - 1; cs >= CurrentSprite; cs--)
            {
                for (int y = 0; y < 256; y++)
                {
                    for (int x = 0; x < 256; x++)
                    {

                        spritepixel[CurrentBank, cs + 1, x, y] = spritepixel[CurrentBank, cs, x, y];

                    }
                }
            }

            for (int y = 0; y < Spr_Hei[CurrentSprite]; y++)
            {
                for (int x = 0; x < Spr_Wid[CurrentSprite]; x++)
                {
                    spritepixel[CurrentBank, CurrentSprite, x, y] = 0;
                }
            }

            btnRefresh_Click(sender, e);
        }

        private void addMultipleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }
            for (int x = 0; x < 256; x++)
            {
                for (int y = 0; y < 256; y++)
                {
                    spritepixel[CurrentBank, 0, x, y] = 0;
                }
            }
            txtNextTile.Text = "1";


            int spritenum = CurrentSprite;
            string TileMap = "";
            for (int sp = spritenum; sp < SpriteCount; sp++)
            {

                TileMap = AddTileMap(TileMap, sp);
                txtSaveTileCount.Text = txtNextTile.Text;
            }


            chkSaveMultiRaw.Checked = false;
            VbX.MsgBox("TileCount:" + txtNextTile.Text);
            Clipboard.SetText(TileMap);
        }

        private void btnExportTilelist_Click(object sender, EventArgs e)
        {
            int pixelcount = 0;
            String List = "";
            for (int s = 1; s < SpriteCount; s++)
            {

                List += VbX.Left("    dw Sprite_" + VbX.CStr(s) + VbX.Space(50), 50) + ";SpriteAddr " + s.ToString() + VbX.nl();
                pixelcount = pixelcount + (int)(Spr_Wid[s]) * (int)(Spr_Hei[s]);
                List += VbX.Left("     db " + Spr_Wid[s].ToString() + "," + (Spr_Hei[s] - Spr_MinY[s]).ToString() + VbX.Space(50), 50) + ";XY " + VbX.nl();

            }
            Clipboard.SetText(List);
            VbX.MsgBox("Copied to Clipboard");
        }

        private void deresAllMultipleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int cs = 1; cs < SpriteCount; cs++)
            {
                CurrentSprite = cs;
                for (int x = 0; x < Spr_Wid[cs]; x += 8)
                {
                    for (int y = 0; y < Spr_Hei[cs]; y += 8)
                    {

                        TileCopy(x, y, new MouseEventArgs(MouseButtons.Middle, 0, 0, 0, 0), false);
                    }
                }
            }
            CurrentSprite = 0;
            btnRefresh_Click(null, null);

        }

        private void saveCDSpriteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Neo Geo CD Sprite
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "NeoGeo CD Sprite (*.SPR)|*.SPR";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);



            long bytecount = 0;
            int planes = 4;
            for (int bnk = 0; bnk < BankCount; bnk++)
            {
                for (int spritenum = 0; spritenum < SpriteCount; spritenum++)
                {

                    for (int x = 0; x < Spr_Wid[spritenum]; x += 16)
                    {

                        for (int y2 = 0; y2 < Spr_Hei[spritenum]; y2 += 16)
                        {
                            for (int x2 = 8; x2 >= 0; x2 -= 8)
                            {
                                for (int y = 0; y < 16; y += 1)
                                {
                                    for (int pp = 7; pp > 7 - planes; pp--)
                                    //  for (int p = 4; p <= 7; p++)
                                    {
                                        int p = 0;
                                        if (pp == 7) p = 6;
                                        if (pp == 6) p = 7;
                                        if (pp == 5) p = 4;
                                        if (pp == 4) p = 5;

                                        int sp0 = GetDisplayNum(bnk, spritenum, x + x2 + 7, y + y2);
                                        int sp1 = GetDisplayNum(bnk, spritenum, x + x2 + 6, y + y2);
                                        int sp2 = GetDisplayNum(bnk, spritenum, x + x2 + 5, y + y2);
                                        int sp3 = GetDisplayNum(bnk, spritenum, x + x2 + 4, y + y2);
                                        int sp4 = GetDisplayNum(bnk, spritenum, x + x2 + 3, y + y2);
                                        int sp5 = GetDisplayNum(bnk, spritenum, x + x2 + 2, y + y2);
                                        int sp6 = GetDisplayNum(bnk, spritenum, x + x2 + 1, y + y2);
                                        int sp7 = GetDisplayNum(bnk, spritenum, x + x2 + 0, y + y2);

                                        string tbyte = "";
                                        tbyte += VbX.Dec2Bin8Bit(sp0).Substring(p, 1);
                                        tbyte += VbX.Dec2Bin8Bit(sp1).Substring(p, 1);
                                        tbyte += VbX.Dec2Bin8Bit(sp2).Substring(p, 1);
                                        tbyte += VbX.Dec2Bin8Bit(sp3).Substring(p, 1);
                                        tbyte += VbX.Dec2Bin8Bit(sp4).Substring(p, 1);
                                        tbyte += VbX.Dec2Bin8Bit(sp5).Substring(p, 1);
                                        tbyte += VbX.Dec2Bin8Bit(sp6).Substring(p, 1);
                                        tbyte += VbX.Dec2Bin8Bit(sp7).Substring(p, 1);

                                        bytecount++;
                                        BW.Write((Byte)VbX.Bin2Dec(tbyte));

                                    }
                                }//x
                            }//y

                        }//p
                    }

                }//s
            }   //bnk
            long targetcount = VbX.Val(txtFixedFileSize.Text);
            while (bytecount < targetcount)
            {
                bytecount++;

                BW.Write((Byte)0);
            }


            BW.Close();
        }

        private void saveHalfHeightRawBitmap8x4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // SMS halfheight raw bitmap
            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);
            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);
            int firsts = 0;
            int lasts = BankSpriteCount;
            if (!chkSaveMultiRaw.Checked) { firsts = CurrentSprite; lasts = CurrentSprite + 1; }

            for (int cn = firsts; cn < lasts; cn++)
            {
                if (rdoDisplayCPC.Checked)
                {
                    SaveRAW_Planar(BW, cn, 2, 8, 8, 2);
                }
                else
                {
                    SaveRAW_Planar(BW, cn, 4, 8, 8, 2);
                }
            }

            BW.Close();
            ST.Close();



            tabControl1.SelectedTab = tabControl1.TabPages[0];

            btnRefresh_Click(sender, e);
        }

        private void saveRawBitmapToolStripMenuItem22_Click(object sender, EventArgs e)
        {
            //Pet


            if (helpon) { ShowHelp(((ToolStripMenuItem)sender).ToolTipText); return; }
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "RAW Bitmap (*.RAW)|*.RAW";
            DialogResult dr = fd.ShowDialog();
            if (dr != DialogResult.OK) return;


            int firstspritepos = VbX.Val(txtSpriteDataOffSet.Text);
            for (int s = 0; s < BankSpriteCount; s++)
            {
                SpriteStats(s);         // update all our info on the sprites
            }

            System.IO.Stream ST = new System.IO.FileStream(fd.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);
            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(ST);

            int spritenum = CurrentSprite;
            int bnk = CurrentBank;
            string result = "";
            for (int y = 0; y < Spr_Hei[spritenum]; y += 2)
            {
            for (int x = 0; x < Spr_Wid[spritenum]; x += 2)
            {
               

                    string bb = "";
                    if (GetDisplayNum(bnk, spritenum, x + 1, y + 1) > 0) bb += "1"; else bb += "0";
                    if (GetDisplayNum(bnk, spritenum, x + 0, y + 1) > 0) bb += "1"; else bb += "0";
                    if (GetDisplayNum(bnk, spritenum, x + 1, y + 0) > 0) bb += "1"; else bb += "0";
                    if (GetDisplayNum(bnk, spritenum, x + 0, y + 0) > 0) bb += "1"; else bb += "0";

                    int b = 0;
                    BW.Write((Byte)(PetBlocks[VbX.Bin2Dec(bb)]));

                }//x
            }//y

            BW.Close();
            ST.Close();

        }

    }
    }
/************************************************************************************************************************************************/


