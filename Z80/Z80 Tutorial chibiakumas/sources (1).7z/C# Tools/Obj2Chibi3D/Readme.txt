This program can be used to convert OBJ files exported from Blender to ASM source for use with ChibiScape 3D

Chibiscape -W- currently only supports 4 sided Faces and 2 point lines

However this program has support for possible future features:
it can export multipoint lines, and many sided faces - as well as numbered materials (which will be mapped to colors in a future version of ChibiScape)