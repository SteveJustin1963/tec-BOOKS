﻿namespace Obj2Chibi3D
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.txtSource = new System.Windows.Forms.TextBox();
            this.txtDest = new System.Windows.Forms.TextBox();
            this.btnConv = new System.Windows.Forms.Button();
            this.lblInfo = new System.Windows.Forms.Label();
            this.chkRectOnly = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtXshift = new System.Windows.Forms.TextBox();
            this.txtXScale = new System.Windows.Forms.TextBox();
            this.txtYScale = new System.Windows.Forms.TextBox();
            this.txtYshift = new System.Windows.Forms.TextBox();
            this.txtZScale = new System.Windows.Forms.TextBox();
            this.txtZshift = new System.Windows.Forms.TextBox();
            this.chk16bitv = new System.Windows.Forms.CheckBox();
            this.chkUseMaterial = new System.Windows.Forms.CheckBox();
            this.chkMultipartLine = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(418, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(78, 49);
            this.button1.TabIndex = 1;
            this.button1.Text = "Browse";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtSource
            // 
            this.txtSource.Location = new System.Drawing.Point(4, 2);
            this.txtSource.Name = "txtSource";
            this.txtSource.Size = new System.Drawing.Size(400, 19);
            this.txtSource.TabIndex = 0;
            this.txtSource.Text = "F:\\Progs\\Obj2Chibi3D3\\Obj2Chibi3D1\\untitled.obj";
            // 
            // txtDest
            // 
            this.txtDest.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDest.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDest.Location = new System.Drawing.Point(4, 116);
            this.txtDest.Multiline = true;
            this.txtDest.Name = "txtDest";
            this.txtDest.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDest.Size = new System.Drawing.Size(407, 306);
            this.txtDest.TabIndex = 1;
            // 
            // btnConv
            // 
            this.btnConv.Location = new System.Drawing.Point(502, 2);
            this.btnConv.Name = "btnConv";
            this.btnConv.Size = new System.Drawing.Size(79, 49);
            this.btnConv.TabIndex = 1;
            this.btnConv.Text = "Convert";
            this.btnConv.UseVisualStyleBackColor = true;
            this.btnConv.Click += new System.EventHandler(this.btnConv_Click);
            // 
            // lblInfo
            // 
            this.lblInfo.BackColor = System.Drawing.Color.Black;
            this.lblInfo.ForeColor = System.Drawing.Color.Lime;
            this.lblInfo.Location = new System.Drawing.Point(416, 116);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(165, 306);
            this.lblInfo.TabIndex = 2;
            this.lblInfo.Text = ".";
            // 
            // chkRectOnly
            // 
            this.chkRectOnly.AutoSize = true;
            this.chkRectOnly.Checked = true;
            this.chkRectOnly.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkRectOnly.Location = new System.Drawing.Point(7, 47);
            this.chkRectOnly.Name = "chkRectOnly";
            this.chkRectOnly.Size = new System.Drawing.Size(118, 16);
            this.chkRectOnly.TabIndex = 3;
            this.chkRectOnly.Text = "4 Vert Faces Only";
            this.chkRectOnly.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(134, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(12, 12);
            this.label1.TabIndex = 4;
            this.label1.Text = "X";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(134, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(12, 12);
            this.label2.TabIndex = 5;
            this.label2.Text = "Y";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(134, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(12, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "Z";
            // 
            // txtXshift
            // 
            this.txtXshift.Location = new System.Drawing.Point(163, 36);
            this.txtXshift.Name = "txtXshift";
            this.txtXshift.Size = new System.Drawing.Size(54, 19);
            this.txtXshift.TabIndex = 7;
            this.txtXshift.Text = "128";
            // 
            // txtXScale
            // 
            this.txtXScale.Location = new System.Drawing.Point(223, 36);
            this.txtXScale.Name = "txtXScale";
            this.txtXScale.Size = new System.Drawing.Size(54, 19);
            this.txtXScale.TabIndex = 8;
            this.txtXScale.Text = "127";
            // 
            // txtYScale
            // 
            this.txtYScale.Location = new System.Drawing.Point(223, 55);
            this.txtYScale.Name = "txtYScale";
            this.txtYScale.Size = new System.Drawing.Size(54, 19);
            this.txtYScale.TabIndex = 10;
            this.txtYScale.Text = "127";
            // 
            // txtYshift
            // 
            this.txtYshift.Location = new System.Drawing.Point(163, 55);
            this.txtYshift.Name = "txtYshift";
            this.txtYshift.Size = new System.Drawing.Size(54, 19);
            this.txtYshift.TabIndex = 9;
            this.txtYshift.Text = "128";
            // 
            // txtZScale
            // 
            this.txtZScale.Location = new System.Drawing.Point(223, 75);
            this.txtZScale.Name = "txtZScale";
            this.txtZScale.Size = new System.Drawing.Size(54, 19);
            this.txtZScale.TabIndex = 12;
            this.txtZScale.Text = "127";
            // 
            // txtZshift
            // 
            this.txtZshift.Location = new System.Drawing.Point(163, 75);
            this.txtZshift.Name = "txtZshift";
            this.txtZshift.Size = new System.Drawing.Size(54, 19);
            this.txtZshift.TabIndex = 11;
            this.txtZshift.Text = "128";
            // 
            // chk16bitv
            // 
            this.chk16bitv.AutoSize = true;
            this.chk16bitv.Location = new System.Drawing.Point(7, 26);
            this.chk16bitv.Name = "chk16bitv";
            this.chk16bitv.Size = new System.Drawing.Size(104, 16);
            this.chk16bitv.TabIndex = 13;
            this.chk16bitv.Text = "16 bit Vert XYZ";
            this.chk16bitv.UseVisualStyleBackColor = true;
            // 
            // chkUseMaterial
            // 
            this.chkUseMaterial.AutoSize = true;
            this.chkUseMaterial.Checked = true;
            this.chkUseMaterial.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkUseMaterial.Location = new System.Drawing.Point(7, 93);
            this.chkUseMaterial.Name = "chkUseMaterial";
            this.chkUseMaterial.Size = new System.Drawing.Size(85, 16);
            this.chkUseMaterial.TabIndex = 14;
            this.chkUseMaterial.Text = "UseMaterial";
            this.chkUseMaterial.UseVisualStyleBackColor = true;
            // 
            // chkMultipartLine
            // 
            this.chkMultipartLine.AutoSize = true;
            this.chkMultipartLine.Location = new System.Drawing.Point(7, 71);
            this.chkMultipartLine.Name = "chkMultipartLine";
            this.chkMultipartLine.Size = new System.Drawing.Size(95, 16);
            this.chkMultipartLine.TabIndex = 15;
            this.chkMultipartLine.Text = "MultiPart Line";
            this.chkMultipartLine.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(171, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 12);
            this.label4.TabIndex = 16;
            this.label4.Text = "Offset";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(233, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(33, 12);
            this.label5.TabIndex = 17;
            this.label5.Text = "Scale";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 424);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.chkMultipartLine);
            this.Controls.Add(this.chkUseMaterial);
            this.Controls.Add(this.chk16bitv);
            this.Controls.Add(this.txtZScale);
            this.Controls.Add(this.txtZshift);
            this.Controls.Add(this.txtYScale);
            this.Controls.Add(this.txtYshift);
            this.Controls.Add(this.txtXScale);
            this.Controls.Add(this.txtXshift);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.chkRectOnly);
            this.Controls.Add(this.txtDest);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.btnConv);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtSource);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Obj2Chibi3D - Wavefront OBJ to ChibiScape 3D";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSource;
        private System.Windows.Forms.Button btnConv;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtDest;
        private System.Windows.Forms.Label lblInfo;
        private System.Windows.Forms.CheckBox chkRectOnly;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtXshift;
        private System.Windows.Forms.TextBox txtXScale;
        private System.Windows.Forms.TextBox txtYScale;
        private System.Windows.Forms.TextBox txtYshift;
        private System.Windows.Forms.TextBox txtZScale;
        private System.Windows.Forms.TextBox txtZshift;
        private System.Windows.Forms.CheckBox chk16bitv;
        private System.Windows.Forms.CheckBox chkUseMaterial;
        private System.Windows.Forms.CheckBox chkMultipartLine;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}

