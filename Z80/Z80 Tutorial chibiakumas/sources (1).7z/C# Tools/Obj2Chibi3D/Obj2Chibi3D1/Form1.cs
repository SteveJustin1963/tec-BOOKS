﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Obj2Chibi3D
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public String PadVert(int i) {
            if (chk16bitv.Checked)
            {
                return VbX.Right("     "+VbX.CStr(i), 5);
            }
            return VbX.Right("   " + VbX.CStr(i), 3);
        }
        public String Padface(int i)
        {
            // if (chk16bitv.Checked)
            //{
            //    return VbX.Right("     " + VbX.CStr(i), 5);
           // }
            return VbX.Right("   " + VbX.CStr(i), 3);
        }
        private void btnConv_Click(object sender, EventArgs e)
        {
            float maxx = 0, maxy = 0, maxz = 0, minx = 0, miny = 0, minz = 0;
            int Material = 0;
            int Vnum = 0;
            int Fnum = 0;
            int Lnum = 0;
            bool overflow = false;
            String template = "V,V,V";
            String templatel;
            if (chkUseMaterial.Checked) template = "M," + template;
            templatel = template;
            if (chkMultipartLine.Checked) templatel = templatel +",0";
            if (!chkRectOnly.Checked) template = template + ",0";
            bool allfaces4vert = true;
            bool nomultipartlines = true;
            String txtVert = "Vertexes:         ;X,Y,Z" + VbX.nl(); //' + ";x y z [w]" + VbX.nl();
            String txtFace = "Faces:            ;" +template+ VbX.nl();// +";Polygonal face element (vertexIdx/textureIdx/normalIdx)" + VbX.nl();
            String txtLine = "Lines:            ;" + templatel + VbX.nl();// +";Line element (V V V)" + VbX.nl();
            System.IO.StreamReader sr = new System.IO.StreamReader(txtSource.Text);
            while (sr.Peek() >= 0)
            {
                String lin = sr.ReadLine().Trim();

                String cmd = ss.GetItem(lin, " ", 0);
                switch (cmd)
                {
                    case "usemtl":
                        {
                            Material = VbX.CInt(VbX.Right(ss.GetItem(lin, " ", 1), 3));
                        }
                        break;
                    case "v":
                        {
                            float x = float.Parse(ss.GetItem(lin, " ", 1));
                            float y = float.Parse(ss.GetItem(lin, " ", 2));
                            float z = float.Parse(ss.GetItem(lin, " ", 3));

                            if (x < minx) minx = x;
                            if (y < miny) miny = y;
                            if (z < minz) minz = z;

                            if (x > maxx) maxx = x;
                            if (y > maxy) maxy = y;
                            if (z > maxz) maxz = z;
                            if (chk16bitv.Checked)
                            {

                                txtVert = txtVert + "   dw ";
                            }
                            else txtVert = txtVert + "   db ";
                            int xx = VbX.CInt(x * VbX.CInt(txtXScale.Text) + VbX.CInt(txtXshift.Text));
                            int yy = VbX.CInt(y * VbX.CInt(txtYScale.Text) + VbX.CInt(txtYshift.Text));
                            int zz = VbX.CInt(z * VbX.CInt(txtZScale.Text) + VbX.CInt(txtZshift.Text));

                            if (!chk16bitv.Checked && (xx > 255 || yy > 255 || zz > 255)) overflow = true;

                            txtVert = txtVert + PadVert(xx) + ", ";
                            txtVert = txtVert + PadVert(yy) + ", " ;
                            txtVert = txtVert + PadVert(zz);
                            Vnum++;
                            txtVert = txtVert +"    ;"+Vnum.ToString() +VbX.nl();
                        }
                        break;
                    case "f":
                        {
                            txtFace = txtFace + "   db ";
                            if (chkUseMaterial.Checked)
                            {
                                txtFace = txtFace + Padface(Material) + ", ";
                            }
                            if (ss.CountItems(lin, " ") != 4) allfaces4vert = false;

                            for (int i = 1; i <= ss.CountItems(lin, " "); i++)
                            {
                                if (i > 1) txtFace = txtFace + ", ";
                                txtFace = txtFace + Padface(VbX.CInt(ss.GetItem(ss.GetItem(lin, " ", i), "/", 0)));

                            }
                            if (!chkRectOnly.Checked) txtFace = txtFace + ", " + Padface(0);
                            Fnum++;
                            txtFace = txtFace + "    ;" + Fnum.ToString() + VbX.nl();
                        }
                        break;
                    case "l":
                        {
                            txtLine = txtLine + "   db ";
                            if (chkUseMaterial.Checked)
                            {
                                txtLine = txtLine + Padface(0)+ ", ";
                            }
                            if (ss.CountItems(lin, " ") != 2) nomultipartlines = false;
                            
                            for (int i = 1; i <= ss.CountItems(lin, " "); i++)
                            {
                                if (i > 1) txtLine = txtLine + ", ";
                                txtLine = txtLine + Padface(VbX.CInt(ss.GetItem(ss.GetItem(lin, " ", i), "/", 0)));
                            }
                            if (chkMultipartLine.Checked) txtLine = txtLine + ", "+Padface(0);
                            Lnum++;
                            txtLine = txtLine + "    ;" + Lnum.ToString() + VbX.nl();
                        }
                        break;
                }
                

                lblInfo.Text = "X Range: " + minx.ToString() + " ... " + maxx.ToString() + VbX.nl();
                lblInfo.Text += "Y Range: " + miny.ToString() + " ... " + maxy.ToString() + VbX.nl();
                lblInfo.Text += "Z Range: " + minz.ToString() + " ... " + maxz.ToString() + VbX.nl() + VbX.nl();

                if (overflow) lblInfo.Text += "** LIMIT OVERFLOW **";

                float min = minx, max = maxx;

                if (miny < min) min = miny;
                if (minz < min) min = minz;

                if (maxy > max) max = maxy;
                if (maxz > max) max = maxz;
                lblInfo.Text += "- Range: " + min.ToString() + " ... " + max.ToString() + VbX.nl();
                lblInfo.Text += "Suggest Offset: 128" + " Scale " + VbX.CInt(127/(max - min)).ToString() + VbX.nl() + VbX.nl();


                if (allfaces4vert) lblInfo.Text += "All Faces 4 Vert"; else lblInfo.Text += "NOT All Faces 4 Vert!!!";
                lblInfo.Text += VbX.nl();
                if (nomultipartlines) lblInfo.Text += "no multipart lines"; else lblInfo.Text += "MUTLTIPART LINES!!!";
            }
            txtVert += "Vertexes_End:" + VbX.nl();
            txtFace += "Faces_End:" + VbX.nl();
            txtLine += "Lines_End:" + VbX.nl();
            txtDest.Text = txtVert + VbX.nl() + txtFace + VbX.nl() + txtLine + VbX.nl();
            // tabControl1.SelectedTab = tabPage2;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            openFileDialog1.Filter = "Objects|*.obj";

            DialogResult result = openFileDialog1.ShowDialog(); // Show the dialog.
            if (result == DialogResult.OK) // Test result.
            {
                txtSource.Text= openFileDialog1.FileName;
            }
        }
    }
}
