#include <iostream>
#include <fstream>
#include <string.h>
using namespace std;

int main(int argc, char* argv[])
{
    if (argc<3){
    cout << "Usage:" << endl;
    cout << "  PlusThreeHeader [InFile] [OutFile]" << endl;

    return 0;

    }
    cout << "PlusThreeHeader" << endl;
    std::cout << "File:" << argv[1]<< std::endl;
//    std::cout << "ExecutePos:" << argv[2]<< std::endl;

    char x='x';
    char check=123;
    streampos begin,end;
    ifstream infile;
    infile.open(argv[1], ios::binary | ios::in);
    int bytecount=0;

    do{
        infile.read(&x, sizeof(char)); // reads 7 bytes into a cell that is either 2 or 4

       if (!infile.eof()) {
         bytecount++;
       }
    } while  (!infile.eof());

    //infile.seekg (0, ios::end);


    infile.close();
    infile.open(argv[1], ios::binary | ios::in);
    ofstream outfile;
    outfile.open(argv[2], ios::binary | ios::out);


    outfile.write("PLUS3DOS", sizeof(char)*8);	//Header
    x=26;    outfile.write(&x, sizeof(char));	//EOF
    x=1;     outfile.write(&x, sizeof(char));	// Issue num
    x=0;     outfile.write(&x, sizeof(char));	// Ver
    int thislen=bytecount+128;
    x=thislen%256;     outfile.write(&x, sizeof(char));check=check+x;	//Lenth
    x=thislen/256;     outfile.write(&x, sizeof(char));check=check+x;
    x=0;     outfile.write(&x, sizeof(char));							//Basic Header
    x=0;     outfile.write(&x, sizeof(char));
    x=3;     outfile.write(&x, sizeof(char));
    thislen=bytecount;
    x=thislen%256;     outfile.write(&x, sizeof(char));check=check+x;
    x=thislen/256;     outfile.write(&x, sizeof(char));check=check+x;
    x=0;     outfile.write(&x, sizeof(char));
    x=128;     outfile.write(&x, sizeof(char));
    x=0;     outfile.write(&x, sizeof(char));
    x=128;     outfile.write(&x, sizeof(char));
    for (int i=0;i<105;i++){
        x=0;     outfile.write(&x, sizeof(char));

    }
    x=check;     outfile.write(&x, sizeof(char));						// Checksum of header
    do {
        infile.read(&x, sizeof(char)); // reads 7 bytes into a cell that is either 2 or 4
       if (!infile.eof()) outfile.write(&x, sizeof(char)); // sizeof can take a type
    } while (!infile.eof());
    infile.close();
    outfile.close();
return 0;




}
