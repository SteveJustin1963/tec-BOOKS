﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Aks2CBT
{
    public partial class Form1 : Form
    {
        public int[] NoteLut = { 0, 1, 2, 3, 4, 6, 7, 8, 9, 10, 11, 12 };
        public Form1()
        {
            InitializeComponent();


            int MaxPat = 0;
            String result="";
            String Cpat0="";
            String Cpat1="";
            String Cpat2="";
            String Patterns="";
            int cmdlen = 0;
            int effect = 0;
            int state=0;
            System.IO.StreamReader sr = new System.IO.StreamReader("F:\\Progs\\Aks2CBT\\Aks2CBT\\test.asm");
                        while (sr.Peek() >= 0)
                        {
                            String lin = sr.ReadLine().Trim();
                            if (lin.StartsWith("Main_Subsong0_Track")) {

                                string pnum=lin.Replace("Main_Subsong0_Track", "");
                                if (VbX.CInt(pnum) > MaxPat){
                                    Patterns += "    db 1,&10" + VbX.Chr(13) + VbX.Chr(10);
                                    MaxPat = VbX.CInt(pnum);
                             
                                }
                                state = 1; Patterns += VbX.Chr(13) + VbX.Chr(10)+"Pattern"+pnum+":" +VbX.Chr(13) + VbX.Chr(10); }

                            if (lin.Contains("; SpeedTracks")) state = 0;

                            if (state == 1) { 
                                    if (lin.Contains("; Instrument.")){
                                        Patterns = Patterns + " ,Cmd_Inst,Ins" + ConvNote(VbX.CInt(lin.Replace("; Instrument.", "").Replace("db ", "").Trim()));

                                }

                                    if (lin.Contains("; Effect number"))
                                    {
                                        effect = VbX.CInt(lin.Substring(0, VbX.InStr(lin, ";") - 1).Replace("db", "").Trim());

                                    }
                                    if (lin.Contains("; Effect value"))
                                    {
                                        if (effect == 5)
                                        {
                                            int vol = VbX.CInt(lin.Substring(0, VbX.InStr(lin, ";") - 1).Replace("dw", "").Trim()) / 16;
                                            Patterns = Patterns + ", Cmd_Volu," + vol.ToString();
                                        }
                                    }
                                if (lin.Contains("; No note.")){
                                    Patterns = Patterns + "    db 1*MSpd";
                                    cmdlen = 1;
                                }
                                if (lin.Contains("; Note.")){
                                    Patterns = Patterns + "    db 1*MSpd, Cmd_Note," + ConvNote(VbX.CInt(lin.Replace("; Note.", "").Replace("db ", "").Trim()));
                                    cmdlen = 1;
                                }
                                if (lin.Contains("db 0	; End of effects.")){
                                   if (cmdlen >0) Patterns = Patterns + ",0" + VbX.Chr(13) + VbX.Chr(10);
                                }
                                if (lin.Contains("empty cells."))
                                {
                                    int time = VbX.CInt(lin.Substring(0, VbX.InStr(lin, ";") - 1).Replace("db", "").Trim())-127;
                                    Patterns = Patterns + "    db "+time.ToString()+"*MSpd, 0" + VbX.Chr(13) + VbX.Chr(10);
                                    cmdlen = 0;
                                }
                                
                            }
                            if (lin.Contains("; Pattern ")){
                                lin = sr.ReadLine().Trim();
                                string t0 = ss.GetItem(lin, 0).Replace("dw Main_Subsong0_Track", "").Trim();
                                string t1 = ss.GetItem(lin, 1).Replace("Main_Subsong0_Track", "").Trim();
                                string t2 = ss.GetItem(lin, 2).Replace("Main_Subsong0_Track", "").Trim();
                                if (Cpat0.Length == 0) Cpat0 += "    db " + t0; else Cpat0 += "," + t0;
                                if (Cpat1.Length == 0) Cpat1 += "    db " + t1; else Cpat1 += "," + t1;
                                if (Cpat2.Length == 0) Cpat2 += "    db " + t2; else Cpat2 += "," + t2;

                                

                            }
                        }

                    

                        sr.Close();

                        textBox1.Text += "SongBase:" + VbX.Chr(13) + VbX.Chr(10) ;
                        textBox1.Text += "	dw SongSequence_0"+VbX.Chr(13)+VbX.Chr(10);
                        textBox1.Text += "	dw SongSequence_1" + VbX.Chr(13) + VbX.Chr(10);
                        textBox1.Text += "	dw SongSequence_2" + VbX.Chr(13) + VbX.Chr(10); 
                        textBox1.Text += VbX.Chr(13) + VbX.Chr(10);

                        textBox1.Text += "SongSequence_0:"+VbX.Chr(13)+VbX.Chr(10)+Cpat0+VbX.Chr(13)+VbX.Chr(10);
                        textBox1.Text += "SongSequence_1:" + VbX.Chr(13) + VbX.Chr(10) + Cpat1 + VbX.Chr(13) + VbX.Chr(10);
                        textBox1.Text += "SongSequence_2:" + VbX.Chr(13) + VbX.Chr(10) + Cpat2 + VbX.Chr(13) + VbX.Chr(10);

                        Patterns += "    db 1,&10" + VbX.Chr(13) + VbX.Chr(10);

                        textBox1.Text += Patterns + VbX.Chr(13) + VbX.Chr(10);

                        textBox1.Text += "PatternList:" + VbX.Chr(13) + VbX.Chr(10);
                        for (int i = 0; i <= MaxPat; i++) {
                            textBox1.Text += "    dw Pattern"+i.ToString() + VbX.Chr(13) + VbX.Chr(10);
                        }


        }
        int ConvNote(int src)
        {
            
            int oct = src / 12;
            int note = src % 12;
            int c = oct * 14 + NoteLut[note];
          
            return c;
        }
    }
}
