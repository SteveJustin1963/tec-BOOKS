﻿using System;
using System.Collections.Generic;

using System.Text;

using System.Windows.Forms;
    //Fake Visual Basic eXtensions
   public static class VbX
    {
       // objects we need to do the work
       private static Random VbXrnd= new Random();
       public static string nz(string nz) { if (nz == null) return ""; return nz; }
       
       public static String nl(){
        return VbX.Chr(13) + VbX.Chr(10);
   }
           
       public static String InputBox(String title,String promptText, String value) {
           Form form = new Form();
           Label label = new Label();
           TextBox textBox = new TextBox();
           Button buttonOk = new Button();
           Button buttonCancel = new Button();

           form.Text = title;
           label.Text = promptText;
           textBox.Text = value;
           if ((textBox.Text.ToLower())=="null") textBox.Visible=false;
           

           buttonOk.Text = "OK";
           buttonCancel.Text = "Cancel";

           if ((textBox.Text.ToLower()) == "yes/no")
           {
               textBox.Visible = false; buttonOk.Text = "Yes";
               buttonCancel.Text = "No";
           }

           buttonOk.DialogResult = DialogResult.OK;
           buttonCancel.DialogResult = DialogResult.Cancel;

           label.SetBounds(9, 20, 372, 13);
           textBox.SetBounds(12, 36, 372, 20);
           buttonOk.SetBounds(228, 72, 75, 23);
           buttonCancel.SetBounds(309, 72, 75, 23);

           label.AutoSize = true;
           textBox.Anchor = textBox.Anchor | AnchorStyles.Right;
           buttonOk.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
           buttonCancel.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;

           form.ClientSize = new System.Drawing.Size(396, 107);
           form.Controls.AddRange(new Control[] { label, textBox, buttonOk, buttonCancel });
           form.ClientSize = new System.Drawing.Size(Math.Max(300, label.Right + 10), form.ClientSize.Height);
           form.FormBorderStyle = FormBorderStyle.FixedDialog;
           form.StartPosition = FormStartPosition.CenterScreen;
           form.MinimizeBox = false;
           form.MaximizeBox = false;
           form.AcceptButton = buttonOk;
           form.CancelButton = buttonCancel;

           DialogResult dialogResult = form.ShowDialog();
           if ((textBox.Text.ToLower()) == "yes/no") {
               
               if (dialogResult == DialogResult.OK) return "*yes*";
               return "*no*";
           }
           
           return textBox.Text;
       }
       public static string NoCaseReplace(string haystack,string needle1,string needle2) { 
           // case insensitive replace - result is same case as before, but needle1 matches anything
           haystack=haystack.Replace(needle1, needle2); // try a basic replace first
           int pos=0;
           do
           {
               pos = InStr(haystack.ToLower(), needle1.ToLower());
               if (pos>0) haystack = Left(haystack, pos - 1) + needle2 + Mid(haystack,pos + needle1.Length, haystack.Length - (pos + needle1.Length-1));
               
           } while (pos > 0);
           return haystack;
       }

       public static int Bin2Dec(string bin) {
           return Convert.ToInt32(bin, 2);
       }
       public static string Dec2Oct8Bit(int dec) {
            return Right("00000000"+Convert.ToString(dec, 8),3);
       }
       public static String Dec2Bin8Bit(int dec) {
           return Right("00000000"+Convert.ToString(dec, 2),8);
       }
       public static string Dec2Oct16Bit(int dec)
       {
           return Right("00000000" + Convert.ToString(dec, 8), 6);
       }
       public static String Dec2Bin16Bit(int dec)
       {
           return Right("0000000000000000" + Convert.ToString(dec, 2), 16);
       }
       public static int Hex2Dec(string hex)
       {
           if (Left(hex,1)=="&") hex=Right(hex,Len(hex)-1);
           return int.Parse(hex, System.Globalization.NumberStyles.HexNumber);
       }

       public static string Dec2Hex(int dec) {
          return dec.ToString("X");
       }
       public static string Dec2Hex8bit(int dec)
       {
           return Right("00"+dec.ToString("X"),2);
       }
       public static string Hex(int dec)
       {
           return Dec2Hex(dec);
       }
       // Functions and subs which fake VB.Net functionality
       public static String ChrW(int lin) { 
           if (lin<=0) return "";
           
           return Char.ConvertFromUtf32(lin); }
       //public static void Beep() { Console.Beep(); }
       public static int AscW(String lin) {
          // try
          // {
           if (lin.Length==0) return 0;
           Char[] ss           = lin.Substring(0, 1).ToCharArray();

               return ((int)ss[0]);
           //}
          // catch (Exception ex) { }
           //return 0;
       }



       public static void Randomize() { VbXrnd = new Random(); }
        public static string Chr(int num) { char ch = (char)(num); return ch.ToString(); }
        public static int Len(String Lin) { return Lin.Length; }
        public static string Mid(String Lin, int Start, int len) { if (len < 1) return ""; else return Lin.Substring(Start - 1, len); }
        public static string Right(String Lin, int len) {
            if (len <= 0) return "";
            if (string.IsNullOrEmpty(Lin)) return "";
            if (Lin.Length <= len) return Lin; else return Lin.Substring(Lin.Length - len); 
        }
        public static int InStr(String Lin, String Lin2) { return Lin.IndexOf(Lin2)+1; }
        public static string Replace(String lin, String Lin2, String Lin3) {
            if (string.IsNullOrEmpty(lin)) return "";
            if (lin.Length > 0 && Lin2.Length>0) return lin.Replace(Lin2, Lin3); else return ""; }
        public static bool StringGT(String lin1, String lin2) {
            // is string1 > String2 ?
            int minlen = lin1.Length;
            if (lin2.Length < minlen) minlen = lin2.Length;

            for (int i=0;i<minlen;i++){
                if (AscW(lin1.Substring(i, 1)) > AscW(lin2.Substring(i, 1))) return true;
                if (AscW(lin1.Substring(i, 1)) < AscW(lin2.Substring(i, 1))) return false;
            }
            if (lin1.Length<lin2.Length) return true;
            return false;
        }
        public static string SafeSub(string lin, int from, int len) {
            if (len<=0) return "";      // no length
            if (lin.Length==0) return ""; // no source string
            if (from>=lin.Length) return ""; // startpoint after end of string 
            if (from <0) return ""; // before end of string 
            if (from + len > lin.Length) len = lin.Length - from;
            return lin.Substring(from, len);
        }
        public static string Left( string value, int maxLength)
        {
            if (maxLength <= 0) return "";
            if (string.IsNullOrEmpty(value)) return value;
            maxLength = Math.Abs(maxLength);

            return (value.Length <= maxLength
                   ? value
                   : value.Substring(0, maxLength)
                   );
        }
        //public static String Environ(String lin) { return System.Environment.GetEnvironmentVariable(lin); }
        public static String CurDir() {
            return System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
        }
        public static char[] CChar(string lin) { return lin.ToCharArray(); }
        public static string LCase(string lin) { return lin.ToLower(); }
        public static string Trim(string lin) { return lin.Trim(); }

       // this is an incomplete version - Dir should allow a folder to be listed item by item, but this does not.
        public static String Dir(string lin) {

            String file = System.IO.Path.GetFileName(lin);
            String path = System.IO.Path.GetDirectoryName(lin);
            string[] files = System.IO.Directory.GetFiles(path, file, System.IO.SearchOption.TopDirectoryOnly);
            if (files.Length > 0)
            {
                return lin;
            } else {
                return "";
            }


            //if (lnx.exists(lin)) return lin; else return ""; 
        }

       
        public static void Kill(String lin) { System.IO.File.Delete(lin); }
        public static void Rename(String File1,String File2) { System.IO.File.Move(File1,File2); }
        public static void doMessageBox(String lin) { System.Diagnostics.Debug.Write(lin); }
        public static void MsgBox(String lin)
        {

            InputBox("MsgBox", lin, "null");

            // System.Diagnostics.Debug.Write(lin);

        }
        //public static String Format(object obj, String lin) {return String.Format(lin, obj); }
        public static bool CBool(string lin) { if (lin.Trim() == "1" || lin.Trim().ToLower() == "true") return true; else return false; }
        public static int CInt(string lin) {
            if (Left(lin, 1) == "&") {
                return Hex2Dec(lin);
            }

            if (lin.Length== 0) return 0;
            int a=0;
            if (Int32.TryParse(lin,out a))  return int.Parse(lin);  else return 0; }
        public static int CInt(double lin) { return (int)(lin); }
        public static string CStr(double lin) { return (lin.ToString()); }
        public static int Val(string Lin) { 
            return int.Parse(Lin); } 
        public static double CDbl(string Lin) {
            double a;
            if (Double.TryParse(Lin,out a)) return double.Parse(Lin); else return 0;
        }
        public static string LTrim(string lin) { return lin.TrimStart(); }
        public static string RTrim(string lin) { return lin.TrimEnd(); }
        //public static void NCoreLogfileMessage(String lin, int num) {if (num>5){System.Diagnostics.Debug.Write(lin);} }
        public static double Rnd() {  return VbXrnd.NextDouble();
        }
    }

