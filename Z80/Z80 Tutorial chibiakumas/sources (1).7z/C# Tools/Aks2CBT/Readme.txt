This is an experimental converter, it converts songs exported with Arkostracker 2 in RAW AKR format into ChibiTrack format ASM

This is for my Work In Progress music player.