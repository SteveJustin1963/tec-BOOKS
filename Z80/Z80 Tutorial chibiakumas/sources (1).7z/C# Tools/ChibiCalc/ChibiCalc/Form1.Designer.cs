﻿namespace ChibiCalc
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtDecimal = new System.Windows.Forms.TextBox();
            this.txtHex = new System.Windows.Forms.TextBox();
            this.lblDec = new System.Windows.Forms.Label();
            this.lblHex = new System.Windows.Forms.Label();
            this.lblBin = new System.Windows.Forms.Label();
            this.txtBinary = new System.Windows.Forms.TextBox();
            this.lbloct = new System.Windows.Forms.Label();
            this.txtOctal = new System.Windows.Forms.TextBox();
            this.lblasc = new System.Windows.Forms.Label();
            this.txtAscii = new System.Windows.Forms.TextBox();
            this.lblHex2 = new System.Windows.Forms.Label();
            this.lblbin2 = new System.Windows.Forms.Label();
            this.lbloct2 = new System.Windows.Forms.Label();
            this.lblcommand = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtDecimal
            // 
            this.txtDecimal.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDecimal.BackColor = System.Drawing.Color.Black;
            this.txtDecimal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDecimal.Font = new System.Drawing.Font("Crystal", 26.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDecimal.ForeColor = System.Drawing.Color.Lime;
            this.txtDecimal.Location = new System.Drawing.Point(48, 12);
            this.txtDecimal.Name = "txtDecimal";
            this.txtDecimal.Size = new System.Drawing.Size(291, 42);
            this.txtDecimal.TabIndex = 0;
            this.txtDecimal.Text = "12345 ABC";
            this.txtDecimal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDecimal.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtDecimal_KeyUp);
            this.txtDecimal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDecimal_KeyPress);
            // 
            // txtHex
            // 
            this.txtHex.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtHex.BackColor = System.Drawing.Color.Black;
            this.txtHex.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtHex.Font = new System.Drawing.Font("Crystal", 26.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHex.ForeColor = System.Drawing.Color.Red;
            this.txtHex.Location = new System.Drawing.Point(48, 60);
            this.txtHex.Name = "txtHex";
            this.txtHex.Size = new System.Drawing.Size(291, 42);
            this.txtHex.TabIndex = 1;
            this.txtHex.Text = "FFFFFFFFFFFFFFFF";
            this.txtHex.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtHex.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtHex_KeyUp);
            this.txtHex.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtHex_KeyPress);
            // 
            // lblDec
            // 
            this.lblDec.AutoSize = true;
            this.lblDec.Font = new System.Drawing.Font("Crystal", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDec.ForeColor = System.Drawing.Color.Lime;
            this.lblDec.Location = new System.Drawing.Point(9, 12);
            this.lblDec.Name = "lblDec";
            this.lblDec.Size = new System.Drawing.Size(33, 16);
            this.lblDec.TabIndex = 2;
            this.lblDec.Text = "DEC:";
            // 
            // lblHex
            // 
            this.lblHex.AutoSize = true;
            this.lblHex.Font = new System.Drawing.Font("Crystal", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHex.ForeColor = System.Drawing.Color.Red;
            this.lblHex.Location = new System.Drawing.Point(9, 60);
            this.lblHex.Name = "lblHex";
            this.lblHex.Size = new System.Drawing.Size(33, 16);
            this.lblHex.TabIndex = 3;
            this.lblHex.Text = "HEX:";
            this.lblHex.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblBin
            // 
            this.lblBin.AutoSize = true;
            this.lblBin.Font = new System.Drawing.Font("Crystal", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBin.ForeColor = System.Drawing.Color.Red;
            this.lblBin.Location = new System.Drawing.Point(9, 120);
            this.lblBin.Name = "lblBin";
            this.lblBin.Size = new System.Drawing.Size(30, 16);
            this.lblBin.TabIndex = 5;
            this.lblBin.Text = "BIN:";
            // 
            // txtBinary
            // 
            this.txtBinary.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBinary.BackColor = System.Drawing.Color.Black;
            this.txtBinary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBinary.Font = new System.Drawing.Font("Crystal", 26.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBinary.ForeColor = System.Drawing.Color.Red;
            this.txtBinary.Location = new System.Drawing.Point(48, 120);
            this.txtBinary.Name = "txtBinary";
            this.txtBinary.Size = new System.Drawing.Size(291, 42);
            this.txtBinary.TabIndex = 4;
            this.txtBinary.Text = "11111111111111111111111111111111";
            this.txtBinary.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtBinary.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtBinary_KeyUp);
            this.txtBinary.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBinary_KeyPress);
            // 
            // lbloct
            // 
            this.lbloct.AutoSize = true;
            this.lbloct.Font = new System.Drawing.Font("Crystal", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbloct.ForeColor = System.Drawing.Color.Red;
            this.lbloct.Location = new System.Drawing.Point(9, 182);
            this.lbloct.Name = "lbloct";
            this.lbloct.Size = new System.Drawing.Size(33, 16);
            this.lbloct.TabIndex = 7;
            this.lbloct.Text = "OCT:";
            // 
            // txtOctal
            // 
            this.txtOctal.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOctal.BackColor = System.Drawing.Color.Black;
            this.txtOctal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtOctal.Font = new System.Drawing.Font("Crystal", 26.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOctal.ForeColor = System.Drawing.Color.Red;
            this.txtOctal.Location = new System.Drawing.Point(48, 182);
            this.txtOctal.Name = "txtOctal";
            this.txtOctal.Size = new System.Drawing.Size(291, 42);
            this.txtOctal.TabIndex = 6;
            this.txtOctal.Text = "7777777777777777";
            this.txtOctal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtOctal.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtOctal_KeyUp);
            this.txtOctal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOctal_KeyPress);
            // 
            // lblasc
            // 
            this.lblasc.AutoSize = true;
            this.lblasc.Font = new System.Drawing.Font("Crystal", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblasc.ForeColor = System.Drawing.Color.Red;
            this.lblasc.Location = new System.Drawing.Point(9, 241);
            this.lblasc.Name = "lblasc";
            this.lblasc.Size = new System.Drawing.Size(34, 16);
            this.lblasc.TabIndex = 9;
            this.lblasc.Text = "ASC:";
            // 
            // txtAscii
            // 
            this.txtAscii.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAscii.BackColor = System.Drawing.Color.Black;
            this.txtAscii.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAscii.Font = new System.Drawing.Font("MS PGothic", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAscii.ForeColor = System.Drawing.Color.Red;
            this.txtAscii.Location = new System.Drawing.Point(48, 241);
            this.txtAscii.Name = "txtAscii";
            this.txtAscii.Size = new System.Drawing.Size(291, 42);
            this.txtAscii.TabIndex = 8;
            this.txtAscii.Text = "FFFFFFFFFFFFFFFF";
            this.txtAscii.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAscii.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtAscii_KeyUp);
            this.txtAscii.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAscii_KeyPress);
            // 
            // lblHex2
            // 
            this.lblHex2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHex2.Font = new System.Drawing.Font("Crystal", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHex2.ForeColor = System.Drawing.Color.DarkRed;
            this.lblHex2.Location = new System.Drawing.Point(-142, 105);
            this.lblHex2.Name = "lblHex2";
            this.lblHex2.Size = new System.Drawing.Size(483, 15);
            this.lblHex2.TabIndex = 10;
            this.lblHex2.Text = "63                                       31                 15        7         0" +
                "";
            this.lblHex2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.lblHex2.Click += new System.EventHandler(this.label6_Click);
            // 
            // lblbin2
            // 
            this.lblbin2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblbin2.Font = new System.Drawing.Font("Crystal", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbin2.ForeColor = System.Drawing.Color.DarkRed;
            this.lblbin2.Location = new System.Drawing.Point(-290, 165);
            this.lblbin2.Name = "lblbin2";
            this.lblbin2.Size = new System.Drawing.Size(629, 10);
            this.lblbin2.TabIndex = 11;
            this.lblbin2.Text = "31                                                                               " +
                "              15                                              7                 " +
                "                          0";
            this.lblbin2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.lblbin2.Click += new System.EventHandler(this.label7_Click);
            // 
            // lbloct2
            // 
            this.lbloct2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbloct2.Font = new System.Drawing.Font("Crystal", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbloct2.ForeColor = System.Drawing.Color.DarkRed;
            this.lbloct2.Location = new System.Drawing.Point(-157, 227);
            this.lbloct2.Name = "lbloct2";
            this.lbloct2.Size = new System.Drawing.Size(499, 15);
            this.lbloct2.TabIndex = 12;
            this.lbloct2.Text = "47                                            23                     11        5 " +
                "        0";
            this.lbloct2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblcommand
            // 
            this.lblcommand.AutoSize = true;
            this.lblcommand.Font = new System.Drawing.Font("Arial", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcommand.ForeColor = System.Drawing.Color.Cyan;
            this.lblcommand.Location = new System.Drawing.Point(340, 0);
            this.lblcommand.Name = "lblcommand";
            this.lblcommand.Size = new System.Drawing.Size(37, 40);
            this.lblcommand.TabIndex = 13;
            this.lblcommand.Text = "=";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(378, 289);
            this.Controls.Add(this.lblcommand);
            this.Controls.Add(this.lbloct2);
            this.Controls.Add(this.lblbin2);
            this.Controls.Add(this.lblHex2);
            this.Controls.Add(this.lblasc);
            this.Controls.Add(this.txtAscii);
            this.Controls.Add(this.lbloct);
            this.Controls.Add(this.txtOctal);
            this.Controls.Add(this.lblBin);
            this.Controls.Add(this.txtBinary);
            this.Controls.Add(this.lblHex);
            this.Controls.Add(this.lblDec);
            this.Controls.Add(this.txtHex);
            this.Controls.Add(this.txtDecimal);
            this.Name = "Form1";
            this.Text = "ChibiCalc!";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtDecimal;
        private System.Windows.Forms.TextBox txtHex;
        private System.Windows.Forms.Label lblDec;
        private System.Windows.Forms.Label lblHex;
        private System.Windows.Forms.Label lblBin;
        private System.Windows.Forms.TextBox txtBinary;
        private System.Windows.Forms.Label lbloct;
        private System.Windows.Forms.TextBox txtOctal;
        private System.Windows.Forms.Label lblasc;
        private System.Windows.Forms.TextBox txtAscii;
        private System.Windows.Forms.Label lblbin2;
        private System.Windows.Forms.Label lbloct2;
        private System.Windows.Forms.Label lblHex2;
        private System.Windows.Forms.Label lblcommand;
    }
}

