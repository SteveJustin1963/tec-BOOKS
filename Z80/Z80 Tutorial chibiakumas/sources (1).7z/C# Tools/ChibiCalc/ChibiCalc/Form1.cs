﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ChibiCalc
{
    public partial class Form1 : Form
    {
        long lastparam = 0;
        public Form1()
        {
            InitializeComponent();
            SetAll(0, null);
            txtDecimal.SelectionStart = 1;
            txtDecimal.SelectionLength = 0;
            lblcommand.Text = "";
        }

        private void txtDecimal_KeyUp(object sender, KeyEventArgs e)
        {
            long Val=VbX.CInt(txtDecimal.Text);
            SetAll(Val,sender);
         
        }
        private void sethighlight(object sender ) {
            txtDecimal.ForeColor = Color.Red;
            lblDec.ForeColor = Color.Red;


            txtHex.ForeColor = Color.Red;
            lblHex.ForeColor = Color.Red;
            lblHex2.ForeColor = Color.DarkRed;


            txtBinary.ForeColor = Color.Red;
            lblBin.ForeColor = Color.Red;
            lblbin2.ForeColor = Color.DarkRed;

            txtAscii.ForeColor = Color.Red;
            lblasc.ForeColor = Color.Red;

            txtOctal.ForeColor = Color.Red;
            lbloct.ForeColor = Color.Red;
            lbloct2.ForeColor = Color.DarkRed;
            

            if (sender == txtDecimal) {
                txtDecimal.ForeColor = Color.Lime;
                lblDec.ForeColor = Color.Lime;

            }

            if (sender == txtHex)
            {

                txtHex.ForeColor = Color.Lime;
                lblHex.ForeColor = Color.Lime;
                lblHex2.ForeColor = Color.Green;


            }

            if (sender == txtBinary) {

                txtBinary.ForeColor = Color.Lime;
                lblBin.ForeColor = Color.Lime;
                lblbin2.ForeColor = Color.Green;

            }
            if (sender == txtAscii) {
                txtAscii.ForeColor = Color.Lime;
                lblasc.ForeColor = Color.Lime;

            }
            if (sender == txtOctal) {

                txtOctal.ForeColor = Color.Lime;
                lbloct.ForeColor = Color.Lime;
                lbloct2.ForeColor = Color.Green;
            }
        }
        private void SetAll(long decval, object sender) {
            
            if (sender!=txtDecimal) txtDecimal.Text = VbX.CStr(decval);
            if (sender != txtHex) txtHex.Text = VbX.Hex(decval);
            if (sender != txtOctal) txtOctal.Text = VbX.Dec2Oct(decval);
            if (sender != txtBinary) txtBinary.Text = VbX.Dec2Bin(decval);
            if (sender != txtAscii) txtAscii.Text = VbX.ChrW((int)decval);
            if (sender != null)
            {
                sethighlight(sender);
            }
        }

        private void txtHex_KeyPress(object sender, KeyPressEventArgs e)
        {
            string kc = VbX.UCase(e.KeyChar.ToString());
            if (e.KeyChar == 13) kc = "=";
            if (e.KeyChar < 32 && e.KeyChar != 13) return;

            if (((TextBox)sender).Text == "0") ((TextBox)sender).Text = "";
            if (processCommand(kc, sender) == true) e.Handled = true;
            if (VbX.InStr("1234567890ABCDEF",kc)==0) kc="";

            if (kc.Length == 0) { e.KeyChar = (char)(0); e.Handled = true; } else e.KeyChar = kc.ToCharArray()[0];
            
        }
        private void reset() {
            SetAll(0, null);
            lblcommand.Text = "";
            lastparam = 0;
        }
        private void txtDecimal_KeyPress(object sender, KeyPressEventArgs e)
        {
            string kc = VbX.UCase(e.KeyChar.ToString());
            if (e.KeyChar == 13) kc = "=";
            if (e.KeyChar == 27) { reset(); return; }
            if (e.KeyChar < 32 && e.KeyChar != 13) return;

            if (((TextBox)sender).Text == "0") ((TextBox)sender).Text = "";
            if (processCommand(kc, sender) == true) e.Handled = true;

            if (VbX.InStr("-1234567890", kc) == 0) kc = "";
            

            if (kc.Length == 0) { e.KeyChar = (char)(0); e.Handled = true; } else e.KeyChar = kc.ToCharArray()[0];
        }

        private bool processCommand(string lin,object sender){
            if (lin == "+" || lin == "-" || lin == "*" || lin == "/" || lin == "%" || lin == "<" || lin == ">" || lin == "&" || lin == "|" || lin == "^" || lin == "l")
            {

                if (lblcommand.Text!=""){
                    DoMaths();
                }
                if (lin=="&") lin="&&";
                lblcommand.Text = lin;
                lastparam = VbX.CInt(txtDecimal.Text);
                SetAll(0, null);
                return true;
            }
            if (lin == "=")
            {
                if (lblcommand.Text != "")
                {
                    DoMaths();
                }
                lblcommand.Text = lin;
                
                return true;
            }

            if (lin == "[")
            {
                SetAll(VbX.CInt(txtDecimal.Text)*2, null);
                return true;
            }
            if (lin == "[")
            {
                SetAll(VbX.CInt(txtDecimal.Text) * 2, null);
                return true;
            }
            if (lin == "_")
            {
                SetAll(-VbX.CInt(txtDecimal.Text), null);
                return true;
            }
            if (lin == "!")
            {
                SetAll(-VbX.CInt(txtDecimal.Text)-1, null);
                return true;
            }

            if (lblcommand.Text == "=") { lblcommand.Text = ""; }
            return false;
        }
        private void DoMaths(){
            long param=VbX.CInt(txtDecimal.Text);
            if (lblcommand.Text=="+"){
                SetAll(param+lastparam, null);
            }
            if (lblcommand.Text == "-")
            {
                SetAll(lastparam-param, null);
            }
            if (lblcommand.Text == "*")
            {
                SetAll(param * lastparam, null);
            }
            if (lblcommand.Text == "/")
            {
                SetAll(lastparam /param  , null);
            }
            if (lblcommand.Text == "%")
            {
                SetAll(lastparam%param, null);
            }
            if (lblcommand.Text == ">")
            {
                SetAll(lastparam >> (int)param, null);
            }
            if (lblcommand.Text == "<")
            {
                SetAll(lastparam << (int)param, null);
            }
            if (lblcommand.Text == "&&")
            {
                SetAll(lastparam & param, null);
            }
            if (lblcommand.Text == "|")
            {
                SetAll(lastparam | param, null);
            }
            if (lblcommand.Text == "^")
            {
                SetAll(lastparam ^ param, null);
            }
            
        }
        private void txtBinary_KeyPress(object sender, KeyPressEventArgs e)
        {
            string kc = VbX.UCase(e.KeyChar.ToString());
            if (e.KeyChar == 13) kc = "=";
            if (e.KeyChar < 32 && e.KeyChar != 13) return;

            if (((TextBox)sender).Text == "0") ((TextBox)sender).Text = "";
            if (processCommand(kc, sender) == true) e.Handled = true;
            if (VbX.InStr("10", kc) == 0) kc = "";

            if (kc.Length == 0) { e.KeyChar = (char)(0); e.Handled = true; } else e.KeyChar = kc.ToCharArray()[0];
        }

        private void txtOctal_KeyPress(object sender, KeyPressEventArgs e)
        {
            string kc = VbX.UCase(e.KeyChar.ToString());
            if (e.KeyChar == 13) kc = "=";
            if (e.KeyChar < 32 && e.KeyChar != 13) return;

            if (((TextBox)sender).Text == "0") ((TextBox)sender).Text = "";
            if (processCommand(kc, sender) == true) e.Handled = true;
            if (VbX.InStr("01234567", kc) == 0) kc = "";

            if (kc.Length == 0) { e.KeyChar = (char)(0); e.Handled = true; } else e.KeyChar = kc.ToCharArray()[0];
        }

        private void txtAscii_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtAscii.Text = "";
        }

        private void txtAscii_KeyUp(object sender, KeyEventArgs e)
        {
            int Val = VbX.AscW(txtAscii.Text);
            SetAll(Val, sender);
        }

        private void txtBinary_KeyUp(object sender, KeyEventArgs e)
        {
            int Val = VbX.Bin2Dec(txtBinary.Text);
            SetAll(Val, sender);
        }

        private void txtOctal_KeyUp(object sender, KeyEventArgs e)
        {
            int Val = VbX.Oct2Dec(txtOctal.Text);
            SetAll(Val, sender);
        }

        private void txtHex_KeyUp(object sender, KeyEventArgs e)
        {
            long Val = VbX.Hex2Dec(txtHex.Text);
            SetAll(Val, sender);
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }



    }
}
