﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length == 0)
            {
                usage();
            } else {
                switch (VbX.LCase(args[0]))
                {
                    case "insert":
                        insert(args);
                        break;
                    case "checksum":
                        checksum(args);
                        break;
                    case "fill":
                        fill(args, false);
                        break;
                    case "fill16":
                        fill(args, true);
                        break;
                    case "value16":
                        value(args,"16");
                        break;
                    case "value32":
                        value(args, "32");
                        break;
                    case "value16be":
                        value(args,"16b");
                        break;
                    case "value32be":
                        value(args, "32b");
                        break;
                    case "bytes":
                        bytes(args);
                        break;
                    case "align":
                        align(args);
                        break;
                    default:
                        usage();
                        break;
                }
            }
#if DEBUG
            Console.ReadLine();
#endif  
        }
        static void usage() {
            Console.WriteLine("Binary Tools... File Hacker!");
            Console.WriteLine("Usage:");
            Console.WriteLine("insert [Sourcefile] [start] [length] [DestFile] [position]");
            Console.WriteLine("checksum [Sourcefile] [start] [length] [DestFile] [position] [ChkFormat]");
            Console.WriteLine("value [attribute] [Sourcefile/SourceVal] [DestFile] [Position] [Operator] [Value] [Operator] [Value]...");
            Console.WriteLine("valueBE [attribute] [Sourcefile/SourceVal] [DestFile] [Position] [Operator] [Value] [Operator] [Value]...");
            Console.WriteLine("Fill [DestFile] [position] [Length] [byte] ");
            Console.WriteLine("Fill16 [DestFile] [position] [Length] [byte] ");
            Console.WriteLine("Bytes [DestFile] [position] [byte] [byte]...");
            Console.WriteLine("Align [DestFile] [alignment] [byte]");
            Console.WriteLine("");
            
            Console.WriteLine("Positions 0=first byte ... -1 = File end/length... -2 = 1byte from end");
            Console.WriteLine("ChkFormat [blank] 8bit 16bit comp(liment) comp16");
            Console.WriteLine("attributes length ");
            Console.WriteLine("[Operator Value]... + 3 / 2 ");
            Console.WriteLine("");
            Console.WriteLine("BinaryTools value length test.out test.out 20 / 2 + 1000");
            Console.WriteLine("Fill16 test.bin 100 256 &6932");
            Console.WriteLine("Bytes test.bin 100 &16 &32 &64");
            Console.WriteLine("align out2.bin 32768 &69");
            Console.WriteLine("");
        }
        

        static void align(string[] args)
        {
            //Align [DestFile] [alignment]
            
            int alignment = VbX.CInt(getarg(args, 2));
            string source = getarg(args, 1);
            byte fill = (byte)VbX.CInt(getarg(args, 3));
            
            int EndValue = 0;

            System.IO.BinaryReader BR = new System.IO.BinaryReader(System.IO.File.Open(source, System.IO.FileMode.OpenOrCreate));

            long len = BR.BaseStream.Length;
            BR.Close();

            long currentblocks = len / alignment;
            currentblocks *= alignment;

            if (currentblocks == len)
            {
                Console.WriteLine("Align " + source.ToString() + " Not needed");
                return;
            }
            currentblocks += alignment;
            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(System.IO.File.Open(source, System.IO.FileMode.OpenOrCreate));
            BW.BaseStream.Seek(0, System.IO.SeekOrigin.End);


            long File1Length = currentblocks - len;

            while (File1Length > 0)
            {
                BW.Write(fill);
                File1Length--;

            }
                
            BW.Close();
            Console.WriteLine("Align " + source.ToString() + " to " + currentblocks +" - padding: " +fill.ToString());
        }
        


        static void insert(string[] args)
        {

            long File2Start = VbX.CInt(args[5]);
            String File2 = args[4];


            long File1Length = VbX.CInt(args[3]);
            long File1Start = VbX.CInt(args[2]);
            String File1 = args[1];

            System.IO.BinaryReader BR = new System.IO.BinaryReader(System.IO.File.Open(File1, System.IO.FileMode.OpenOrCreate));
            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(System.IO.File.Open(File2, System.IO.FileMode.OpenOrCreate));

            if (File1Start<0) File1Start = BR.BaseStream.Length+1+File1Start;
            if (File1Length <0) File1Length = (BR.BaseStream.Length)- File1Start;

            if (File2Start < 0) File2Start = BW.BaseStream.Length + 1 + File2Start;
            Console.WriteLine("Copying " + File1Length.ToString() + " bytes from " + File1Start.ToString() + " in " + File1 + " to " + File2Start.ToString()+" in "+File2);

            BW.Seek(0, System.IO.SeekOrigin.Begin);
            BW.Seek((int)File2Start, System.IO.SeekOrigin.Current);


            BR.BaseStream.Seek(0, System.IO.SeekOrigin.Begin);
            BR.BaseStream.Seek((int)File1Start, System.IO.SeekOrigin.Current);

            while (File1Length>0)
            {
                BW.Write(BR.ReadByte());
                File1Length--; 
                
            }
            BR.Close();
            BW.Close();
        }

        static void checksum(string[] args)
        {

            long File2Start = VbX.CInt(args[5]);
            String File2 = args[4];
            string chkformat = "8bit";
            int checksumval=0;
            long File1Length = VbX.CInt(args[3]);
            long File1Start = VbX.CInt(args[2]);

            if (args.Length > 6) chkformat = args[6].ToLower();
            String File1 = args[1];

            System.IO.BinaryReader BR = new System.IO.BinaryReader(System.IO.File.Open(File1, System.IO.FileMode.OpenOrCreate));

            if (File1Start <0) File1Start = BR.BaseStream.Length + 1 + File1Start;
            if (File1Length <0) File1Length = (BR.BaseStream.Length +1+File1Length)- File1Start;

            BR.BaseStream.Seek(0, System.IO.SeekOrigin.Begin);
            BR.BaseStream.Seek((int)File1Start, System.IO.SeekOrigin.Current);

            long File1LengthOld = File1Length;
     
            while (File1Length > 0)
            {
                //BW.Write(BR.ReadByte());#
                if (chkformat == "8bit" || chkformat == "16bit")
                {
                    checksumval = checksumval + BR.ReadByte();
                }
                if (chkformat == "comp" || chkformat == "comp16")
                {
                    checksumval = checksumval - BR.ReadByte()-1;
                }
                File1Length--;

            }

            BR.Close();

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(System.IO.File.Open(File2, System.IO.FileMode.OpenOrCreate));

            if (File2Start < 0) File2Start = BW.BaseStream.Length + 1 + File2Start;
   
            BW.Seek(0, System.IO.SeekOrigin.Begin);
            BW.Seek((int)File2Start, System.IO.SeekOrigin.Current);
            if (chkformat == "8bit" || chkformat == "comp")  { 
                checksumval= checksumval % 256; 
                BW.Write((byte)checksumval); 
            
            }
            if (chkformat == "16bit" || chkformat == "comp16") {
                checksumval = checksumval % 65536;
                BW.Write((ushort)checksumval);
            }
            Console.WriteLine("Checksum=" + checksumval.ToString() + " of " + File1LengthOld.ToString() + " bytes from " + File1Start.ToString() + " in " + File1 + " to " + File2Start.ToString() + " in " + File2);

            BW.Close();
        }


        static void value(string[] args,string myformat)
        {
            // Console.WriteLine("value [attribute] [Sourcefile/SourceVal] [DestFile] [Position] [Operator] [Value]");
            //value length c:\test.out c:\test.out 20 comp
            string attribute = getarg(args, 1);
            string source = getarg(args, 2);

            long File2Start = VbX.CInt(getarg(args, 4));
            String File2 = getarg(args, 3);
            
            int EndValue = 0;
            Console.WriteLine(source);

            System.IO.BinaryReader BR = new System.IO.BinaryReader(System.IO.File.Open(source, System.IO.FileMode.OpenOrCreate));

            EndValue = (int)BR.BaseStream.Length;
            BR.Close();


            for (int i=5;i<args.Length;i+=2){
                string op = getarg(args, i);
                string val2 = getarg(args, i+1);
                EndValue = domaths(EndValue, op, VbX.CInt(val2));
            
            }

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(System.IO.File.Open(File2, System.IO.FileMode.OpenOrCreate));

            BW.Seek(0, System.IO.SeekOrigin.Begin);
            BW.Seek((int)File2Start, System.IO.SeekOrigin.Current);


            if (File2Start < 0) File2Start = BW.BaseStream.Length + 1 + File2Start;
            WriteData(BW, EndValue, myformat);
            // BW.Write((ushort)EndValue);

                Console.WriteLine("WriteValue=" + EndValue.ToString() + "  to Pos " + File2Start.ToString() + " in " + File2);

            BW.Close();
        }

        static void WriteData(System.IO.BinaryWriter BW, int MyValue, string MyFormat)
        {
            switch (MyFormat) {
                case "32b":
                    {
                        byte b;
                        b = (byte)(MyValue / (256 * 256 * 256));
                        MyValue = MyValue - b * (256 * 256 * 256);
                        BW.Write(b);

                        b = (byte)(MyValue / (256 * 256));
                        MyValue = MyValue - b * (256 * 256);
                        BW.Write(b);

                        b = (byte)(MyValue / (256));
                        MyValue = MyValue - b * (256);
                        BW.Write(b);

                        b = (byte)(MyValue % 256);
                        BW.Write(b);
                    }
                    break;
                case "16b":
                    {
                        byte b;
                        b = (byte)(MyValue / 256);
                        BW.Write(b);
                        b = (byte)(MyValue % 256);
                        BW.Write(b);
                    }
                    break;
                case "8b":
                    BW.Write((byte)MyValue);
                    break;
                case "32":
                    BW.Write((UInt32)MyValue);
                    break;
                case "16":
                    BW.Write((ushort)MyValue);
                    break;
                case "8":
                    BW.Write((byte)MyValue);
                    break;
            }
            
        
        }

        static int domaths(int val1, string op, int val2) {
            switch (op) { 
                case "+":
                    val1 = val1 + val2;
                    break;
                case "-":
                    val1 = val1 - val2;
                    break;
                case "*":
                    val1 = val1 * val2;
                    break;
                case "/":
                    val1 = val1 / val2;
                    break;
            }
            return val1;
        }

        static void fill(string[] args, bool bit16)
        {
            // Console.WriteLine("Fill [DestFile] [position] [Length] [byte] ");

            String File2 = args[1];
            long File2Start = VbX.CInt(args[2]);
            long File2Length = VbX.CInt(args[3]);
            byte thisbyte = (byte)VbX.CInt(args[4]);
            ushort thisbyte16 = (ushort)VbX.CInt(args[4]);

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(System.IO.File.Open(File2, System.IO.FileMode.OpenOrCreate));
            
            if (File2Length < 0) File2Length = (BW.BaseStream.Length + 1 + File2Length )- File2Start;
            if (File2Start < 0) File2Start = BW.BaseStream.Length + 1 + File2Start;

            Console.WriteLine("Fill " + File2Length.ToString() + " bytes in " + File2 + " to " + File2Start.ToString() + " with " + thisbyte16.ToString());
            
            BW.Seek(0, System.IO.SeekOrigin.Begin);
            BW.Seek((int)File2Start, System.IO.SeekOrigin.Current);

            while (File2Length > 0)
            {
                if (bit16 == false)
                {
                    BW.Write(thisbyte);
                    File2Length--;
                }
                else {
                    BW.Write(thisbyte16);
                    File2Length--;
                    File2Length--;
                }

            }
            BW.Close();

        }

        static void bytes(string[] args)
        {
            // Console.WriteLine("Fill [DestFile] [position] [nyte] [byte] ");

            String File2 = args[1];
            long File2Start = VbX.CInt(args[2]);
            string nextbyte = args[3];
            int nextbytenum=4;

            System.IO.BinaryWriter BW = new System.IO.BinaryWriter(System.IO.File.Open(File2, System.IO.FileMode.OpenOrCreate));

            if (File2Start < 0) File2Start = BW.BaseStream.Length + 1 + File2Start;
            string bytestring="";
            

            BW.Seek(0, System.IO.SeekOrigin.Begin);
            BW.Seek((int)File2Start, System.IO.SeekOrigin.Current);

            while (nextbyte!= "")
            {
                if (bytestring != "") bytestring += ",";
                bytestring=bytestring+nextbyte.ToString();
                    BW.Write((byte)(VbX.CInt(nextbyte)));
                    nextbyte = getarg(args,nextbytenum);
                nextbytenum++;
                
            }
            BW.Close();
            Console.WriteLine("Bytes " + bytestring+" " + File2 + " to " + File2Start.ToString());

        }
        static string getarg(string[] args, int i) {
            if (args.Length > i) return args[i].ToLower();
            return "";
        }
    }
}
