﻿namespace ChibiTracker
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.timerSong = new System.Windows.Forms.Timer(this.components);
            this.button7 = new System.Windows.Forms.Button();
            this.txtDebug = new System.Windows.Forms.TextBox();
            this.timerUI = new System.Windows.Forms.Timer(this.components);
            this.tabControl14 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.lblPatternchannels3 = new System.Windows.Forms.Label();
            this.lblPatternchannels2 = new System.Windows.Forms.Label();
            this.lblColumntTitles = new System.Windows.Forms.Label();
            this.lblPatternchannels = new System.Windows.Forms.Label();
            this.lstPattern = new System.Windows.Forms.ListBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lstSequence = new System.Windows.Forms.ListBox();
            this.lstInstruments = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.txtInstrument = new System.Windows.Forms.TextBox();
            this.lblInstrument = new System.Windows.Forms.Label();
            this.lstInstrument = new System.Windows.Forms.ListBox();
            this.tabControl14.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Webdings", 14.25F);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(177, 31);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(63, 33);
            this.button1.TabIndex = 0;
            this.button1.Text = "<";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Webdings", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(315, 31);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(63, 33);
            this.button2.TabIndex = 1;
            this.button2.Text = "4";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // timerSong
            // 
            this.timerSong.Interval = 10;
            this.timerSong.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Webdings", 14.25F);
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(246, 31);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(63, 33);
            this.button7.TabIndex = 8;
            this.button7.Text = "9";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // txtDebug
            // 
            this.txtDebug.Location = new System.Drawing.Point(6, 6);
            this.txtDebug.Multiline = true;
            this.txtDebug.Name = "txtDebug";
            this.txtDebug.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDebug.Size = new System.Drawing.Size(491, 487);
            this.txtDebug.TabIndex = 9;
            // 
            // timerUI
            // 
            this.timerUI.Interval = 50;
            this.timerUI.Tick += new System.EventHandler(this.timerUI_Tick);
            // 
            // tabControl14
            // 
            this.tabControl14.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.tabControl14.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl14.Controls.Add(this.tabPage1);
            this.tabControl14.Controls.Add(this.tabPage3);
            this.tabControl14.Controls.Add(this.tabPage2);
            this.tabControl14.Location = new System.Drawing.Point(177, 70);
            this.tabControl14.Multiline = true;
            this.tabControl14.Name = "tabControl14";
            this.tabControl14.SelectedIndex = 0;
            this.tabControl14.Size = new System.Drawing.Size(529, 507);
            this.tabControl14.TabIndex = 10;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Black;
            this.tabPage1.Controls.Add(this.lblPatternchannels3);
            this.tabPage1.Controls.Add(this.lblPatternchannels2);
            this.tabPage1.Controls.Add(this.lblColumntTitles);
            this.tabPage1.Controls.Add(this.lblPatternchannels);
            this.tabPage1.Controls.Add(this.lstPattern);
            this.tabPage1.Location = new System.Drawing.Point(22, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(503, 499);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Patterns";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // lblPatternchannels3
            // 
            this.lblPatternchannels3.AutoSize = true;
            this.lblPatternchannels3.Font = new System.Drawing.Font("Lucida Console", 9F);
            this.lblPatternchannels3.ForeColor = System.Drawing.Color.Yellow;
            this.lblPatternchannels3.Location = new System.Drawing.Point(10, 34);
            this.lblPatternchannels3.Name = "lblPatternchannels3";
            this.lblPatternchannels3.Size = new System.Drawing.Size(47, 12);
            this.lblPatternchannels3.TabIndex = 4;
            this.lblPatternchannels3.Text = "label4";
            // 
            // lblPatternchannels2
            // 
            this.lblPatternchannels2.AutoSize = true;
            this.lblPatternchannels2.Font = new System.Drawing.Font("Lucida Console", 9F);
            this.lblPatternchannels2.ForeColor = System.Drawing.Color.Yellow;
            this.lblPatternchannels2.Location = new System.Drawing.Point(10, 20);
            this.lblPatternchannels2.Name = "lblPatternchannels2";
            this.lblPatternchannels2.Size = new System.Drawing.Size(47, 12);
            this.lblPatternchannels2.TabIndex = 3;
            this.lblPatternchannels2.Text = "label4";
            // 
            // lblColumntTitles
            // 
            this.lblColumntTitles.AutoSize = true;
            this.lblColumntTitles.Font = new System.Drawing.Font("Lucida Console", 9F);
            this.lblColumntTitles.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblColumntTitles.Location = new System.Drawing.Point(10, 48);
            this.lblColumntTitles.Name = "lblColumntTitles";
            this.lblColumntTitles.Size = new System.Drawing.Size(5, 12);
            this.lblColumntTitles.TabIndex = 2;
            this.lblColumntTitles.Text = "​";
            // 
            // lblPatternchannels
            // 
            this.lblPatternchannels.AutoSize = true;
            this.lblPatternchannels.Font = new System.Drawing.Font("Lucida Console", 9F);
            this.lblPatternchannels.ForeColor = System.Drawing.Color.Olive;
            this.lblPatternchannels.Location = new System.Drawing.Point(10, 6);
            this.lblPatternchannels.Name = "lblPatternchannels";
            this.lblPatternchannels.Size = new System.Drawing.Size(5, 12);
            this.lblPatternchannels.TabIndex = 1;
            this.lblPatternchannels.Text = "​";
            // 
            // lstPattern
            // 
            this.lstPattern.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lstPattern.BackColor = System.Drawing.Color.Black;
            this.lstPattern.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lstPattern.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstPattern.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lstPattern.FormattingEnabled = true;
            this.lstPattern.ItemHeight = 12;
            this.lstPattern.Location = new System.Drawing.Point(9, 63);
            this.lstPattern.Name = "lstPattern";
            this.lstPattern.ScrollAlwaysVisible = true;
            this.lstPattern.Size = new System.Drawing.Size(488, 420);
            this.lstPattern.TabIndex = 0;
            this.lstPattern.MouseClick += new System.Windows.Forms.MouseEventHandler(this.lstPattern_MouseClick);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Gray;
            this.tabPage2.Controls.Add(this.txtDebug);
            this.tabPage2.Location = new System.Drawing.Point(22, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(503, 499);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Debug";
            // 
            // lstSequence
            // 
            this.lstSequence.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.lstSequence.BackColor = System.Drawing.Color.Black;
            this.lstSequence.Font = new System.Drawing.Font("Lucida Console", 9F);
            this.lstSequence.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lstSequence.FormattingEnabled = true;
            this.lstSequence.ItemHeight = 12;
            this.lstSequence.Location = new System.Drawing.Point(12, 281);
            this.lstSequence.Name = "lstSequence";
            this.lstSequence.ScrollAlwaysVisible = true;
            this.lstSequence.Size = new System.Drawing.Size(152, 292);
            this.lstSequence.TabIndex = 11;
            this.lstSequence.MouseClick += new System.Windows.Forms.MouseEventHandler(this.lstSequence_MouseClick);
            // 
            // lstInstruments
            // 
            this.lstInstruments.BackColor = System.Drawing.Color.Black;
            this.lstInstruments.Font = new System.Drawing.Font("Lucida Console", 9F);
            this.lstInstruments.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lstInstruments.FormattingEnabled = true;
            this.lstInstruments.ItemHeight = 12;
            this.lstInstruments.Location = new System.Drawing.Point(12, 49);
            this.lstInstruments.Name = "lstInstruments";
            this.lstInstruments.ScrollAlwaysVisible = true;
            this.lstInstruments.Size = new System.Drawing.Size(152, 208);
            this.lstInstruments.TabIndex = 12;
            this.lstInstruments.MouseClick += new System.Windows.Forms.MouseEventHandler(this.lstInstruments_MouseClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Console", 9F);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(12, 266);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 12);
            this.label2.TabIndex = 13;
            this.label2.Text = "Sequence";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Lucida Console", 9F);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(12, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 12);
            this.label3.TabIndex = 14;
            this.label3.Text = "Instrument";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(718, 24);
            this.menuStrip1.TabIndex = 15;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(36, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.aboutToolStripMenuItem.Text = "About";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(468, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(157, 29);
            this.label1.TabIndex = 16;
            this.label1.Text = "Chibi Tracker !";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.Location = new System.Drawing.Point(640, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(66, 66);
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.tabPage3.Controls.Add(this.lstInstrument);
            this.tabPage3.Controls.Add(this.lblInstrument);
            this.tabPage3.Controls.Add(this.txtInstrument);
            this.tabPage3.Controls.Add(this.label4);
            this.tabPage3.Location = new System.Drawing.Point(22, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(503, 499);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Instruments";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(17, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "Instrument Name";
            // 
            // txtInstrument
            // 
            this.txtInstrument.Location = new System.Drawing.Point(132, 12);
            this.txtInstrument.Name = "txtInstrument";
            this.txtInstrument.Size = new System.Drawing.Size(156, 19);
            this.txtInstrument.TabIndex = 1;
            // 
            // lblInstrument
            // 
            this.lblInstrument.AutoSize = true;
            this.lblInstrument.Font = new System.Drawing.Font("MS UI Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblInstrument.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.lblInstrument.Location = new System.Drawing.Point(348, 12);
            this.lblInstrument.Name = "lblInstrument";
            this.lblInstrument.Size = new System.Drawing.Size(139, 24);
            this.lblInstrument.TabIndex = 2;
            this.lblInstrument.Text = "lblInstrument";
            // 
            // lstInstrument
            // 
            this.lstInstrument.BackColor = System.Drawing.Color.Black;
            this.lstInstrument.Font = new System.Drawing.Font("Lucida Console", 9F);
            this.lstInstrument.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.lstInstrument.FormattingEnabled = true;
            this.lstInstrument.ItemHeight = 12;
            this.lstInstrument.Location = new System.Drawing.Point(11, 54);
            this.lstInstrument.Name = "lstInstrument";
            this.lstInstrument.ScrollAlwaysVisible = true;
            this.lstInstrument.Size = new System.Drawing.Size(475, 424);
            this.lstInstrument.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(718, 589);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lstInstruments);
            this.Controls.Add(this.lstSequence);
            this.Controls.Add(this.tabControl14);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Chibi Tracker !";
            this.tabControl14.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Timer timerSong;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox txtDebug;
        private System.Windows.Forms.Timer timerUI;
        private System.Windows.Forms.TabControl tabControl14;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ListBox lstSequence;
        private System.Windows.Forms.ListBox lstInstruments;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox lstPattern;
        private System.Windows.Forms.Label lblPatternchannels;
        private System.Windows.Forms.Label lblColumntTitles;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.Label lblPatternchannels2;
        private System.Windows.Forms.Label lblPatternchannels3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox txtInstrument;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblInstrument;
        private System.Windows.Forms.ListBox lstInstrument;
    }
}

