﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ChibiTracker
{
    class ChibiTrackerChannel
    {
        public static string[] ChibiOctiveT = { "-E ", "-E+", "-F ", "-F#", "-G ", "-G#", "-A ", "-A#", "-B ", "-B+", "-C ", "-C#", "-D ", "-D#" };
        public static int[] ChibiOctive = {0x0000,0x0800,0x1000,0x2000,0x2800,0x3000,0x4000,    //0
                                    0x4CFB,0x56FB,0x6980,0x79C0,0x8840,0x8F40,0x9b80,           //1
                                    0xa640,0xab59,0xb499,0xbcd2,0xc433,0xc7a0,0xcd9e,           //2
                                    0xd300,0xd5c0,0xda60,0xde80,0xe220,0xe3d0,0xe710,           //3
                                    0xe990,0xeae0,0xed40,0xef40,0xF130,0xf200,0xf380,           //4
                                    0xf4f0,0xf580,0xf6a0,0xf7a0,0xf880,0xf900,0xf9e0,           //5
                                    0xFA60,0xFAE0,0xFB60,0xFBE0,0xFC10,0xFC60,0xFD10,           //6
                                    0xFD80,0xFDC0,0xFE00,0xFE80,0xFF00,0xFF80,0xFFFF,           //7
                                    0xFFFF,0xFFFF,0xFFFF,0xFFFF,0xFFFF,0xFFFF,0xFFFF};   


        private int ChannelFreq = 100;
        private int ChannelFreqm = 100;
        private int testfreqTime = 0;
        //public byte testByte = 127;
        public int PlaySamples = 0;
        public int PlaySamplesPerTick = 44100 / 60;
        public int tick = 0;
        bool noise = false;      
        public Random randomizer = new Random();
        public int channelnumber = 0;
        Single LeftVol = 1;
        Single RightVol = 1F;

        Single LeftVolm = 0;
        Single RightVolm = 0F;  /// Channel setting * Vol

        Single Volume = 1;
        int pitch = 0;
        int instrument = 0;
        int note = 0;


        public int Sample = 16;
        public int polarity = -1;
        public byte MyByteL = 0;
        public byte MyByteR = 0;

        
        public int PlayingPattern = 0;
        public int PlayingPatternLine = 0;
        public int PlayingPatternPos = 0;
        public int PlayingPatternTime = -1;

        public int PlayingInstrument = 0;
        public int PlayingInstrumentLine = 0;
        public int PlayingInstrumentPos = 0;
        public int PlayingInstrumentTime = 1;


        /*
        Cmd_Ptch equ $0F	;$0F,n
        Cmd_Volu equ $0E	;$0E,n - Absolute volume n
        Cmd_Note equ $0D	;$0D,n - Play Note pitch n
        Cmd_Loop equ $0C	;$0C,n - Jump back n bytes
        Cmd_Inst equ $0B	;$0B,n - select instrument n

        Cmd_VolA equ $F0	;&F0+n - Volume Adjust
        Cmd_VolD equ $00	;&F0+ -n - Volume Adjust


        Cmd_PtcD equ $E0	;$E0+n
        Cmd_PtcU equ $D0	;$D0+n
        Cmd_Nois equ $C0	;$C0+n (1/0) - Noise On/Off

        Cmd_Pend equ $10	;$10 - Pattern End

        Seq_Repeat equ 255

        ;0 = end of commands

        ;0F,x = Pitch to x
        ;0E,x = vol to x
        ;0D,x = note to x
        ;0C,x = Loop to Offset -0 to -255 bytes
        ;0B,x = Play Instrument x

        ;Fx = Vol shift -8 to +7
        ;Ex = Pitch shift down 0 to -15
        ;Dx = Pitch shift up 0 to +15
        ;Cx = Noise state x (1=on 0=off)
        ;10 = End of Pattern

        ;Pattern 255=Repeat whole song

        */

        public string txtStatus() {

            string result = " I:" + PlayingInstrument.ToString() + " V:" + VbX.CInt(Volume * 255).ToString().PadLeft(3) + " P:" + pitch.ToString().PadLeft(3);
            return result;
        }

        public string txtStatus2()
        {

            string result = " N:" + note.ToString().PadLeft(3) + " " + VbX.CInt(note / 14).ToString() + ChibiOctiveT[note % 14] ; 


            if (noise) result += " N"; else result += "  ";
            if (LeftVolm + RightVolm > 0) {
                if (PlayingPatternLine % 2 == 0)
                {
                    result += " ♫♪♫";
                }
                else {
                    result += " ♪♫♪";
                }
                
            }
            return result;
        }

        public int getoctive(int entrynum)
        {

            if (entrynum % 2 == 0)
            {
                return ChibiOctive[entrynum / 2];
            }
            return (ChibiOctive[entrynum / 2] + ChibiOctive[(entrynum + 1) / 2]) / 2;
        }


        public int tweener(int entry1, int entry2, int tween)
        {
            int result = (entry2 * tween) / 16;
            result += (entry1 * (16 - tween)) / 16;

            return result;
        }

        public void UpdateChannelPatternEvents(ref Song mysong)
        {
            PlayingPatternTime--;

            if (PlayingPatternTime == 0) {
                PlayingPatternTime = ProcessCommands(ref mysong.Pattern, ref PlayingPattern, ref PlayingPatternLine, ref PlayingPatternPos);
            }
        }

        public void UpdateChannelInstrumentEvents(ref Song mysong)
        {
            if (PlayingInstrumentTime >= 0)
            {
                PlayingInstrumentTime--;

                if (PlayingInstrumentTime == 0)
                {
                    PlayingInstrumentTime = ProcessCommands(ref mysong.instrument, ref PlayingInstrument, ref PlayingInstrumentLine, ref PlayingInstrumentPos);
                    if (PlayingInstrumentTime == 0) {
                        LeftVolm = 0;
                        RightVolm = 0;
                    } else
                    {
                        int o1 = getoctive(note + (pitch / 16));
                        int o2 = getoctive(note + (pitch / 16) + 1);
                        setfrequency(tweener(o1, o2, pitch & 0x0F));
                    }
                }
            }
        }

        public int ProcessCommands(ref byte[, ,] cmdsrc,ref int cmditem,ref int cmdlin,ref int cmdnum)
        {
            int cmd = 0;
            cmd = cmdsrc[cmditem, cmdlin, cmdnum];cmdnum++;

            int NewTime = cmd;

            bool done = false;

            if (NewTime == 0) done = true;

            while (!done)
            {

                cmd = cmdsrc[cmditem, cmdlin, cmdnum]; cmdnum++;

                //Single Volume = 1;
                //int pitch = 0;
                //; int instrument = 0;
                // int note = 0;

                if (cmd == 0x0F)
                { //Pitch
                    int param = cmdsrc[cmditem, cmdlin, cmdnum]; cmdnum++;
                    pitch = param;
                }

                if (cmd == 0x0E)
                { //Volume
                    int param = cmdsrc[cmditem, cmdlin, cmdnum]; cmdnum++;
                    Volume = ((float)param) / 255;
                }

                if (cmd == 0x0D)
                { //Play Note
                    int param = cmdsrc[cmditem, cmdlin, cmdnum]; cmdnum++;
                    note = param;
                }

                if (cmd == 0x0C)
                { //Loop
                    int param = cmdsrc[cmditem, cmdlin, cmdnum]; cmdnum++;
                    // TODO
                }
                if (cmd == 0x0B)
                { //Instrument
                    int param = cmdsrc[cmditem, cmdlin, cmdnum]; cmdnum++;
                    instrument = param;
                    LeftVolm = LeftVol * Volume;
                    RightVolm = RightVol * Volume;
                    PlayingInstrument = instrument;
                    PlayingInstrumentLine = 0;
                    PlayingInstrumentPos = 0;
                    PlayingInstrumentTime = 1;
                    
                }
                if (cmd >= 0xE0 && cmd <= 0xEF)
                { //PitchDown
                    pitch = -(cmd % 16);
                }
                if (cmd >= 0xD0 && cmd <= 0xDF)
                { //PitchUp
                    pitch =  (cmd % 16);
                }
                if (cmd >= 0xC0 && cmd <= 0xCF)
                { //Noise
                    if (cmd == 0xC0) noise = false;
                    if (cmd == 0xC1) noise = true;
                }
                if (cmd == 0x10)
                { //Pattern End
                    NewTime = -1;
                    done = true;
                }
                if (cmd == 0x0)
                { //Commands end
                    cmdnum = 0;
                    cmdlin++;
                    done = true;
                
                }


            }
            
            return ((int)NewTime);
        }


        public bool UpdateChannelWave()
        {
            testfreqTime++;

            if (testfreqTime > ChannelFreqm)
            {
                PlaySamples += testfreqTime;
                while (PlaySamples > PlaySamplesPerTick)
                {
                    PlaySamples -= PlaySamplesPerTick;

                    tick++;
                }
                if (noise)
                {
                    int r = randomizer.Next(Sample * 4);
                    MyByteL = (byte)(LeftVolm * r);  // Left H Byte
                    MyByteR = (byte)(RightVolm * r);  // Right H Byte
                }
                else
                {
                    MyByteL = (byte)(polarity * LeftVolm * Sample);  // Left H Byte
                    MyByteR = (byte)(polarity * RightVolm * Sample);  // Right H Byte

                    polarity = -polarity;
                }
                testfreqTime = 0;
                return true;
            }
            return false;
        }
        public void setpanning(float newvolL, float newvolR)
        {
            LeftVol = newvolL;
            RightVol = newvolR;

            LeftVolm = LeftVol * Volume;
            RightVolm = RightVol * Volume;
        }
        public void setvolume(float newvol)
        {
            Volume = newvol;

            LeftVolm = LeftVol * Volume;
            RightVolm = RightVol * Volume;
        }

        public void setfrequency(int myfreq)
        {
            ChannelFreq = (65535-myfreq)/86;
            ChannelFreqm = ChannelFreq;
        }
        public void setnoise(bool mynoise) {
            noise = mynoise;

            if (noise)
            {
                ChannelFreqm = ChannelFreq/5;
            }
        }
        public void reset() {
            tick = 0;
            testfreqTime = 0;
        
        }
        public void ChibiSoundPro_Set(int freq, int vol, bool noise) {
            setfrequency(freq);
            setvolume(vol);
            setnoise(noise);
        }
    }
    
}
