﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/*
 
ChibiOctive:
	;   E     F     G      A     B     C     D   
	dw $0000,$0800,$1000,$2000,$2800,$3000,$4000 ;0
	;   41.2  43.6   49    55   61.7  65.4  73.4
	dw $4CFB,$56FB,$6980,$79C0,$8840,$8F40,$9b80 ;1
	;   82.4  87.3  98    110   123    130   146
	dw $a640,$ab59,$b499,$bcd2,$c433,$c7a0,$cd9e ;2
	;	164   174    196   220 	246   261   293
	dw $d300,$d5c0,$da60,$de80,$e220,$e3d0,$e710;3
	;   329   349   392   440   493   523    587
	dw $e990,$eae0,$ed40,$ef40,$F130,$f200,$f380 ;4
	;    659  698   783   880   987   1046  1174
	dw $f4f0,$f580,$f6a0,$f7a0,$f880,$f900,$f9e0 ;5
	;   1318  1396  1567  1760  1975  2093  2349
	dw $FA60,$FAE0,$FB60,$FBE0,$FC10,$FC60,$FD10;6
	dw $FD80,$FDC0,$FE00,$FE80,$FF00,$FF80,$FFFF ;EXTRA

 
 */
namespace ChibiTracker
{
    class ChibiTrackerController
    {
       public static int[] ChibiOctive = {0x0000,0x0800,0x1000,0x2000,0x2800,0x3000,0x4000,
                                    0x4CFB,0x56FB,0x6980,0x79C0,0x8840,0x8F40,0x9b80,
                                    0xa640,0xab59,0xb499,0xbcd2,0xc433,0xc7a0,0xcd9e,
                                    0xd300,0xd5c0,0xda60,0xde80,0xe220,0xe3d0,0xe710,
                                    0xe990,0xeae0,0xed40,0xef40,0xF130,0xf200,0xf380,
                                    0xf4f0,0xf580,0xf6a0,0xf7a0,0xf880,0xf900,0xf9e0,
                                    0xFA60,0xFAE0,0xFB60,0xFBE0,0xFC10,0xFC60,0xFD10,
                                    0xFD80,0xFDC0,0xFE00,0xFE80,0xFF00,0xFF80,0xFFFF};

        public String MyMessage = "";
        public ChibiTrackerChannel [] Channel = new ChibiTrackerChannel[8];
        public int BufferLength = 1024;
        public byte MyByteL;
        public byte MyByteR;
        public bool shownewpattern = false;
        public bool shownewpatternline = false;
        public int TicksOccurred=0;
        public int PatternTicks = 0;
        public int PatternPos = 0;
        public bool playing = false;
        //public string Playing_Patterns="";
       // public string Playing_Instruments = "";
        public int getoctive(int entrynum) {

            if (entrynum % 2 == 0) {
                return ChibiOctive[entrynum / 2];
            }
            return (ChibiOctive[entrynum / 2] + ChibiOctive[(entrynum+1) / 2])/2;
        }
        public int tweener(int entry1,int entry2,int tween)
        {
            int result=(entry2*tween)/16;
            result += (entry1 * (16-tween)) / 16;

            return result;
        }



        public ChibiTrackerController() {
            for (int i=0;i<3;i++){
                Channel[i] = new ChibiTrackerChannel();
                Channel[i].channelnumber = i;
            }
            Channel[1].setpanning(1   , .2f);
            Channel[2].setpanning(.2f , 1);
            
        }
        public void Play()
        {
            playing = true;
        }
        public void UpdateSong(ref Song mysong) {
            if (playing == false) return;
            //Playing_Patterns = "";
            //Playing_Instruments = "";
            bool nextpattern=false;
            for (int c = 0; c < mysong.channels; c++)
            {
                if (Channel[c].PlayingPatternTime == -1) {
                    nextpattern = true;
                    shownewpattern = true;
                }
            }
            if (nextpattern == true) {
                mysong.SongSequencePos++;
                PatternPos=-1;
                shownewpatternline = true;
                if (mysong.Sequence[0, mysong.SongSequencePos] == 255) mysong.SongSequencePos=0;

                for (int c = 0; c < mysong.channels; c++)
                {
                    Channel[c].PlayingPatternPos = 0;
                    Channel[c].PlayingPatternTime = 1;
                    Channel[c].PlayingPatternLine = 0;
                    Channel[c].PlayingPattern = mysong.Sequence[c, mysong.SongSequencePos];
                    
                }

            }

            PatternTicks++;
            if (PatternTicks > mysong.SongSpeed) {
                for (int c = 0; c < mysong.channels; c++)
                {
                    Channel[c].UpdateChannelPatternEvents(ref mysong);  
                }
                PatternTicks = 0;
                PatternPos++;
                shownewpatternline = true;
            }
            for (int c = 0; c < mysong.channels; c++)
            {    
                Channel[c].UpdateChannelInstrumentEvents(ref mysong);
            }
            //mysong.SongSequencePos++;
            TicksOccurred++;       
        }

        public void UpdateChannel()
        {

            


            bool needsupdate = false;
            if (Channel[0].UpdateChannelWave()) needsupdate = true;
            if (Channel[1].UpdateChannelWave()) needsupdate = true;
            if (Channel[2].UpdateChannelWave()) needsupdate = true;
            if (needsupdate)
            {
                MyByteL = (byte)(Channel[0].MyByteL + Channel[1].MyByteL + Channel[2].MyByteL);
                MyByteR = (byte)(Channel[0].MyByteR + Channel[1].MyByteR + Channel[2].MyByteR);
            }
        }

        public void Stop()
        {
            playing = false;
        }
        public void Restart() {
            // Channel[0].reset();
            // Channel[1].reset();
            // Channel[2].reset();
            playing = true;
        
        }
    }

}
