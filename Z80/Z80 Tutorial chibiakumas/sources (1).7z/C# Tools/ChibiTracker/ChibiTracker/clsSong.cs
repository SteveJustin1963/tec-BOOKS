﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/*
Cmd_Ptch equ $0F	;$0F,n
Cmd_Volu equ $0E	;$0E,n - Absolute volume n
Cmd_Note equ $0D	;$0D,n - Play Note pitch n
Cmd_Loop equ $0C	;$0C,n - Jump back n bytes
Cmd_Inst equ $0B	;$0B,n - select instrument n

Cmd_VolA equ $F0	;&F0+n - Volume Adjust
Cmd_VolD equ $00	;&F0+ -n - Volume Adjust


Cmd_PtcD equ $E0	;$E0+n
Cmd_PtcU equ $D0	;$D0+n
Cmd_Nois equ $C0	;$C0+n (1/0) - Noise On/Off

Cmd_Pend equ $10	;$10 - Pattern End

Seq_Repeat equ 255

;0 = end of commands

;0F,x = Pitch to x
;0E,x = vol to x
;0D,x = note to x
;0C,x = Loop to Offset -0 to -255 bytes
;0B,x = Play Instrument x

;Fx = Vol shift -8 to +7
;Ex = Pitch shift down 0 to -15
;Dx = Pitch shift up 0 to +15
;Cx = Noise state x (1=on 0=off)
;10 = End of Pattern

;Pattern 255=Repeat whole song

 * */


namespace ChibiTracker
{
    class Song
    {
        public static string[] ChibiOctiveT = { "-E ", "-E+", "-F ", "-F#", "-G ", "-G#", "-A ", "-A#", "-B ", "-B+", "-C ", "-C#", "-D ", "-D#" };


const byte Cmd_Ptch = 0x0F;	//$0F,n
const byte Cmd_Volu = 0x0E;	//$0E,n - Absolute volume n
const byte Cmd_Note = 0x0D;	//$0D,n - Play Note pitch n
const byte Cmd_Loop = 0x0C;	//$0C,n - Jump back n bytes
const byte Cmd_Inst = 0x0B;	//$0B,n - select instrument n

const byte Cmd_VolA = 0xF0;	//&F0+n - Volume Adjust -8 to +7

const byte Cmd_PtcD = 0xE0;	//$E0+n
const byte Cmd_PtcU = 0xD0;	//$D0+n
const byte Cmd_Nois = 0xC0;	//$C0+n (1/0) - Noise On/Off

const byte Cmd_Pend = 0x10;	//$10 - Pattern End

const byte Seq_Repeat = 255;

const byte Ins7 = 7;
const byte Ins6 =6;
const byte Ins23 = 23;
const byte Ins20 = 20;
//const byte MSpd = 4;

public int channels = 3;
public int RepeatPoint = 0;
public int SongSequencePos = -1;

    public int[,] Sequence = new int[3,64] ;
    public int[] SequenceLength = new int[8];
        
               /// up to 8 channels
    public byte[, ,] Pattern = new byte[128,128,128];  /// Up to 128 patterns, 128 lines per pattern
                                                       /// pattern,line,byte
    public int patterncount=0;
    public int[] patternlinecount = new int[128];
    public int[,] patternlinelength = new int[128, 128];

    public int instrumentcount = 0;
    public int[] instrumentlinecount = new int[128];
    public int[,] instrumentlinelength = new int[128, 128];


    public byte[, ,] instrument = new byte[128,128,128]
; /// Up to 128 Instruments, 128 lines per pattern

    public string[] ChannelName = new string[8];
    public string[] PatternName = new string[128];
    public string[] InstrumentName = new string[128];

        public int SongSpeed = 4;

        public Song(){

            for (int i = 0; i < 32; i++) {
                InstrumentName[i] = "Ins" + i.ToString();
            }

            //VbX.MsgBox(CommandsToText(instrument,0,0));    
        }
        public string LoadBinary(String sourcefile)
        {
            System.IO.Stream ST = new System.IO.FileStream(sourcefile, System.IO.FileMode.Open, System.IO.FileAccess.Read);
            System.IO.BinaryReader BR = new System.IO.BinaryReader(ST);

            string response = "";

            channels=BR.ReadByte();
            RepeatPoint = BR.ReadByte();
            UInt16 PatternList = BR.ReadUInt16();
            UInt16 InstrumentList = BR.ReadUInt16();
            UInt16[] SequenceList = new UInt16[8];
            
            for (int c = 0; c < channels; c++)
            {
                SequenceList[c] = BR.ReadUInt16();
            }

//SEQUENCES

            //VbX.MsgBox("Seq"+SequenceList[2].ToString());
            for (int c = 0; c < channels; c++)
            {
                ST.Seek(SequenceList[c],System.IO.SeekOrigin.Begin);
                int spos = 0;
                do{
                    Sequence[c,spos] = BR.ReadByte();
                    if (Sequence[c,spos]<255){
                        if (Sequence[c, spos] > patterncount) patterncount = Sequence[c, spos];
                    }
                    spos++;
                } while (Sequence[c,spos-1]<255);
                SequenceLength[c] = spos;
            }
            //VbX.MsgBox("S" + Sequence[0, 0]);

//PATTERNS


            for (int pnum = 0; pnum <= patterncount; pnum++)
            {
                ST.Seek(PatternList + (pnum * 2), System.IO.SeekOrigin.Begin);
                UInt16 patternaddress = BR.ReadUInt16();
                ST.Seek(patternaddress, System.IO.SeekOrigin.Begin);

                int ppos = 0;
                int plin = 0;
                bool done = false;
                do
                {
         
                    byte thisbyte=BR.ReadByte();
                    Pattern[pnum, plin, ppos] = thisbyte;
                    ppos++;
                    if (thisbyte == 0) done = true;
                    else
                    {
                        bool linedone = false;
                        do
                        {
                            thisbyte = BR.ReadByte();
                            Pattern[pnum, plin, ppos] = thisbyte;
                            ppos++;
                            if (thisbyte == 0) linedone = true;
                            else
                            {
                                int extrabytes = 0;
                                switch (thisbyte)
                                {
                                    case 11: //instrument select
                                    case 12:
                                    case 13:
                                    case 14:
                                    case 15:
                                        extrabytes = 1;
                                        break;
                                    case 16:
                                        linedone = true;
                                        done = true;
                                        break;

                                }
                                while (extrabytes > 0)
                                {
                                    extrabytes--;
                                    byte valuebyte=BR.ReadByte();
                                    Pattern[pnum, plin, ppos] = valuebyte;

                                    if (thisbyte == 11) {
                                        if (valuebyte > instrumentcount) {
                                            instrumentcount = valuebyte;
                                        }
                                    }
                                    ppos++;
                                }
                            }
                        } while (!linedone);
                    }
                    patternlinelength[pnum,plin]=ppos;
                    plin++;
                    ppos = 0;
                } while (!done);
                patternlinecount[pnum] = plin;
                // VbX.MsgBox("Seq" + SequenceList[2].ToString());
            }


//INSTRUMENTS


            for (int inum = 0; inum <= instrumentcount; inum++)
            {
                ST.Seek(InstrumentList + (inum * 2), System.IO.SeekOrigin.Begin);
                UInt16 instrumentaddress = BR.ReadUInt16();
                ST.Seek(instrumentaddress, System.IO.SeekOrigin.Begin);

                int ipos = 0;
                int ilin = 0;
                bool done = false;
                do
                {

                    byte thisbyte = BR.ReadByte();
                    instrument[inum, ilin, ipos] = thisbyte;
                    ipos++;
                    if (thisbyte == 0) done = true;
                    else
                    {
                        bool linedone = false;
                        do
                        {
                            thisbyte = BR.ReadByte();
                           instrument[inum, ilin, ipos] = thisbyte;
                            ipos++;
                            if (thisbyte == 0) linedone = true;
                            else
                            {
                                int extrabytes = 0;
                                switch (thisbyte)
                                {
                                    case 11: //instrument select
                                    case 12:
                                    case 13:
                                    case 14:
                                    case 15:
                                        extrabytes = 1;
                                        break;
                                    case 16:
                                        linedone = true;
                                        done = true;
                                        break;

                                }
                                while (extrabytes > 0)
                                {
                                    extrabytes--;
                                    byte valuebyte = BR.ReadByte();
                                    instrument[inum, ilin, ipos] = valuebyte;

                                    if (thisbyte == 11)
                                    {
                                        if (valuebyte > instrumentcount)
                                        {
                                            instrumentcount = valuebyte;
                                        }
                                    }
                                    ipos++;
                                }
                            }
                        } while (!linedone);
                    }
                    instrumentlinelength[inum, ilin] = ipos;
                    ilin++;
                    ipos = 0;
                } while (!done);
                instrumentlinecount[inum] = ilin;
                // VbX.MsgBox("Seq" + SequenceList[2].ToString());
            }

// Show File contents for debug

            for (int c = 0; c < 3; c++)
            {
                response += VbX.nl() + "Sequence " + c + ":" + VbX.nl();
                for (int s = 0; s < SequenceLength[c]; s++)
                {
                    response += Sequence[c, s] + ",";
                }
                response += VbX.nl();
            }


            for (int p = 0; p < patterncount; p++)
            {
                response += VbX.nl() + "Pattern " + p + ":" + VbX.nl();
                for (int l = 0; l < patternlinecount[p]; l++)
                {
                    for (int b = 0; b < patternlinelength[p, l]; b++)
                    {
                        response += Pattern[p, l, b] + ",";
                    }
                    response += VbX.nl();
                }
            }




            for (int p = 0; p < instrumentcount; p++)
            {
                response += VbX.nl() + "Instrument " + p + ":" + VbX.nl();
                for (int l = 0; l < instrumentlinecount[p]; l++)
                {
                    for (int b = 0; b < instrumentlinelength[p, l]; b++)
                    {
                        response += instrument[p, l, b] + ",";
                    }
                    response += VbX.nl();
                }
            }


            // VbX.MsgBox("S" + Sequence[0, 1]);
            // VbX.MsgBox("S" + Sequence[0, 2]);

            //public int channels = 3;
            //public int RepeatPoint = 0;
            return response;
        }

        public string CommandsToText(byte[, ,] commands, int number, int line,int Mode)
        {
            string ResultString = "";
            int pitch = -65536;
            int volume = -65536;
            int note = -65536;
            int loop = -65536;
            int Instrument = -65536;
            for (int i = 1; i < commands.Length; i++) {
                string ThisPart = "";
                switch (commands[number,line,i]) { 
                
                    case 0:
                        i = commands.Length ;
                        break;
                    case 0x0F:
                        
                        ThisPart += "Pitch=";
                        i++;
                        ThisPart += commands[number, line, i].ToString();
                        pitch = commands[number, line, i];
                        break;
                    case 0x0E:
                        
                        ThisPart += "Volume=";
                        i++;
                        ThisPart += commands[number, line, i].ToString();
                        volume = commands[number, line, i];
                        break;
                    case 0x0D:
                        
                        ThisPart += "Note:";
                        i++;
                        ThisPart += commands[number, line, i].ToString();
                        note = commands[number, line, i];
                        break;
                    case 0x0C:
                        
                        ThisPart += "Loop back ";
                        i++;
                        ThisPart += commands[number, line, i].ToString();
                        loop = commands[number, line, i];
                        break;
                    case 0x0B:
                        
                        ThisPart += "Select Instrument";
                        i++;
                        ThisPart += commands[number, line, i].ToString();
                        Instrument = commands[number, line, i];
                        break;
                    case 0xC0:
                        
                        ThisPart += "Nose:OFF";
                        break;
                    case 0xC1:
                        
                        ThisPart += "Nose: ON";
                        break;
                        //if (cmd >= 0xE0 && cmd <= 0xEF)
                        //{ //PitchDown
                        //    pitch = -(cmd % 16);
                        //}
                        //if (cmd >= 0xD0 && cmd <= 0xDF)
                        //{ //PitchUp
                        //    pitch = (cmd % 16);
                        //}
                        //if (cmd >= 0xC0 && cmd <= 0xCF)
                        
                   
                    case 0x10:
                        
                        ThisPart += "PatternEnd";
                        break;
                    default:
                        
                        ThisPart += commands[number, line, i].ToString();
                        break;
                }
                //if (ThisPart.Length > 0 && ResultString.Length > 0) ResultString += ", ";
                if (ThisPart.Length > 0) ResultString+= ( ThisPart).PadRight(16);
            }
            if (Mode == 1) {

                ResultString = "";
                if (Instrument >= 0) ResultString += Instrument.ToString().PadLeft(2); else ResultString += "..".PadLeft(2);
                if (note >= 0) ResultString += (note.ToString().PadLeft(3) + " " + VbX.CInt(note / 14).ToString() + ChibiOctiveT[note % 14]).PadLeft(8); else ResultString += ".. ... ".PadLeft(8);
                if (volume >= 0) ResultString += volume.ToString().PadLeft(4); else ResultString += "...".PadLeft(4);
                if (pitch >= 0) ResultString += pitch.ToString().PadLeft(4); else ResultString += "...".PadLeft(4);

                //Line length
                //ResultString = commands[number, line, 0].ToString().PadLeft(4) + ":" + ResultString.PadLeft(16);

                if (commands[number, line, 0]==0){
                    ResultString = "   *** END ***";
                }
            }
            return ResultString;
        }
    }

}
