﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Runtime.InteropServices;
using System.Threading;
using SlimDX;
using SlimDX.XAudio2;
using SlimDX.Multimedia;
using SlimDX.DirectSound;
namespace ChibiTracker
{
    

    public partial class Form1 : Form
    {
        const int ChannelLabelWidth =20;
        //static extern short GetAsyncKeyState(int key);		//spedific to this example. see below
        const int VK_ESCAPE = 0x1B;
        int SelectedChn = 0;
        int SelectedLin = 0;
        int SelectedSeq = 0;
        int SelectedIns = 0;
        public Form1()
        {
            InitializeComponent();
            txtDebug.Text = mysong.LoadBinary("F:\\Progs\\ChibiTracker\\ChibiTracker\\song\\song2.cbt");
            for (int i = 0; i < 34; i++)
            {

                lstPattern.Items.Add("");
            }

            for (int i = 0; i < 32; i++) {
                lstInstruments.Items.Add("");
            }
            for (int i = 0; i < 32; i++)
            {
                lstSequence.Items.Add("");
            }
            
            UpdateSequenceView();
            UpdateInstrumentView();
        }
        Song mysong = new Song();
        

        int songtick = 0;       //Vblanks

        ChibiTrackerController ctc = new ChibiTrackerController();

        //private void button1_Click(object sender, EventArgs e)
        //{
        //    XAudio2 device = new XAudio2(); //audio output stream/device

        //    MasteringVoice masteringVoice = new MasteringVoice(device); //no idea, presumably prepares the out stream

        //    // play a PCM file
        //    PlayPCM(device, "C:\\WINDOWS\\Media\\Windows XP Startup.wav"); //this actually plays a wav file

        //    // play a 5.1 PCM wave extensible file
        //    PlayPCM(device, "C:\\WINDOWS\\Media\\Windows XP Startup.wav");

        //    masteringVoice.Dispose();	//cleanup
        //    device.Dispose();			//
        //}
        // static void PlayPCM(XAudio2 device, string fileName)
        //{
        //    var s = System.IO.File.OpenRead(fileName);	//open the wav file
        //    WaveStream stream = new WaveStream(s);		//pass the stream to the library
        //    s.Close();	//close the file

        //    AudioBuffer buffer = new AudioBuffer();	//init the buffer
        //    buffer.AudioData = stream;				//set the input stream for the audio
        //    buffer.AudioBytes = (int)stream.Length;	//set the size of the buffer to the size of the stream
        //    buffer.Flags = SlimDX.XAudio2.BufferFlags.EndOfStream;	//presumably set it to play until the end of the stream/file 
			

        //    SourceVoice sourceVoice = new SourceVoice(device, stream.Format); //this looks like it might initalise the actual output
        //    sourceVoice.SubmitSourceBuffer(buffer); //pass the buffer to the output thingo
        //    sourceVoice.Start(); //start the playback?
			
        //    //above 2 sections are guessed, there is no documentation on the classes/proerties.

        //    // loop until the sound is done playing
        //    while (sourceVoice.State.BuffersQueued > 0)	// This keeps looping while there is sound in the buffer
        //    {											// (presumably). For this specific example it will stop
        //        // if (GetAsyncKeyState(VK_ESCAPE) != 0)	// plying the sound if escape is pressed. That is what the
        //          //  break;								// DLLImport and stuff at the top is for
        //        Thread.Sleep(10);						//
        //    }

        //    // wait until the escape key is released
        //    //while (GetAsyncKeyState(VK_ESCAPE) != 0) //it jsut waits here until the person presses escape
        //        Thread.Sleep(10);

        //    // cleanup the voice
        //    buffer.Dispose();
        //    sourceVoice.Dispose();
        //    stream.Dispose();
        //}

        private void PlaySound(Guid soundCardGuid) {
        DirectSound ds = new DirectSound(soundCardGuid);
            
        ds.SetCooperativeLevel(this.Handle, CooperativeLevel.Priority);

        WaveFormat format = new WaveFormat();
        format.BitsPerSample = 16;
        format.BlockAlignment = 4;
        format.Channels = 2;
        format.FormatTag = WaveFormatTag.Pcm;
        format.SamplesPerSecond = 44100;
        format.AverageBytesPerSecond = format.SamplesPerSecond * format.BlockAlignment;
        
        //SoundBufferDescription desc = new SoundBufferDescription();
        //desc.Format = format;
        //desc.Flags = SlimDX.DirectSound.BufferFlags.GlobalFocus;
        //desc.SizeInBytes = 8 * format.AverageBytesPerSecond; 

        //PrimarySoundBuffer pBuffer = new PrimarySoundBuffer(ds, desc);

        SoundBufferDescription desc2 = new SoundBufferDescription();
        desc2.Format = format;
        desc2.Flags = SlimDX.DirectSound.BufferFlags.GlobalFocus | SlimDX.DirectSound.BufferFlags.ControlPositionNotify | SlimDX.DirectSound.BufferFlags.GetCurrentPosition2;
        desc2.SizeInBytes = (44100/30)*2*2*2; //60fps, 2 channels, 2 bytes per sample, 2 buffers;

            ctc.Play();
        
        //System.IO.Stream stream = System.IO.File.Open(audioFile, System.IO.FileMode.Open);

        Thread fillBuffer = new Thread(() => Updater( desc2, ds, ref ctc));
        fillBuffer.Start();
            

    
}
        static void Updater( SoundBufferDescription desc2, DirectSound ds, ref ChibiTrackerController ctc)
        {

            SecondarySoundBuffer sBuffer1 = new SecondarySoundBuffer(ds, desc2);
            byte[] bytes1 = new byte[desc2.SizeInBytes / 2];
            //byte[] bytes2 = new byte[desc2.SizeInBytes];


            NotificationPosition[] notifications = new NotificationPosition[2];
            notifications[0].Offset = desc2.SizeInBytes / 2 + 1;
            notifications[1].Offset = desc2.SizeInBytes - 1; ;

            notifications[0].Event = new AutoResetEvent(false);
            notifications[1].Event = new AutoResetEvent(false);
            sBuffer1.SetNotificationPositions(notifications);



            //bytesRead = stream.Read(bytes1, 0, desc2.SizeInBytes / 2);

            //sBuffer1.Write<byte>(bytes1, 0, LockFlags.None);
            sBuffer1.Write<byte>(GetBuffer(ref ctc), 0, LockFlags.None);
            sBuffer1.Play(0, SlimDX.DirectSound.PlayFlags.Looping);

            while (1 == 1)
            {
                ctc.BufferLength = desc2.SizeInBytes / 2;


                if (ctc.playing==false) { break; }
                notifications[0].Event.WaitOne();

                //bytesRead = stream.Read(bytes1, 0, ctc.BufferLength);
                sBuffer1.Write<byte>(GetBuffer(ref ctc), 0, LockFlags.None);

                if (ctc.playing == false) { break; }
                notifications[1].Event.WaitOne();
                //bytesRead = stream.Read(bytes1, 0, bytes1.Length);


                sBuffer1.Write<byte>(GetBuffer(ref ctc), ctc.BufferLength, LockFlags.None);
                   
            }
            //stream.Close();
            //stream.Dispose();
            ctc.MyMessage = "Stop!";
        }

        private static byte[] GetBuffer( ref ChibiTrackerController ctc)
        {

            byte[] mybytes = new byte[ctc.BufferLength];

            //byte v = 127;
            //int p = ctc.testfreq;// 1024;
            //for (int i = 0; i < ctc.BufferLength; i += p)
            
            //    for (int a = 1; a < p; a+=4)
            //    {
            //        if (i + a + 2 < ctc.BufferLength)
            //        {
            //            mybytes[i + a + 0] = (byte)ctc.testByte;   // Left H Byte
            //            mybytes[i + a + 2] = (byte)ctc.testByte;   // Right H Byte
            //        }
            //    }
            //    ctc.testByte = (byte)(255 - ctc.testByte);
            

            //return mybytes;

            for (int i = 0; i < ctc.BufferLength; i += 4)
            {
                ctc.UpdateChannel();
                // ctc.Channel[0].UpdateChannel();
                //ctc.Channel[1].UpdateChannel();
                mybytes[i + 1] = ctc.MyByteL;// (byte)(ctc.Channel[0].MyByteL + ctc.Channel[1].MyByteL);
                mybytes[i + 3] = ctc.MyByteR;//(byte)(ctc.Channel[0].MyByteR + ctc.Channel[1].MyByteR);
            }
            //    mybytes[i + 1] = (byte)(ctc.Channel[0].polarity * ctc.Channel[0].LeftVol * ctc.Channel[0].Sample);  // Left H Byte
            //    mybytes[i + 3] = (byte)(ctc.Channel[0].polarity * ctc.Channel[0].RightVol * ctc.Channel[0].Sample);  // Right H Byte
            //            ctc.testfreqTime++;

            //            if (ctc.testfreqTime > ctc.testfreq)
            //            {
            //                ctc.PlaySamples += ctc.testfreqTime;
            //                while (ctc.PlaySamples > ctc.PlaySamplesPerTick) {
            //                    ctc.PlaySamples -= ctc.PlaySamplesPerTick;
                                
            //                        ctc.tick++;
            //                }
            //                ctc.Channel[0].polarity = -ctc.Channel[0].polarity;
            //                ctc.testfreqTime = 0;
                            
            //            }
            //}
            return mybytes;
        }


        private void button2_Click(object sender, EventArgs e)
        {
            ctc.Restart();
            PlaySound(new Guid("DEF00000-9C6D-47ED-AAF1-4DDA8F2B5C03"));
            timerSong.Enabled=true;
            timerUI.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
         //   songtick++;
         //   if (songtick >= 50) { 
           //     songtick=0;
                ctc.UpdateSong(ref mysong);
   
           // }




            
            // ctc.Channel[1].setfrequency(VbX.Hex2Dec(textBox1.Text));
 //           ctc.Channel[1].setfrequency(ctc.getoctive(VbX.Hex2Dec(textBox1.Text)));
            // ctc.Channel[1].setnoise(true);
   //         ctc.Channel[0].setvolume(0);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ctc.Stop();
            timerSong.Enabled = false;
            timerUI.Enabled = false;
        }


        private void button7_Click(object sender, EventArgs e)
        {

            ctc.Restart();
            PlaySound(new Guid("DEF00000-9C6D-47ED-AAF1-4DDA8F2B5C03"));
            timerSong.Enabled = true;
            timerUI.Enabled = true;
        }

        private void timerUI_Tick(object sender, EventArgs e)
        {
            // label1.Text = ctc.TicksOccurred.ToString() + VbX.nl();
            lblPatternchannels2.Text = "  |" + ctc.Channel[0].txtStatus().PadRight(ChannelLabelWidth) + "|";
            lblPatternchannels2.Text += ctc.Channel[1].txtStatus().PadRight(ChannelLabelWidth) + "|";
            lblPatternchannels2.Text += ctc.Channel[2].txtStatus().PadRight(ChannelLabelWidth) + "|";


            lblPatternchannels3.Text = "  |" + ctc.Channel[0].txtStatus2().PadRight(ChannelLabelWidth) + "|";
            lblPatternchannels3.Text += ctc.Channel[1].txtStatus2().PadRight(ChannelLabelWidth) + "|";
            lblPatternchannels3.Text += ctc.Channel[2].txtStatus2().PadRight(ChannelLabelWidth) + "|";

            if (ctc.shownewpattern || SelectedSeq != mysong.SongSequencePos) {
                ctc.shownewpattern = false;
                SelectedSeq = mysong.SongSequencePos;
                lstSequence.SelectedIndex = mysong.SongSequencePos;
                UpdateSequenceView();
                updatepatternview();
            }
            
            if (ctc.shownewpatternline) {
                lstPattern.SelectedIndex = ctc.PatternPos;
                ctc.shownewpatternline = false;
            }
        }

        private void UpdateInstrumentView()
        {
            int c = 0;
            for (int i = 0; i < 32; i++)
            {
                if (SelectedIns == i)
                {
                    lstInstruments.Items[i] = (VbX.Dec2Hex8bit(i) + " ►" + mysong.InstrumentName[i]).PadRight(16) + "◄";
                }
                else
                {
                    lstInstruments.Items[i]=(VbX.Dec2Hex8bit(i) + "  " + mysong.InstrumentName[i]).PadRight(10)+" ";
                }
            }
        }


        private void UpdateSequenceView()
        {
            bool done = false;
            int c = 0;
            while (!done)
            {
                string thisstring= VbX.Dec2Hex8bit(c) + " ";
                for (int ch = 0; ch < 3; ch++)
                {
                    if (SelectedChn == ch && SelectedSeq==c)
                    {
                        thisstring += "►" + mysong.Sequence[ch, c].ToString().PadLeft(3) + "◄";
                    } else {
                        thisstring += " " + mysong.Sequence[ch, c].ToString().PadLeft(3) + " ";
                    }
                }
                lstSequence.Items[c] = thisstring;
                if (mysong.Sequence[0, c] == 255) done = true;
                c++;

            }

        }
        private void updatepatternview() {
            bool done = false;

            int ssp = SelectedSeq;
            if (ssp < 0) ssp = 0;


            lblPatternchannels.Text = "  |";
            lblColumntTitles.Text = "  |";
            string[,] PatternText = new string[3, 64];

            for (int channel = 0; channel < 3; channel++)
            {
                lblColumntTitles.Text += " In [Note]  Vol Pch".PadRight(20) + "|";
                int sq = mysong.Sequence[channel,ssp];

                lblPatternchannels.Text += ("   Chn:" + channel.ToString() + "  Seq:" + sq.ToString()).PadRight(20) + "|";

                int lin = 0; done = false;
                int len = 1;
                int txtlin = 0;
                while (!done)
                {
                    PatternText[channel, txtlin] = ".. .. ...  ... ...";
                    string thisline = "";

                    len--;
                    if (len <= 0)
                    {
                        len = mysong.Pattern[sq, lin, 0];
                        thisline = mysong.CommandsToText(mysong.Pattern, sq, lin, 1);
                        PatternText[channel, txtlin] = thisline;

                        if (mysong.Pattern[sq, lin, 0] == 0) done = true;
                        lin++;
                    }
                    if (SelectedChn == channel && SelectedLin == txtlin)
                    {
                        PatternText[channel, txtlin] = "►" + PatternText[channel, txtlin] + "◄";
                    }
                    else {
                        PatternText[channel, txtlin] = " " + PatternText[channel, txtlin] + " ";
                    }


                    txtlin++;
                }
            }

            for (int i = 0; i < 34; i++)
            {

                lstPattern.Items[i] = VbX.Dec2Hex8bit(i) + " " + (VbX.nz(PatternText[0, i]).PadRight(21) + VbX.nz(PatternText[1, i]).PadRight(21) + VbX.nz(PatternText[2, i]).PadRight(21));
            }
        }

        private void lstPattern_MouseClick(object sender, MouseEventArgs e)
        {
            SelectedLin = lstPattern.SelectedIndex;
            SelectedChn = (e.X-20) / 145;
            
            updatepatternview();
        }

        private void lstSequence_MouseClick(object sender, MouseEventArgs e)
        {
            SelectedSeq = lstSequence.SelectedIndex;
            SelectedChn = (e.X - 20) / 35;
            //label1.Text = e.X.ToString() + "-" + e.Y.ToString();
            UpdateSequenceView();
            updatepatternview();
        }

        private void lstInstruments_MouseClick(object sender, MouseEventArgs e)
        {
            SelectedIns = lstInstruments.SelectedIndex;
            UpdateInstrumentView();
            UpdateInstrument();
        }
        private void UpdateInstrument(){
            txtInstrument.Text=mysong.InstrumentName[SelectedIns];
            lblInstrument.Text = "Instrument " + SelectedIns.ToString();
            lstInstrument.Items.Clear();
            bool done=false;
            int lin=0;
            int len = 0;
            while (!done){
                len = mysong.instrument[SelectedIns, lin, 0];
                string thisline = len.ToString().PadRight(4)+mysong.CommandsToText(mysong.instrument, SelectedIns, lin, 0);
                lstInstrument.Items.Add( thisline);

                if (mysong.instrument[SelectedIns, lin, 0] == 0) done = true;
                lin++;
            }
            

        }

    }
}
