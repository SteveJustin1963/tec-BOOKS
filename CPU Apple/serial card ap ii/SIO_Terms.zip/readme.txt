Three terminal programs precompiled for use with the Klein-Baker SIO daughter board attachment
to the PCPI Applicard:
- MEX
- IMP
- QTerm

Overlays are also included should you need to make changes.

Note: The Klein-Baker SIO uses a clock of 1.84320 MHz making the CTC settings for baud rates
different than the traditional SABA Klein SIO card which used a clock of 3 MHz.