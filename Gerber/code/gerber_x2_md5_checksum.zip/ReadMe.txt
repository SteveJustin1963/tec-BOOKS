To add/update the md5 checksum of a Gerber X2 file:

- Open a command window (Windows menu > Run > cmd)
- Type <path to perl executable> <path to GerberX2_md5.pl> <path to Gerber file> and press Enter key
- See generated result message (MD5 can be correct / missing / incorrect)
- If correct: You can check the next file
- If missing or incorrect: 
    -- Select and copy to the clipboard 2 generated lines (calculated MD5 and MO2*)
    -- Open the Gerber file using a plain text editor like Notepad
    -- Move to the end of the text and replace (when incorrect) or append (when missing) 2 lines from the clipboard.
    -- Save the file (keep the original file name and extension)
